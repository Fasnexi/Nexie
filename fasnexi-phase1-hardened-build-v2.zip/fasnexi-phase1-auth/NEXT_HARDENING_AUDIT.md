# FasNexi Phase 1 — Repository-Wide Hardening Audit

## Baseline
- Expo: 54.0.0
- React Native: ~0.81.5
- React: 19.1.0
- React Native Web: 0.21.0
- Node: 20.19.4 (`.nvmrc`, `.node-version`, `package.json.engines`)

## Verification performed
- Enumerated backend API routes and frontend API endpoint modules.
- Searched frontend/backend source for stale broken/no-op/placeholder messaging.
- Confirmed all TypeScript source files pass a structural delimiter smoke check.
- Reviewed checkout and webhook flow end-to-end.
- Reviewed cart persistence and checkout clearing behavior.
- Reviewed auth/session wiring and settings sign-out.
- Reviewed promotion UI for stale backend-bug messaging.
- Confirmed Phase 0 Prisma migration is present.

## Fixes made in this pass

### 1. Stripe product webhook idempotency
`backend/packages/api/src/checkout/stripe.ts`
- Added preflight lookup by unique `checkoutSessionId`.
- Added a transaction-time re-check for concurrent webhook deliveries.
- Existing database unique constraint remains the final race guard.
- This prevents duplicate order side effects on Stripe redelivery.

### 2. Stripe inventory atomicity
`backend/packages/api/src/checkout/stripe.ts`
- Removed the non-transactional `decrementInventory()` call from the Stripe order transaction.
- Inventory is now decremented through the transaction client with an `inventoryCount >= quantity` guard.
- `isInStock` is turned off when inventory reaches zero.
- This keeps order creation and inventory decrement in the same transaction.

### 3. Promotions UI stale warning
`frontend/app/(tabs)/profile/dashboards/promotions.tsx`
- Removed the obsolete message claiming promotion creation was permanently broken.
- Generic user-facing failure now tells the user to retry instead of describing an already-fixed schema defect.

### 4. Real sign-out action
`frontend/app/(tabs)/profile/settings.tsx`
- Replaced the disabled/stub sign-out presentation with a real Better Auth `signOut()` call.
- Added a user-facing failure alert.

### 5. Documentation/comments cleanup
- Removed stale auth-layout wording that claimed auth screens were not built.
- Removed obsolete API-client documentation claiming the backend had not adopted structured error fields.
- Removed obsolete video comment about unverified Expo AV API usage from the current source audit notes.

## Important existing hardening retained
- Persistent cart via AsyncStorage.
- Cart remains intact through failed/cancelled checkout.
- Single-currency cart enforcement.
- Product checkout validates product currency against checkout currency.
- Order lookup by checkout session.
- Currency-separated creator earnings.
- Quantity-aware and currency-separated vendor revenue.
- Promotion total + daily budget enforcement.
- Structured 4xx errors for the previously inconsistent routes.
- Search and event/ticket surfaces.
- Ticket Stripe completion and expired-reservation handling.

## Remaining release gate
The supplied repository does not include installed dependencies/node_modules. Therefore this sandbox cannot truthfully certify:
- `npm install`
- `npx expo-doctor`
- TypeScript compilation against installed packages
- Metro bundling
- iOS native compilation
- Android native compilation
- EAS build
- physical-device QA

Run these in the development environment:

```bash
nvm use
npm install
npx expo install --fix
npx expo-doctor
npm run typecheck
npx expo start
```

Then run iOS/Android device smoke tests and an EAS preview build.

## Next release-readiness work
1. Install dependencies and execute the real Expo/TypeScript checks.
2. Fix any SDK-54 dependency/type/native issues discovered by those checks.
3. Run backend Prisma generation/migrations and the backend test suite against the real database.
4. Execute full payment webhook integration tests.
5. Perform safe-area/edge-to-edge review on physical iOS and Android devices.
6. Configure and execute EAS preview build.
7. Run complete regression journeys: auth, onboarding, marketplace, search, cart, checkout, orders, promotions, events/tickets, resale, tailor, wardrobe, Nexi, notifications.
