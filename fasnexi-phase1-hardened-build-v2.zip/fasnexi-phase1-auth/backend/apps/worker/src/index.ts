// =============================================================================
// FASNEXI — WORKER APP ENTRY POINT
// apps/worker/src/index.ts
//
// Background job processor running as a separate Fly.io app (fasnexi-worker-*).
// Registers BullMQ Workers for all queues defined in packages/api/src/queue.
//
// Queue processors registered here:
//   nexi-vision     — Claude Vision garment tagging
//   feed-ranking    — async Post.rankScore update
//   notifications   — Expo push notifications
//   moderation      — AI content screening
//   trade-matching  — FSE order book (Phase 7 placeholder)
//   challenges-cron — advance challenge statuses (repeatable job)
//
// Each Worker runs in its own concurrency slot. nexi-vision is capped at 3
// concurrent jobs to control Claude API parallelism and cost per minute.
// =============================================================================

import { Worker, type Job } from "bullmq";
import type {
  FeedRankingJobData,
  NexiVisionJobData,
  NotificationJobData,
  ModerationJobData,
} from "@fasnexi/api/queue";

const REDIS_CONFIG = {
  host: process.env.REDIS_URL
    ? new URL(process.env.REDIS_URL).hostname
    : "localhost",
  port: process.env.REDIS_URL
    ? parseInt(new URL(process.env.REDIS_URL).port || "6379")
    : 6379,
  password: process.env.REDIS_URL
    ? new URL(process.env.REDIS_URL).password || undefined
    : undefined,
  tls: process.env.REDIS_URL?.startsWith("rediss://") ? {} : undefined,
};

// ---------------------------------------------------------------------------
// NEXI VISION WORKER — Claude Vision garment tagging
// Concurrency 3: balances throughput vs Claude API rate limits
// ---------------------------------------------------------------------------
const nexiVisionWorker = new Worker<NexiVisionJobData>(
  "nexi-vision",
  async (job: Job<NexiVisionJobData>) => {
    const { tagGarment } = await import("@fasnexi/api/wardrobe/tagger");
    const { analyseWardrobeGaps } = await import("@fasnexi/api/gaps/analyser");

    const { wardrobeItemId, imageUrl, userId } = job.data;

    console.log(`[nexi-vision] Tagging wardrobe item ${wardrobeItemId}`);
    const tags = await tagGarment(wardrobeItemId, imageUrl);
    console.log(
      `[nexi-vision] Tagged ${wardrobeItemId}: ${tags.category} confidence=${tags.confidence.toFixed(2)}`,
    );

    // After tagging completes, re-run gap analysis to pick up the new item
    // (rate-limited to 1/24h inside analyseWardrobeGaps itself)
    await analyseWardrobeGaps(userId);
  },
  {
    connection: REDIS_CONFIG,
    concurrency: 3,
    limiter: {
      max: 10,
      duration: 60_000, // max 10 vision calls per minute across all workers
    },
  },
);

nexiVisionWorker.on("completed", (job) => {
  console.log(`[nexi-vision] Job ${job.id} completed`);
});

nexiVisionWorker.on("failed", (job, err) => {
  console.error(`[nexi-vision] Job ${job?.id} failed:`, err.message);
});

// ---------------------------------------------------------------------------
// FEED RANKING WORKER — recomputes Post.rankScore after engagement events
// High concurrency (10) since these are lightweight DB updates
// ---------------------------------------------------------------------------
const feedRankingWorker = new Worker<FeedRankingJobData>(
  "feed-ranking",
  async (job: Job<FeedRankingJobData>) => {
    const { updatePostRankScore } = await import("@fasnexi/api/feed/ranking");
    await updatePostRankScore(job.data.postId);
  },
  {
    connection: REDIS_CONFIG,
    concurrency: 10,
  },
);

feedRankingWorker.on("failed", (job, err) => {
  console.error(`[feed-ranking] Job ${job?.id} failed:`, err.message);
});

// ---------------------------------------------------------------------------
// NOTIFICATIONS WORKER — Expo Push Notification Service
//
// GAP FIX: this previously wrote the in-app Notification row and left push
// delivery as a "TODO Phase 5" stub. Push-token registration now exists
// (POST /api/push-tokens, packages/api/src/notifications/push.ts), so this
// dispatches for real. In-app notification write happens FIRST and
// unconditionally — push delivery is best-effort on top of it, never a
// dependency for it. A push failure (dead token, Expo outage) must not lose
// the in-app notification, which is why dispatchPushToUser() never throws.
// ---------------------------------------------------------------------------
const notificationsWorker = new Worker<NotificationJobData>(
  "notifications",
  async (job: Job<NotificationJobData>) => {
    const { recipientId, type, data } = job.data;

    const { db } = await import("@fasnexi/db");
    const { createNotificationFromJob } = await import("@fasnexi/api/notifications/service");
    const { dispatchPushToUser, notificationToPushCopy } = await import("@fasnexi/api/notifications/push");

    const user = await db.user.findUnique({
      where: { id: recipientId },
      select: { id: true },
    });
    if (!user) return;

    // In-app notification centre write — unconditional, this is the
    // authoritative record regardless of whether push delivery succeeds.
    await createNotificationFromJob({ recipientId, type, data });

    // Best-effort push on top. Never throws — see push.ts.
    const copy = notificationToPushCopy(type, data);
    const result = await dispatchPushToUser(recipientId, {
      title: copy.title,
      body: copy.body,
      data: { type, ...data },
    });

    console.log(
      `[notifications] ${type} for ${recipientId}: in-app saved, push ${result.sent}/${result.attempted} sent` +
      (result.invalidTokensRemoved > 0 ? ` (${result.invalidTokensRemoved} dead tokens removed)` : ""),
    );
  },
  {
    connection: REDIS_CONFIG,
    concurrency: 20,
  },
);

notificationsWorker.on("failed", (job, err) => {
  console.error(`[notifications] Job ${job?.id} failed:`, err.message);
});

// ---------------------------------------------------------------------------
// MODERATION WORKER — Phase 6 full implementation
// Phase 3 stub: logs the job, defers to manual review queue
// ---------------------------------------------------------------------------
const moderationWorker = new Worker<ModerationJobData>(
  "moderation",
  async (job: Job<ModerationJobData>) => {
    console.log(`[moderation] Received screening job for post ${job.data.postId}`);
    // Phase 6: AWS Rekognition + OpenAI Moderation API + human review queue
  },
  {
    connection: REDIS_CONFIG,
    concurrency: 5,
  },
);

// ---------------------------------------------------------------------------
// CHALLENGES CRON — advance challenge statuses (UPCOMING→ACTIVE→VOTING→COMPLETED)
// Registered as a repeatable job so it runs every minute automatically.
// ---------------------------------------------------------------------------
import { challengeStatusQueue } from "./challengesCron";
challengeStatusQueue; // import registers the repeatable job

// ---------------------------------------------------------------------------
// GRACEFUL SHUTDOWN
// ---------------------------------------------------------------------------
const workers = [nexiVisionWorker, feedRankingWorker, notificationsWorker, moderationWorker];

async function shutdown() {
  console.log("[worker] Shutting down gracefully...");
  await Promise.all(workers.map(w => w.close()));
  console.log("[worker] All workers closed");
  process.exit(0);
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

console.log("[worker] FasNexi worker started — listening on queues: nexi-vision, feed-ranking, notifications, moderation");
