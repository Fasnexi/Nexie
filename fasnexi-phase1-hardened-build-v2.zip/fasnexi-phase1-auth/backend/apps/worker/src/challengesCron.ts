// apps/worker/src/challengesCron.ts
// Registers a BullMQ repeatable job that advances challenge statuses every minute.
// Imported by index.ts which triggers registration as a side effect.

import { Queue, Worker } from "bullmq";

const REDIS_CONFIG = {
  host: process.env.REDIS_URL ? new URL(process.env.REDIS_URL).hostname : "localhost",
  port: process.env.REDIS_URL ? parseInt(new URL(process.env.REDIS_URL).port || "6379") : 6379,
  password: process.env.REDIS_URL ? new URL(process.env.REDIS_URL).password || undefined : undefined,
  tls: process.env.REDIS_URL?.startsWith("rediss://") ? {} : undefined,
};

export const challengeStatusQueue = new Queue("challenges-cron", {
  connection: REDIS_CONFIG,
});

// Register the repeatable job (idempotent — BullMQ deduplicates by key)
challengeStatusQueue.add(
  "advance-statuses",
  {},
  {
    repeat: { cron: "* * * * *" }, // every minute
    jobId: "challenges-status-advance", // deduplicate key
    removeOnComplete: { count: 5 },
    removeOnFail: { count: 20 },
  },
);

const challengesCronWorker = new Worker(
  "challenges-cron",
  async () => {
    const { advanceChallengeStatuses } = await import("@fasnexi/api/challenges/service");
    await advanceChallengeStatuses();
  },
  { connection: REDIS_CONFIG, concurrency: 1 },
);

challengesCronWorker.on("failed", (_job, err) => {
  console.error("[challenges-cron] Failed:", err.message);
});

export default challengesCronWorker;
