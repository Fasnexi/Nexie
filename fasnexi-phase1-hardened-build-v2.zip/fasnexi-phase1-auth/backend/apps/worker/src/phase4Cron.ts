// =============================================================================
// FASNEXI — PHASE 4 WORKER CRON JOBS
// apps/worker/src/phase4Cron.ts
//
// Registers three repeatable BullMQ jobs, following the exact pattern
// established in Phase 2's challengesCron.ts (Queue + repeatable job +
// dedicated Worker, deduplicated by jobId):
//
//   weekly-payouts     — every Monday 03:00 UTC, batches CONFIRMED
//                         commissions per creator into payout batches
//   daily-fx-refresh   — every day 02:00 UTC, refreshes the FX rate cache
//   expire-promotions  — every 15 minutes, deactivates promoted listings
//                         past their endDate (belt-and-suspenders to the
//                         inline check in billImpressions)
// =============================================================================

import { Queue, Worker } from "bullmq";

const REDIS_CONFIG = {
  host: process.env.REDIS_URL ? new URL(process.env.REDIS_URL).hostname : "localhost",
  port: process.env.REDIS_URL ? parseInt(new URL(process.env.REDIS_URL).port || "6379") : 6379,
  password: process.env.REDIS_URL ? new URL(process.env.REDIS_URL).password || undefined : undefined,
  tls: process.env.REDIS_URL?.startsWith("rediss://") ? {} : undefined,
};

export const phase4CronQueue = new Queue("phase4-cron", { connection: REDIS_CONFIG });

// Register repeatable jobs — idempotent via jobId, safe to re-register on
// every worker boot (BullMQ deduplicates the repeat schedule by key).
phase4CronQueue.add("weekly-payouts", {}, {
  repeat: { cron: "0 3 * * 1" }, // Monday 03:00 UTC
  jobId: "phase4-weekly-payouts",
  removeOnComplete: { count: 10 },
  removeOnFail: { count: 20 },
});

phase4CronQueue.add("daily-fx-refresh", {}, {
  repeat: { cron: "0 2 * * *" }, // daily 02:00 UTC
  jobId: "phase4-daily-fx-refresh",
  removeOnComplete: { count: 10 },
  removeOnFail: { count: 20 },
});

phase4CronQueue.add("expire-promotions", {}, {
  repeat: { cron: "*/15 * * * *" }, // every 15 minutes
  jobId: "phase4-expire-promotions",
  removeOnComplete: { count: 5 },
  removeOnFail: { count: 20 },
});

const phase4CronWorker = new Worker(
  "phase4-cron",
  async job => {
    switch (job.name) {
      case "weekly-payouts": {
        const { db } = await import("@fasnexi/db");
        const { runCreatorPayout, submitPayoutBatchToStripe } = await import("@fasnexi/api/payouts/service");

        // Find all creators with at least one CONFIRMED commission
        const creatorsWithConfirmed = await db.creatorCommission.findMany({
          where: { status: "CONFIRMED" },
          distinct: ["creatorId"],
          select: { creatorId: true },
        });

        let batched = 0, submitted = 0, skipped = 0;
        for (const { creatorId } of creatorsWithConfirmed) {
          const batch = await runCreatorPayout(creatorId);
          if (!batch) { skipped++; continue; }
          batched++;

          const creator = await db.creatorProfile.findUnique({
            where: { id: creatorId },
            select: { stripeConnectId: true, payoutEnabled: true },
          });
          if (creator?.payoutEnabled && creator.stripeConnectId) {
            await submitPayoutBatchToStripe(batch.batchId, creator.stripeConnectId);
            submitted++;
          }
          // else: batch stays PENDING — surfaced in an admin queue for
          // creators who haven't completed Stripe Connect onboarding yet.
        }

        console.log(`[phase4-cron] weekly-payouts: ${batched} batched, ${submitted} submitted, ${skipped} below threshold`);
        break;
      }

      case "daily-fx-refresh": {
        const { refreshAllRates } = await import("@fasnexi/api/fx/service");
        const result = await refreshAllRates();
        console.log(`[phase4-cron] daily-fx-refresh: ${result.updated} updated, ${result.failed} failed`);
        break;
      }

      case "expire-promotions": {
        const { db } = await import("@fasnexi/db");
        const result = await db.promotedProduct.updateMany({
          where: { isActive: true, endDate: { lt: new Date() } },
          data: { isActive: false },
        });
        if (result.count > 0) {
          console.log(`[phase4-cron] expire-promotions: deactivated ${result.count} expired campaigns`);
        }
        break;
      }
    }
  },
  { connection: REDIS_CONFIG, concurrency: 1 },
);

phase4CronWorker.on("failed", (job, err) => {
  console.error(`[phase4-cron] ${job?.name} failed:`, err.message);
});

export default phase4CronWorker;
