// apps/web/app/api/tickets/[id]/purchase/route.ts
// POST /api/tickets/:id/purchase — :id is a TicketTier id
// Reserves capacity atomically, then creates a Stripe checkout session.
// Mirrors the resale purchase route's reserve-then-checkout pattern.

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { reserveTicket, releaseTicketReservation } from "@fasnexi/api/events/ticketing";
import { db } from "@fasnexi/db";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();

  const reservation = await reserveTicket(params.id, user.id);
  if (!reservation.reserved) {
    return Response.json({ error: "This ticket tier is sold out" }, { status: 409 });
  }

  const tier = await db.ticketTier.findUniqueOrThrow({
    where: { id: params.id },
    include: { event: { select: { title: true } } },
  });

  const origin = request.headers.get("origin") ?? "https://fasnexi.com";

  try {
    const Stripe = (await import("stripe")).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [{
        price_data: {
          currency: tier.currency.toLowerCase(),
          product_data: { name: `${tier.event.title} — ${tier.name}` },
          unit_amount: tier.priceAmount,
        },
        quantity: 1,
      }],
      success_url: `${origin}/tickets/success?ticketId=${reservation.ticketId}`,
      cancel_url: `${origin}/events/${tier.eventId}`,
      metadata: { ticketId: reservation.ticketId!, kind: "ticket" },
    });

    await db.ticket.update({ where: { id: reservation.ticketId! }, data: { paymentRef: session.id } });
    return Response.json({ url: session.url, sessionId: session.id, ticketId: reservation.ticketId });
  } catch (err) {
    // Checkout session creation failed — release the reservation so the
    // capacity isn't held indefinitely by an abandoned attempt.
    await releaseTicketReservation(reservation.ticketId!);
    throw err;
  }
});
