// apps/web/app/api/tickets/scan/route.ts
// POST /api/tickets/scan — door scanner validates a QR code
// GET  /api/tickets — user's own ticket list

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { validateTicketScan, getUserTickets } from "@fasnexi/api/events/ticketing";

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "EVENT_ORGANIZER");

  const { qrPayload } = await request.json();
  if (!qrPayload) return Response.json({ error: "qrPayload is required" }, { status: 400 });

  const result = await validateTicketScan(qrPayload, user.id);
  return Response.json(result, { status: result.valid ? 200 : 400 });
});
