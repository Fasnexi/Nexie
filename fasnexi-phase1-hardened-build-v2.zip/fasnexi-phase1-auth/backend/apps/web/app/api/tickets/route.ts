// apps/web/app/api/tickets/route.ts
// GET /api/tickets — current user's ticket history

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getUserTickets } from "@fasnexi/api/events/ticketing";

export const GET = withErrorHandling(async (_request: Request) => {
  const user = await requireUser();
  const tickets = await getUserTickets(user.id);
  return Response.json({ tickets });
});
