// apps/web/app/api/feed/route.ts
// GET /api/feed?cursor=&limit=
// Returns paginated, Style DNA-weighted feed for the authenticated user.

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getPersonalisedFeed } from "@fasnexi/api/feed/ranking";
import { enqueueFeedRankUpdate } from "@fasnexi/api/queue";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { searchParams } = new URL(request.url);

  const feed = await getPersonalisedFeed({
    userId: user.id,
    cursor: searchParams.get("cursor") ?? undefined,
    limit: Math.min(parseInt(searchParams.get("limit") ?? "20"), 50),
  });

  return Response.json({ posts: feed, count: feed.length });
});

// POST /api/feed/event — record an engagement event and trigger async re-rank
export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { postId, event } = await request.json();

  if (!postId || !event) {
    return Response.json({ error: "postId and event are required" }, { status: 400 });
  }

  const validEvents = ["like", "comment", "share", "save", "view"] as const;
  if (!validEvents.includes(event)) {
    return Response.json({ error: `event must be one of: ${validEvents.join(", ")}` }, { status: 400 });
  }

  // Increment the denormalized count on Post (cheap, in-request)
  const countField: Record<string, string> = {
    like: "likeCount", comment: "commentCount",
    share: "shareCount", save: "saveCount", view: "viewCount",
  };
  await import("@fasnexi/db").then(({ db }) =>
    db.post.update({
      where: { id: postId },
      data: { [countField[event]]: { increment: 1 } },
    }),
  );

  // Enqueue async rank score recomputation (BullMQ, non-blocking)
  await enqueueFeedRankUpdate(postId, event);

  return Response.json({ ok: true });
});
