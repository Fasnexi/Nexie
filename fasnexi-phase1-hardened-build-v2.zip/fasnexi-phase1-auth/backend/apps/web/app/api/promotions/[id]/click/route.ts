// apps/web/app/api/promotions/[id]/click/route.ts
// POST /api/promotions/:id/click — record a click on a promoted product card
// No auth required — clicks can come from any feed viewer, tracked by promo id only.
// IP-rate-limited: this write is cheap and unauthenticated, so without a
// limit it's a free way to inflate a vendor's click stats or hammer the DB.

import { recordClick } from "@fasnexi/api/promotions/service";
import { atomicRateLimit } from "@fasnexi/api/redis";

const CLICK_LIMIT = 60;       // per IP
const CLICK_WINDOW_SECONDS = 60;

function clientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  return forwarded?.split(",")[0]?.trim() || request.headers.get("cf-connecting-ip") || "unknown";
}

export const POST = async (
  request: Request,
  { params }: { params: { id: string } },
): Promise<Response> => {
  try {
    const { allowed } = await atomicRateLimit({
      key: `promo-click:${clientIp(request)}`,
      limit: CLICK_LIMIT,
      ttlSeconds: CLICK_WINDOW_SECONDS,
    });
    if (!allowed) {
      return Response.json({ recorded: false }, { status: 429 });
    }
    await recordClick(params.id);
    return Response.json({ recorded: true });
  } catch {
    // Non-critical — never fail the user's navigation over a tracking write
    return Response.json({ recorded: false });
  }
};
