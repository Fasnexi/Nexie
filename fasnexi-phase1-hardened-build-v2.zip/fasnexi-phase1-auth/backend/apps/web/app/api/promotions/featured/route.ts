import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getActivePromotions } from "@fasnexi/api/promotions/service";

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  const parsed = Number(searchParams.get("limit") ?? "6");
  const limit = Number.isFinite(parsed) ? Math.min(Math.max(Math.trunc(parsed), 1), 12) : 6;
  const promotions = await getActivePromotions(limit);
  return Response.json({ promotions });
});
