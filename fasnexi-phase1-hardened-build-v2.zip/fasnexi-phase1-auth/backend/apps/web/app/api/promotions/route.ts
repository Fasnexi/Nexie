// apps/web/app/api/promotions/route.ts
// GET  /api/promotions — vendor's own campaign dashboard
// POST /api/promotions — create a new promoted listing campaign

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { createPromotedListing, getVendorPromotions } from "@fasnexi/api/promotions/service";

export const GET = withErrorHandling(async (_request: Request) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "VENDOR");
  const promotions = await getVendorPromotions(user.id);
  return Response.json({ promotions });
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "VENDOR");

  const body = await request.json();
  const { productId, budgetAmount, dailyBudget, cpmAmount, currency, startDate, endDate } = body;

  if (typeof productId !== "string" || !productId ||
      !Number.isInteger(budgetAmount) || budgetAmount <= 0 ||
      !Number.isInteger(dailyBudget) || dailyBudget <= 0 ||
      !Number.isInteger(cpmAmount) || cpmAmount <= 0 ||
      typeof currency !== "string" || !currency ||
      typeof startDate !== "string" || typeof endDate !== "string") {
    return Response.json({ error: "Invalid promotion payload", code: "VALIDATION_ERROR" }, { status: 400 });
  }

  const start = new Date(startDate);
  const end = new Date(endDate);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    return Response.json({ error: "startDate and endDate must be valid ISO dates", code: "VALIDATION_ERROR" }, { status: 400 });
  }

  try {
    const promo = await createPromotedListing({
      productId,
      vendorUserId: user.id,
      budgetAmount,
      dailyBudget,
      cpmAmount,
      currency,
      startDate: start,
      endDate: end,
    });
    return Response.json({ promotion: promo }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("do not own") || err.message?.includes("must be after") || err.message?.includes("cannot exceed") || err.message?.includes("must be positive") || err.message?.includes("does not match product currency")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
