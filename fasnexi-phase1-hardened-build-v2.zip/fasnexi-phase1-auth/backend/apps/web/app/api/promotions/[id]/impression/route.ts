import { withErrorHandling, requireUser, BadRequestError } from "@fasnexi/auth/middleware/guards";
import { billImpressions } from "@fasnexi/api/promotions/service";

export const POST = withErrorHandling(async (request: Request, { params }: { params: { id: string } }) => {
  await requireUser();
  const body = await request.json().catch(() => ({}));
  const count = Number(body?.count ?? 1);
  if (!Number.isInteger(count) || count < 1 || count > 20) {
    throw new BadRequestError("count must be an integer between 1 and 20", { count: "Invalid impression count" });
  }
  const result = await billImpressions(params.id, count);
  return Response.json(result);
});
