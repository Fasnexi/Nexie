// apps/web/app/api/loyalty/route.ts
// GET /api/loyalty              — account summary (tier, points, next tier)
// GET /api/loyalty?view=history — transaction history
// POST /api/loyalty             — redeem points  body: { points, reason }

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getLoyaltyAccount, getLoyaltyHistory, redeemPoints } from "@fasnexi/api/loyalty/service";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { searchParams } = new URL(request.url);

  if (searchParams.get("view") === "history") {
    return Response.json(
      await getLoyaltyHistory(
        user.id,
        searchParams.get("cursor") ?? undefined,
        Math.min(parseInt(searchParams.get("limit") ?? "30"), 100),
      ),
    );
  }

  return Response.json(await getLoyaltyAccount(user.id));
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { points, reason } = await request.json();

  if (typeof points !== "number" || points <= 0) {
    return Response.json({ error: "points must be a positive number" }, { status: 400 });
  }

  try {
    const result = await redeemPoints(user.id, points, reason ?? "Redemption");
    return Response.json(result);
  } catch (err: any) {
    if (err.message?.includes("Insufficient points")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
