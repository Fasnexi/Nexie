// apps/web/app/api/push-tokens/route.ts
// POST /api/push-tokens — register (or re-register) this device for push
// body: { expoToken, platform?: "ios"|"android"|"web", deviceName? }
//
// GAP FIX: no endpoint existed for the frontend's Expo Notifications client
// to hand off a push token. See packages/api/src/notifications/push.ts for
// the registration logic and dispatch side.

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { registerDeviceToken, type DevicePlatform } from "@fasnexi/api/notifications/push";

const VALID_PLATFORMS = new Set(["ios", "android", "web", "unknown"]);

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { expoToken, platform, deviceName } = await request.json();

  if (!expoToken || typeof expoToken !== "string") {
    return Response.json({ error: "expoToken is required" }, { status: 400 });
  }

  if (platform && !VALID_PLATFORMS.has(platform)) {
    return Response.json(
      { error: `platform must be one of: ${[...VALID_PLATFORMS].join(", ")}` },
      { status: 400 },
    );
  }

  try {
    const result = await registerDeviceToken({
      userId: user.id,
      expoToken,
      platform: platform as DevicePlatform | undefined,
      deviceName: deviceName ?? undefined,
    });
    return Response.json({ registered: true, id: result.id }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("valid Expo push token")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
