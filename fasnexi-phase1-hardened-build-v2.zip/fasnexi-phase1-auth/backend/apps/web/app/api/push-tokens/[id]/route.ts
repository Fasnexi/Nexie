// apps/web/app/api/push-tokens/[id]/route.ts
// DELETE /api/push-tokens/:id — unregister this device (call on sign-out /
// notification permission revoke so a signed-out device stops receiving push)

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { unregisterDeviceToken } from "@fasnexi/api/notifications/push";

export const DELETE = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  const result = await unregisterDeviceToken(params.id, user.id);

  if (!result.deleted) {
    return Response.json({ error: "Device token not found" }, { status: 404 });
  }

  return new Response(null, { status: 204 });
});
