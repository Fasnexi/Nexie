// apps/web/app/api/auth/[...all]/route.ts
// Single catch-all for all Better Auth endpoints including
// the custom /roles/* endpoints from multiRolePlugin.
import { auth } from "@fasnexi/auth";
import { toNextJsHandler } from "better-auth/next-js";
export const { GET, POST } = toNextJsHandler(auth);
