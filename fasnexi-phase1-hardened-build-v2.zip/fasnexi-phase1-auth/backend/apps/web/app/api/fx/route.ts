// apps/web/app/api/fx/route.ts
// GET /api/fx?amount=3000&from=USD&to=NGN — display-only conversion

import { withErrorHandling } from "@fasnexi/auth/middleware/guards";
import { convertForDisplay } from "@fasnexi/api/fx/service";
import type { Currency } from "@prisma/client";

export const GET = withErrorHandling(async (request: Request) => {
  const { searchParams } = new URL(request.url);
  const amount = parseInt(searchParams.get("amount") ?? "");
  const from = searchParams.get("from") as Currency;
  const to = searchParams.get("to") as Currency;

  if (isNaN(amount) || !from || !to) {
    return Response.json({ error: "amount, from, and to query params are required" }, { status: 400 });
  }

  const result = await convertForDisplay(amount, from, to);
  return Response.json(result);
});
