import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { db } from "@fasnexi/db";

const LIMIT = 8;
const MAX_QUERY = 80;

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") ?? "").trim();
  const type = searchParams.get("type") ?? "all";
  const limit = Math.min(Math.max(Number(searchParams.get("limit") ?? LIMIT), 1), 20);

  if (q.length < 2) {
    return Response.json({ query: q, products: [], vendors: [], creators: [], users: [], events: [], categories: [] });
  }
  if (q.length > MAX_QUERY) {
    return Response.json({ error: `Search query must be ${MAX_QUERY} characters or fewer`, code: "INVALID_QUERY" }, { status: 400 });
  }

  const contains = { contains: q, mode: "insensitive" as const };
  const include = new Set(type === "all" ? ["products", "vendors", "creators", "users", "events", "categories"] : type.split(","));

  const [products, vendors, creators, users, events] = await Promise.all([
    include.has("products") ? db.product.findMany({
      where: { isPublished: true, OR: [{ name: contains }, { brand: contains }, { description: contains }, { slug: contains }, { subcategory: contains }] },
      select: { id: true, name: true, slug: true, imageUrls: true, priceAmount: true, priceCurrency: true, category: true, isInStock: true, vendor: { select: { id: true, businessName: true } } },
      orderBy: [{ salesCount: "desc" }, { createdAt: "desc" }], take: limit,
    }) : [],
    include.has("vendors") ? db.vendorProfile.findMany({
      where: { OR: [{ businessName: contains }, { description: contains }, { country: contains }] },
      select: { id: true, businessName: true, logoUrl: true, country: true, isVerified: true },
      orderBy: [{ isVerified: "desc" }, { createdAt: "desc" }], take: limit,
    }) : [],
    include.has("creators") ? db.creatorProfile.findMany({
      where: { OR: [{ bio: contains }, { culturalFocus: { has: q } }, { user: { displayName: contains } }, { user: { username: contains } }] },
      select: { id: true, bannerUrl: true, followerCount: true, user: { select: { id: true, username: true, displayName: true, avatarUrl: true } } },
      orderBy: [{ followerCount: "desc" }, { createdAt: "desc" }], take: limit,
    }) : [],
    include.has("users") ? db.user.findMany({
      where: { isBanned: false, OR: [{ username: contains }, { displayName: contains }] },
      select: { id: true, username: true, displayName: true, avatarUrl: true },
      orderBy: { createdAt: "desc" }, take: limit,
    }) : [],
    include.has("events") ? db.event.findMany({
      where: { isPublished: true, OR: [{ title: contains }, { description: contains }, { venue: contains }, { city: contains }, { country: contains }] },
      select: { id: true, title: true, description: true, coverUrl: true, venue: true, city: true, country: true, startDate: true, endDate: true, isLive: true, organizer: { select: { orgName: true } } },
      orderBy: { startDate: "asc" }, take: limit,
    }) : [],
  ]);

  const categories = include.has("categories") ? Array.from(new Set(
    products.map((p) => p.category),
  )).slice(0, limit) : [];

  return Response.json({ query: q, products, vendors, creators, users, events, categories });
});
