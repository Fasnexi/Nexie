import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getStyleProfile, upsertStyleProfile } from "@fasnexi/api/style-profile/service";
import { z } from "zod";

const enumOf = (values: string[]) => z.enum(values as [string, ...string[]]);
const styleDnaSchema = z.object({
  archetype: z.object({ primaryArchetype: enumOf(["MODERN_MINIMALIST","AFROCENTRIC_MAXIMALIST","STREET_STYLE_FUSION","TRADITIONAL_CONTEMPORARY","AVANT_GARDE","EVERYDAY_ELEGANCE"]), secondaryArchetype: enumOf(["MODERN_MINIMALIST","AFROCENTRIC_MAXIMALIST","STREET_STYLE_FUSION","TRADITIONAL_CONTEMPORARY","AVANT_GARDE","EVERYDAY_ELEGANCE"]).optional() }).optional(),
  bodyProfile: z.object({ bodyShape: enumOf(["HOURGLASS","PEAR","APPLE","RECTANGLE","INVERTED_TRIANGLE"]).optional(), fitPreferences: z.array(enumOf(["FITTED","RELAXED","OVERSIZED","TAILORED","FLOWY"])).optional(), sizeTopUS: z.string().max(32).optional(), sizeBottomUS: z.string().max(32).optional(), sizeShoeUS: z.string().max(32).optional(), coveragePreferences: z.array(enumOf(["MINIMAL","MODERATE","FULL","FLEXIBLE"])).optional() }).optional(),
  lifestyle: z.object({ primaryOccasions: z.array(enumOf(["WORK","CASUAL","SOCIAL","RELIGIOUS","CULTURAL_EVENT","WEDDING","FORMAL","SPORT","TRAVEL"])).optional(), climateZone: enumOf(["TROPICAL","SEMI_ARID","ARID","HUMID","TEMPERATE"]).optional(), activityLevel: enumOf(["LOW","MODERATE","HIGH"]).optional(), preferredColors: z.array(z.string().regex(/^#[0-9a-fA-F]{6}$/)).optional(), avoidedColors: z.array(z.string().regex(/^#[0-9a-fA-F]{6}$/)).optional(), seasonalPreference: enumOf(["ALL_YEAR","DRY","WET","HARMATTAN","SPRING","SUMMER","AUTUMN","WINTER"]).optional() }).optional(),
}).strict();

export const GET = withErrorHandling(async () => {
  const user = await requireUser();
  return Response.json({ profile: await getStyleProfile(user.id) });
});

export const PUT = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const parsed = styleDnaSchema.safeParse(await request.json());
  if (!parsed.success) return Response.json({ error: "Invalid Style DNA payload", code: "VALIDATION_ERROR", fields: parsed.error.flatten().fieldErrors }, { status: 400 });
  const profile = await upsertStyleProfile(user.id, parsed.data);
  return Response.json({ profile });
});
