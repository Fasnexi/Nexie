// apps/web/app/api/gaps/route.ts
// GET  /api/gaps — return current gap recommendations
// POST /api/gaps — trigger fresh gap analysis (rate limited to 1/24h)

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { analyseWardrobeGaps, getExistingGaps } from "@fasnexi/api/gaps/analyser";

export const GET = withErrorHandling(async (_request: Request) => {
  const user = await requireUser();
  const gaps = await getExistingGaps(user.id);
  return Response.json({ gaps, count: gaps.length });
});

export const POST = withErrorHandling(async (_request: Request) => {
  const user = await requireUser();

  const result = await analyseWardrobeGaps(user.id);

  return Response.json({
    gaps: result.gaps,
    wellCoveredOccasions: result.wellCoveredOccasions,
    analysedAt: result.analysedAt,
    count: result.gaps.length,
  });
});
