// apps/web/app/api/notifications/route.ts
// GET   /api/notifications?cursor=&limit=&unreadOnly=  — list (+ unreadCount)
// PATCH /api/notifications  body: { action: "mark_all_read" }

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getNotifications, markAllNotificationsRead } from "@fasnexi/api/notifications/service";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { searchParams } = new URL(request.url);

  const result = await getNotifications(user.id, {
    cursor: searchParams.get("cursor") ?? undefined,
    limit: Math.min(parseInt(searchParams.get("limit") ?? "30"), 100),
    unreadOnly: searchParams.get("unreadOnly") === "true",
  });

  return Response.json(result);
});

export const PATCH = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { action } = await request.json();

  if (action !== "mark_all_read") {
    return Response.json({ error: "action must be 'mark_all_read'" }, { status: 400 });
  }

  const result = await markAllNotificationsRead(user.id);
  return Response.json(result);
});
