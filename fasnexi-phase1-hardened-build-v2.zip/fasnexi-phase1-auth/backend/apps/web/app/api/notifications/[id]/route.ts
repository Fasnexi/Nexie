// apps/web/app/api/notifications/[id]/route.ts
// PATCH /api/notifications/:id  body: { action: "mark_read" }

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { markNotificationRead } from "@fasnexi/api/notifications/service";

export const PATCH = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  const { action } = await request.json();

  if (action !== "mark_read") {
    return Response.json({ error: "action must be 'mark_read'" }, { status: 400 });
  }

  const result = await markNotificationRead(params.id, user.id);
  if (!result.updated) {
    return Response.json({ error: "Notification not found" }, { status: 404 });
  }

  return Response.json({ updated: true });
});
