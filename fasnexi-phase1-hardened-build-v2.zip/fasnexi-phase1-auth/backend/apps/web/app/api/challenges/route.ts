// apps/web/app/api/challenges/route.ts
// GET /api/challenges?status=ACTIVE|UPCOMING|VOTING|COMPLETED&cursor=

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { listChallenges } from "@fasnexi/api/challenges/service";

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  return Response.json(
    await listChallenges({
      status: searchParams.get("status") ?? undefined,
      cursor: searchParams.get("cursor") ?? undefined,
      limit: Math.min(parseInt(searchParams.get("limit") ?? "20"), 50),
    }),
  );
});
