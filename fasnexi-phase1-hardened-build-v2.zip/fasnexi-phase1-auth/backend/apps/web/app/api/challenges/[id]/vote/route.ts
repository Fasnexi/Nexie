// apps/web/app/api/challenges/[id]/vote/route.ts
// POST /api/challenges/:id/vote  body: { entryId }

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { voteForEntry } from "@fasnexi/api/challenges/service";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  const { entryId } = await request.json();
  if (!entryId) return Response.json({ error: "entryId required" }, { status: 400 });

  try {
    const result = await voteForEntry(params.id, entryId, user.id);
    return Response.json(result);
  } catch (err: any) {
    if (err.message?.includes("not found")) return Response.json({ error: err.message, code: "NOT_FOUND" }, { status: 404 });
    if (err.message?.includes("already voted") || err.message?.includes("closed") || err.message?.includes("not eligible")) return Response.json({ error: err.message, code: "CONFLICT" }, { status: 409 });
    throw err;
  }
});
