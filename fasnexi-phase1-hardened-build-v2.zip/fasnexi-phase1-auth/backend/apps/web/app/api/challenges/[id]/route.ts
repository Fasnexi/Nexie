// apps/web/app/api/challenges/[id]/route.ts
// GET /api/challenges/:id

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getChallenge } from "@fasnexi/api/challenges/service";

export const GET = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  await requireUser();
  const challenge = await getChallenge(params.id);
  if (!challenge) return Response.json({ error: "Challenge not found" }, { status: 404 });
  return Response.json({ challenge });
});
