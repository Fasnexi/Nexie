// apps/web/app/api/challenges/[id]/entries/route.ts
// POST /api/challenges/:id/entries — submit entry

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { submitChallengeEntry } from "@fasnexi/api/challenges/service";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  const { caption, mediaUrls, culturalTags } = await request.json();

  if (!Array.isArray(mediaUrls) || mediaUrls.length === 0) {
    return Response.json({ error: "At least one media URL is required" }, { status: 400 });
  }

  const entry = await submitChallengeEntry({
    challengeId: params.id,
    userId: user.id,
    caption: caption ?? "",
    mediaUrls,
    culturalTags,
  });

  return Response.json({ entry }, { status: 201 });
});
