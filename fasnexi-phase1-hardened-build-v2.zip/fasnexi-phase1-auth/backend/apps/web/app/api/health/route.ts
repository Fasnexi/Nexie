// apps/web/app/api/health/route.ts
// GET /api/health — checked by Fly.io (every 10s) and CI blue/green deploy.
// Returns 200 { status: "ok" } when the app + DB + Redis are all healthy.
// Used by deploy-production.yml health-check job (6 consecutive passes required
// before Cloudflare traffic cut-over).

import { db } from "@fasnexi/db";

export const dynamic = "force-dynamic";

// DB sub-health
export async function GET(request: Request) {
  const { pathname } = new URL(request.url);

  // /api/health/db — checked by deploy job separately
  if (pathname.endsWith("/db")) {
    try {
      await db.$queryRaw`SELECT 1`;
      return Response.json({ status: "ok" });
    } catch {
      return Response.json({ status: "error", detail: "db unreachable" }, { status: 503 });
    }
  }

  // /api/health/redis
  if (pathname.endsWith("/redis")) {
    try {
      const { createClient } = await import("redis");
      const client = createClient({ url: process.env.REDIS_URL });
      await client.connect();
      await client.ping();
      await client.disconnect();
      return Response.json({ status: "ok" });
    } catch {
      return Response.json({ status: "error", detail: "redis unreachable" }, { status: 503 });
    }
  }

  // Root /api/health — quick composite check
  let dbOk = false;
  try {
    await db.$queryRaw`SELECT 1`;
    dbOk = true;
  } catch { /* fall through — health response still returns */ }

  const instance = process.env.INSTANCE_COLOR ?? "unknown";
  const version  = process.env.npm_package_version ?? "unknown";

  if (!dbOk) {
    return Response.json(
      { status: "degraded", instance, version, db: "error" },
      { status: 503 },
    );
  }

  return Response.json({
    status: "ok",
    instance,  // "blue" | "green" — checked by deploy-production.yml cut-traffic step
    version,
    db: "ok",
    timestamp: new Date().toISOString(),
  });
}
