// apps/web/app/api/resale/route.ts
// GET  /api/resale — browse listings
// POST /api/resale — create a listing from a wardrobe item

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import { browseResaleListings, createResaleListing } from "@fasnexi/api/resale/service";
import type { ResaleCondition } from "@prisma/client";

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);

  const result = await browseResaleListings({
    condition: (searchParams.get("condition") as ResaleCondition) ?? undefined,
    maxPrice: searchParams.has("maxPrice") ? parseInt(searchParams.get("maxPrice")!) : undefined,
    cursor: searchParams.get("cursor") ?? undefined,
    limit: Math.min(parseInt(searchParams.get("limit") ?? "24"), 100),
  });

  return Response.json(result);
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requirePermission(user, "resale_item", "create");

  const { wardrobeItemId, askingPrice, currency, condition, description } = await request.json();

  if (!wardrobeItemId || typeof askingPrice !== "number" || askingPrice <= 0 || !currency || !condition) {
    return Response.json(
      { error: "wardrobeItemId, askingPrice (positive number), currency, and condition are required" },
      { status: 400 },
    );
  }

  try {
    const listing = await createResaleListing({
      wardrobeItemId, sellerId: user.id, askingPrice, currency, condition, description,
    });
    return Response.json({ listing }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("do not own") || err.message?.includes("already has an active") || err.message?.includes("archived")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
