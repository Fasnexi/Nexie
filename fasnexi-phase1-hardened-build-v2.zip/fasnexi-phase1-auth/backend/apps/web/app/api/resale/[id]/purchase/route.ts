// apps/web/app/api/resale/[id]/purchase/route.ts
// POST /api/resale/:id/purchase — reserve listing (atomic), then start checkout
//
// Two-step flow: reserveListing() atomically claims the item so no other
// buyer can purchase it concurrently, THEN a checkout session is created.
// If checkout is abandoned, a scheduled job calls releaseReservation()
// after a timeout (not shown — mirrors resale/service.ts's release path).

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { reserveListing } from "@fasnexi/api/resale/service";
import { db } from "@fasnexi/db";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();

  let reservation;
  try {
    reservation = await reserveListing(params.id, user.id);
  } catch (err: any) {
    if (err.message?.includes("Cannot purchase your own")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }

  if (!reservation.reserved) {
    return Response.json(
      { error: "This item is no longer available — it may have just been purchased by someone else" },
      { status: 409 },
    );
  }

  const listing = await db.resaleItem.findUniqueOrThrow({
    where: { id: params.id },
    select: { askingPrice: true, currency: true, wardrobeItem: { select: { imageUrl: true, category: true } } },
  });

  const origin = request.headers.get("origin") ?? "https://fasnexi.com";

  // Build a checkout session for the resale item — reuses the same
  // createCheckoutSession machinery conceptually, but resale items aren't
  // Products, so this constructs a minimal one-off Stripe session directly.
  // (Full gateway routing mirrors packages/api/src/checkout/stripe.ts.)
  const Stripe = (await import("stripe")).default;
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [{
      price_data: {
        currency: listing.currency.toLowerCase(),
        product_data: {
          name: `Resale: ${listing.wardrobeItem.category}`,
          images: [listing.wardrobeItem.imageUrl],
        },
        unit_amount: listing.askingPrice,
      },
      quantity: 1,
    }],
    success_url: `${origin}/resale/success?resaleItemId=${params.id}`,
    cancel_url: `${origin}/resale/${params.id}`,
    metadata: { resaleItemId: params.id, buyerId: user.id, kind: "resale" },
  });

  return Response.json({ url: session.url, sessionId: session.id });
});
