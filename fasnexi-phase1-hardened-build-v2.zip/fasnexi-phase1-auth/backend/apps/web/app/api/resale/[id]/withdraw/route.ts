// apps/web/app/api/resale/[id]/withdraw/route.ts
// POST /api/resale/:id/withdraw — seller cancels their own listing

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import { withdrawListing } from "@fasnexi/api/resale/service";
import { db } from "@fasnexi/db";

export const POST = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();

  const listing = await db.resaleItem.findUnique({
    where: { id: params.id },
    select: { sellerId: true },
  });
  if (!listing) return Response.json({ error: "Listing not found" }, { status: 404 });

  await requirePermission(user, "resale_item", "update", { isOwner: listing.sellerId === user.id });

  try {
    await withdrawListing(params.id, user.id);
    return Response.json({ withdrawn: true });
  } catch (err: any) {
    return Response.json({ error: err.message }, { status: 400 });
  }
});
