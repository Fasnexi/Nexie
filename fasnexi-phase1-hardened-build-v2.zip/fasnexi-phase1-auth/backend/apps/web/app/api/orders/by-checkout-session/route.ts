import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getConsumerOrderByCheckoutSession } from "@fasnexi/api/orders/storefront";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const sessionId = new URL(request.url).searchParams.get("sessionId");
  if (!sessionId) return Response.json({ error: "sessionId is required", code: "VALIDATION_ERROR" }, { status: 400 });
  const order = await getConsumerOrderByCheckoutSession(user.id, sessionId);
  if (!order) return Response.json({ error: "Order not found", code: "NOT_FOUND" }, { status: 404 });
  return Response.json({ order });
});
