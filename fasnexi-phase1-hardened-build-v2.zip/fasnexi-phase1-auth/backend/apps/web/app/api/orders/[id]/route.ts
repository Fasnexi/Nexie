import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getConsumerOrder } from "@fasnexi/api/orders/storefront";

export const GET = withErrorHandling(async (_request: Request, { params }: { params: { id: string } }) => {
  const user = await requireUser();
  const order = await getConsumerOrder(user.id, params.id);
  if (!order) return Response.json({ error: "Order not found", code: "NOT_FOUND" }, { status: 404 });
  return Response.json({ order });
});
