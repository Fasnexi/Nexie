import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getConsumerOrders } from "@fasnexi/api/orders/storefront";
import type { OrderStatus } from "@prisma/client";

const statuses = new Set(["PENDING","PAYMENT_PROCESSING","PAID","FULFILLING","SHIPPED","DELIVERED","CANCELLED","REFUNDED","DISPUTED"]);
export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const params = new URL(request.url).searchParams;
  const rawStatus = params.get("status") ?? undefined;
  if (rawStatus && !statuses.has(rawStatus)) return Response.json({ error: "Invalid order status", code: "VALIDATION_ERROR" }, { status: 400 });
  const limitRaw = params.get("limit");
  const limit = limitRaw ? Number(limitRaw) : undefined;
  if (limit !== undefined && (!Number.isInteger(limit) || limit < 1 || limit > 50)) return Response.json({ error: "limit must be an integer between 1 and 50", code: "VALIDATION_ERROR" }, { status: 400 });
  return Response.json(await getConsumerOrders(user.id, { status: rawStatus as OrderStatus | undefined, cursor: params.get("cursor") ?? undefined, limit }));
});
