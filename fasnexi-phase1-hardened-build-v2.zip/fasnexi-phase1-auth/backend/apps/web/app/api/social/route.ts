// apps/web/app/api/social/route.ts
// GET /api/social?action=followers|following|relationship&userId=&cursor=

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getFollowers, getFollowing, getRelationship } from "@fasnexi/api/social/graph";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { searchParams } = new URL(request.url);
  const action = searchParams.get("action");
  const targetId = searchParams.get("userId") ?? user.id;
  const cursor = searchParams.get("cursor") ?? undefined;
  const limit = Math.min(parseInt(searchParams.get("limit") ?? "30"), 100);

  if (action === "relationship") {
    return Response.json(await getRelationship(user.id, targetId));
  }
  if (action === "followers") {
    return Response.json(await getFollowers(targetId, cursor, limit));
  }
  return Response.json(await getFollowing(targetId, cursor, limit));
});
