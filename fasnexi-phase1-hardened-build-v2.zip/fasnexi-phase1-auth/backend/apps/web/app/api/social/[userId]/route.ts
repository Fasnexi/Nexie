// apps/web/app/api/social/[userId]/route.ts
// POST /api/social/:userId  body: { action: "follow" | "unfollow" }

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { followUser, unfollowUser } from "@fasnexi/api/social/graph";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { userId: string } },
) => {
  const user = await requireUser();
  const { action } = await request.json();

  if (action === "unfollow") {
    return Response.json(await unfollowUser(user.id, params.userId));
  }
  return Response.json(await followUser(user.id, params.userId));
});
