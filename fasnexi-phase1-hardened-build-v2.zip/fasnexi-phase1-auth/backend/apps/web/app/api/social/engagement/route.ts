// apps/web/app/api/social/engagement/route.ts
// POST /api/social/engagement — like, save, comment, delete_comment
// GET  /api/social/engagement?postId=&cursor= — list comments

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import {
  toggleLike, toggleSave, createComment, deleteComment, getComments,
} from "@fasnexi/api/social/engagement";

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const body = await request.json();
  const { action, postId, commentId, body: commentBody, parentId } = body;

  switch (action) {
    case "like":
      return Response.json(await toggleLike(user.id, postId));
    case "save":
      return Response.json(await toggleSave(user.id, postId));
    case "comment":
      return Response.json(
        await createComment({ userId: user.id, postId, body: commentBody, parentId }),
      );
    case "delete_comment":
      await deleteComment(commentId, user.id);
      return Response.json({ deleted: true });
    default:
      return Response.json({ error: "Unknown action" }, { status: 400 });
  }
});

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  const postId = searchParams.get("postId");
  if (!postId) return Response.json({ error: "postId required" }, { status: 400 });

  return Response.json(
    await getComments(
      postId,
      searchParams.get("cursor") ?? undefined,
      Math.min(parseInt(searchParams.get("limit") ?? "20"), 50),
    ),
  );
});
