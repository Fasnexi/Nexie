// apps/web/app/api/creators/[handle]/route.ts
// GET /api/creators/:handle — public storefront page

import { withErrorHandling } from "@fasnexi/auth/middleware/guards";
import { getStorefront } from "@fasnexi/api/creators/storefront";

export const GET = withErrorHandling(async (
  _request: Request,
  { params }: { params: { handle: string } },
) => {
  const storefront = await getStorefront(params.handle);
  if (!storefront) return Response.json({ error: "Creator not found" }, { status: 404 });
  return Response.json({ storefront });
});
