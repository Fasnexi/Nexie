// apps/web/app/api/creators/route.ts
// GET  /api/creators — list top creators
// POST /api/creators — update own creator profile

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import {
  getTopCreators, updateCreatorProfile, getCreatorProfile,
} from "@fasnexi/api/creators/storefront";

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  const limit = Math.min(parseInt(searchParams.get("limit") ?? "10"), 50);
  return Response.json(await getTopCreators(limit));
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requirePermission(user, "creator_profile", "update", { isOwner: true });
  const body = await request.json();
  const profile = await updateCreatorProfile(user.id, body);
  return Response.json({ profile });
});
