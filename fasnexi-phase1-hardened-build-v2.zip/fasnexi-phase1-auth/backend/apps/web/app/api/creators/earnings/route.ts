// apps/web/app/api/creators/earnings/route.ts
// GET /api/creators/earnings?period=week|month|all

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import { getCreatorEarnings } from "@fasnexi/api/creators/storefront";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requirePermission(user, "creator_commission", "read", { isOwner: true });

  const { searchParams } = new URL(request.url);
  const period = (searchParams.get("period") ?? "month") as "week" | "month" | "all";

  return Response.json(await getCreatorEarnings(user.id, period));
});
