// apps/web/app/api/uploads/sign/route.ts
// POST /api/uploads/sign  body: { folder: "wardrobe" | "posts" | "video" | "avatars" }
//
// GAP FIX: nothing authorized direct-to-Cloudinary uploads before this.
// Frontend flow: POST here → get {signature, timestamp, apiKey, cloudName,
// folder} → POST the file directly to
// https://api.cloudinary.com/v1_1/{cloudName}/auto/upload with those fields
// (+ the file itself) → Cloudinary returns a secure_url → POST that url to
// /api/wardrobe or /api/video as imageUrl/videoUrl.

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { generateUploadSignature, type UploadFolder } from "@fasnexi/api/uploads/cloudinary";

const VALID_FOLDERS = new Set(["wardrobe", "posts", "video", "avatars"]);

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { folder } = await request.json();

  if (!folder || !VALID_FOLDERS.has(folder)) {
    return Response.json(
      { error: `folder is required and must be one of: ${[...VALID_FOLDERS].join(", ")}` },
      { status: 400 },
    );
  }

  try {
    const result = generateUploadSignature({ userId: user.id, folder: folder as UploadFolder });
    return Response.json(result);
  } catch (err: any) {
    if (err.message?.includes("not configured")) {
      // Distinguish ops misconfiguration (500, alertable) from a bad request (400)
      console.error("[uploads/sign] Cloudinary env vars missing:", err.message);
      return Response.json({ error: "Uploads are temporarily unavailable" }, { status: 503 });
    }
    throw err;
  }
});
