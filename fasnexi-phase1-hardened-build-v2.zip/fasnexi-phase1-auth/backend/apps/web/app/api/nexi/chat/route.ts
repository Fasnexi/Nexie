// =============================================================================
// FASNEXI — NEXI CHAT API ROUTE
// apps/web/app/api/nexi/chat/route.ts
//
// POST /api/nexi/chat
//
// Supports two response modes selected by the `stream` body field:
//   stream: true  → SSE stream (ReadableStream), for the chat UI
//   stream: false → JSON response, for programmatic callers
//
// SSE event format:
//   data: {"type":"session","sessionId":"..."}         — sent first
//   data: {"type":"delta","text":"..."}                — streamed chunks
//   data: {"type":"done","sessionId":"...","tokenCount":N}
//   data: {"type":"error","message":"..."}
//
// Rate limit headers are included in every response:
//   X-Nexi-Remaining: N    — queries remaining today
// =============================================================================

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { runNexiChat, streamNexiChat } from "@fasnexi/api/nexi/engine";

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();

  const body = await request.json();
  const {
    query,
    sessionId,
    occasion,
    season,
    stream: useStream = true,
  } = body;

  if (!query || typeof query !== "string" || query.trim().length === 0) {
    return Response.json({ error: "query is required and must be a non-empty string" }, { status: 400 });
  }

  if (query.length > 2000) {
    return Response.json({ error: "query exceeds 2000 character limit" }, { status: 400 });
  }

  const req = {
    userId: user.id,
    sessionId: sessionId ?? undefined,
    query: query.trim(),
    occasion: occasion ?? undefined,
    season: season ?? undefined,
    mode: "chat" as const,
  };

  // Streaming path
  if (useStream) {
    try {
      // GAP FIX: remaining was always computed by streamNexiChat's rate-limit
      // check, but never returned to this route or set as a header — the
      // comment above documented X-Nexi-Remaining but the header was never
      // actually sent. It's known before the stream starts (the rate-limit
      // check happens up front), so it can go on the initial response headers.
      const { stream, sessionId: resolvedSessionId, remaining } = await streamNexiChat(req);

      return new Response(stream, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache, no-transform",
          "Connection": "keep-alive",
          "X-Accel-Buffering": "no", // disable Nginx buffering
          "X-Nexi-Session": resolvedSessionId,
          "X-Nexi-Remaining": String(remaining),
        },
      });
    } catch (err: any) {
      // Rate limit and other domain errors surface as 429 / 400
      if (err.message?.includes("limit")) {
        return Response.json({ error: err.message }, { status: 429 });
      }
      throw err;
    }
  }

  // Non-streaming path
  try {
    const result = await runNexiChat(req);
    // GAP FIX: result.remaining is already in the JSON body, but the header
    // comment at the top of this file promises it on "every response" — set
    // it here too so callers reading only headers (consistent with the
    // streaming path) don't need to special-case JSON mode.
    return Response.json(result, {
      headers: { "X-Nexi-Remaining": String(result.remaining) },
    });
  } catch (err: any) {
    if (err.message?.includes("limit")) {
      return Response.json({ error: err.message }, { status: 429 });
    }
    throw err;
  }
});
