// apps/web/app/api/nexi/outfit/route.ts
// POST /api/nexi/outfit
//
// Generates N outfit suggestions from the user's wardrobe.
// Mood-based: body { mood, occasion, count }
// Returns structured OutfitSuggestion[] JSON (not streamed — caller needs full response).

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { generateOutfits } from "@fasnexi/api/nexi/engine";

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();

  const body = await request.json();
  const { mood, occasion, season, count = 2, sessionId } = body;

  if (!mood && !occasion) {
    return Response.json(
      { error: "Provide at least one of: mood, occasion" },
      { status: 400 },
    );
  }

  const outfitCount = Math.min(Math.max(parseInt(count) || 2, 1), 3);

  try {
    const result = await generateOutfits({
      userId: user.id,
      sessionId: sessionId ?? undefined,
      query: mood ?? "",
      occasion: occasion ?? undefined,
      season: season ?? undefined,
      mode: "outfit",
      outfitCount,
    });
    return Response.json(result);
  } catch (err: any) {
    if (err.message?.includes("limit")) {
      return Response.json({ error: err.message }, { status: 429 });
    }
    throw err;
  }
});
