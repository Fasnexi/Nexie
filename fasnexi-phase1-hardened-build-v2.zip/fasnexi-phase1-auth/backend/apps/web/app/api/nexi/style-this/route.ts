// apps/web/app/api/nexi/style-this/route.ts
// POST /api/nexi/style-this
// body: { wardrobeItemId, occasion?, count? }
//
// "Style This" flow: user taps a wardrobe item → Nexi generates outfit
// combinations using that item as the anchor piece, prioritising other
// owned items and flagging gaps for purchase.

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import { generateOutfits } from "@fasnexi/api/nexi/engine";
import { db } from "@fasnexi/db";

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requirePermission(user, "nexi_session", "create");

  const body = await request.json();
  const { wardrobeItemId, occasion, season, count = 2, sessionId } = body;

  if (!wardrobeItemId || typeof wardrobeItemId !== "string") {
    return Response.json({ error: "wardrobeItemId is required" }, { status: 400 });
  }

  // Verify item belongs to this user
  const item = await db.wardrobeItem.findFirst({
    where: { id: wardrobeItemId, userId: user.id, isArchived: false },
    select: { id: true, category: true, aiTagged: true },
  });

  if (!item) {
    return Response.json({ error: "Wardrobe item not found" }, { status: 404 });
  }

  if (!item.aiTagged) {
    return Response.json(
      { error: "This item is still being tagged by AI. Try again in a moment." },
      { status: 202 },
    );
  }

  const outfitCount = Math.min(Math.max(parseInt(count) || 2, 1), 3);

  try {
    const result = await generateOutfits({
      userId: user.id,
      sessionId: sessionId ?? undefined,
      query: "",
      occasion: occasion ?? undefined,
      season: season ?? undefined,
      mode: "style-this",
      baseItemId: wardrobeItemId,
      outfitCount,
    });
    return Response.json(result);
  } catch (err: any) {
    if (err.message?.includes("limit")) {
      return Response.json({ error: err.message }, { status: 429 });
    }
    throw err;
  }
});
