// apps/web/app/api/stories/route.ts
// GET  /api/stories  — story feed for authenticated user
// POST /api/stories  — create a new story

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getStoryFeed, createStory } from "@fasnexi/api/stories/service";

export const GET = withErrorHandling(async (_request: Request) => {
  const user = await requireUser();
  const feed = await getStoryFeed(user.id);
  return Response.json({ stories: feed });
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { mediaUrl, mediaType = "image", durationSeconds } = await request.json();

  if (!mediaUrl) return Response.json({ error: "mediaUrl required" }, { status: 400 });

  const story = await createStory({
    userId: user.id,
    mediaUrl,
    mediaType,
    durationSeconds,
  });

  return Response.json({ story }, { status: 201 });
});
