// apps/web/app/api/stories/[userId]/route.ts
// POST /api/stories/:userId  body: { storyId, action: "view" }

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { markStoryViewed } from "@fasnexi/api/stories/service";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { userId: string } },
) => {
  const user = await requireUser();
  const { storyId, action } = await request.json();

  if (action === "view" && storyId) {
    await markStoryViewed(storyId, user.id);
    return Response.json({ ok: true });
  }

  return Response.json({ error: "Unknown action or missing storyId" }, { status: 400 });
});
