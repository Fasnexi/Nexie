// apps/web/app/api/video/route.ts
// GET  /api/video — dedicated video feed
// POST /api/video — create a video post (after Cloudinary transcode completes)

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { createVideoPost, getVideoFeed } from "@fasnexi/api/video/service";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { searchParams } = new URL(request.url);
  return Response.json(
    await getVideoFeed(
      user.id,
      searchParams.get("cursor") ?? undefined,
      Math.min(parseInt(searchParams.get("limit") ?? "20"), 50),
    ),
  );
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { videoUrl, thumbnailUrl, durationSeconds, caption, culturalTags, taggedProductIds } = await request.json();

  if (!videoUrl || !thumbnailUrl || typeof durationSeconds !== "number") {
    return Response.json({ error: "videoUrl, thumbnailUrl, and durationSeconds are required" }, { status: 400 });
  }

  try {
    const post = await createVideoPost({
      userId: user.id, videoUrl, thumbnailUrl, durationSeconds, caption, culturalTags, taggedProductIds,
    });
    return Response.json({ post }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("exceeds maximum duration")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
