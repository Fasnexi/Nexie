// apps/web/app/api/tailor/route.ts
// GET  /api/tailor — browse verified tailors (filterable by specialty/city)
// POST /api/tailor — submit a custom order brief to a tailor

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { submitCustomOrderBrief } from "@fasnexi/api/tailor/service";
import { db } from "@fasnexi/db";

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  const city = searchParams.get("city");
  const specialty = searchParams.get("specialty");

  const tailors = await db.tailorProfile.findMany({
    where: {
      isVerified: true,
      isAvailable: true,
      ...(city && { city: { equals: city, mode: "insensitive" } }),
      ...(specialty && { specialties: { has: specialty as any } }),
    },
    orderBy: { ratingAvg: "desc" },
    take: 30,
    select: {
      id: true, businessName: true, country: true, city: true,
      specialties: true, portfolioUrls: true, ratingAvg: true,
      ratingCount: true, responseHours: true,
      user: { select: { username: true, displayName: true, avatarUrl: true } },
    },
  });

  return Response.json({ tailors });
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { tailorId, brief, attachments, deadline } = await request.json();

  if (!tailorId || !brief) {
    return Response.json({ error: "tailorId and brief are required" }, { status: 400 });
  }

  try {
    const parsedDeadline = deadline ? new Date(deadline) : undefined;
    if (parsedDeadline && Number.isNaN(parsedDeadline.getTime())) return Response.json({ error: "deadline must be a valid ISO date", code: "VALIDATION_ERROR" }, { status: 400 });
    const order = await submitCustomOrderBrief({
      tailorId,
      clientId: user.id,
      brief,
      attachments,
      deadline: parsedDeadline,
    });
    return Response.json({ order }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("not found") || err.message?.includes("not verified") || err.message?.includes("not currently accepting")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
