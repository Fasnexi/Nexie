// apps/web/app/api/tailor/[id]/quote/route.ts
// POST /api/tailor/:id/quote — tailor sets price for a custom order brief
// :id here is the CustomOrder id

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { provideQuote } from "@fasnexi/api/tailor/service";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "TAILOR");

  const { quoteAmount, currency, notes } = await request.json();
  if (typeof quoteAmount !== "number" || quoteAmount <= 0) {
    return Response.json({ error: "quoteAmount must be a positive number" }, { status: 400 });
  }
  if (!currency) {
    return Response.json({ error: "currency is required" }, { status: 400 });
  }

  try {
    const order = await provideQuote({
      customOrderId: params.id,
      tailorUserId: user.id,
      quoteAmount,
      currency,
      notes,
    });
    return Response.json({ order });
  } catch (err: any) {
    if (err.message?.includes("do not own")) {
      return Response.json({ error: err.message }, { status: 403 });
    }
    if (err.message?.includes("not found") || err.message?.includes("Cannot quote")) {
      return Response.json({ error: err.message }, { status: 400 });
    }
    throw err;
  }
});
