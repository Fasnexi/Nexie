// apps/web/app/api/tailor/[id]/deposit/route.ts
// POST /api/tailor/:id/deposit — client pays the deposit on a quoted
// CustomOrder. :id is the CustomOrder id.
//
// GAP FIX: the brief → quote → status/messaging flow all existed and
// worked, but nothing ever created a checkout session for the deposit
// amount once a tailor quoted — confirmDepositPaid() in tailor/service.ts
// was already written and waiting (comment: "called by checkout webhook
// handler") but had no caller anywhere. This route is the missing first
// half; the webhook branch below (payments.ts) is the second half.
//
// Pattern mirrors resale/[id]/purchase and tickets/[id]/purchase: build a
// one-off Stripe session directly (not the multi-gateway
// createCheckoutSession, which is Product/cart-shaped) with metadata that
// tells the webhook what to do on success.

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { db } from "@fasnexi/db";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();

  const order = await db.customOrder.findUnique({
    where: { id: params.id },
    select: {
      id: true,
      clientId: true,
      status: true,
      depositPaid: true,
      quoteAmount: true,
      currency: true,
      tailor: { select: { businessName: true } },
    },
  });

  if (!order) {
    return Response.json({ error: "Custom order not found" }, { status: 404 });
  }

  // Ownership: only the client who submitted the brief can pay its deposit —
  // same isOwner-from-DB pattern used throughout tailor/service.ts.
  if (order.clientId !== user.id) {
    return Response.json({ error: "This is not your custom order" }, { status: 403 });
  }

  if (order.depositPaid) {
    return Response.json({ error: "Deposit already paid for this order" }, { status: 409 });
  }

  if (order.status !== "PAYMENT_PROCESSING" || !order.quoteAmount) {
    return Response.json(
      { error: `This order isn't ready for deposit payment yet (status: ${order.status})` },
      { status: 400 },
    );
  }

  const origin = request.headers.get("origin") ?? "https://fasnexi.com";

  const Stripe = (await import("stripe")).default;
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [{
      price_data: {
        currency: order.currency.toLowerCase(),
        product_data: {
          name: `Custom order deposit — ${order.tailor.businessName ?? "Tailor"}`,
        },
        unit_amount: order.quoteAmount,
      },
      quantity: 1,
    }],
    success_url: `${origin}/tailor/orders/${order.id}?deposit=success`,
    cancel_url: `${origin}/tailor/orders/${order.id}`,
    // kind: "tailor_deposit" routes the webhook to confirmDepositPaid()
    // instead of the default product-order parsing — see payments.ts.
    metadata: { customOrderId: order.id, kind: "tailor_deposit" },
  });

  return Response.json({ url: session.url, sessionId: session.id });
});
