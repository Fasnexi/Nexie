// apps/web/app/api/tailor/[id]/messages/route.ts
// GET  /api/tailor/:id/messages — fetch conversation thread for a custom order
// POST /api/tailor/:id/messages — send a message in the thread

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getCustomOrderMessages, sendCustomOrderMessage } from "@fasnexi/api/tailor/service";

export const GET = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  try {
    const messages = await getCustomOrderMessages(params.id, user.id);
    return Response.json({ messages });
  } catch (err: any) {
    if (err.message?.includes("not a participant")) {
      return Response.json({ error: err.message }, { status: 403 });
    }
    if (err.message?.includes("not found")) {
      return Response.json({ error: err.message }, { status: 404 });
    }
    throw err;
  }
});

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  const { body, mediaUrl } = await request.json();

  if (!body || typeof body !== "string" || body.trim().length === 0) {
    return Response.json({ error: "body is required" }, { status: 400 });
  }

  try {
    const message = await sendCustomOrderMessage({
      customOrderId: params.id,
      senderId: user.id,
      body: body.trim(),
      mediaUrl,
    });
    return Response.json({ message }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("not a participant")) {
      return Response.json({ error: err.message }, { status: 403 });
    }
    if (err.message?.includes("not found")) {
      return Response.json({ error: err.message }, { status: 404 });
    }
    throw err;
  }
});
