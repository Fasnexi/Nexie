// apps/web/app/api/tailor/orders/route.ts
// GET /api/tailor/orders — role-aware: TAILOR sees their queue, else client history

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { getTailorOrders, getClientCustomOrders } from "@fasnexi/api/tailor/service";

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const { searchParams } = new URL(request.url);

  if (user.activeRole === "TAILOR") {
    const status = searchParams.get("status") as any;
    const orders = await getTailorOrders(user.id, status ?? undefined);
    return Response.json({ orders });
  }

  const orders = await getClientCustomOrders(user.id);
  return Response.json({ orders });
});
