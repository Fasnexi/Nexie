// apps/web/app/api/tailor/[id]/status/route.ts
// PATCH /api/tailor/:id/status — advance custom order FSM

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { updateCustomOrderStatus } from "@fasnexi/api/tailor/service";

const VALID_NEXT = new Set(["FULFILLING", "SHIPPED", "DELIVERED", "CANCELLED"]);

export const PATCH = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "TAILOR");

  const { status } = await request.json();
  if (!VALID_NEXT.has(status)) {
    return Response.json({ error: `status must be one of: ${[...VALID_NEXT].join(", ")}` }, { status: 400 });
  }

  try {
    const order = await updateCustomOrderStatus(params.id, user.id, status);
    return Response.json({ order });
  } catch (err: any) {
    if (err.message?.includes("do not own")) return Response.json({ error: err.message, code: "FORBIDDEN" }, { status: 403 });
    if (err.message?.includes("not found")) return Response.json({ error: err.message, code: "NOT_FOUND" }, { status: 404 });
    if (err.message?.includes("Cannot transition")) return Response.json({ error: err.message, code: "CONFLICT" }, { status: 409 });
    throw err;
  }
});
