// apps/web/app/api/checkout/callback/paystack/route.ts
// POST /api/checkout/callback/paystack
//
// Paystack webhooks arrive with a x-paystack-signature HMAC-SHA512 header.
// This route verifies the signature, then routes into the SAME idempotent
// processPaymentWebhookIdempotent() used by the Stripe path (Phase 1 +
// hardening pass) — the ProcessedWebhookEvent(provider, eventId) unique
// constraint covers Paystack the same way it covers Stripe, just with
// provider="paystack" so the two gateways' event IDs never collide.

import crypto from "crypto";
import { processPaymentWebhookIdempotent } from "@fasnexi/api/financial/payments";

export const POST = async (request: Request): Promise<Response> => {
  const rawBody = await request.text();
  const signature = request.headers.get("x-paystack-signature");

  if (!signature) {
    return Response.json({ error: "Missing x-paystack-signature header" }, { status: 400 });
  }

  const expectedSignature = crypto
    .createHmac("sha512", process.env.PAYSTACK_SECRET_KEY!)
    .update(rawBody)
    .digest("hex");

  // Constant-time comparison — plain !== leaks timing info about how many
  // leading characters matched, which is avoidable for a security check.
  const signatureBuf = Buffer.from(signature, "utf8");
  const expectedBuf = Buffer.from(expectedSignature, "utf8");
  const signatureValid =
    signatureBuf.length === expectedBuf.length &&
    crypto.timingSafeEqual(signatureBuf, expectedBuf);

  if (!signatureValid) {
    return Response.json({ error: "Invalid signature" }, { status: 400 });
  }

  const event = JSON.parse(rawBody);

  if (event.event !== "charge.success") {
    return Response.json({ received: true, ignored: event.event });
  }

  const data = event.data;

  try {
    const result = await processPaymentWebhookIdempotent({
      provider: "paystack",
      eventId: `paystack-${data.id}`, // Paystack transaction id is stable & unique
      eventType: "checkout.session.completed",
      paymentIntent: {
        id: data.reference,
        amount: data.amount, // already in kobo/smallest unit
        currency: data.currency.toUpperCase(),
        status: "succeeded",
        metadata: data.metadata ?? {},
      },
    });

    return Response.json({ received: true, orderId: result.orderId, alreadyProcessed: result.alreadyProcessed });
  } catch (err: any) {
    console.error("Paystack webhook processing error:", err);
    // 500 → Paystack will retry; safe because processPaymentWebhookIdempotent
    // is idempotent on (provider, eventId)
    return Response.json({ error: "Processing failed" }, { status: 500 });
  }
};

export const config = {
  api: { bodyParser: false },
};
