// apps/web/app/api/checkout/webhook/route.ts
// POST /api/checkout/webhook
//
// Stripe webhooks arrive with raw body — Next.js must NOT parse JSON here.
// The export config disables body parsing so we can verify the Stripe signature
// against the raw buffer and construct the event securely.
//
// This route handles:
//   checkout.session.completed → create Order, decrement inventory,
//                                  attribute commissions, award loyalty points
//
// Paystack and Flutterwave callbacks are handled at /api/checkout/callback/[gateway]
// (separate route, same pattern — signature verification then order creation).

import { handleCheckoutComplete } from "@fasnexi/api/checkout/stripe";

export const POST = async (request: Request): Promise<Response> => {
  const rawBody = Buffer.from(await request.arrayBuffer());
  const signature = request.headers.get("stripe-signature");

  if (!signature) {
    return Response.json({ error: "Missing stripe-signature header" }, { status: 400 });
  }

  try {
    await handleCheckoutComplete(rawBody, signature);
    return Response.json({ received: true });
  } catch (err: any) {
    // Stripe retries on non-2xx. Log and return 400 for signature failures,
    // 500 for genuine processing errors (Stripe will retry those).
    if (err.message?.includes("signature")) {
      console.error("Webhook signature verification failed:", err.message);
      return Response.json({ error: "Invalid signature" }, { status: 400 });
    }
    console.error("Webhook processing error:", err);
    return Response.json({ error: "Processing failed" }, { status: 500 });
  }
};

// CRITICAL: disable Next.js body parsing — Stripe signature verification
// requires the raw buffer, not the parsed JSON.
export const config = {
  api: { bodyParser: false },
};
