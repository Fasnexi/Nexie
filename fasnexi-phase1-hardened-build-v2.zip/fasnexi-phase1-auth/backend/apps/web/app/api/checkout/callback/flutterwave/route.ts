// apps/web/app/api/checkout/callback/flutterwave/route.ts
// POST /api/checkout/callback/flutterwave
//
// Flutterwave sends a verif-hash header matching a secret configured in
// the Flutterwave dashboard (not HMAC — a static shared secret comparison).
// Same idempotent processing path as Stripe and Paystack.

import crypto from "crypto";
import { processPaymentWebhookIdempotent } from "@fasnexi/api/financial/payments";

export const POST = async (request: Request): Promise<Response> => {
  const signature = request.headers.get("verif-hash");
  const expectedSecret = process.env.FLUTTERWAVE_WEBHOOK_SECRET!;

  // Constant-time comparison — Flutterwave's verif-hash is a static shared
  // secret (not an HMAC), so a naive !== is a textbook timing side-channel
  // against that secret.
  const signatureValid =
    !!signature &&
    signature.length === expectedSecret.length &&
    crypto.timingSafeEqual(Buffer.from(signature, "utf8"), Buffer.from(expectedSecret, "utf8"));

  if (!signatureValid) {
    return Response.json({ error: "Invalid or missing verif-hash" }, { status: 400 });
  }

  const event = await request.json();

  if (event.event !== "charge.completed" || event.data?.status !== "successful") {
    return Response.json({ received: true, ignored: true });
  }

  const data = event.data;

  try {
    const result = await processPaymentWebhookIdempotent({
      provider: "flutterwave",
      eventId: `flutterwave-${data.id}`,
      eventType: "checkout.session.completed",
      paymentIntent: {
        id: data.tx_ref,
        amount: Math.round(data.amount * 100), // Flutterwave sends whole units; normalise to smallest unit
        currency: data.currency.toUpperCase(),
        status: "succeeded",
        metadata: data.meta ?? {},
      },
    });

    return Response.json({ received: true, orderId: result.orderId, alreadyProcessed: result.alreadyProcessed });
  } catch (err: any) {
    console.error("Flutterwave webhook processing error:", err);
    return Response.json({ error: "Processing failed" }, { status: 500 });
  }
};

export const config = {
  api: { bodyParser: false },
};
