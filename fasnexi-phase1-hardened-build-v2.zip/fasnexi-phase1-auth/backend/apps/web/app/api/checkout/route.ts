// apps/web/app/api/checkout/route.ts
// POST /api/checkout — create Stripe / African gateway session

import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { createCheckoutSession } from "@fasnexi/api/checkout/stripe";
import type { Currency } from "@prisma/client";

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  const body = await request.json();

  const { items, currency = "USD", creatorId, couponCode } = body;
  const supportedCurrencies = new Set(["USD","NGN","KES","GHS","ZAR","XOF","XAF"]);
  if (typeof currency !== "string" || !supportedCurrencies.has(currency)) {
    return Response.json({ error: "Unsupported checkout currency", code: "VALIDATION_ERROR" }, { status: 400 });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return Response.json({ error: "items must be a non-empty array" }, { status: 400 });
  }

  for (const item of items) {
    if (!item.productId || typeof item.quantity !== "number" || item.quantity < 1) {
      return Response.json(
        { error: "Each item needs a productId and a quantity >= 1" },
        { status: 400 },
      );
    }
  }

  const origin = request.headers.get("origin") ?? "https://fasnexi.com";

  try {
    const session = await createCheckoutSession({
      userId: user.id,
      items,
      currency: currency as Currency,
      successUrl: `${origin}/orders/success`,
      cancelUrl: `${origin}/cart`,
      creatorId: creatorId ?? undefined,
      couponCode: couponCode ?? undefined,
    });

    return Response.json(session);
  } catch (err: any) {
    if (err.message?.includes("currency") || err.message?.includes("stock") || err.message?.includes("Duplicate products")) {
      return Response.json({ error: err.message, code: "VALIDATION_ERROR" }, { status: 400 });
    }
    throw err;
  }
});
