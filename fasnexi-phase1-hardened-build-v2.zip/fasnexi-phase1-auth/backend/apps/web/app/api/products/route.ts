// apps/web/app/api/products/route.ts
// GET /api/products — browse/search catalog
//
// GAP FIX: listProducts() has existed since Phase 1 in
// packages/api/src/products/catalog.ts (full filtering, PostgreSQL full-text
// search fallback, Typesense when TYPESENSE_HOST is set) but was never wired
// to a route — Discover and Shop had a product-detail endpoint and nothing
// to list from. This route is a thin wrapper; all logic already existed.
//
// Query params (all optional, all match ProductListOptions in catalog.ts):
//   q              — search text (name/description, or brand/culturalTags via Typesense)
//   category       — GarmentCategory enum value
//   minPrice       — smallest-unit integer
//   maxPrice       — smallest-unit integer
//   currency       — Currency enum value (default USD; display/filter only,
//                    does not convert — see /api/fx for display conversion)
//   culturalTags   — comma-separated list
//   occasion       — Occasion enum value
//   vendorId       — restrict to one vendor's catalog (used by storefront pages)
//   inStockOnly    — "true" | "false" (default true)
//   cursor, limit  — cursor pagination, max 60
//   sortBy         — "price_asc" | "price_desc" | "newest" | "popular" (default popular)

import { withErrorHandling } from "@fasnexi/auth/middleware/guards";
import { listProducts } from "@fasnexi/api/products/catalog";
import type { GarmentCategory, Currency } from "@prisma/client";

const VALID_SORT = new Set(["price_asc", "price_desc", "newest", "popular"]);

export const GET = withErrorHandling(async (request: Request) => {
  const { searchParams } = new URL(request.url);

  const sortBy = searchParams.get("sortBy") ?? "popular";
  if (!VALID_SORT.has(sortBy)) {
    return Response.json(
      { error: `sortBy must be one of: ${[...VALID_SORT].join(", ")}` },
      { status: 400 },
    );
  }

  const minPrice = searchParams.has("minPrice") ? parseInt(searchParams.get("minPrice")!) : undefined;
  const maxPrice = searchParams.has("maxPrice") ? parseInt(searchParams.get("maxPrice")!) : undefined;

  if (minPrice !== undefined && isNaN(minPrice)) {
    return Response.json({ error: "minPrice must be an integer" }, { status: 400 });
  }
  if (maxPrice !== undefined && isNaN(maxPrice)) {
    return Response.json({ error: "maxPrice must be an integer" }, { status: 400 });
  }
  if (minPrice !== undefined && maxPrice !== undefined && minPrice > maxPrice) {
    return Response.json({ error: "minPrice cannot exceed maxPrice" }, { status: 400 });
  }

  const culturalTagsParam = searchParams.get("culturalTags");

  const result = await listProducts({
    query: searchParams.get("q") ?? undefined,
    category: (searchParams.get("category") as GarmentCategory) ?? undefined,
    minPrice,
    maxPrice,
    currency: (searchParams.get("currency") as Currency) ?? undefined,
    culturalTags: culturalTagsParam ? culturalTagsParam.split(",").map(t => t.trim()).filter(Boolean) : undefined,
    occasion: searchParams.get("occasion") ?? undefined,
    vendorId: searchParams.get("vendorId") ?? undefined,
    inStockOnly: searchParams.get("inStockOnly") !== "false",
    cursor: searchParams.get("cursor") ?? undefined,
    limit: Math.min(parseInt(searchParams.get("limit") ?? "24"), 60),
    sortBy: sortBy as "price_asc" | "price_desc" | "newest" | "popular",
  });

  return Response.json(result);
});

// Intentionally no POST here — product creation isn't in the current route
// surface at all (not just this one); vendors presumably create products
// through a path not covered by the 51 routes reviewed. Flagging rather than
// guessing at a shape: if the Vendor Console (frontend plan §2) needs product
// creation, that's a separate gap to scope, not assumed as part of this fix.
