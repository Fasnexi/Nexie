// apps/web/app/api/products/[id]/route.ts
// GET    /api/products/:id — product detail + reviews (public)
// PATCH  /api/products/:id — vendor updates their own product
// DELETE /api/products/:id — vendor soft-deletes (unpublish) their own product
//
// CONSOLIDATION NOTE: GET and PATCH/DELETE were delivered as two separate
// route.ts files across different uploads (fasnexi-phase1 had GET only,
// fasnexi-auth had PATCH/DELETE only) — Next.js only allows one route.ts per
// path, so these are merged here rather than one silently overwriting the
// other. Demonstrates the full three-layer guard pattern on the write paths:
//   1. requireUser()            → signed in, not banned
//   2. requireVerifiedRole()    → VENDOR role + isVerified=true on VendorProfile
//   3. requirePermission()      → product:update_own (only their own product)

import { db } from "@fasnexi/db";
import {
  requireUser, requireVerifiedRole, requirePermission, withErrorHandling,
} from "@fasnexi/auth/middleware/guards";
import { getProduct } from "@fasnexi/api/products/catalog";

export const GET = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const product = await getProduct(params.id);
  if (!product) return Response.json({ error: "Product not found" }, { status: 404 });
  return Response.json({ product });
});

export const PATCH = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "VENDOR");

  const product = await db.product.findUnique({
    where: { id: params.id },
    include: { vendor: { select: { userId: true } } },
  });
  if (!product) return Response.json({ error: "Product not found" }, { status: 404 });

  await requirePermission(user, "product", "update", {
    isOwner: product.vendor.userId === user.id,
  });

  const body = await request.json();
  const updated = await db.product.update({
    where: { id: params.id },
    data: {
      name: body.name,
      description: body.description,
      priceAmount: body.priceAmount,
      inventoryCount: body.inventoryCount,
      isPublished: body.isPublished,
    },
  });

  return Response.json({ product: updated });
});

export const DELETE = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "VENDOR");

  const product = await db.product.findUnique({
    where: { id: params.id },
    include: { vendor: { select: { userId: true } } },
  });
  if (!product) return Response.json({ error: "Product not found" }, { status: 404 });

  await requirePermission(user, "product", "delete", {
    isOwner: product.vendor.userId === user.id,
  });

  // Soft-delete: unpublish rather than hard-delete. OrderItem rows reference
  // this product with onDelete: Restrict so hard deletes would fail anyway.
  await db.product.update({
    where: { id: params.id },
    data: { isPublished: false, isInStock: false },
  });

  return new Response(null, { status: 204 });
});
