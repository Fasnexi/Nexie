// apps/web/app/api/wardrobe/[id]/route.ts
// GET    /api/wardrobe/:id  — item detail including outfit history
// PATCH  /api/wardrobe/:id  — update user-editable fields
// DELETE /api/wardrobe/:id  — soft-archive

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import {
  getWardrobeItem, updateWardrobeItem, archiveWardrobeItem, recordWear,
} from "@fasnexi/api/wardrobe/service";
import type { GarmentCategory } from "@prisma/client";

const VALID_CATEGORIES = new Set<string>([
  "TOP","BOTTOM","DRESS","OUTERWEAR","FOOTWEAR",
  "ACCESSORY","BAG","TRADITIONAL","ACTIVEWEAR","SWIMWEAR","UNDERWEAR",
]);

export const GET = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  const item = await getWardrobeItem(params.id, user.id);
  if (!item) return Response.json({ error: "Item not found" }, { status: 404 });
  return Response.json({ item });
});

export const PATCH = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requirePermission(user, "wardrobe_item", "update", { isOwner: true });

  const body = await request.json();

  // recordWear action
  if (body.action === "record_wear") {
    const wornOn = body.wornOn ? new Date(body.wornOn) : new Date();
    if (isNaN(wornOn.getTime())) {
      return Response.json({ error: "Invalid wornOn date" }, { status: 400 });
    }
    try {
      await recordWear(params.id, user.id, wornOn);
      return Response.json({ recorded: true });
    } catch (err: any) {
      if (err.message?.includes("not found")) return Response.json({ error: err.message, code: "NOT_FOUND" }, { status: 404 });
      throw err;
    }
  }

  const { category, subcategory, brand, colorLabel, size, notes, purchasePrice, purchaseDate } = body;

  if (category && !VALID_CATEGORIES.has(category)) {
    return Response.json({ error: `Invalid category: ${category}` }, { status: 400 });
  }

  let updated;
  try {
    updated = await updateWardrobeItem(params.id, user.id, {
    category: category as GarmentCategory | undefined,
    subcategory,
    brand,
    colorLabel,
    size,
    notes,
    purchasePrice: purchasePrice !== undefined ? parseFloat(purchasePrice) : undefined,
    purchaseDate: purchaseDate ? new Date(purchaseDate) : undefined,
    });
  } catch (err: any) {
    if (err.message?.includes("not found")) return Response.json({ error: err.message, code: "NOT_FOUND" }, { status: 404 });
    throw err;
  }

  return Response.json({ item: updated });
});

export const DELETE = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requirePermission(user, "wardrobe_item", "delete", { isOwner: true });

  try {
    await archiveWardrobeItem(params.id, user.id);
    return new Response(null, { status: 204 });
  } catch (err: any) {
    if (err.message?.includes("resale listing")) return Response.json({ error: err.message, code: "CONFLICT" }, { status: 409 });
    if (err.message?.includes("not found")) return Response.json({ error: err.message, code: "NOT_FOUND" }, { status: 404 });
    throw err;
  }
});
