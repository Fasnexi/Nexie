// apps/web/app/api/wardrobe/[id]/tag/route.ts
// POST /api/wardrobe/:id/tag — retrigger AI tagging for a wardrobe item
// Used when the initial tagging failed, or user uploads a better image.

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import { retriggerTagging } from "@fasnexi/api/wardrobe/service";

export const POST = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requirePermission(user, "wardrobe_item", "update", { isOwner: true });

  try {
    await retriggerTagging(params.id, user.id);
  } catch (err: any) {
    if (err.message?.includes("not found")) return Response.json({ error: err.message, code: "NOT_FOUND" }, { status: 404 });
    throw err;
  }

  return Response.json({
    queued: true,
    message: "Re-tagging queued. The item will be updated in a few seconds.",
  });
});
