// apps/web/app/api/wardrobe/route.ts
// GET  /api/wardrobe — list user's wardrobe items (paginated)
// POST /api/wardrobe — create wardrobe item after Cloudinary upload

import { withErrorHandling, requireUser, requirePermission } from "@fasnexi/auth/middleware/guards";
import { createWardrobeItem, getWardrobeItems, getWardrobeAnalytics } from "@fasnexi/api/wardrobe/service";
import type { GarmentCategory } from "@prisma/client";

const VALID_CATEGORIES = new Set<string>([
  "TOP","BOTTOM","DRESS","OUTERWEAR","FOOTWEAR",
  "ACCESSORY","BAG","TRADITIONAL","ACTIVEWEAR","SWIMWEAR","UNDERWEAR",
]);

export const GET = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requirePermission(user, "wardrobe_item", "read", { isOwner: true });

  const { searchParams } = new URL(request.url);
  const view = searchParams.get("view");

  // Analytics view
  if (view === "analytics") {
    return Response.json(await getWardrobeAnalytics(user.id));
  }

  const category = searchParams.get("category");
  if (category && !VALID_CATEGORIES.has(category)) {
    return Response.json({ error: `Invalid category: ${category}` }, { status: 400 });
  }

  const result = await getWardrobeItems(user.id, {
    category: (category as GarmentCategory) ?? undefined,
    cursor: searchParams.get("cursor") ?? undefined,
    limit: Math.min(parseInt(searchParams.get("limit") ?? "40"), 100),
    taggedOnly: searchParams.get("tagged") === "true",
  });

  return Response.json(result);
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requirePermission(user, "wardrobe_item", "create");

  const body = await request.json();
  const {
    imageUrl,
    thumbnailUrl,
    category,
    subcategory,
    brand,
    colorLabel,
    size,
    purchasePrice,
    purchaseCurrency,
    purchaseDate,
    notes,
  } = body;

  if (!imageUrl || typeof imageUrl !== "string") {
    return Response.json({ error: "imageUrl is required" }, { status: 400 });
  }

  if (!category || !VALID_CATEGORIES.has(category)) {
    return Response.json(
      { error: `category is required and must be one of: ${[...VALID_CATEGORIES].join(", ")}` },
      { status: 400 },
    );
  }

  const item = await createWardrobeItem({
    userId: user.id,
    imageUrl,
    thumbnailUrl,
    category: category as GarmentCategory,
    subcategory,
    brand,
    colorLabel,
    size,
    purchasePrice: purchasePrice ? parseFloat(purchasePrice) : undefined,
    purchaseCurrency,
    purchaseDate: purchaseDate ? new Date(purchaseDate) : undefined,
    notes,
  });

  return Response.json({ item }, { status: 201 });
});
