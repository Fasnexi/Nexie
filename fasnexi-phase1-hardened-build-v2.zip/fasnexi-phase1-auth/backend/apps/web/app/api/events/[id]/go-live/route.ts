// apps/web/app/api/events/[id]/go-live/route.ts
// POST /api/events/:id/go-live
//
// Returns 501 Not Implemented with a clear message until a real
// StreamProvider (Mux) is configured in packages/api/src/live/service.ts.
// This is intentional — see the scoping note in that file.

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { goLive } from "@fasnexi/api/live/service";

export const POST = withErrorHandling(async (
  _request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "EVENT_ORGANIZER");

  try {
    const event = await goLive(params.id, user.id);
    return Response.json({ event });
  } catch (err: any) {
    if (err.message?.includes("not yet configured")) {
      return Response.json({ error: err.message }, { status: 501 });
    }
    if (err.message?.includes("do not own") || err.message?.includes("not found")) {
      return Response.json({ error: err.message }, { status: 403 });
    }
    throw err;
  }
});
