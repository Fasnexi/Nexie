import { withErrorHandling, requireUser } from "@fasnexi/auth/middleware/guards";
import { db } from "@fasnexi/db";

export const GET = withErrorHandling(async (_request: Request, { params }: { params: { id: string } }) => {
  await requireUser();
  const event = await db.event.findFirst({
    where: { id: params.id, isPublished: true },
    include: {
      organizer: { select: { id: true, orgName: true, country: true } },
      ticketTiers: { orderBy: { priceAmount: "asc" } },
    },
  });
  if (!event) return Response.json({ error: "Event not found", code: "NOT_FOUND" }, { status: 404 });
  return Response.json({ event });
});
