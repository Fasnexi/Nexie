// apps/web/app/api/events/[id]/tickets/route.ts
// POST /api/events/:id/tickets — create a ticket tier for an event

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { createTicketTier } from "@fasnexi/api/events/ticketing";

export const POST = withErrorHandling(async (
  request: Request,
  { params }: { params: { id: string } },
) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "EVENT_ORGANIZER");

  const { name, description, priceAmount, currency, capacity } = await request.json();
  if (!name || typeof priceAmount !== "number" || !currency || typeof capacity !== "number") {
    return Response.json({ error: "name, priceAmount, currency, and capacity are required" }, { status: 400 });
  }

  try {
    const tier = await createTicketTier({
      eventId: params.id, organizerUserId: user.id, name, description, priceAmount, currency, capacity,
    });
    return Response.json({ tier }, { status: 201 });
  } catch (err: any) {
    if (err.message?.includes("do not own") || err.message?.includes("not found")) {
      return Response.json({ error: err.message }, { status: 403 });
    }
    throw err;
  }
});
