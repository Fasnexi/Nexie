// apps/web/app/api/events/route.ts
// GET  /api/events — upcoming live/shopping events
// POST /api/events — schedule a new event

import { withErrorHandling, requireUser, requireVerifiedRole } from "@fasnexi/auth/middleware/guards";
import { scheduleLiveEvent, getUpcomingLiveEvents } from "@fasnexi/api/live/service";
import { db } from "@fasnexi/db";

export const GET = withErrorHandling(async (request: Request) => {
  await requireUser();
  const { searchParams } = new URL(request.url);
  const events = await getUpcomingLiveEvents(Math.min(parseInt(searchParams.get("limit") ?? "10"), 50));
  return Response.json({ events });
});

export const POST = withErrorHandling(async (request: Request) => {
  const user = await requireUser();
  await requireVerifiedRole(user, "EVENT_ORGANIZER");

  const { title, description, coverUrl, startDate, productIds } = await request.json();
  if (!title || !startDate) {
    return Response.json({ error: "title and startDate are required" }, { status: 400 });
  }

  const organizer = await db.eventOrganizerProfile.findUniqueOrThrow({ where: { userId: user.id }, select: { id: true } });

  const event = await scheduleLiveEvent({
    organizerId: organizer.id,
    title,
    description,
    coverUrl,
    startDate: new Date(startDate),
    productIds: productIds ?? [],
  });

  return Response.json({ event }, { status: 201 });
});
