// =============================================================================
// FASNEXI — NEXT.JS MIDDLEWARE
// apps/web/middleware.ts
//
// Edge-level route guard — checks role membership before the request reaches
// a page or API handler. Cannot check resource ownership (no DB at edge), so
// fine-grained checks still happen server-side per requirePermission() calls.
// =============================================================================
import { NextResponse, type NextRequest } from "next/server";
import { auth } from "@fasnexi/auth";

const ROLE_GATED_ROUTES = [
  { prefix: "/dashboard/creator",   roles: ["CREATOR"] },
  { prefix: "/dashboard/vendor",    roles: ["VENDOR"] },
  { prefix: "/dashboard/designer",  roles: ["DESIGNER"] },
  { prefix: "/dashboard/tailor",    roles: ["TAILOR"] },
  { prefix: "/dashboard/events",    roles: ["EVENT_ORGANIZER"] },
  { prefix: "/dashboard/impact",    roles: ["SUSTAINABLE_PARTNER"] },
  { prefix: "/dashboard/portfolio", roles: ["INVESTOR"] },
  { prefix: "/admin",               roles: ["ADMIN"] },
  { prefix: "/moderation",          roles: ["MODERATOR", "ADMIN"] },
];

const PUBLIC_ROUTES = ["/", "/login", "/signup", "/about", "/legal"];

// Routes under /api/ that must be reachable WITHOUT an existing session.
// Each of these already enforces its own auth internally where it needs to
// (Better Auth handles sign-in/up itself; webhooks verify provider
// signatures; health checks are infra-only; click tracking is intentionally
// anonymous). Without this allowlist, the /api/ blanket-auth rule below
// 401s all of them — including the sign-in endpoint itself, which makes it
// impossible for anyone to ever establish a session.
const PUBLIC_API_PREFIXES = [
  "/api/auth",                    // Better Auth: sign-in/up, OAuth callbacks, /roles/*
  "/api/checkout/webhook",        // Stripe webhook — verified via stripe-signature
  "/api/checkout/callback",       // Paystack/Flutterwave callbacks — verified via provider signature
  "/api/health",                  // Fly.io + blue/green deploy health checks
];

function isPublicApiRoute(pathname: string): boolean {
  if (PUBLIC_API_PREFIXES.some(p => pathname === p || pathname.startsWith(`${p}/`))) return true;
  // /api/promotions/:id/click — anonymous impression-adjacent click tracking,
  // deliberately unauthenticated (see route comment). Impressions, which
  // actually bill vendor budgets, stay behind requireUser() in-route.
  if (/^\/api\/promotions\/[^/]+\/click$/.test(pathname)) return true;
  return false;
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (PUBLIC_ROUTES.some(p => pathname === p)) return NextResponse.next();
  if (isPublicApiRoute(pathname)) return NextResponse.next();

  const gate = ROLE_GATED_ROUTES.find(r => pathname.startsWith(r.prefix));
  const needsAuth = gate || pathname.startsWith("/dashboard") || pathname.startsWith("/api/");
  if (!needsAuth) return NextResponse.next();

  const session = await auth.api.getSession({ headers: request.headers });

  if (!session) {
    if (pathname.startsWith("/api/"))
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    const url = new URL("/login", request.url);
    url.searchParams.set("redirect", pathname);
    return NextResponse.redirect(url);
  }

  if ((session.user as any).isBanned)
    return NextResponse.redirect(new URL("/account-suspended", request.url));

  if (gate) {
    const userRoles: string[] = (session.user as any).roles ?? [];
    const hasRole = gate.roles.some(r => userRoles.includes(r));
    if (!hasRole) {
      if (pathname.startsWith("/api/"))
        return NextResponse.json({ error: `Requires one of: ${gate.roles.join(", ")}` }, { status: 403 });
      return NextResponse.redirect(new URL("/dashboard?error=role_required", request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
