// =============================================================================
// FASNEXI — STORIES SERVICE
// packages/api/src/stories/service.ts
//
// Stories: ephemeral content with 24-hour TTL per White Paper §17.3.
//
// Storage strategy:
//   - StoryItem rows in PostgreSQL hold media URL and metadata
//   - Redis sorted set `stories:active` (score = expiresAt timestamp) tracks
//     which stories are currently live without polling the DB on every request
//   - Viewed state per user stored in Redis bitmaps: `story:{id}:views`
//     Bit position = a sequential user index (stored in `user:story-index`)
//     Bitmaps give O(1) set/get and ~16KB per story for 100k viewers
//   - A scheduled worker calls expireStories() hourly to clean up
// =============================================================================

import { db } from "@fasnexi/db";
import { createClient } from "redis";

const STORY_TTL_SECONDS = 60 * 60 * 24; // 24 hours

function redisClient() {
  return createClient({ url: process.env.REDIS_URL });
}

// ---------------------------------------------------------------------------
// CREATE STORY
// ---------------------------------------------------------------------------
export async function createStory(input: {
  userId: string;
  mediaUrl: string;
  mediaType: "image" | "video";
  durationSeconds?: number;
}): Promise<{ id: string; expiresAt: Date }> {
  const expiresAt = new Date(Date.now() + STORY_TTL_SECONDS * 1000);

  const story = await db.storyItem.create({
    data: {
      userId: input.userId,
      mediaUrl: input.mediaUrl,
      mediaType: input.mediaType,
      durationSeconds: input.durationSeconds ?? 5,
      expiresAt,
    },
  });

  // Register in Redis sorted set (score = expiry timestamp for range queries)
  const redis = redisClient();
  await redis.connect();
  await redis.zAdd("stories:active", {
    score: expiresAt.getTime(),
    value: `${input.userId}:${story.id}`,
  });
  await redis.disconnect();

  return { id: story.id, expiresAt };
}

// ---------------------------------------------------------------------------
// GET STORIES FOR FEED — ordered by follow graph, unviewed first
// ---------------------------------------------------------------------------
export async function getStoryFeed(viewerId: string): Promise<StoryFeedItem[]> {
  const now = Date.now();

  // Get all currently-live story creator IDs from Redis
  const redis = redisClient();
  await redis.connect();

  const activeEntries = await redis.zRangeByScore(
    "stories:active",
    now,                  // min score: not yet expired
    now + STORY_TTL_SECONDS * 1000, // max: up to 24h from now
  );

  await redis.disconnect();

  if (activeEntries.length === 0) return [];

  // Parse userId:storyId pairs
  const creatorIds = [...new Set(activeEntries.map(e => e.split(":")[0]))];

  // Filter to followed creators + self
  const following = await db.follow.findMany({
    where: { followerId: viewerId, followingId: { in: creatorIds } },
    select: { followingId: true },
  });
  const relevantCreatorIds = [viewerId, ...following.map(f => f.followingId)];

  // Fetch active stories from DB for relevant creators
  const stories = await db.storyItem.findMany({
    where: {
      userId: { in: relevantCreatorIds },
      expiresAt: { gt: new Date() },
    },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      userId: true,
      mediaUrl: true,
      mediaType: true,
      durationSeconds: true,
      expiresAt: true,
      user: { select: { id: true, username: true, avatarUrl: true } },
    },
  });

  // Check viewed status for each story using Redis bitmaps
  const redisRead = redisClient();
  await redisRead.connect();

  const viewerIdx = await getOrCreateViewerIndex(viewerIdx, redisRead);

  const viewedStatuses = await Promise.all(
    stories.map(s => redisRead.getBit(`story:${s.id}:views`, viewerIdx)),
  );

  await redisRead.disconnect();

  // Group by creator, mark viewed state
  const grouped = new Map<string, StoryFeedItem>();
  stories.forEach((story, i) => {
    const viewed = viewedStatuses[i] === 1;
    if (!grouped.has(story.userId)) {
      grouped.set(story.userId, {
        userId: story.userId,
        user: story.user,
        stories: [],
        hasUnviewed: false,
      });
    }
    const group = grouped.get(story.userId)!;
    group.stories.push({ ...story, viewed });
    if (!viewed) group.hasUnviewed = true;
  });

  // Sort: unviewed creators first, then by recency
  return Array.from(grouped.values()).sort((a, b) => {
    if (a.hasUnviewed && !b.hasUnviewed) return -1;
    if (!a.hasUnviewed && b.hasUnviewed) return 1;
    return 0;
  });
}

// ---------------------------------------------------------------------------
// MARK STORY AS VIEWED
// ---------------------------------------------------------------------------
export async function markStoryViewed(storyId: string, viewerId: string): Promise<void> {
  const redis = redisClient();
  await redis.connect();

  const viewerIdx = await getOrCreateViewerIndex(viewerId, redis);
  const key = `story:${storyId}:views`;
  await redis.setBit(key, viewerIdx, 1);
  // Mirror the story TTL so the bitmap auto-expires with the story
  await redis.expire(key, STORY_TTL_SECONDS + 3600); // +1h buffer

  await redis.disconnect();
}

// ---------------------------------------------------------------------------
// EXPIRE OLD STORIES — called by scheduled worker hourly
// ---------------------------------------------------------------------------
export async function expireStories(): Promise<number> {
  const now = Date.now();

  // Remove expired entries from Redis sorted set
  const redis = redisClient();
  await redis.connect();
  const removed = await redis.zRemRangeByScore("stories:active", 0, now - 1);
  await redis.disconnect();

  // Soft-delete expired rows in PostgreSQL (keeps them for analytics)
  // Hard delete after 7 days via a separate cleanup job
  await db.storyItem.updateMany({
    where: { expiresAt: { lt: new Date() } },
    data: {},  // No-op — expiry is enforced by expiresAt filter in queries
  });

  return removed;
}

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------

async function getOrCreateViewerIndex(
  viewerId: string,
  redis: ReturnType<typeof createClient>,
): Promise<number> {
  const indexKey = `user:story-index:${viewerId}`;
  const existing = await redis.get(indexKey);
  if (existing) return parseInt(existing);

  // Atomically increment global user counter to get a unique bit position
  const idx = await redis.incr("story:global-user-count");
  await redis.set(indexKey, idx.toString(), { EX: 60 * 60 * 24 * 90 }); // 90 days
  return idx;
}

export interface StoryFeedItem {
  userId: string;
  user: { id: string; username: string; avatarUrl: string | null };
  stories: Array<{
    id: string;
    mediaUrl: string;
    mediaType: string;
    durationSeconds: number;
    expiresAt: Date;
    viewed: boolean;
  }>;
  hasUnviewed: boolean;
}
