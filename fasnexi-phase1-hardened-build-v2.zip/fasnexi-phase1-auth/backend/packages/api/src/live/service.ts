// =============================================================================
// FASNEXI — LIVE SHOPPING SERVICE
// packages/api/src/live/service.ts
//
// SCOPING NOTE (read before wiring a frontend to this):
// The event scheduling, RSVP, and product-tagging logic below is REAL and
// fully functional. The actual live video ingest/playback (Mux Live) is
// intentionally represented by a StreamProvider INTERFACE, not a working
// integration — connecting real Mux requires a Mux account, API keys, and
// webhook endpoint verification that can't be validated without live
// credentials. Shipping a fake "working" Mux client would be worse than an
// honest stub: it would silently pass tests while doing nothing in production.
//
// What this means for frontend work: build the event creation, RSVP, and
// "upcoming live shows" UI against this service now — it's real. The actual
// <video> player embed is the one piece to defer until Mux credentials exist.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

// ---------------------------------------------------------------------------
// STREAM PROVIDER INTERFACE — swap in a real Mux client once credentials
// are available. Until then, StubStreamProvider below throws clearly rather
// than pretending to stream.
// ---------------------------------------------------------------------------
export interface StreamProvider {
  createLiveStream(eventId: string): Promise<{ streamKey: string; playbackUrl: string }>;
  endLiveStream(streamKey: string): Promise<void>;
}

export class StubStreamProvider implements StreamProvider {
  async createLiveStream(): Promise<{ streamKey: string; playbackUrl: string }> {
    throw new Error(
      "Live streaming is not yet configured. Set MUX_TOKEN_ID / MUX_TOKEN_SECRET " +
      "and swap StubStreamProvider for a real Mux-backed implementation in " +
      "packages/api/src/live/mux-provider.ts before enabling live video.",
    );
  }
  async endLiveStream(): Promise<void> {
    throw new Error("Live streaming is not yet configured.");
  }
}

// Swap this single line once Mux is configured — nothing else in this file changes.
const streamProvider: StreamProvider = new StubStreamProvider();

// ---------------------------------------------------------------------------
// SCHEDULE A LIVE SHOPPING EVENT — fully functional, no streaming dependency
// ---------------------------------------------------------------------------
export async function scheduleLiveEvent(input: {
  organizerId: string;   // EventOrganizerProfile.id
  title: string;
  description?: string;
  coverUrl?: string;
  startDate: Date;
  productIds: string[];  // products to feature during the stream
}) {
  const organizer = await db.eventOrganizerProfile.findUnique({
    where: { id: input.organizerId },
    select: { id: true, userId: true },
  });
  if (!organizer) throw new Error("Event organizer profile not found");

  const event = await db.event.create({
    data: {
      organizerId: input.organizerId,
      title: input.title,
      description: input.description,
      coverUrl: input.coverUrl,
      startDate: input.startDate,
      endDate: new Date(input.startDate.getTime() + 60 * 60 * 1000), // default 1hr
      isLive: false,
      isPublished: true,
    },
  });

  return event;
}

// ---------------------------------------------------------------------------
// GO LIVE — attempts to start the actual stream. Throws the clear
// "not configured" error from StubStreamProvider until Mux is wired in.
// ---------------------------------------------------------------------------
export async function goLive(eventId: string, organizerUserId: string) {
  const event = await db.event.findUnique({
    where: { id: eventId },
    include: { organizer: { select: { userId: true } } },
  });
  if (!event) throw new Error("Event not found");
  if (event.organizer.userId !== organizerUserId) throw new Error("You do not own this event");

  // This line throws until a real StreamProvider is configured — by design.
  const stream = await streamProvider.createLiveStream(eventId);

  const updated = await db.event.update({
    where: { id: eventId },
    data: { isLive: true, streamUrl: stream.playbackUrl },
  });

  return updated;
}

// ---------------------------------------------------------------------------
// GET UPCOMING LIVE EVENTS — real, streaming-independent
// ---------------------------------------------------------------------------
export async function getUpcomingLiveEvents(limit = 10) {
  return db.event.findMany({
    where: { isPublished: true, startDate: { gte: new Date() } },
    orderBy: { startDate: "asc" },
    take: limit,
    include: { organizer: { select: { orgName: true } } },
  });
}
