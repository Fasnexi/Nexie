// =============================================================================
// FASNEXI — CART STORE
// packages/api/src/store/cart.ts
//
// Zustand store for client-side cart state. Used by both apps/web and
// apps/mobile — the store is isomorphic (no window/localStorage references)
// so React Native imports it identically to Next.js.
//
// Server persistence: the cart is intentionally client-only for Phase 1.
// The checkout API call creates the Order server-side on completion.
// Phase 4+ will add server-side cart persistence for cross-device resume.
// =============================================================================

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface CartItem {
  productId: string;
  name: string;
  priceAmount: number;   // in smallest unit (cents/kobo)
  priceCurrency: string;
  imageUrl: string;
  size?: string;
  color?: string;
  quantity: number;
  /** Creator who referred this item — written to commission on checkout */
  referredByCreatorId?: string;
}

interface CartState {
  items: CartItem[];
  currency: string;  // selected at checkout — all items share one currency

  // Actions
  addItem: (item: Omit<CartItem, "quantity"> & { quantity?: number }) => void;
  removeItem: (productId: string, size?: string, color?: string) => void;
  updateQuantity: (productId: string, quantity: number, size?: string, color?: string) => void;
  setCurrency: (currency: string) => void;
  clear: () => void;

  // Derived
  totalItems: () => number;
  subtotal: () => number;
}

// Unique key per cart slot — products can appear multiple times with diff sizes
const slotKey = (productId: string, size?: string, color?: string) =>
  `${productId}::${size ?? ""}::${color ?? ""}`;

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      currency: "USD",

      addItem: (incoming) => {
        const key = slotKey(incoming.productId, incoming.size, incoming.color);
        set(state => {
          const existing = state.items.find(
            i => slotKey(i.productId, i.size, i.color) === key,
          );
          if (existing) {
            return {
              items: state.items.map(i =>
                slotKey(i.productId, i.size, i.color) === key
                  ? { ...i, quantity: i.quantity + (incoming.quantity ?? 1) }
                  : i,
              ),
            };
          }
          return { items: [...state.items, { ...incoming, quantity: incoming.quantity ?? 1 }] };
        });
      },

      removeItem: (productId, size, color) => {
        const key = slotKey(productId, size, color);
        set(state => ({
          items: state.items.filter(i => slotKey(i.productId, i.size, i.color) !== key),
        }));
      },

      updateQuantity: (productId, quantity, size, color) => {
        if (quantity <= 0) {
          get().removeItem(productId, size, color);
          return;
        }
        const key = slotKey(productId, size, color);
        set(state => ({
          items: state.items.map(i =>
            slotKey(i.productId, i.size, i.color) === key ? { ...i, quantity } : i,
          ),
        }));
      },

      setCurrency: (currency) => set({ currency }),

      clear: () => set({ items: [] }),

      totalItems: () => get().items.reduce((sum, i) => sum + i.quantity, 0),

      subtotal: () => get().items.reduce((sum, i) => sum + i.priceAmount * i.quantity, 0),
    }),
    {
      name: "fasnexi-cart",
      // On web: persisted to localStorage automatically by Zustand persist.
      // On mobile: swap storage to AsyncStorage or expo-secure-store by
      // passing a custom `storage` option when importing in apps/mobile.
      // The store definition itself stays unchanged.
    },
  ),
);

// ---------------------------------------------------------------------------
// CHECKOUT HELPER — calls the /api/checkout endpoint with the current cart
// ---------------------------------------------------------------------------
export async function submitCart(
  baseUrl: string,
  currency: string,
  creatorId?: string,
): Promise<{ url: string; sessionId: string }> {
  const { items } = useCartStore.getState();

  if (items.length === 0) throw new Error("Cart is empty");

  const response = await fetch(`${baseUrl}/api/checkout`, {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      items: items.map(i => ({
        productId: i.productId,
        quantity: i.quantity,
        size: i.size,
        color: i.color,
      })),
      currency,
      creatorId: creatorId ?? items.find(i => i.referredByCreatorId)?.referredByCreatorId,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error ?? "Checkout failed");
  }

  return response.json();
}
