// =============================================================================
// FASNEXI — VIDEO CONTENT SERVICE
// packages/api/src/video/service.ts
//
// Per White Paper §17.5: short-form video (max 3min), Cloudinary auto-transcode
// to HLS. This is a REAL implementation — Cloudinary is already the platform's
// media provider from Phase 1, so video is an extension of the existing upload
// pipeline, not a new dependency.
//
// Scope note: caption overlay and licensed-music selection (mentioned in the
// original roadmap) are frontend/editor features, not backend services — the
// backend only needs to store the final rendered video URL plus metadata.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

const MAX_DURATION_SECONDS = 180; // 3 minutes

export interface CreateVideoPostInput {
  userId: string;
  videoUrl: string;       // Cloudinary-hosted, already transcoded
  thumbnailUrl: string;
  durationSeconds: number;
  caption?: string;
  culturalTags?: string[];
  taggedProductIds?: string[];
}

// ---------------------------------------------------------------------------
// CREATE VIDEO POST
// ---------------------------------------------------------------------------
export async function createVideoPost(input: CreateVideoPostInput) {
  if (input.durationSeconds > MAX_DURATION_SECONDS) {
    throw new Error(`Video exceeds maximum duration of ${MAX_DURATION_SECONDS}s`);
  }

  const post = await db.post.create({
    data: {
      userId: input.userId,
      type: "VIDEO",
      status: "PUBLISHED",
      caption: input.caption ?? null,
      mediaUrls: [input.videoUrl],
      mediaTypes: ["video"],
      thumbnailUrl: input.thumbnailUrl,
      videoUrl: input.videoUrl,
      videoDuration: input.durationSeconds,
      culturalTags: input.culturalTags ?? [],
      publishedAt: new Date(),
      rankScore: 0,
      ...(input.taggedProductIds?.length && {
        taggedProducts: {
          create: input.taggedProductIds.map(productId => ({ productId })),
        },
      }),
    },
  });

  return post;
}

// ---------------------------------------------------------------------------
// GET VIDEO FEED — same ranking as Phase 1's getPersonalisedFeed but
// filtered to type=VIDEO for a dedicated video-first surface
// ---------------------------------------------------------------------------
export async function getVideoFeed(userId: string, cursor?: string, limit = 20) {
  const posts = await db.post.findMany({
    where: {
      type: "VIDEO",
      status: "PUBLISHED",
      userId: { not: userId },
      ...(cursor && { id: { lt: cursor } }),
    },
    orderBy: [{ rankScore: "desc" }, { id: "desc" }],
    take: limit,
    select: {
      id: true, userId: true, caption: true, videoUrl: true, thumbnailUrl: true,
      videoDuration: true, likeCount: true, commentCount: true,
      user: { select: { username: true, displayName: true, avatarUrl: true } },
      taggedProducts: { select: { product: { select: { id: true, name: true, priceAmount: true, priceCurrency: true } } } },
    },
  });

  return { videos: posts, nextCursor: posts.length === limit ? posts[posts.length - 1].id : null };
}
