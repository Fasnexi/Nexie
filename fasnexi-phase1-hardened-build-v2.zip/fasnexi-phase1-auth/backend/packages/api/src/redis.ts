// =============================================================================
// FASNEXI — SINGLETON REDIS CLIENT
// packages/api/src/redis.ts
//
// ROOT CAUSE: Every service (stories, challenges, nexi/engine) called
// createClient() + connect() + disconnect() on every single request.
// This creates a new TCP connection for each API call — expensive, slow,
// and exhausts Upstash's connection limits under load.
//
// FIX: Module-level singleton with lazy connect. The client connects once
// when first used and stays connected for the lifetime of the process.
// On worker/edge runtimes that don't persist modules between requests,
// the connect() is a no-op if already connected.
//
// USAGE: import { redis } from "@fasnexi/api/redis"
//        await redis.get(key)          // no connect/disconnect needed
// =============================================================================

import { createClient, type RedisClientType } from "redis";

let _client: RedisClientType | null = null;
let _connecting: Promise<void> | null = null;

export async function getRedis(): Promise<RedisClientType> {
  if (_client?.isReady) return _client;

  // Prevent concurrent connect() calls (double-connect throws)
  if (_connecting) {
    await _connecting;
    return _client!;
  }

  const client = createClient({
    url: process.env.REDIS_URL,
    socket: {
      // Reconnect with exponential backoff, max 30s
      reconnectStrategy: (retries: number) => {
        if (retries > 10) return new Error("Redis reconnect limit exceeded");
        return Math.min(retries * 100, 30_000);
      },
      keepAlive: 30_000,
      connectTimeout: 5_000,
    },
  }) as RedisClientType;

  client.on("error", (err) => {
    // Log but don't throw — the reconnect strategy handles recovery
    console.error("[redis] Client error:", err.message);
  });

  client.on("reconnecting", () => {
    console.warn("[redis] Reconnecting...");
  });

  _connecting = client.connect().then(() => {
    _client = client;
    _connecting = null;
  });

  await _connecting;
  return _client!;
}

// ---------------------------------------------------------------------------
// ATOMIC RATE LIMITER — replaces the non-atomic GET → check → INCR pattern
//
// Uses Lua script to make the check + increment atomic at the Redis level.
// No race condition possible: the entire logic runs as a single command.
// ---------------------------------------------------------------------------

const RATE_LIMIT_SCRIPT = `
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local ttl = tonumber(ARGV[2])

local current = tonumber(redis.call('GET', key) or '0')
if current >= limit then
  return {current, 0}  -- {count, allowed: 0=false}
end

local new_count = redis.call('INCR', key)
if new_count == 1 then
  redis.call('EXPIRE', key, ttl)
end
return {new_count, 1}  -- {count, allowed: 1=true}
`;

export async function atomicRateLimit(opts: {
  key: string;
  limit: number;
  ttlSeconds: number;
}): Promise<{ allowed: boolean; count: number; remaining: number }> {
  const client = await getRedis();

  const result = await client.eval(RATE_LIMIT_SCRIPT, {
    keys: [opts.key],
    arguments: [opts.limit.toString(), opts.ttlSeconds.toString()],
  }) as [number, number];

  const [count, allowedFlag] = result;
  const allowed = allowedFlag === 1;

  return {
    allowed,
    count,
    remaining: Math.max(0, opts.limit - count),
  };
}

// ---------------------------------------------------------------------------
// GRACEFUL SHUTDOWN — called by worker/web app process exit handlers
// ---------------------------------------------------------------------------
export async function closeRedis(): Promise<void> {
  if (_client?.isReady) {
    await _client.quit();
    _client = null;
  }
}
