// =============================================================================
// FASNEXI — TAILOR MARKETPLACE SERVICE
// packages/api/src/tailor/service.ts
//
// Per White Paper §8.3: custom order flow is brief submission → quote →
// deposit payment → production → delivery. State machine enforced exactly
// like Order (Phase 1) and creator commissions (hardening pass) — every
// transition is validated against an explicit allowed-transitions map, and
// ownership (tailor must own the CustomOrder they're modifying) is verified
// from the DB before any write, following the same pattern as
// requirePermission's isOwner contract from the auth hardening.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

// ---------------------------------------------------------------------------
// STATE MACHINE — mirrors the Order FSM pattern from vendors/dashboard.ts
// ---------------------------------------------------------------------------
type CustomOrderStatus =
  | "PENDING"             // brief submitted, awaiting tailor quote
  | "PAYMENT_PROCESSING"  // quote given, deposit checkout in progress
  | "PAID"                // deposit paid, production can begin
  | "FULFILLING"          // tailor is producing the garment
  | "SHIPPED"             // garment dispatched
  | "DELIVERED"           // client confirmed receipt
  | "CANCELLED";

const VALID_TRANSITIONS: Record<CustomOrderStatus, CustomOrderStatus[]> = {
  PENDING:             ["PAYMENT_PROCESSING", "CANCELLED"],
  PAYMENT_PROCESSING:  ["PAID", "CANCELLED"],
  PAID:                ["FULFILLING", "CANCELLED"],
  FULFILLING:          ["SHIPPED", "CANCELLED"],
  SHIPPED:             ["DELIVERED"],
  DELIVERED:           [],
  CANCELLED:           [],
};

// ---------------------------------------------------------------------------
// SUBMIT BRIEF — client requests a custom order from a tailor
// ---------------------------------------------------------------------------
export async function submitCustomOrderBrief(input: {
  tailorId: string;      // TailorProfile.id (not userId)
  clientId: string;
  brief: string;
  attachments?: string[];
  deadline?: Date;
}) {
  const tailor = await db.tailorProfile.findUnique({
    where: { id: input.tailorId },
    select: { id: true, isVerified: true, isAvailable: true, userId: true },
  });
  if (!tailor) throw new Error("Tailor not found");
  if (!tailor.isVerified) throw new Error("This tailor is not yet verified");
  if (!tailor.isAvailable) throw new Error("This tailor is not currently accepting new orders");

  const order = await db.customOrder.create({
    data: {
      tailorId: input.tailorId,
      clientId: input.clientId,
      brief: input.brief,
      attachments: input.attachments ?? [],
      status: "PENDING",
      deadline: input.deadline ?? null,
    },
  });

  await enqueueNotification({
    recipientId: tailor.userId,
    type: "SYSTEM",
    data: { message: "New custom order brief received", customOrderId: order.id },
  });

  return order;
}

// ---------------------------------------------------------------------------
// PROVIDE QUOTE — tailor sets price, moves order to PAYMENT_PROCESSING
// Ownership verified: only the tailor who owns this order can quote it.
// ---------------------------------------------------------------------------
export async function provideQuote(input: {
  customOrderId: string;
  tailorUserId: string;   // User.id of the requesting tailor
  quoteAmount: number;    // smallest currency unit
  currency: string;
  notes?: string;
}) {
  return db.$transaction(async tx => {
    const order = await tx.customOrder.findUnique({
      where: { id: input.customOrderId },
      include: { tailor: { select: { userId: true } } },
    });
    if (!order) throw new Error("Custom order not found");

    // Ownership check — the requesting user must own the TailorProfile
    // this order belongs to. Same isOwner-from-DB pattern as product routes.
    if (order.tailor.userId !== input.tailorUserId) {
      throw new Error("You do not own this tailor profile — cannot quote this order");
    }

    if (order.status !== "PENDING") {
      throw new Error(`Cannot quote an order in status ${order.status}`);
    }

    const updated = await tx.customOrder.update({
      where: { id: input.customOrderId },
      data: {
        quoteAmount: input.quoteAmount,
        currency: input.currency as any,
        notes: input.notes ?? order.notes,
        status: "PAYMENT_PROCESSING",
      },
    });

    await enqueueNotification({
      recipientId: order.clientId,
      type: "SYSTEM",
      data: { message: "Your tailor sent a quote", customOrderId: order.id, quoteAmount: input.quoteAmount },
    });

    return updated;
  });
}

// ---------------------------------------------------------------------------
// CONFIRM DEPOSIT PAID — called by checkout webhook handler, idempotent
// Mirrors the webhook idempotency pattern from the financial hardening —
// re-delivery of the same payment confirmation is a safe no-op.
// ---------------------------------------------------------------------------
export async function confirmDepositPaid(customOrderId: string, paymentRef: string) {
  return db.$transaction(async tx => {
    const order = await tx.customOrder.findUnique({
      where: { id: customOrderId },
      select: { status: true, depositPaid: true, tailor: { select: { userId: true } } },
    });
    if (!order) throw new Error("Custom order not found");

    // Idempotent: already confirmed → no-op, not an error
    if (order.depositPaid) {
      return { alreadyConfirmed: true };
    }

    if (order.status !== "PAYMENT_PROCESSING") {
      throw new Error(`Cannot confirm deposit for order in status ${order.status}`);
    }

    await tx.customOrder.update({
      where: { id: customOrderId },
      data: { status: "PAID", depositPaid: true },
    });

    await enqueueNotification({
      recipientId: order.tailor.userId,
      type: "SYSTEM",
      data: { message: "Deposit received — you can begin production", customOrderId, paymentRef },
    });

    return { alreadyConfirmed: false };
  });
}

// ---------------------------------------------------------------------------
// UPDATE STATUS — tailor advances the order through FULFILLING → SHIPPED
// ---------------------------------------------------------------------------
export async function updateCustomOrderStatus(
  customOrderId: string,
  tailorUserId: string,
  nextStatus: Extract<CustomOrderStatus, "FULFILLING" | "SHIPPED" | "DELIVERED" | "CANCELLED">,
) {
  return db.$transaction(async tx => {
    const order = await tx.customOrder.findUnique({
      where: { id: customOrderId },
      include: { tailor: { select: { userId: true } } },
    });
    if (!order) throw new Error("Custom order not found");
    if (order.tailor.userId !== tailorUserId) {
      throw new Error("You do not own this order");
    }

    const allowed = VALID_TRANSITIONS[order.status as CustomOrderStatus] ?? [];
    if (!allowed.includes(nextStatus)) {
      throw new Error(`Cannot transition from ${order.status} to ${nextStatus}`);
    }

    const updated = await tx.customOrder.update({
      where: { id: customOrderId },
      data: {
        status: nextStatus,
        ...(nextStatus === "DELIVERED" && { completedAt: new Date() }),
      },
    });

    await enqueueNotification({
      recipientId: order.clientId,
      type: "ORDER_UPDATE",
      data: { customOrderId, status: nextStatus },
    });

    return updated;
  });
}

// ---------------------------------------------------------------------------
// MESSAGE THREAD — in-app messaging tied to a custom order
// ---------------------------------------------------------------------------
export async function sendCustomOrderMessage(input: {
  customOrderId: string;
  senderId: string;
  body: string;
  mediaUrl?: string;
}) {
  const order = await db.customOrder.findUnique({
    where: { id: input.customOrderId },
    select: { id: true, threadId: true, clientId: true, tailor: { select: { userId: true } } },
  });
  if (!order) throw new Error("Custom order not found");

  const participantIds = [order.clientId, order.tailor.userId];
  if (!participantIds.includes(input.senderId)) {
    throw new Error("You are not a participant in this order's conversation");
  }

  // Lazily assign a threadId on first message
  const threadId = order.threadId ?? crypto.randomUUID();
  if (!order.threadId) {
    await db.customOrder.update({ where: { id: order.id }, data: { threadId } });
  }

  const receiverId = participantIds.find(id => id !== input.senderId)!;

  const message = await db.message.create({
    data: {
      senderId: input.senderId,
      receiverId,
      threadId,
      body: input.body,
      mediaUrl: input.mediaUrl ?? null,
    },
  });

  await enqueueNotification({
    recipientId: receiverId,
    type: "SYSTEM",
    data: { message: "New message about your custom order", customOrderId: order.id },
  });

  return message;
}

export async function getCustomOrderMessages(customOrderId: string, requesterId: string) {
  const order = await db.customOrder.findUnique({
    where: { id: customOrderId },
    select: { threadId: true, clientId: true, tailor: { select: { userId: true } } },
  });
  if (!order) throw new Error("Custom order not found");

  const participantIds = [order.clientId, order.tailor.userId];
  if (!participantIds.includes(requesterId)) {
    throw new Error("You are not a participant in this order's conversation");
  }

  if (!order.threadId) return [];

  return db.message.findMany({
    where: { threadId: order.threadId },
    orderBy: { createdAt: "asc" },
  });
}

// ---------------------------------------------------------------------------
// LIST ORDERS — for tailor dashboard and client order history
// ---------------------------------------------------------------------------
export async function getTailorOrders(tailorUserId: string, status?: CustomOrderStatus) {
  const tailor = await db.tailorProfile.findUnique({
    where: { userId: tailorUserId },
    select: { id: true },
  });
  if (!tailor) throw new Error("No tailor profile found for this user");

  return db.customOrder.findMany({
    where: { tailorId: tailor.id, ...(status && { status }) },
    orderBy: { createdAt: "desc" },
  });
}

export async function getClientCustomOrders(clientId: string) {
  return db.customOrder.findMany({
    where: { clientId },
    orderBy: { createdAt: "desc" },
    include: { tailor: { select: { businessName: true, city: true, country: true } } },
  });
}
