// =============================================================================
// FASNEXI — CREATOR PAYOUT SERVICE
// packages/api/src/payouts/service.ts
//
// Per White Paper §18: weekly automated payouts via Stripe Connect Express,
// minimum payout threshold $20.
//
// FINANCIAL INTEGRITY: follows the same pattern enforced in the hardening
// pass for wallets — a CreatorPayoutBatch is created transactionally with
// the commission rows it covers, and commission.status only flips from
// PENDING/CONFIRMED to PAID once the batch is created, inside the same
// transaction. This prevents the double-payout race where two concurrent
// payout runs could both select the same PENDING commissions.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

const MINIMUM_PAYOUT_AMOUNT = 2000; // $20.00 in cents

// ---------------------------------------------------------------------------
// RUN PAYOUT BATCH FOR ONE CREATOR
// Called by the scheduled worker (weekly cron). Idempotent per creator per
// run — if a batch was already created for the currently-eligible
// commissions (all now marked PROCESSING), a second call finds nothing
// PENDING left to batch and returns null.
// ---------------------------------------------------------------------------
export async function runCreatorPayout(creatorId: string): Promise<{
  batchId: string;
  totalAmount: number;
  currency: string;
  commissionCount: number;
} | null> {
  return db.$transaction(async tx => {
    // Lock in the eligible commissions atomically — CONFIRMED status means
    // the underlying order has passed any refund window (set by a separate
    // job, not shown here, that flips PENDING → CONFIRMED after N days).
    const eligible = await tx.creatorCommission.findMany({
      where: { creatorId, status: "CONFIRMED" },
      select: { id: true, amount: true, currency: true },
    });

    if (eligible.length === 0) return null;

    const totalAmount = eligible.reduce((sum, c) => sum + c.amount, 0);
    if (totalAmount < MINIMUM_PAYOUT_AMOUNT) return null;

    const currency = eligible[0].currency;
    // Guard against mixed-currency batches — split by currency in a real
    // multi-currency creator base; for a single batch we require uniformity.
    if (!eligible.every(c => c.currency === currency)) {
      throw new Error(`Creator ${creatorId} has commissions in multiple currencies — payout batching requires per-currency runs`);
    }

    const commissionIds = eligible.map(c => c.id);

    const batch = await tx.creatorPayoutBatch.create({
      data: {
        creatorId,
        totalAmount,
        currency,
        status: "PENDING",
        commissionIds,
      },
    });

    // Flip commissions to PAID atomically in the SAME transaction as batch
    // creation — this is the critical fix: no window exists where a second
    // concurrent payout run could see these commissions as still CONFIRMED.
    await tx.creatorCommission.updateMany({
      where: { id: { in: commissionIds } },
      data: { status: "PAID" },
    });

    return {
      batchId: batch.id,
      totalAmount,
      currency,
      commissionCount: eligible.length,
    };
  });
}

// ---------------------------------------------------------------------------
// SUBMIT BATCH TO STRIPE CONNECT — called after runCreatorPayout, separate
// step so a Stripe API failure doesn't roll back the commission state
// (commissions are already correctly marked PAID/batched; the batch's own
// status tracks whether the actual transfer succeeded).
// ---------------------------------------------------------------------------
export async function submitPayoutBatchToStripe(batchId: string, stripeAccountId: string) {
  const batch = await db.creatorPayoutBatch.findUnique({ where: { id: batchId } });
  if (!batch) throw new Error("Payout batch not found");
  if (batch.status !== "PENDING") throw new Error(`Batch already in status ${batch.status}`);

  await db.creatorPayoutBatch.update({
    where: { id: batchId },
    data: { status: "PROCESSING" },
  });

  try {
    // Stripe Connect transfer call — abstracted here since the actual
    // Stripe SDK call belongs in packages/api/src/financial/payments.ts's
    // PaymentProvider implementation, not duplicated in this service.
    const { stripeTransferToConnectAccount } = await import("../financial/stripe-transfers");
    const transfer = await stripeTransferToConnectAccount({
      destinationAccountId: stripeAccountId,
      amount: batch.totalAmount,
      currency: batch.currency,
      metadata: { payoutBatchId: batch.id },
    });

    await db.creatorPayoutBatch.update({
      where: { id: batchId },
      data: { status: "PAID", stripePayoutId: transfer.id, settledAt: new Date() },
    });

    const creator = await db.creatorProfile.findUnique({
      where: { id: batch.creatorId },
      select: { userId: true },
    });
    if (creator) {
      await enqueueNotification({
        recipientId: creator.userId,
        type: "PAYOUT_PROCESSED",
        data: { batchId, amount: batch.totalAmount, currency: batch.currency },
      });
    }

    return transfer;
  } catch (err) {
    // Transfer failed — mark batch FAILED but leave commissions as PAID.
    // A human reviews FAILED batches and either retries the transfer or
    // manually reverses the commission status; this is intentionally NOT
    // auto-reversed to avoid a second, potentially-conflicting write path
    // touching commission state outside the payout batch transaction.
    await db.creatorPayoutBatch.update({
      where: { id: batchId },
      data: { status: "FAILED" },
    });
    throw err;
  }
}

// ---------------------------------------------------------------------------
// GET PAYOUT HISTORY
// ---------------------------------------------------------------------------
export async function getCreatorPayoutHistory(creatorUserId: string) {
  const creator = await db.creatorProfile.findUnique({
    where: { userId: creatorUserId },
    select: { id: true },
  });
  if (!creator) throw new Error("No creator profile found");

  return db.creatorPayoutBatch.findMany({
    where: { creatorId: creator.id },
    orderBy: { createdAt: "desc" },
  });
}
