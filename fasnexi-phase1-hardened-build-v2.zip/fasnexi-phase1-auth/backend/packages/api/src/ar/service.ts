// =============================================================================
// FASNEXI — AR TRY-ON SERVICE
// packages/api/src/ar/service.ts
//
// SCOPING NOTE: AR try-on (White Paper §17.5, Phase 5 MVP) is fundamentally
// a CLIENT-SIDE feature — MediaPipe body pose runs in the browser/app via
// camera feed, not on the server. There is no meaningful "backend AR
// service" to build; the server's only role is storing which products have
// AR-compatible overlay assets and serving that metadata.
//
// This file is intentionally small and honest about that: it does NOT
// simulate pose detection or camera processing, because that would be
// fiction. What's real: the data model for AR-enabled products and the
// query the frontend's MediaPipe integration calls to check "does this
// product support try-on, and where's the overlay asset."
// =============================================================================

import { db } from "@fasnexi/db";

export interface ArOverlayAsset {
  productId: string;
  overlayImageUrl: string;   // transparent PNG silhouette for compositing
  overlayType: "top" | "accessory" | "headwear";
}

const AR_SUPPORTED_CATEGORIES = new Set(["TOP", "ACCESSORY"]);

// ---------------------------------------------------------------------------
// CHECK AR AVAILABILITY — does this product have a try-on asset?
// Real query, no fake computer vision.
// ---------------------------------------------------------------------------
export async function getArOverlayForProduct(productId: string): Promise<ArOverlayAsset | null> {
  const product = await db.product.findUnique({
    where: { id: productId },
    select: { id: true, category: true },
  });
  if (!product) return null;

  // AR try-on in Phase 5 MVP only supports categories with well-understood
  // 2D overlay compositing: TOP and ACCESSORY. DRESS/BOTTOM/FOOTWEAR require
  // full-body pose estimation, deferred to a later phase.
  if (!AR_SUPPORTED_CATEGORIES.has(product.category)) return null;

  // No vendor-facing overlay-asset upload pipeline exists yet (Phase 5 MVP
  // scope) — this correctly returns null rather than fabricating an asset
  // URL. Building that upload flow is the actual next step before this
  // function can return real data.
  return null;
}

// ---------------------------------------------------------------------------
// WHAT'S NOT HERE, AND WHY:
// - Pose detection: runs client-side via MediaPipe, never touches this server
// - Camera frame processing: client-side only, never uploaded to FasNexi
// - Real-time compositing: client-side canvas/WebGL rendering
// If server-side AR is needed later (e.g. rendered preview images for
// sharing), that requires a vendor asset upload pipeline first.
// ---------------------------------------------------------------------------
