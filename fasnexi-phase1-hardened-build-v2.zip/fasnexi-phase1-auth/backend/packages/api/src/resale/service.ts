// =============================================================================
// FASNEXI — RESALE MARKETPLACE SERVICE
// packages/api/src/resale/service.ts
//
// Per White Paper §8.3: resale integrated with Digital Wardrobe. Seller lists
// a WardrobeItem, buyer purchases, ownership transfers on completion, 10%
// platform fee.
//
// CONCURRENCY: purchasing a resale listing is the same "last unit" race
// class fixed in the hardening pass for product inventory — two buyers could
// both see status=LISTED and both attempt to buy. Fixed here with the exact
// same atomic-conditional-update pattern: updateMany WHERE status='LISTED'
// guards the transition, so only one concurrent purchase attempt succeeds.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";
import type { ResaleCondition, Currency } from "@prisma/client";

const PLATFORM_FEE_RATE = 0.10;

// ---------------------------------------------------------------------------
// CREATE LISTING
// ---------------------------------------------------------------------------
export async function createResaleListing(input: {
  wardrobeItemId: string;
  sellerId: string;
  askingPrice: number;
  currency: Currency;
  condition: ResaleCondition;
  description?: string;
}) {
  const item = await db.wardrobeItem.findUnique({
    where: { id: input.wardrobeItemId },
    select: { id: true, userId: true, isArchived: true, resaleListing: { select: { id: true, status: true } } },
  });
  if (!item) throw new Error("Wardrobe item not found");
  if (item.userId !== input.sellerId) throw new Error("You do not own this wardrobe item");
  if (item.isArchived) throw new Error("Cannot list an archived item");
  if (item.resaleListing && ["LISTED", "RESERVED"].includes(item.resaleListing.status)) {
    throw new Error("This item already has an active listing");
  }

  const platformFeeAmount = Math.round(input.askingPrice * PLATFORM_FEE_RATE);
  const sellerReceivesAmount = input.askingPrice - platformFeeAmount;

  return db.resaleItem.upsert({
    where: { wardrobeItemId: input.wardrobeItemId },
    create: {
      wardrobeItemId: input.wardrobeItemId,
      sellerId: input.sellerId,
      askingPrice: input.askingPrice,
      currency: input.currency,
      condition: input.condition,
      description: input.description,
      status: "LISTED",
      platformFeeAmount,
      sellerReceivesAmount,
      listedAt: new Date(),
    },
    update: {
      askingPrice: input.askingPrice,
      currency: input.currency,
      condition: input.condition,
      description: input.description,
      status: "LISTED",
      platformFeeAmount,
      sellerReceivesAmount,
      listedAt: new Date(),
      buyerId: null,
      soldAt: null,
    },
  });
}

// ---------------------------------------------------------------------------
// WITHDRAW LISTING — seller cancels before sale
// ---------------------------------------------------------------------------
export async function withdrawListing(resaleItemId: string, sellerId: string) {
  const result = await db.resaleItem.updateMany({
    where: { id: resaleItemId, sellerId, status: "LISTED" },
    data: { status: "WITHDRAWN" },
  });
  if (result.count === 0) {
    throw new Error("Listing not found, not owned by you, or already sold/reserved");
  }
}

// ---------------------------------------------------------------------------
// RESERVE FOR PURCHASE — atomic conditional transition LISTED → RESERVED
// This is the race-condition-safe step: only one buyer can win this update.
// Mirrors decrementInventoryHardened's updateMany + WHERE guard pattern.
// ---------------------------------------------------------------------------
export async function reserveListing(resaleItemId: string, buyerId: string): Promise<{ reserved: boolean }> {
  const listing = await db.resaleItem.findUnique({
    where: { id: resaleItemId },
    select: { sellerId: true },
  });
  if (!listing) throw new Error("Listing not found");
  if (listing.sellerId === buyerId) throw new Error("Cannot purchase your own listing");

  const result = await db.resaleItem.updateMany({
    where: { id: resaleItemId, status: "LISTED" }, // ← atomic guard, same pattern as inventory
    data: { status: "RESERVED", buyerId },
  });

  if (result.count === 0) {
    // Either doesn't exist, or another buyer won the race, or already sold
    return { reserved: false };
  }
  return { reserved: true };
}

// ---------------------------------------------------------------------------
// COMPLETE SALE — called after payment confirmation (checkout webhook).
// Transfers wardrobe item ownership atomically alongside the sale record.
// Idempotent: if already SOLD, this is a safe no-op (webhook redelivery safe).
// ---------------------------------------------------------------------------
export async function completeSale(resaleItemId: string, escrowRef: string) {
  return db.$transaction(async tx => {
    const listing = await tx.resaleItem.findUnique({
      where: { id: resaleItemId },
      select: { status: true, buyerId: true, sellerId: true, wardrobeItemId: true, askingPrice: true, currency: true },
    });
    if (!listing) throw new Error("Listing not found");

    if (listing.status === "SOLD") {
      return { alreadyCompleted: true };
    }
    if (listing.status !== "RESERVED" || !listing.buyerId) {
      throw new Error(`Cannot complete sale for listing in status ${listing.status}`);
    }

    await tx.resaleItem.update({
      where: { id: resaleItemId },
      data: { status: "SOLD", soldAt: new Date(), escrowRef },
    });

    // Transfer wardrobe item ownership to buyer — atomic within the same TX
    // as the sale completion, so ownership and sale state never diverge.
    await tx.wardrobeItem.update({
      where: { id: listing.wardrobeItemId },
      data: { userId: listing.buyerId },
    });

    await enqueueNotification({
      recipientId: listing.sellerId,
      type: "SYSTEM",
      data: { message: "Your item sold!", resaleItemId, amount: listing.askingPrice },
    });
    await enqueueNotification({
      recipientId: listing.buyerId,
      type: "ORDER_UPDATE",
      data: { message: "Purchase complete — item added to your wardrobe", resaleItemId },
    });

    return { alreadyCompleted: false };
  });
}

// ---------------------------------------------------------------------------
// RELEASE RESERVATION — payment failed/expired, return to LISTED
// ---------------------------------------------------------------------------
export async function releaseReservation(resaleItemId: string) {
  await db.resaleItem.updateMany({
    where: { id: resaleItemId, status: "RESERVED" },
    data: { status: "LISTED", buyerId: null },
  });
}

// ---------------------------------------------------------------------------
// BROWSE LISTINGS
// ---------------------------------------------------------------------------
export async function browseResaleListings(opts: {
  category?: string;
  condition?: ResaleCondition;
  maxPrice?: number;
  cursor?: string;
  limit?: number;
} = {}) {
  const { condition, maxPrice, cursor, limit = 24 } = opts;

  const listings = await db.resaleItem.findMany({
    where: {
      status: "LISTED",
      ...(condition && { condition }),
      ...(maxPrice !== undefined && { askingPrice: { lte: maxPrice } }),
      ...(cursor && { id: { lt: cursor } }),
    },
    orderBy: { listedAt: "desc" },
    take: limit + 1,
    include: {
      wardrobeItem: {
        select: { imageUrl: true, category: true, brand: true, aiColors: true },
      },
      seller: { select: { username: true, displayName: true, avatarUrl: true } },
    },
  });

  const hasMore = listings.length > limit;
  return {
    listings: hasMore ? listings.slice(0, limit) : listings,
    nextCursor: hasMore ? listings[limit - 1].id : null,
  };
}
