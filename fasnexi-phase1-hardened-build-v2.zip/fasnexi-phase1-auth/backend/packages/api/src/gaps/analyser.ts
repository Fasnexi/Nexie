// =============================================================================
// FASNEXI — WARDROBE GAP ANALYSIS SERVICE
// packages/api/src/gaps/analyser.ts
//
// Per White Paper §12.3: compares wardrobe composition against Style DNA
// occasion needs, identifies missing essential categories, generates
// prioritised GapRecommendation rows, and links to products from the
// catalog that fill each gap.
//
// Gap analysis runs:
//   1. On demand (user requests gap analysis from Nexi or wardrobe tab)
//   2. Automatically after each new wardrobe item is tagged (triggered by
//      the vision worker after tagging completes)
//   3. At most once per 24h per user (Redis gate to prevent spam)
//
// Results are stored in GapRecommendation rows so the feed can surface
// "Shop the Gap" cards without re-running analysis on every feed load.
// =============================================================================

import { db } from "@fasnexi/db";
import type { GarmentCategory, Occasion } from "@prisma/client";

// ---------------------------------------------------------------------------
// OCCASION → REQUIRED CATEGORIES MAP
// What garment categories does each occasion typically require?
// This is the FasNexi-specific taxonomy for African fashion contexts.
// ---------------------------------------------------------------------------
const OCCASION_REQUIRED_CATEGORIES: Record<string, GarmentCategory[]> = {
  WORK:           ["TOP", "BOTTOM", "FOOTWEAR"],
  CASUAL:         ["TOP", "BOTTOM", "FOOTWEAR"],
  SOCIAL:         ["TOP", "BOTTOM", "FOOTWEAR", "BAG"],
  RELIGIOUS:      ["TOP", "BOTTOM", "FOOTWEAR", "ACCESSORY"],
  CULTURAL_EVENT: ["TRADITIONAL", "FOOTWEAR", "ACCESSORY"],
  WEDDING:        ["TRADITIONAL", "DRESS", "FOOTWEAR", "ACCESSORY", "BAG"],
  FORMAL:         ["TOP", "BOTTOM", "FOOTWEAR", "BAG", "ACCESSORY"],
  SPORT:          ["ACTIVEWEAR", "FOOTWEAR"],
  TRAVEL:         ["TOP", "BOTTOM", "OUTERWEAR", "FOOTWEAR", "BAG"],
};

// Minimum items per category to be considered "covered"
const COVERAGE_MINIMUM = 2;

// ---------------------------------------------------------------------------
// MAIN ANALYSIS FUNCTION
// ---------------------------------------------------------------------------
export interface GapAnalysisResult {
  userId: string;
  gaps: GapItem[];
  wellCoveredOccasions: string[];
  analysedAt: string;
}

export interface GapItem {
  category: GarmentCategory;
  occasion: Occasion;
  priority: number; // 1 = highest
  reason: string;
  currentCount: number;
  minimumNeeded: number;
}

export async function analyseWardrobeGaps(userId: string): Promise<GapAnalysisResult> {
  // Rate gate: max once per 24h
  const lastAnalysis = await db.gapRecommendation.findFirst({
    where: { userId },
    orderBy: { createdAt: "desc" },
    select: { createdAt: true },
  });

  const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  if (lastAnalysis && lastAnalysis.createdAt > twentyFourHoursAgo) {
    // Return existing unresolved gaps without re-running
    const existing = await getExistingGaps(userId);
    return {
      userId,
      gaps: existing,
      wellCoveredOccasions: [],
      analysedAt: lastAnalysis.createdAt.toISOString(),
    };
  }

  // Fetch style profile for occasion needs
  const styleProfile = await db.styleProfile.findUnique({
    where: { userId },
    select: { primaryOccasions: true },
  });

  const primaryOccasions: Occasion[] = (styleProfile?.primaryOccasions as Occasion[]) ?? [];
  if (primaryOccasions.length === 0) {
    return {
      userId,
      gaps: [],
      wellCoveredOccasions: [],
      analysedAt: new Date().toISOString(),
    };
  }

  // Fetch all tagged, non-archived wardrobe items
  const wardrobeItems = await db.wardrobeItem.findMany({
    where: { userId, isArchived: false, aiTagged: true },
    select: { category: true, aiOccasions: true },
  });

  // Build a coverage map: occasion → category → count
  const coverage = new Map<string, Map<string, number>>();

  for (const item of wardrobeItems) {
    const itemOccasions = (item.aiOccasions as string[]).length > 0
      ? item.aiOccasions as string[]
      : inferOccasionsFromCategory(item.category);

    for (const occ of itemOccasions) {
      if (!coverage.has(occ)) coverage.set(occ, new Map());
      const catMap = coverage.get(occ)!;
      catMap.set(item.category, (catMap.get(item.category) ?? 0) + 1);
    }
  }

  // Identify gaps for each primary occasion
  const gaps: GapItem[] = [];
  const wellCovered: string[] = [];

  for (const occasion of primaryOccasions) {
    const required = OCCASION_REQUIRED_CATEGORIES[occasion] ?? [];
    const occCoverage = coverage.get(occasion) ?? new Map<string, number>();

    const occasionGaps: GapItem[] = [];

    for (const category of required) {
      const count = occCoverage.get(category) ?? 0;
      if (count < COVERAGE_MINIMUM) {
        occasionGaps.push({
          category,
          occasion,
          priority: 0, // will be set below
          reason: buildGapReason(category, occasion, count),
          currentCount: count,
          minimumNeeded: COVERAGE_MINIMUM,
        });
      }
    }

    if (occasionGaps.length === 0) {
      wellCovered.push(occasion);
    } else {
      gaps.push(...occasionGaps);
    }
  }

  // Assign priorities (1 = highest): fewer items = higher priority
  // Cultural events and weddings get priority boost
  const HIGH_PRIORITY_OCCASIONS: Occasion[] = ["CULTURAL_EVENT", "WEDDING", "RELIGIOUS"];

  gaps.sort((a, b) => {
    const aBoost = HIGH_PRIORITY_OCCASIONS.includes(a.occasion) ? -1 : 0;
    const bBoost = HIGH_PRIORITY_OCCASIONS.includes(b.occasion) ? -1 : 0;
    const aScore = a.currentCount + aBoost;
    const bScore = b.currentCount + bBoost;
    return aScore - bScore;
  });

  gaps.forEach((g, i) => { g.priority = i + 1; });

  // Persist gaps to DB, replacing any previous unresolved ones
  await db.$transaction([
    // Clear old unresolved gaps
    db.gapRecommendation.deleteMany({
      where: { userId, resolvedAt: null },
    }),
    // Create new ones
    db.gapRecommendation.createMany({
      data: gaps.map(g => ({
        userId,
        category: g.category,
        occasion: g.occasion,
        priority: g.priority,
        reason: g.reason,
      })),
    }),
  ]);

  // Link products from catalog to each gap
  await linkProductsToGaps(userId, gaps);

  return {
    userId,
    gaps,
    wellCoveredOccasions: wellCovered,
    analysedAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// GET EXISTING GAPS — for the feed and wardrobe tab (no re-analysis)
// ---------------------------------------------------------------------------
export async function getExistingGaps(userId: string): Promise<GapItem[]> {
  const recs = await db.gapRecommendation.findMany({
    where: { userId, resolvedAt: null },
    orderBy: { priority: "asc" },
    select: {
      id: true,
      category: true,
      occasion: true,
      priority: true,
      reason: true,
    },
  });

  return recs.map(r => ({
    category: r.category as GarmentCategory,
    occasion: r.occasion as Occasion,
    priority: r.priority,
    reason: r.reason,
    currentCount: 0,
    minimumNeeded: COVERAGE_MINIMUM,
  }));
}

// ---------------------------------------------------------------------------
// LINK PRODUCTS TO GAPS — finds catalog products that fill each gap
// ---------------------------------------------------------------------------
async function linkProductsToGaps(userId: string, gaps: GapItem[]): Promise<void> {
  for (const gap of gaps) {
    const gapRec = await db.gapRecommendation.findFirst({
      where: { userId, category: gap.category, occasion: gap.occasion, resolvedAt: null },
      select: { id: true },
    });
    if (!gapRec) continue;

    const products = await db.product.findMany({
      where: {
        category: gap.category,
        isPublished: true,
        isInStock: true,
        occasions: { has: gap.occasion },
      },
      take: 4,
      orderBy: { salesCount: "desc" },
      select: { id: true },
    });

    if (products.length > 0) {
      await db.gapRecommendation.update({
        where: { id: gapRec.id },
        data: {
          products: { connect: products.map(p => ({ id: p.id })) },
        },
      });
    }
  }
}

// ---------------------------------------------------------------------------
// MARK GAP RESOLVED — called when user purchases an item in that category
// ---------------------------------------------------------------------------
export async function resolveGap(
  userId: string,
  category: GarmentCategory,
  occasion: Occasion,
): Promise<void> {
  await db.gapRecommendation.updateMany({
    where: { userId, category, occasion, resolvedAt: null },
    data: { resolvedAt: new Date() },
  });
}

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------

function buildGapReason(category: GarmentCategory, occasion: Occasion, currentCount: number): string {
  const categoryLabel: Record<string, string> = {
    TOP: "tops",
    BOTTOM: "bottoms",
    DRESS: "dresses",
    OUTERWEAR: "outerwear",
    FOOTWEAR: "footwear",
    ACCESSORY: "accessories",
    BAG: "bags",
    TRADITIONAL: "traditional attire",
    ACTIVEWEAR: "activewear",
  };

  const occasionLabel: Record<string, string> = {
    WORK: "work",
    CASUAL: "everyday wear",
    SOCIAL: "social outings",
    RELIGIOUS: "religious occasions",
    CULTURAL_EVENT: "cultural events",
    WEDDING: "weddings",
    FORMAL: "formal events",
    SPORT: "sport and fitness",
    TRAVEL: "travel",
  };

  const catLabel = categoryLabel[category] ?? category.toLowerCase();
  const occLabel = occasionLabel[occasion] ?? occasion.toLowerCase();

  if (currentCount === 0) {
    return `You have no ${catLabel} tagged for ${occLabel}. Adding even one versatile option would complete this look.`;
  }
  return `You only have ${currentCount} ${catLabel} tagged for ${occLabel}. A second option gives you mix-and-match flexibility.`;
}

function inferOccasionsFromCategory(category: GarmentCategory): string[] {
  const map: Record<string, string[]> = {
    ACTIVEWEAR: ["SPORT"],
    TRADITIONAL: ["CULTURAL_EVENT", "WEDDING", "RELIGIOUS"],
    SWIMWEAR: ["CASUAL", "SOCIAL"],
    OUTERWEAR: ["WORK", "CASUAL", "TRAVEL"],
  };
  return map[category] ?? ["CASUAL"];
}
