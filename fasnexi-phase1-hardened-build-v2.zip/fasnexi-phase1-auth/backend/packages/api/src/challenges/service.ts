// =============================================================================
// FASNEXI — CHALLENGES SERVICE
// packages/api/src/challenges/service.ts
//
// Community fashion challenges per White Paper §8.1.
// Challenge lifecycle: UPCOMING → ACTIVE → VOTING → COMPLETED
// Status transitions are driven by startDate/endDate/votingEnds timestamps,
// checked by a scheduled job in the worker app (not inline).
//
// Entry rules:
//   - One entry per user per challenge
//   - Entry is a Post with type=CHALLENGE_ENTRY linked via ChallengeEntry
//   - Voting is community (any authenticated user) + optional editorial weight
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

// ---------------------------------------------------------------------------
// LIST CHALLENGES
// ---------------------------------------------------------------------------
export async function listChallenges(options: {
  status?: string;
  cursor?: string;
  limit?: number;
} = {}) {
  const { status, cursor, limit = 20 } = options;

  const challenges = await db.challenge.findMany({
    where: {
      ...(status && { status: status as any }),
      ...(cursor && { id: { lt: cursor } }),
    },
    orderBy: { startDate: "desc" },
    take: limit + 1,
    select: {
      id: true,
      title: true,
      description: true,
      theme: true,
      coverUrl: true,
      status: true,
      startDate: true,
      endDate: true,
      votingEnds: true,
      prizePool: true,
      currency: true,
      _count: { select: { entries: true } },
    },
  });

  const hasMore = challenges.length > limit;
  return {
    challenges: hasMore ? challenges.slice(0, limit) : challenges,
    nextCursor: hasMore ? challenges[limit - 1].id : null,
  };
}

// ---------------------------------------------------------------------------
// GET CHALLENGE DETAIL
// ---------------------------------------------------------------------------
export async function getChallenge(challengeId: string) {
  return db.challenge.findUnique({
    where: { id: challengeId },
    include: {
      entries: {
        orderBy: { voteCount: "desc" },
        take: 20,
        select: {
          id: true,
          voteCount: true,
          rank: true,
          createdAt: true,
          user: {
            select: { id: true, username: true, displayName: true, avatarUrl: true },
          },
          post: {
            select: { id: true, mediaUrls: true, caption: true, likeCount: true },
          },
        },
      },
      _count: { select: { entries: true } },
    },
  });
}

// ---------------------------------------------------------------------------
// SUBMIT ENTRY
// One entry per user. Creates a Post of type CHALLENGE_ENTRY and links it.
// ---------------------------------------------------------------------------
export async function submitChallengeEntry(input: {
  challengeId: string;
  userId: string;
  caption: string;
  mediaUrls: string[];
  culturalTags?: string[];
}) {
  const { challengeId, userId, caption, mediaUrls, culturalTags = [] } = input;

  // Validate challenge is ACTIVE
  const challenge = await db.challenge.findUnique({
    where: { id: challengeId },
    select: { status: true, endDate: true, maxEntries: true, title: true },
  });
  if (!challenge) throw new Error("Challenge not found");
  if (challenge.status !== "ACTIVE") throw new Error("Challenge is not currently accepting entries");
  if (new Date() > challenge.endDate) throw new Error("Challenge entry period has closed");

  // One entry per user
  const existing = await db.challengeEntry.findUnique({
    where: { challengeId_userId: { challengeId, userId } },
  });
  if (existing) throw new Error("You have already submitted an entry to this challenge");

  // Max entries cap
  if (challenge.maxEntries) {
    const count = await db.challengeEntry.count({ where: { challengeId } });
    if (count >= challenge.maxEntries) throw new Error("Challenge has reached its maximum entries");
  }

  // Create post + entry atomically
  const [entry] = await db.$transaction([
    db.challengeEntry.create({
      data: {
        challengeId,
        userId,
        post: {
          create: {
            userId,
            type: "CHALLENGE_ENTRY",
            status: "PUBLISHED",
            caption,
            mediaUrls,
            culturalTags,
            challengeId,
            publishedAt: new Date(),
            rankScore: 0,
          },
        },
      },
      include: {
        post: { select: { id: true } },
      },
    }),
  ]);

  return entry;
}

// ---------------------------------------------------------------------------
// VOTE ON ENTRY — one vote per user per challenge (not per entry)
// ---------------------------------------------------------------------------
export async function voteForEntry(
  challengeId: string,
  entryId: string,
  voterId: string,
): Promise<{ voteCount: number }> {
  const challenge = await db.challenge.findUnique({
    where: { id: challengeId },
    select: { status: true, votingEnds: true },
  });
  if (!challenge) throw new Error("Challenge not found");
  if (challenge.status !== "VOTING") throw new Error("Challenge is not in the voting phase");
  if (challenge.votingEnds && new Date() > challenge.votingEnds) {
    throw new Error("Voting period has ended");
  }

  // Verify entry belongs to this challenge
  const entry = await db.challengeEntry.findUnique({
    where: { id: entryId },
    select: { challengeId: true, userId: true, voteCount: true },
  });
  if (!entry || entry.challengeId !== challengeId) throw new Error("Entry not found in this challenge");
  if (entry.userId === voterId) throw new Error("Cannot vote for your own entry");

  // Prevent double voting: store voter+challenge combination in a simple
  // approach — use a unique constraint on a vote tracking table.
  // Phase 2 uses a Redis sorted set approach instead to avoid a schema
  // migration mid-phase: ZADD challenge:{id}:voters {timestamp} {userId}
  // The score lets us expire old votes if needed. ZSCORE check for duplicates.
  const { createClient } = await import("redis");
  const redis = createClient({ url: process.env.REDIS_URL });
  await redis.connect();

  const voteKey = `challenge:${challengeId}:votes`;
  const alreadyVoted = await redis.zScore(voteKey, voterId);
  if (alreadyVoted !== null) {
    await redis.disconnect();
    throw new Error("You have already voted in this challenge");
  }

  await redis.zAdd(voteKey, { score: Date.now(), value: voterId });
  // Set expiry: clean up 7 days after challenge ends
  await redis.expire(voteKey, 60 * 60 * 24 * 7);
  await redis.disconnect();

  // Increment vote count on the entry
  const updated = await db.challengeEntry.update({
    where: { id: entryId },
    data: { voteCount: { increment: 1 } },
    select: { voteCount: true, userId: true },
  });

  // Notify entry owner of vote milestone (every 10 votes)
  if (updated.voteCount % 10 === 0) {
    await enqueueNotification({
      recipientId: updated.userId,
      type: "SYSTEM",
      data: {
        message: `Your challenge entry reached ${updated.voteCount} votes!`,
        challengeId,
        entryId,
      },
    });
  }

  return { voteCount: updated.voteCount };
}

// ---------------------------------------------------------------------------
// ADVANCE CHALLENGE STATUS — called by scheduled worker
// ---------------------------------------------------------------------------
export async function advanceChallengeStatuses(): Promise<void> {
  const now = new Date();

  await db.$transaction([
    // UPCOMING → ACTIVE
    db.challenge.updateMany({
      where: { status: "UPCOMING", startDate: { lte: now } },
      data: { status: "ACTIVE" },
    }),
    // ACTIVE → VOTING
    db.challenge.updateMany({
      where: { status: "ACTIVE", endDate: { lte: now } },
      data: { status: "VOTING" },
    }),
    // VOTING → COMPLETED
    db.challenge.updateMany({
      where: { status: "VOTING", votingEnds: { lte: now } },
      data: { status: "COMPLETED" },
    }),
  ]);

  // Assign ranks to completed challenges
  const justCompleted = await db.challenge.findMany({
    where: { status: "COMPLETED" },
    select: { id: true },
  });

  for (const challenge of justCompleted) {
    await rankChallengeEntries(challenge.id);
  }
}

async function rankChallengeEntries(challengeId: string): Promise<void> {
  const entries = await db.challengeEntry.findMany({
    where: { challengeId },
    orderBy: { voteCount: "desc" },
    select: { id: true, userId: true, voteCount: true },
  });

  await db.$transaction(
    entries.map((entry, index) =>
      db.challengeEntry.update({
        where: { id: entry.id },
        data: { rank: index + 1 },
      }),
    ),
  );

  // Notify top 3 winners
  for (const [idx, entry] of entries.slice(0, 3).entries()) {
    await enqueueNotification({
      recipientId: entry.userId,
      type: "SYSTEM",
      data: {
        message: `Congratulations! You placed #${idx + 1} in the challenge!`,
        challengeId,
        rank: idx + 1,
      },
    });
  }
}
