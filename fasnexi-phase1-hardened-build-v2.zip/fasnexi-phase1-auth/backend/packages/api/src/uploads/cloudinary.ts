// =============================================================================
// FASNEXI — CLOUDINARY SIGNED UPLOAD
// packages/api/src/uploads/cloudinary.ts
//
// GAP FIX: POST /api/wardrobe and POST /api/video both expect a finished
// Cloudinary URL already in the request body (confirmed from source — see
// wardrobe/service.ts, video/service.ts, wardrobe/tagger.ts) — the frontend
// uploads directly to Cloudinary and only tells the backend the resulting
// URL. That means the upload itself needs to be authorized somehow; this
// is that authorization. An unsigned upload preset would also work and
// needs no backend endpoint at all, but signed uploads are the safer
// default (folder/resource constraints are enforced server-side, not just
// by preset configuration the client could theoretically bypass).
//
// Cloudinary's signature scheme: every param that will be sent to their
// upload API (except file, api_key, and signature itself) gets included in
// a deterministic string, SHA-1 hashed with the API secret appended. The
// client then sends that signature + timestamp + these exact params to
// Cloudinary directly — the backend never touches the file.
// =============================================================================

import crypto from "crypto";

const UPLOAD_FOLDERS = ["wardrobe", "posts", "video", "avatars"] as const;
export type UploadFolder = (typeof UPLOAD_FOLDERS)[number];

export interface UploadSignature {
  signature: string;
  timestamp: number;
  apiKey: string;
  cloudName: string;
  folder: string;
}

export function generateUploadSignature(opts: {
  userId: string;
  folder: UploadFolder;
}): UploadSignature {
  const apiSecret = process.env.CLOUDINARY_API_SECRET;
  const apiKey = process.env.CLOUDINARY_API_KEY;
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME;

  if (!apiSecret || !apiKey || !cloudName) {
    throw new Error("Cloudinary is not configured (CLOUDINARY_API_SECRET/API_KEY/CLOUD_NAME env vars missing)");
  }

  if (!UPLOAD_FOLDERS.includes(opts.folder)) {
    throw new Error(`folder must be one of: ${UPLOAD_FOLDERS.join(", ")}`);
  }

  const timestamp = Math.round(Date.now() / 1000);

  // Namespace uploads per-user within the folder — keeps a runaway/abusive
  // account's uploads trivially identifiable and scoped, and matches the
  // ownership-scoping pattern used everywhere else in the backend.
  const folder = `${opts.folder}/${opts.userId}`;

  // Cloudinary requires params in the signature string sorted alphabetically
  // by key, formatted as key=value pairs joined with &, secret appended
  // directly (not as a separate HMAC key — this is Cloudinary's specific
  // scheme, not a generic HMAC).
  const paramsToSign = `folder=${folder}&timestamp=${timestamp}${apiSecret}`;
  const signature = crypto.createHash("sha1").update(paramsToSign).digest("hex");

  return { signature, timestamp, apiKey, cloudName, folder };
}
