// =============================================================================
// FASNEXI — PRODUCT CATALOG SERVICE
// packages/api/src/products/catalog.ts
//
// Handles product listing, search, and detail retrieval.
// Search is backed by Typesense (Phase 6), but falls through to PostgreSQL
// full-text until the Typesense cluster is live — controlled by the
// TYPESENSE_HOST env var. This means Phase 1 works with zero additional infra.
// =============================================================================

import { db } from "@fasnexi/db";
import type { GarmentCategory, Currency } from "@prisma/client";

export interface ProductListOptions {
  query?: string;
  category?: GarmentCategory;
  minPrice?: number;
  maxPrice?: number;
  currency?: Currency;
  culturalTags?: string[];
  occasion?: string;
  styleArchetype?: string;
  vendorId?: string;
  inStockOnly?: boolean;
  cursor?: string;
  limit?: number;
  sortBy?: "price_asc" | "price_desc" | "newest" | "popular";
}

export interface ProductListResult {
  products: ProductSummary[];
  nextCursor: string | null;
  total: number;
}

export interface ProductSummary {
  id: string;
  name: string;
  slug: string;
  priceAmount: number;
  priceCurrency: string;
  imageUrls: string[];
  category: string;
  isInStock: boolean;
  salesCount: number;
  vendor: { id: string; businessName: string };
}

// ---------------------------------------------------------------------------
// LIST PRODUCTS — with optional full-text search and faceted filtering
// ---------------------------------------------------------------------------
export async function listProducts(options: ProductListOptions): Promise<ProductListResult> {
  const {
    query,
    category,
    minPrice,
    maxPrice,
    currency = "USD",
    culturalTags,
    occasion,
    inStockOnly = true,
    cursor,
    limit = 24,
    sortBy = "popular",
  } = options;

  // Use Typesense if configured (Phase 6+), otherwise fall through to PostgreSQL
  if (process.env.TYPESENSE_HOST && query) {
    return searchWithTypesense(options);
  }

  const where: Record<string, any> = {
    isPublished: true,
    ...(inStockOnly && { isInStock: true }),
    ...(category && { category }),
    ...(minPrice !== undefined && { priceAmount: { gte: minPrice } }),
    ...(maxPrice !== undefined && { priceAmount: { lte: maxPrice } }),
    ...(culturalTags?.length && { culturalTags: { hasSome: culturalTags } }),
    ...(occasion && { occasions: { has: occasion } }),
    ...(vendorId && { vendorId }),
    ...(currency && { priceCurrency: currency }),
    // PostgreSQL full-text search on name + description when no Typesense
    ...(query && {
      OR: [
        { name: { contains: query, mode: "insensitive" } },
        { description: { contains: query, mode: "insensitive" } },
      ],
    }),
  };

  // Cursor for keyset pagination
  if (cursor) {
    where.id = { lt: cursor };
  }

  const orderBy = {
    price_asc:  [{ priceAmount: "asc" as const }],
    price_desc: [{ priceAmount: "desc" as const }],
    newest:     [{ createdAt: "desc" as const }],
    popular:    [{ salesCount: "desc" as const }, { createdAt: "desc" as const }],
  }[sortBy];

  const [products, total] = await Promise.all([
    db.product.findMany({
      where,
      orderBy,
      take: limit + 1, // +1 to detect next page
      select: {
        id: true,
        name: true,
        slug: true,
        priceAmount: true,
        priceCurrency: true,
        imageUrls: true,
        category: true,
        isInStock: true,
        salesCount: true,
        vendor: { select: { id: true, businessName: true } },
      },
    }),
    db.product.count({ where }),
  ]);

  const hasMore = products.length > limit;
  const items = hasMore ? products.slice(0, limit) : products;

  return {
    products: items as ProductSummary[],
    nextCursor: hasMore ? items[items.length - 1].id : null,
    total,
  };
}

// ---------------------------------------------------------------------------
// GET PRODUCT DETAIL
// ---------------------------------------------------------------------------
export async function getProduct(idOrSlug: string) {
  const product = await db.product.findFirst({
    where: {
      OR: [{ id: idOrSlug }, { slug: idOrSlug }],
      isPublished: true,
    },
    include: {
      vendor: {
        select: {
          id: true,
          businessName: true,
          logoUrl: true,
          country: true,
          isVerified: true,
        },
      },
      reviews: {
        orderBy: { createdAt: "desc" },
        take: 10,
        select: {
          id: true,
          rating: true,
          body: true,
          imageUrls: true,
          createdAt: true,
        },
      },
    },
  });

  if (!product) return null;

  // Aggregate review stats
  const reviewStats = product.reviews.length > 0
    ? {
        count: product.reviews.length,
        average: product.reviews.reduce((sum, r) => sum + r.rating, 0) / product.reviews.length,
      }
    : { count: 0, average: 0 };

  return { ...product, reviewStats };
}

// ---------------------------------------------------------------------------
// UPDATE INVENTORY — called after order fulfillment
// ---------------------------------------------------------------------------
export async function decrementInventory(
  productId: string,
  quantity: number,
): Promise<void> {
  await db.$transaction(async tx => {
    const product = await tx.product.findUnique({
      where: { id: productId },
      select: { inventoryCount: true },
    });

    if (!product || product.inventoryCount < quantity) {
      throw new Error(`Insufficient inventory for product ${productId}`);
    }

    const newCount = product.inventoryCount - quantity;
    await tx.product.update({
      where: { id: productId },
      data: {
        inventoryCount: newCount,
        isInStock: newCount > 0,
      },
    });
  });
}

// ---------------------------------------------------------------------------
// TYPESENSE FALLBACK — returns same shape as PostgreSQL path
// Only active when TYPESENSE_HOST is configured (Phase 6+)
// ---------------------------------------------------------------------------
async function searchWithTypesense(options: ProductListOptions): Promise<ProductListResult> {
  // Lazy import so the Typesense client is never bundled into the DB worker
  const Typesense = await import("typesense");
  const client = new Typesense.Client({
    nodes: [{ host: process.env.TYPESENSE_HOST!, port: 443, protocol: "https" }],
    apiKey: process.env.TYPESENSE_SEARCH_KEY!,
    connectionTimeoutSeconds: 2,
  });

  const searchParameters = {
    q: options.query ?? "*",
    query_by: "name,description,brand,culturalTags",
    filter_by: [
      "isPublished:=true",
      options.category ? `category:=${options.category}` : null,
      options.inStockOnly ? "isInStock:=true" : null,
      options.minPrice !== undefined ? `priceAmount:>=${options.minPrice}` : null,
      options.maxPrice !== undefined ? `priceAmount:<=${options.maxPrice}` : null,
    ].filter(Boolean).join(" && "),
    sort_by: {
      price_asc: "priceAmount:asc",
      price_desc: "priceAmount:desc",
      newest: "createdAt:desc",
      popular: "salesCount:desc",
    }[options.sortBy ?? "popular"],
    per_page: options.limit ?? 24,
  };

  const result = await client.collections("products").documents().search(searchParameters);
  const productIds = (result.hits ?? []).map((h: any) => h.document.id);

  const products = await db.product.findMany({
    where: { id: { in: productIds }, isPublished: true },
    select: {
      id: true, name: true, slug: true, priceAmount: true, priceCurrency: true,
      imageUrls: true, category: true, isInStock: true, salesCount: true,
      vendor: { select: { id: true, businessName: true } },
    },
  });

  // Restore Typesense ranking order
  const idIndex = new Map(productIds.map((id: string, i: number) => [id, i]));
  products.sort((a, b) => (idIndex.get(a.id) ?? 0) - (idIndex.get(b.id) ?? 0));

  return {
    products: products as ProductSummary[],
    nextCursor: null, // Typesense handles its own pagination via page param
    total: result.found ?? 0,
  };
}
