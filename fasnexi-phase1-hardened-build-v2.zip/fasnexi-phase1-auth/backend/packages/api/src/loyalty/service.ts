// =============================================================================
// FASNEXI — LOYALTY SERVICE
// packages/api/src/loyalty/service.ts
//
// Per White Paper §18: Bronze → Silver → Gold → Platinum tiers.
// Thresholds (lifetime points): 0 / 500 / 2000 / 5000.
// Earn: 1pt per $1 spent (already wired in Phase 1 checkout webhook via
// LoyaltyTransaction ref=orderId idempotency guard), 5pt per post,
// 10pt per challenge entry.
//
// Every point movement is an append-only LoyaltyTransaction row, mirroring
// the wallet ledger pattern from the hardening pass — LoyaltyAccount.points
// is a cached projection, never the source of truth. Idempotency is
// enforced via a unique `ref` per transaction where the caller supplies one
// (e.g. `order:${orderId}`, `challenge-entry:${entryId}`), so retried calls
// (webhook redelivery, duplicate client requests) never double-award points.
// =============================================================================

import { db } from "@fasnexi/db";
import type { LoyaltyTier } from "@prisma/client";

const TIER_THRESHOLDS: Array<{ tier: LoyaltyTier; minLifetimePoints: number }> = [
  { tier: "PLATINUM", minLifetimePoints: 5000 },
  { tier: "GOLD",     minLifetimePoints: 2000 },
  { tier: "SILVER",   minLifetimePoints: 500 },
  { tier: "BRONZE",   minLifetimePoints: 0 },
];

export function computeTier(lifetimePoints: number): LoyaltyTier {
  for (const t of TIER_THRESHOLDS) {
    if (lifetimePoints >= t.minLifetimePoints) return t.tier;
  }
  return "BRONZE";
}

export interface AwardPointsInput {
  userId: string;
  delta: number;      // positive = earn, negative = redeem
  reason: string;
  ref?: string;        // idempotency key — e.g. `order:${orderId}`
}

export interface AwardPointsResult {
  awarded: boolean;    // false if this ref was already processed
  points: number;
  lifetimePoints: number;
  tier: LoyaltyTier;
  tierChanged: boolean;
}

// ---------------------------------------------------------------------------
// AWARD (or redeem) POINTS — idempotent via ref, tier recomputed atomically
// ---------------------------------------------------------------------------
export async function awardPoints(input: AwardPointsInput): Promise<AwardPointsResult> {
  const { userId, delta, reason, ref } = input;

  return db.$transaction(async tx => {
    // Idempotency check — if ref supplied and already recorded, no-op
    if (ref) {
      const existing = await tx.loyaltyTransaction.findFirst({
        where: { ref, account: { userId } },
        select: { id: true },
      });
      if (existing) {
        const account = await tx.loyaltyAccount.findUniqueOrThrow({ where: { userId } });
        return {
          awarded: false,
          points: account.points,
          lifetimePoints: account.lifetimePoints,
          tier: account.tier,
          tierChanged: false,
        };
      }
    }

    const account = await tx.loyaltyAccount.upsert({
      where: { userId },
      create: { userId, points: 0, lifetimePoints: 0, tier: "BRONZE" },
      update: {},
    });

    const previousTier = account.tier;

    // Redemptions (negative delta) never reduce lifetimePoints — lifetime
    // is a monotonic "total ever earned" figure used purely for tier status,
    // matching standard loyalty program semantics (spending doesn't demote you).
    const newPoints = account.points + delta;
    if (newPoints < 0) {
      throw new Error(`Insufficient points: have ${account.points}, requested redemption of ${-delta}`);
    }
    const newLifetime = delta > 0 ? account.lifetimePoints + delta : account.lifetimePoints;
    const newTier = computeTier(newLifetime);

    await tx.loyaltyAccount.update({
      where: { userId },
      data: { points: newPoints, lifetimePoints: newLifetime, tier: newTier },
    });

    await tx.loyaltyTransaction.create({
      data: { accountId: account.id, delta, reason, ref: ref ?? null },
    });

    return {
      awarded: true,
      points: newPoints,
      lifetimePoints: newLifetime,
      tier: newTier,
      tierChanged: newTier !== previousTier,
    };
  });
}

// ---------------------------------------------------------------------------
// GET ACCOUNT SUMMARY
// ---------------------------------------------------------------------------
export async function getLoyaltyAccount(userId: string) {
  const account = await db.loyaltyAccount.upsert({
    where: { userId },
    create: { userId, points: 0, lifetimePoints: 0, tier: "BRONZE" },
    update: {},
  });

  const nextTier = TIER_THRESHOLDS
    .filter(t => t.minLifetimePoints > account.lifetimePoints)
    .sort((a, b) => a.minLifetimePoints - b.minLifetimePoints)[0];

  return {
    tier: account.tier,
    points: account.points,
    lifetimePoints: account.lifetimePoints,
    nextTier: nextTier
      ? { tier: nextTier.tier, pointsNeeded: nextTier.minLifetimePoints - account.lifetimePoints }
      : null,
  };
}

// ---------------------------------------------------------------------------
// TRANSACTION HISTORY — paginated
// ---------------------------------------------------------------------------
export async function getLoyaltyHistory(userId: string, cursor?: string, limit = 30) {
  const account = await db.loyaltyAccount.findUnique({ where: { userId }, select: { id: true } });
  if (!account) return { transactions: [], nextCursor: null };

  const transactions = await db.loyaltyTransaction.findMany({
    where: { accountId: account.id, ...(cursor && { id: { lt: cursor } }) },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
  });

  const hasMore = transactions.length > limit;
  return {
    transactions: hasMore ? transactions.slice(0, limit) : transactions,
    nextCursor: hasMore ? transactions[limit - 1].id : null,
  };
}

// ---------------------------------------------------------------------------
// EARN HOOKS — called from other services (posts, challenges)
// Each uses a stable ref so retried calls are no-ops, not double-awards.
// ---------------------------------------------------------------------------
export const EARN_RATES = {
  POST_PUBLISHED: 5,
  CHALLENGE_ENTRY: 10,
} as const;

export async function awardPointsForPost(userId: string, postId: string) {
  return awardPoints({
    userId,
    delta: EARN_RATES.POST_PUBLISHED,
    reason: "Published a post",
    ref: `post:${postId}`,
  });
}

export async function awardPointsForChallengeEntry(userId: string, entryId: string) {
  return awardPoints({
    userId,
    delta: EARN_RATES.CHALLENGE_ENTRY,
    reason: "Entered a challenge",
    ref: `challenge-entry:${entryId}`,
  });
}

// ---------------------------------------------------------------------------
// REDEEM — points → discount voucher. Validates sufficient balance via the
// same insufficient-balance guard as awardPoints (negative delta path).
// ---------------------------------------------------------------------------
export async function redeemPoints(userId: string, points: number, reason: string): Promise<AwardPointsResult> {
  if (points <= 0) throw new Error("Redemption amount must be positive");
  return awardPoints({ userId, delta: -points, reason, ref: `redeem:${userId}:${Date.now()}` });
}
