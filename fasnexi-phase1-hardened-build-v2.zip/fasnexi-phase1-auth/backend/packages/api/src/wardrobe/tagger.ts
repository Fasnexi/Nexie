// =============================================================================
// FASNEXI — CLAUDE VISION GARMENT TAGGER
// packages/api/src/wardrobe/tagger.ts
//
// AI-powered automatic garment attribute tagging using Claude Vision.
// Per White Paper §12.2, the pipeline is:
//   image uploaded → Cloudinary signed URL → Claude Vision API →
//   structured JSON tag schema → stored in WardrobeItem.aiTags fields
//
// This runs asynchronously via the BullMQ `nexi-vision` queue.
// The worker processor calls tagGarment() — the web app only enqueues.
//
// Tag schema output (per White Paper §12.2):
//   color[], pattern, silhouette, category, subcategory, occasion[],
//   season[], formality (1–5), fabricType, styleCategory[], culturalAffinity[]
// =============================================================================

import Anthropic from "@anthropic-ai/sdk";
import { db } from "@fasnexi/db";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

// ---------------------------------------------------------------------------
// VISION PROMPT — elicits the exact JSON schema from Claude Vision
// ---------------------------------------------------------------------------
const VISION_SYSTEM_PROMPT = `You are a fashion analysis AI specialising in African and global fashion. Analyse garment images and return structured JSON tag data. Be precise and factual. Only describe what you can see.`;

const VISION_USER_PROMPT = `Analyse this garment image and return ONLY a valid JSON object — no markdown fences, no explanation — with this exact structure:

{
  "colors": ["string"],
  "pattern": "solid|striped|checked|floral|geometric|abstract|animal_print|ankara|kente|adire|other",
  "silhouette": "fitted|relaxed|oversized|flared|straight|wrap|bodycon|a-line|other",
  "category": "TOP|BOTTOM|DRESS|OUTERWEAR|FOOTWEAR|ACCESSORY|BAG|TRADITIONAL|ACTIVEWEAR|SWIMWEAR|UNDERWEAR",
  "subcategory": "string",
  "occasions": ["WORK","CASUAL","SOCIAL","RELIGIOUS","CULTURAL_EVENT","WEDDING","FORMAL","SPORT","TRAVEL"],
  "seasons": ["ALL_YEAR","DRY","WET","HARMATTAN","SPRING","SUMMER","AUTUMN","WINTER"],
  "formalityScore": 1,
  "fabricType": "string or null",
  "styleCategories": ["MODERN_MINIMALIST","AFROCENTRIC_MAXIMALIST","STREET_STYLE_FUSION","TRADITIONAL_CONTEMPORARY","AVANT_GARDE","EVERYDAY_ELEGANCE"],
  "culturalAffinity": ["WEST_AFRICAN","EAST_AFRICAN","NORTH_AFRICAN","SOUTHERN_AFRICAN","CENTRAL_AFRICAN","GLOBAL","other"]
}

Rules:
- colors: list up to 4 dominant colours as descriptive words (e.g. "cobalt blue", "burnt orange")
- formalityScore: 1=very casual, 2=casual, 3=smart casual, 4=semi-formal, 5=formal
- occasions: list all occasions this garment suits
- seasons: include ALL_YEAR if the fabric is versatile; use specific seasons for seasonal fabrics
- styleCategories: can include multiple if the garment bridges styles
- culturalAffinity: include GLOBAL if the garment has no specific cultural coding
- If a field cannot be determined from the image, use null for strings or [] for arrays
- Do NOT include any text outside the JSON object`;

// ---------------------------------------------------------------------------
// TAG SCHEMA — mirrors the WardrobeItem AI fields exactly
// ---------------------------------------------------------------------------
export interface GarmentTagSchema {
  colors: string[];
  pattern: string | null;
  silhouette: string | null;
  category: string;
  subcategory: string | null;
  occasions: string[];
  seasons: string[];
  formalityScore: number | null;
  fabricType: string | null;
  styleCategories: string[];
  culturalAffinity: string[];
  confidence: number; // 0–1, estimated from completeness of tags
}

// ---------------------------------------------------------------------------
// TAG GARMENT — called by the BullMQ worker
// ---------------------------------------------------------------------------
export async function tagGarment(
  wardrobeItemId: string,
  imageUrl: string,
): Promise<GarmentTagSchema> {
  // Mark as tagging in progress
  await db.wardrobeItem.update({
    where: { id: wardrobeItemId },
    data: { aiTagged: false }, // reset to false while processing
  });

  let tags: GarmentTagSchema;
  try {
    tags = await callClaudeVision(imageUrl);
  } catch (err: any) {
    // Mark item as failed but don't throw — worker should not retry on parse errors
    await db.wardrobeItem.update({
      where: { id: wardrobeItemId },
      data: { aiTagged: false, aiConfidence: 0 },
    });
    throw new Error(`Vision tagging failed for ${wardrobeItemId}: ${err.message}`);
  }

  // Write tags back to the WardrobeItem
  await db.wardrobeItem.update({
    where: { id: wardrobeItemId },
    data: {
      aiTagged: true,
      aiTaggedAt: new Date(),
      aiColors: tags.colors,
      aiPattern: tags.pattern,
      aiSilhouette: tags.silhouette,
      aiOccasions: tags.occasions as any,
      aiSeasons: tags.seasons as any,
      aiFormalityScore: tags.formalityScore,
      aiFabricType: tags.fabricType,
      aiStyleCategories: tags.styleCategories,
      aiCulturalAffinity: tags.culturalAffinity,
      aiConfidence: tags.confidence,
    },
  });

  return tags;
}

// ---------------------------------------------------------------------------
// CLAUDE VISION API CALL
// ---------------------------------------------------------------------------
async function callClaudeVision(imageUrl: string): Promise<GarmentTagSchema> {
  // Fetch the image as base64 for Claude Vision
  // In production: use a Cloudinary signed URL directly (Claude accepts URLs)
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 500, // Tag schema is compact — 500 tokens is generous
    system: VISION_SYSTEM_PROMPT,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "image",
            source: {
              type: "url",
              url: imageUrl,
            },
          },
          {
            type: "text",
            text: VISION_USER_PROMPT,
          },
        ],
      },
    ],
  });

  const rawText = response.content
    .filter(b => b.type === "text")
    .map(b => (b as Anthropic.TextBlock).text)
    .join("")
    .trim();

  return parseVisionResponse(rawText);
}

// ---------------------------------------------------------------------------
// PARSE & VALIDATE — defensive parsing with field-level fallbacks
// ---------------------------------------------------------------------------
function parseVisionResponse(rawText: string): GarmentTagSchema {
  // Strip markdown fences if Claude disobeyed instructions
  const clean = rawText.replace(/```json\n?|```/g, "").trim();

  let parsed: Record<string, any>;
  try {
    parsed = JSON.parse(clean);
  } catch {
    throw new Error(`Claude Vision returned non-JSON: ${clean.slice(0, 200)}`);
  }

  // Validate required fields
  if (!parsed.category || typeof parsed.category !== "string") {
    throw new Error("Vision response missing required field: category");
  }

  // Normalise and sanitise each field
  const colors = Array.isArray(parsed.colors)
    ? parsed.colors.filter((c: any) => typeof c === "string").slice(0, 4)
    : [];

  const occasions = Array.isArray(parsed.occasions)
    ? parsed.occasions.filter(isValidOccasion)
    : [];

  const seasons = Array.isArray(parsed.seasons)
    ? parsed.seasons.filter(isValidSeason)
    : [];

  const styleCategories = Array.isArray(parsed.styleCategories)
    ? parsed.styleCategories.filter(isValidArchetype)
    : [];

  const culturalAffinity = Array.isArray(parsed.culturalAffinity)
    ? parsed.culturalAffinity.filter((c: any) => typeof c === "string")
    : [];

  const formalityScore =
    typeof parsed.formalityScore === "number" &&
    parsed.formalityScore >= 1 &&
    parsed.formalityScore <= 5
      ? Math.round(parsed.formalityScore)
      : null;

  // Estimate confidence from completeness
  const filledFields = [
    colors.length > 0,
    parsed.pattern != null,
    parsed.silhouette != null,
    occasions.length > 0,
    seasons.length > 0,
    formalityScore != null,
    styleCategories.length > 0,
  ].filter(Boolean).length;
  const confidence = filledFields / 7;

  return {
    colors,
    pattern: typeof parsed.pattern === "string" ? parsed.pattern : null,
    silhouette: typeof parsed.silhouette === "string" ? parsed.silhouette : null,
    category: parsed.category.toUpperCase(),
    subcategory: typeof parsed.subcategory === "string" ? parsed.subcategory : null,
    occasions,
    seasons,
    formalityScore,
    fabricType: typeof parsed.fabricType === "string" ? parsed.fabricType : null,
    styleCategories,
    culturalAffinity,
    confidence,
  };
}

// ---------------------------------------------------------------------------
// VALIDATORS — match Prisma enum values exactly
// ---------------------------------------------------------------------------
const VALID_OCCASIONS = new Set([
  "WORK","CASUAL","SOCIAL","RELIGIOUS","CULTURAL_EVENT","WEDDING","FORMAL","SPORT","TRAVEL",
]);
const VALID_SEASONS = new Set([
  "ALL_YEAR","DRY","WET","HARMATTAN","SPRING","SUMMER","AUTUMN","WINTER",
]);
const VALID_ARCHETYPES = new Set([
  "MODERN_MINIMALIST","AFROCENTRIC_MAXIMALIST","STREET_STYLE_FUSION",
  "TRADITIONAL_CONTEMPORARY","AVANT_GARDE","EVERYDAY_ELEGANCE",
]);

const isValidOccasion  = (v: any): v is string => typeof v === "string" && VALID_OCCASIONS.has(v);
const isValidSeason    = (v: any): v is string => typeof v === "string" && VALID_SEASONS.has(v);
const isValidArchetype = (v: any): v is string => typeof v === "string" && VALID_ARCHETYPES.has(v);
