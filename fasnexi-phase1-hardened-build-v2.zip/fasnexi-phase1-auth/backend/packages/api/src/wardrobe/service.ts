// =============================================================================
// FASNEXI — WARDROBE SERVICE
// packages/api/src/wardrobe/service.ts
//
// Manages wardrobe item CRUD, upload pipeline, and outfit combination logic.
// AI tagging is triggered asynchronously via BullMQ — this service only
// creates the DB row and enqueues the vision job. The tagger writes back
// the AI fields when complete.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNexiVisionTag } from "../queue";
import type { GarmentCategory } from "@prisma/client";

// ---------------------------------------------------------------------------
// CREATE WARDROBE ITEM — called after Cloudinary upload succeeds
// ---------------------------------------------------------------------------
export interface CreateWardrobeItemInput {
  userId: string;
  imageUrl: string;
  thumbnailUrl?: string;
  category: GarmentCategory;
  subcategory?: string;
  brand?: string;
  colorLabel?: string;
  size?: string;
  purchasePrice?: number;
  purchaseCurrency?: string;
  purchaseDate?: Date;
  notes?: string;
}

export async function createWardrobeItem(input: CreateWardrobeItemInput) {
  const item = await db.wardrobeItem.create({
    data: {
      userId: input.userId,
      imageUrl: input.imageUrl,
      thumbnailUrl: input.thumbnailUrl ?? null,
      category: input.category,
      subcategory: input.subcategory ?? null,
      brand: input.brand ?? null,
      colorLabel: input.colorLabel ?? null,
      size: input.size ?? null,
      purchasePrice: input.purchasePrice ?? null,
      purchaseCurrency: input.purchaseCurrency as any ?? null,
      purchaseDate: input.purchaseDate ?? null,
      notes: input.notes ?? null,
      aiTagged: false,
    },
    select: {
      id: true,
      imageUrl: true,
      category: true,
      subcategory: true,
      brand: true,
      colorLabel: true,
      aiTagged: true,
      createdAt: true,
    },
  });

  // Enqueue AI tagging immediately — runs in worker app, non-blocking
  await enqueueNexiVisionTag({
    wardrobeItemId: item.id,
    userId: input.userId,
    imageUrl: input.imageUrl,
  });

  return item;
}

// ---------------------------------------------------------------------------
// GET WARDROBE — paginated list for the wardrobe tab
// ---------------------------------------------------------------------------
export async function getWardrobeItems(
  userId: string,
  opts: {
    category?: GarmentCategory;
    cursor?: string;
    limit?: number;
    taggedOnly?: boolean;
  } = {},
) {
  const { category, cursor, limit = 40, taggedOnly = false } = opts;

  const items = await db.wardrobeItem.findMany({
    where: {
      userId,
      isArchived: false,
      ...(category && { category }),
      ...(taggedOnly && { aiTagged: true }),
      ...(cursor && { id: { lt: cursor } }),
    },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    select: {
      id: true,
      imageUrl: true,
      thumbnailUrl: true,
      category: true,
      subcategory: true,
      brand: true,
      colorLabel: true,
      size: true,
      aiTagged: true,
      aiColors: true,
      aiPattern: true,
      aiOccasions: true,
      aiSeasons: true,
      aiFormalityScore: true,
      aiStyleCategories: true,
      aiCulturalAffinity: true,
      aiConfidence: true,
      wearCount: true,
      lastWornAt: true,
      createdAt: true,
    },
  });

  const hasMore = items.length > limit;
  return {
    items: hasMore ? items.slice(0, limit) : items,
    nextCursor: hasMore ? items[limit - 1].id : null,
    total: await db.wardrobeItem.count({ where: { userId, isArchived: false } }),
  };
}

// ---------------------------------------------------------------------------
// GET SINGLE ITEM
// ---------------------------------------------------------------------------
export async function getWardrobeItem(itemId: string, userId: string) {
  const item = await db.wardrobeItem.findFirst({
    where: { id: itemId, userId },
    include: {
      outfitItems: {
        include: {
          outfit: {
            select: { id: true, name: true, occasion: true, imageUrl: true },
          },
        },
        take: 10,
      },
    },
  });
  return item;
}

// ---------------------------------------------------------------------------
// UPDATE WARDROBE ITEM — user-editable fields only
// AI tag fields are never directly writable from this service
// ---------------------------------------------------------------------------
export async function updateWardrobeItem(
  itemId: string,
  userId: string,
  data: {
    category?: GarmentCategory;
    subcategory?: string;
    brand?: string;
    colorLabel?: string;
    size?: string;
    notes?: string;
    purchasePrice?: number;
    purchaseDate?: Date;
  },
) {
  // Ownership check
  const existing = await db.wardrobeItem.findFirst({
    where: { id: itemId, userId },
    select: { id: true },
  });
  if (!existing) throw new Error("Wardrobe item not found");

  return db.wardrobeItem.update({
    where: { id: itemId },
    data: {
      category: data.category,
      subcategory: data.subcategory ?? null,
      brand: data.brand ?? null,
      colorLabel: data.colorLabel ?? null,
      size: data.size ?? null,
      notes: data.notes ?? null,
      purchasePrice: data.purchasePrice ?? null,
      purchaseDate: data.purchaseDate ?? null,
    },
  });
}

// ---------------------------------------------------------------------------
// ARCHIVE (soft delete) — never hard delete wardrobe items
// Resale listings block deletion (handled by FK constraint)
// ---------------------------------------------------------------------------
export async function archiveWardrobeItem(itemId: string, userId: string): Promise<void> {
  const item = await db.wardrobeItem.findFirst({
    where: { id: itemId, userId },
    select: { id: true, resaleListing: { select: { id: true, status: true } } },
  });
  if (!item) throw new Error("Wardrobe item not found");

  if (item.resaleListing && ["LISTED", "RESERVED"].includes(item.resaleListing.status)) {
    throw new Error("Cannot archive an item with an active resale listing. Withdraw the listing first.");
  }

  await db.wardrobeItem.update({
    where: { id: itemId },
    data: { isArchived: true },
  });
}

// ---------------------------------------------------------------------------
// RECORD WEAR — increments wearCount and sets lastWornAt
// Called when user marks an outfit as "worn today" from the calendar
// ---------------------------------------------------------------------------
export async function recordWear(itemId: string, userId: string, wornOn: Date): Promise<void> {
  const item = await db.wardrobeItem.findFirst({
    where: { id: itemId, userId },
    select: { id: true },
  });
  if (!item) throw new Error("Wardrobe item not found");

  await db.wardrobeItem.update({
    where: { id: itemId },
    data: {
      wearCount: { increment: 1 },
      lastWornAt: wornOn,
    },
  });
}

// ---------------------------------------------------------------------------
// RETRIGGER AI TAGGING — user can request re-tag if they uploaded a bad image
// ---------------------------------------------------------------------------
export async function retriggerTagging(itemId: string, userId: string): Promise<void> {
  const item = await db.wardrobeItem.findFirst({
    where: { id: itemId, userId },
    select: { id: true, imageUrl: true },
  });
  if (!item) throw new Error("Wardrobe item not found");

  // Reset tag state
  await db.wardrobeItem.update({
    where: { id: itemId },
    data: {
      aiTagged: false,
      aiTaggedAt: null,
      aiColors: [],
      aiPattern: null,
      aiSilhouette: null,
      aiOccasions: [],
      aiSeasons: [],
      aiFormalityScore: null,
      aiFabricType: null,
      aiStyleCategories: [],
      aiCulturalAffinity: [],
      aiConfidence: null,
    },
  });

  await enqueueNexiVisionTag({
    wardrobeItemId: item.id,
    userId,
    imageUrl: item.imageUrl,
  });
}

// ---------------------------------------------------------------------------
// WARDROBE ANALYTICS — cost-per-wear, category distribution, style evolution
// ---------------------------------------------------------------------------
export async function getWardrobeAnalytics(userId: string) {
  const items = await db.wardrobeItem.findMany({
    where: { userId, isArchived: false },
    select: {
      id: true,
      category: true,
      purchasePrice: true,
      wearCount: true,
      aiStyleCategories: true,
      aiOccasions: true,
      createdAt: true,
    },
  });

  const totalItems = items.length;
  const totalValue = items.reduce((s, i) => s + (i.purchasePrice ? Number(i.purchasePrice) : 0), 0);

  // Category breakdown
  const categoryMap: Record<string, number> = {};
  for (const item of items) {
    categoryMap[item.category] = (categoryMap[item.category] ?? 0) + 1;
  }

  // Style distribution
  const styleMap: Record<string, number> = {};
  for (const item of items) {
    for (const style of item.aiStyleCategories) {
      styleMap[style] = (styleMap[style] ?? 0) + 1;
    }
  }

  // Cost-per-wear for items with both price and wear data
  const cpwItems = items
    .filter(i => i.purchasePrice && i.wearCount > 0)
    .map(i => ({
      id: i.id,
      category: i.category,
      purchasePrice: Number(i.purchasePrice),
      wearCount: i.wearCount,
      costPerWear: Number(i.purchasePrice) / i.wearCount,
    }))
    .sort((a, b) => a.costPerWear - b.costPerWear);

  // Utilisation: items worn at least once / total items (excl. new items < 30 days)
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const establishedItems = items.filter(i => i.createdAt < thirtyDaysAgo);
  const wornItems = establishedItems.filter(i => i.wearCount > 0);
  const utilisationRate = establishedItems.length > 0
    ? wornItems.length / establishedItems.length
    : null;

  return {
    totalItems,
    totalValue,
    categoryBreakdown: categoryMap,
    styleDistribution: styleMap,
    topCostPerWear: cpwItems.slice(0, 5),
    utilisationRate,
  };
}
