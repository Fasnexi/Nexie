// =============================================================================
// FASNEXI — FEED RANKING ENGINE
// packages/api/src/feed/ranking.ts
//
// Style DNA-weighted content ranking per White Paper §8.1.
// Signals weighted:
//   +0.30 — primary style archetype match
//   +0.15 — secondary archetype match
//   +0.20 — cultural tag overlap (proportional)
//   +0.20 — creator affinity (user follows this creator)
//   +0.10 — wardrobe gap relevance (post fills a known gap)
//   ×decay — recency half-life 48 hours
//
// rankScore is pre-computed and stored on Post.rankScore by the async
// updatePostRankScore() function, triggered by BullMQ after each engagement
// event. The DB query sorts by this stored score (indexed), then we
// over-fetch 3× and re-rank client-side with Style DNA context that can't
// economically live in SQL (per-user profile vectors).
// =============================================================================

import { db } from "@fasnexi/db";

export interface FeedOptions {
  userId: string;
  cursor?: string;   // last post id — keyset pagination on (rankScore, id)
  limit?: number;
}

export interface FeedPost {
  id: string;
  userId: string;
  type: string;
  caption: string | null;
  mediaUrls: string[];
  culturalTags: string[];
  likeCount: number;
  commentCount: number;
  saveCount: number;
  rankScore: number;
  publishedAt: Date | null;
  user: { id: string; username: string; displayName: string; avatarUrl: string | null };
  taggedProducts: Array<{
    productId: string;
    product: { id: string; name: string; priceAmount: number; priceCurrency: string; imageUrls: string[] };
  }>;
}

// ---------------------------------------------------------------------------
// PERSONALISED FEED
// ---------------------------------------------------------------------------
export async function getPersonalisedFeed(options: FeedOptions): Promise<FeedPost[]> {
  const { userId, cursor, limit = 20 } = options;

  // Fetch Style DNA, social graph, and gap data in parallel
  const [styleProfile, following, gapRecs] = await Promise.all([
    db.styleProfile.findUnique({
      where: { userId },
      select: {
        primaryArchetype: true,
        secondaryArchetype: true,
        heritage: true,
        primaryOccasions: true,
      },
    }),
    db.follow.findMany({
      where: { followerId: userId },
      select: { followingId: true },
    }),
    db.gapRecommendation.findMany({
      where: { userId, resolvedAt: null },
      select: { category: true },
    }),
  ]);

  const followingIds = new Set(following.map(f => f.followingId));
  const gapCategories = new Set(gapRecs.map(g => g.category));

  // Keyset cursor condition
  let cursorCondition: Record<string, any> = {};
  if (cursor) {
    const pivot = await db.post.findUnique({
      where: { id: cursor },
      select: { rankScore: true },
    });
    if (pivot) {
      cursorCondition = {
        OR: [
          { rankScore: { lt: pivot.rankScore } },
          { rankScore: pivot.rankScore, id: { lt: cursor } },
        ],
      };
    }
  }

  // Over-fetch 3× limit for re-ranking
  const posts = await db.post.findMany({
    where: {
      status: "PUBLISHED",
      publishedAt: { not: null },
      userId: { not: userId }, // exclude own posts from home feed
      ...cursorCondition,
    },
    orderBy: [{ rankScore: "desc" }, { id: "desc" }],
    take: limit * 3,
    select: {
      id: true,
      userId: true,
      type: true,
      caption: true,
      mediaUrls: true,
      culturalTags: true,
      styleCategories: true,
      likeCount: true,
      commentCount: true,
      saveCount: true,
      viewCount: true,
      rankScore: true,
      publishedAt: true,
      user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      taggedProducts: {
        select: {
          productId: true,
          product: {
            select: { id: true, name: true, priceAmount: true, priceCurrency: true, imageUrls: true },
          },
        },
      },
    },
  });

  // Re-rank with Style DNA context and trim to requested limit
  return reRankByStyleDNA(posts, { styleProfile, followingIds, gapCategories })
    .slice(0, limit) as FeedPost[];
}

// ---------------------------------------------------------------------------
// CLIENT-SIDE RE-RANKING — runs in < 5ms on 60 candidates
// ---------------------------------------------------------------------------
function reRankByStyleDNA(
  posts: any[],
  ctx: {
    styleProfile: {
      primaryArchetype: string | null;
      secondaryArchetype: string | null;
      heritage: string[];
      primaryOccasions: string[];
    } | null;
    followingIds: Set<string>;
    gapCategories: Set<string>;
  },
): any[] {
  return posts
    .map(post => {
      let score = post.rankScore ?? 0;

      if (ctx.styleProfile) {
        if (post.styleCategories?.includes(ctx.styleProfile.primaryArchetype))   score += 0.30;
        if (post.styleCategories?.includes(ctx.styleProfile.secondaryArchetype)) score += 0.15;

        // Cultural tag overlap — proportional to fraction of tags matched
        const heritage = ctx.styleProfile.heritage ?? [];
        const matched = post.culturalTags.filter((t: string) => heritage.includes(t)).length;
        if (post.culturalTags.length > 0) score += 0.20 * (matched / post.culturalTags.length);
      }

      if (ctx.followingIds.has(post.userId)) score += 0.20;

      // Gap relevance: tagged product fills a wardrobe gap
      if (post.taggedProducts?.some((tp: any) => ctx.gapCategories.has(tp.product?.category))) {
        score += 0.10;
      }

      // Recency decay: half-life 48 hours
      if (post.publishedAt) {
        const ageHours = (Date.now() - new Date(post.publishedAt).getTime()) / 3_600_000;
        score *= Math.pow(0.5, ageHours / 48);
      }

      return { ...post, _score: score };
    })
    .sort((a, b) => b._score - a._score);
}

// ---------------------------------------------------------------------------
// ASYNC RANK SCORE UPDATER
// Called by BullMQ `feed-ranking` queue after engagement events.
// Writes back to Post.rankScore so the next DB query has it pre-sorted.
// ---------------------------------------------------------------------------
export async function updatePostRankScore(postId: string): Promise<void> {
  const post = await db.post.findUnique({
    where: { id: postId },
    select: {
      likeCount: true, commentCount: true,
      shareCount: true, saveCount: true,
      viewCount: true,  publishedAt: true,
    },
  });
  if (!post?.publishedAt) return;

  const ageHours = (Date.now() - new Date(post.publishedAt).getTime()) / 3_600_000;
  const decay = Math.pow(0.5, ageHours / 48);

  // Weighted engagement sum (comments and saves weighted higher than likes)
  const engagement =
    post.likeCount    * 1.0 +
    post.commentCount * 1.5 +
    post.shareCount   * 2.0 +
    post.saveCount    * 1.8 +
    post.viewCount    * 0.1;

  // log1p smooths low-count posts; decay ensures freshness
  const rankScore = Math.log1p(engagement) * decay;

  await db.post.update({
    where: { id: postId },
    data: { rankScore },
  });
}
