// =============================================================================
// FASNEXI — PHASE 5 TESTS
// packages/api/src/__tests__/phase5.test.ts
// =============================================================================

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { db } from "@fasnexi/db";
import { createVideoPost } from "../video/service";
import { reserveTicket, releaseTicketReservation, validateTicketScan, createTicketTier } from "../events/ticketing";
import { scheduleLiveEvent, goLive, StubStreamProvider } from "../live/service";
import { getArOverlayForProduct } from "../ar/service";

const ts = Date.now();
let userA: any, organizerUser: any;
let organizerId: string, eventId: string, tierId: string;

beforeAll(async () => {
  [userA, organizerUser] = await Promise.all([
    db.user.create({ data: { email: `p5a-${ts}@t.com`, username: `p5a_${ts}`, displayName: "A", roles: ["CONSUMER"], activeRole: "CONSUMER" } }),
    db.user.create({ data: { email: `p5o-${ts}@t.com`, username: `p5o_${ts}`, displayName: "O", roles: ["CONSUMER","EVENT_ORGANIZER"], activeRole: "EVENT_ORGANIZER" } }),
  ]);

  const org = await db.eventOrganizerProfile.create({ data: { userId: organizerUser.id, orgName: "Test Org" } });
  organizerId = org.id;

  const event = await scheduleLiveEvent({
    organizerId, title: "Test Show", startDate: new Date(Date.now() + 3600_000), productIds: [],
  });
  eventId = event.id;

  const tier = await createTicketTier({
    eventId, organizerUserId: organizerUser.id, name: "General", priceAmount: 1000, currency: "USD", capacity: 2,
  });
  tierId = tier.id;
});

afterAll(async () => {
  await db.user.delete({ where: { id: userA.id } }).catch(() => {});
  await db.user.delete({ where: { id: organizerUser.id } }).catch(() => {});
  await db.$disconnect();
});

// ---------------------------------------------------------------------------
// VIDEO
// ---------------------------------------------------------------------------
describe("Video content", () => {
  it("createVideoPost rejects videos over 3 minutes", async () => {
    await expect(
      createVideoPost({ userId: userA.id, videoUrl: "x", thumbnailUrl: "y", durationSeconds: 181 }),
    ).rejects.toThrow("exceeds maximum duration");
  });

  it("createVideoPost accepts videos at exactly the limit", async () => {
    const post = await createVideoPost({ userId: userA.id, videoUrl: "https://cdn.test/v.mp4", thumbnailUrl: "https://cdn.test/t.jpg", durationSeconds: 180 });
    expect(post.type).toBe("VIDEO");
    expect(post.videoDuration).toBe(180);
  });
});

// ---------------------------------------------------------------------------
// TICKETING — capacity race, same class as inventory overselling
// ---------------------------------------------------------------------------
describe("Ticketing — capacity race condition", () => {
  it("three concurrent reservations against capacity=2 → exactly 2 succeed", async () => {
    const buyers = await Promise.all([
      db.user.create({ data: { email: `p5-b1-${ts}@t.com`, username: `p5b1_${ts}`, displayName: "B1", roles: ["CONSUMER"], activeRole: "CONSUMER" } }),
      db.user.create({ data: { email: `p5-b2-${ts}@t.com`, username: `p5b2_${ts}`, displayName: "B2", roles: ["CONSUMER"], activeRole: "CONSUMER" } }),
      db.user.create({ data: { email: `p5-b3-${ts}@t.com`, username: `p5b3_${ts}`, displayName: "B3", roles: ["CONSUMER"], activeRole: "CONSUMER" } }),
    ]);

    try {
      const results = await Promise.allSettled(buyers.map(b => reserveTicket(tierId, b.id)));
      const succeeded = results.filter(r => r.status === "fulfilled" && (r.value as any).reserved);
      expect(succeeded.length).toBe(2); // exactly capacity, never more

      const tier = await db.ticketTier.findUniqueOrThrow({ where: { id: tierId } });
      expect(tier.sold).toBe(2); // never exceeds capacity
    } finally {
      for (const b of buyers) await db.user.delete({ where: { id: b.id } }).catch(() => {});
    }
  });

  it("releaseTicketReservation returns capacity to the pool", async () => {
    const freshTier = await createTicketTier({
      eventId, organizerUserId: organizerUser.id, name: "Release Test", priceAmount: 500, currency: "USD", capacity: 1,
    });
    const buyer = await db.user.create({ data: { email: `p5-rel-${ts}@t.com`, username: `p5rel_${ts}`, displayName: "R", roles: ["CONSUMER"], activeRole: "CONSUMER" } });

    try {
      const r1 = await reserveTicket(freshTier.id, buyer.id);
      expect(r1.reserved).toBe(true);

      await releaseTicketReservation(r1.ticketId!);
      const afterRelease = await db.ticketTier.findUniqueOrThrow({ where: { id: freshTier.id } });
      expect(afterRelease.sold).toBe(0);

      // Capacity is available again
      const r2 = await reserveTicket(freshTier.id, buyer.id);
      expect(r2.reserved).toBe(true);
    } finally {
      await db.user.delete({ where: { id: buyer.id } }).catch(() => {});
    }
  });

  it("validateTicketScan rejects a second scan of the same ticket", async () => {
    const buyer = await db.user.create({ data: { email: `p5-scan-${ts}@t.com`, username: `p5scan_${ts}`, displayName: "S", roles: ["CONSUMER"], activeRole: "CONSUMER" } });
    const scanTier = await createTicketTier({ eventId, organizerUserId: organizerUser.id, name: "Scan Test", priceAmount: 100, currency: "USD", capacity: 5 });

    try {
      const { ticketId } = await reserveTicket(scanTier.id, buyer.id);
      const ticket = await db.ticket.findUniqueOrThrow({ where: { id: ticketId! } });

      const r1 = await validateTicketScan(ticket.qrPayload, organizerUser.id);
      expect(r1.valid).toBe(true);

      const r2 = await validateTicketScan(ticket.qrPayload, organizerUser.id);
      expect(r2.valid).toBe(false);
      expect(r2.reason).toContain("already used");
    } finally {
      await db.user.delete({ where: { id: buyer.id } }).catch(() => {});
    }
  });

  it("validateTicketScan rejects a scanner who doesn't own the event", async () => {
    const buyer = await db.user.create({ data: { email: `p5-wrongscan-${ts}@t.com`, username: `p5wrongscan_${ts}`, displayName: "W", roles: ["CONSUMER"], activeRole: "CONSUMER" } });
    const otherOrganizer = await db.user.create({ data: { email: `p5-otherorg-${ts}@t.com`, username: `p5otherorg_${ts}`, displayName: "OO", roles: ["CONSUMER","EVENT_ORGANIZER"], activeRole: "EVENT_ORGANIZER" } });

    try {
      const scanTier2 = await createTicketTier({ eventId, organizerUserId: organizerUser.id, name: "Wrong Scanner Test", priceAmount: 100, currency: "USD", capacity: 5 });
      const { ticketId } = await reserveTicket(scanTier2.id, buyer.id);
      const ticket = await db.ticket.findUniqueOrThrow({ where: { id: ticketId! } });

      const result = await validateTicketScan(ticket.qrPayload, otherOrganizer.id);
      expect(result.valid).toBe(false);
      expect(result.reason).toContain("not authorized");
    } finally {
      await db.user.delete({ where: { id: buyer.id } }).catch(() => {});
      await db.user.delete({ where: { id: otherOrganizer.id } }).catch(() => {});
    }
  });
});

// ---------------------------------------------------------------------------
// LIVE STREAMING — verify the stub fails loudly, not silently
// ---------------------------------------------------------------------------
describe("Live streaming — honest stub behaviour", () => {
  it("StubStreamProvider.createLiveStream throws a clear configuration error", async () => {
    const provider = new StubStreamProvider();
    await expect(provider.createLiveStream("fake-event-id")).rejects.toThrow("not yet configured");
  });

  it("goLive surfaces the stub's error rather than silently succeeding", async () => {
    await expect(goLive(eventId, organizerUser.id)).rejects.toThrow("not yet configured");
  });

  it("goLive still checks ownership BEFORE attempting to stream (fails fast on auth, not just on streaming)", async () => {
    const notOwner = await db.user.create({ data: { email: `p5-notowner-${ts}@t.com`, username: `p5notowner_${ts}`, displayName: "N", roles: ["CONSUMER"], activeRole: "CONSUMER" } });
    try {
      await expect(goLive(eventId, notOwner.id)).rejects.toThrow("do not own");
    } finally {
      await db.user.delete({ where: { id: notOwner.id } }).catch(() => {});
    }
  });

  it("scheduleLiveEvent works fully without any streaming dependency", async () => {
    const event = await scheduleLiveEvent({
      organizerId, title: "No streaming needed", startDate: new Date(Date.now() + 86400000), productIds: [],
    });
    expect(event.id).toBeDefined();
    expect(event.isLive).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// AR — verify honest null-return, not fake overlay data
// ---------------------------------------------------------------------------
describe("AR try-on — honest scoping", () => {
  it("getArOverlayForProduct returns null for unsupported categories (DRESS)", async () => {
    const vendor = await db.user.create({ data: { email: `p5-ven-${ts}@t.com`, username: `p5ven_${ts}`, displayName: "V", roles: ["CONSUMER","VENDOR"], activeRole: "VENDOR" } });
    const vp = await db.vendorProfile.create({ data: { userId: vendor.id, businessName: "V", country: "NG", isVerified: true } });
    const product = await db.product.create({
      data: { vendorId: vp.id, name: "AR Test Dress", slug: `ar-dress-${ts}`, priceAmount: 100, priceCurrency: "USD", imageUrls: [], category: "DRESS", inventoryCount: 1, isPublished: true, isInStock: true, salesCount: 0 },
    });

    try {
      const overlay = await getArOverlayForProduct(product.id);
      expect(overlay).toBeNull(); // DRESS not in AR_SUPPORTED_CATEGORIES
    } finally {
      await db.user.delete({ where: { id: vendor.id } }).catch(() => {});
    }
  });

  it("getArOverlayForProduct returns null (not fake data) even for supported categories, since no asset pipeline exists yet", async () => {
    const vendor = await db.user.create({ data: { email: `p5-ven2-${ts}@t.com`, username: `p5ven2_${ts}`, displayName: "V2", roles: ["CONSUMER","VENDOR"], activeRole: "VENDOR" } });
    const vp = await db.vendorProfile.create({ data: { userId: vendor.id, businessName: "V2", country: "NG", isVerified: true } });
    const product = await db.product.create({
      data: { vendorId: vp.id, name: "AR Test Top", slug: `ar-top-${ts}`, priceAmount: 100, priceCurrency: "USD", imageUrls: [], category: "TOP", inventoryCount: 1, isPublished: true, isInStock: true, salesCount: 0 },
    });

    try {
      const overlay = await getArOverlayForProduct(product.id);
      // TOP is category-eligible but there's no real overlay asset — must
      // return null, NOT a fabricated overlayImageUrl.
      expect(overlay).toBeNull();
    } finally {
      await db.user.delete({ where: { id: vendor.id } }).catch(() => {});
    }
  });
});
