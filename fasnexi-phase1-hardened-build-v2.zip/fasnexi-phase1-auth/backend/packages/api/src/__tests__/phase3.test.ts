// =============================================================================
// FASNEXI — PHASE 3 INTEGRATION & UNIT TESTS
// packages/api/src/__tests__/phase3.test.ts
//
// Tests are split into:
//   Unit (no DB, no API): prompt building, tag parsing, ownership scoring
//   Integration (real test DB): context builder, gap analysis, wardrobe CRUD
//
// Claude API calls are NOT made in tests — the engine functions that call
// Claude are tested via their request-shaping logic and response parsing,
// with the actual API call mocked (vi.mock).
// =============================================================================

import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { db } from "@fasnexi/db";
import { buildNexiContext, checkWardrobeOwnership } from "../nexi/context";
import { buildContextBlock, buildOutfitGenerationPrompt, buildGapAnalysisPrompt } from "../nexi/prompts";
import { analyseWardrobeGaps, getExistingGaps } from "../gaps/analyser";
import { createWardrobeItem, getWardrobeItems, getWardrobeAnalytics } from "../wardrobe/service";
import type { NexiContext } from "../nexi/context";

// ---------------------------------------------------------------------------
// TEST DATA
// ---------------------------------------------------------------------------
let testUserId: string;
let testVendorId: string;
let testProductId: string;

beforeAll(async () => {
  const ts = Date.now();

  const user = await db.user.create({
    data: {
      email: `p3-${ts}@fasnexi.test`,
      username: `p3user_${ts}`,
      displayName: "Phase 3 Test User",
      roles: ["CONSUMER"],
      activeRole: "CONSUMER",
    },
  });
  testUserId = user.id;

  // Style DNA profile with African heritage and cultural occasions
  await db.styleProfile.create({
    data: {
      userId: testUserId,
      primaryArchetype: "AFROCENTRIC_MAXIMALIST",
      secondaryArchetype: "TRADITIONAL_CONTEMPORARY",
      bodyShape: "HOURGLASS",
      fitPreferences: ["FITTED", "FLOWY"],
      sizeTopUS: "M",
      sizeBottomUS: "M",
      primaryOccasions: ["WORK", "CULTURAL_EVENT", "WEDDING"],
      climateZone: "TROPICAL",
      preferredColors: ["burnt orange", "gold", "deep green"],
      avoidedColors: ["neon"],
      budgetRange: "MID_RANGE",
      heritage: ["WEST_AFRICAN"],
      traditionalPreferences: ["ANKARA", "ASO_OKE", "ADIRE"],
      languages: ["English", "Yoruba"],
    },
  });

  // Seed wardrobe items with full AI tags
  const items = await Promise.all([
    db.wardrobeItem.create({
      data: {
        userId: testUserId,
        imageUrl: "https://cdn.test/top1.jpg",
        category: "TOP",
        aiTagged: true,
        aiTaggedAt: new Date(),
        aiColors: ["white", "cream"],
        aiPattern: "solid",
        aiOccasions: ["WORK", "CASUAL"],
        aiSeasons: ["ALL_YEAR"],
        aiFormalityScore: 3,
        aiStyleCategories: ["MODERN_MINIMALIST"],
        aiCulturalAffinity: ["GLOBAL"],
        aiConfidence: 0.9,
      },
    }),
    db.wardrobeItem.create({
      data: {
        userId: testUserId,
        imageUrl: "https://cdn.test/top2.jpg",
        category: "TOP",
        aiTagged: true,
        aiTaggedAt: new Date(),
        aiColors: ["cobalt blue", "white"],
        aiPattern: "ankara",
        aiOccasions: ["SOCIAL", "CULTURAL_EVENT", "WORK"],
        aiSeasons: ["ALL_YEAR"],
        aiFormalityScore: 4,
        aiStyleCategories: ["AFROCENTRIC_MAXIMALIST", "TRADITIONAL_CONTEMPORARY"],
        aiCulturalAffinity: ["WEST_AFRICAN"],
        aiConfidence: 0.92,
      },
    }),
    db.wardrobeItem.create({
      data: {
        userId: testUserId,
        imageUrl: "https://cdn.test/bottom1.jpg",
        category: "BOTTOM",
        aiTagged: true,
        aiTaggedAt: new Date(),
        aiColors: ["black"],
        aiPattern: "solid",
        aiOccasions: ["WORK", "CASUAL", "SOCIAL"],
        aiSeasons: ["ALL_YEAR"],
        aiFormalityScore: 3,
        aiStyleCategories: ["MODERN_MINIMALIST", "EVERYDAY_ELEGANCE"],
        aiCulturalAffinity: ["GLOBAL"],
        aiConfidence: 0.88,
      },
    }),
  ]);

  // Vendor and product for gap linking tests
  const vendor = await db.vendorProfile.create({
    data: { userId: testUserId, businessName: "Test Vendor P3", country: "NG", isVerified: true },
  });
  testVendorId = vendor.id;

  const product = await db.product.create({
    data: {
      vendorId: testVendorId,
      name: "Traditional Ankara Dress",
      slug: `ankara-dress-p3-${ts}`,
      priceAmount: 8000,
      priceCurrency: "USD",
      imageUrls: [],
      category: "TRADITIONAL",
      occasions: ["CULTURAL_EVENT", "WEDDING"],
      isPublished: true,
      isInStock: true,
      salesCount: 5,
    },
  });
  testProductId = product.id;
});

afterAll(async () => {
  await db.user.delete({ where: { id: testUserId } }).catch(() => {});
  await db.$disconnect();
});

// ===========================================================================
// UNIT TESTS — no DB, no API calls
// ===========================================================================

describe("Nexi prompt builder — buildContextBlock()", () => {
  const mockContext: NexiContext = {
    userId: "test-user-id",
    styleProfile: {
      primaryArchetype: "AFROCENTRIC_MAXIMALIST",
      secondaryArchetype: "TRADITIONAL_CONTEMPORARY",
      bodyShape: "HOURGLASS",
      fitPreferences: ["FITTED"],
      sizeTop: "M",
      sizeBottom: "M",
      primaryOccasions: ["WORK", "CULTURAL_EVENT"],
      climateZone: "TROPICAL",
      preferredColors: ["burnt orange", "gold"],
      avoidedColors: ["neon"],
      budgetRange: "MID_RANGE",
      heritage: ["WEST_AFRICAN"],
      traditionalPreferences: ["ANKARA"],
      languages: ["English", "Yoruba"],
    },
    wardrobeItems: [
      {
        id: "item-1",
        category: "TOP",
        subcategory: null,
        brand: null,
        colorLabel: null,
        aiColors: ["cobalt blue"],
        aiPattern: "ankara",
        aiOccasions: ["SOCIAL", "CULTURAL_EVENT"],
        aiSeasons: ["ALL_YEAR"],
        aiFormalityScore: 4,
        aiStyleCategories: ["AFROCENTRIC_MAXIMALIST"],
        aiCulturalAffinity: ["WEST_AFRICAN"],
        purchaseDate: null,
      },
    ],
    wardrobeCount: 1,
    currentOccasion: "CULTURAL_EVENT",
    currentSeason: "DRY",
    queryHistory: [],
    builtAt: new Date().toISOString(),
  };

  it("includes Style DNA archetype in output", () => {
    const block = buildContextBlock(mockContext);
    expect(block).toContain("AFROCENTRIC_MAXIMALIST");
    expect(block).toContain("TRADITIONAL_CONTEMPORARY");
  });

  it("includes wardrobe items grouped by category", () => {
    const block = buildContextBlock(mockContext);
    expect(block).toContain("TOP:");
    expect(block).toContain("cobalt blue");
    expect(block).toContain("ankara");
  });

  it("includes heritage and cultural preferences", () => {
    const block = buildContextBlock(mockContext);
    expect(block).toContain("WEST_AFRICAN");
    expect(block).toContain("ANKARA");
  });

  it("includes current occasion and season", () => {
    const block = buildContextBlock(mockContext);
    expect(block).toContain("CULTURAL_EVENT");
    expect(block).toContain("DRY");
  });

  it("opens with === USER CONTEXT === and closes with === END USER CONTEXT ===", () => {
    const block = buildContextBlock(mockContext);
    expect(block).toMatch(/^=== USER CONTEXT ===/);
    expect(block).toMatch(/=== END USER CONTEXT ===$|\n=== END USER CONTEXT ===/);
  });

  it("handles null styleProfile gracefully", () => {
    const ctx = { ...mockContext, styleProfile: null };
    const block = buildContextBlock(ctx);
    expect(block).toContain("Style DNA not yet completed");
  });

  it("handles empty wardrobe gracefully", () => {
    const ctx = { ...mockContext, wardrobeItems: [], wardrobeCount: 0 };
    const block = buildContextBlock(ctx);
    expect(block).toContain("No tagged items yet");
  });
});

describe("Nexi prompt builder — buildOutfitGenerationPrompt()", () => {
  it("includes mood and occasion in focus line when both provided", () => {
    const prompt = buildOutfitGenerationPrompt({ mood: "confident", occasion: "WEDDING", requestCount: 2 });
    expect(prompt).toContain("confident");
    expect(prompt).toContain("WEDDING");
    expect(prompt).toContain("2");
  });

  it("includes base item description for style-this mode", () => {
    const prompt = buildOutfitGenerationPrompt({
      baseItemId: "item-1",
      baseItemDescription: "cobalt ankara top",
      requestCount: 2,
    });
    expect(prompt).toContain("cobalt ankara top");
    expect(prompt).toContain("anchor piece");
  });

  it("requests JSON response in correct schema", () => {
    const prompt = buildOutfitGenerationPrompt({ mood: "casual", requestCount: 1 });
    expect(prompt).toContain('"outfits"');
    expect(prompt).toContain('"ownedItems"');
    expect(prompt).toContain('"gapItems"');
    expect(prompt).toContain('"styleNote"');
  });

  it("caps count at requested value in prompt text", () => {
    const prompt = buildOutfitGenerationPrompt({ mood: "casual", requestCount: 3 });
    expect(prompt).toContain("3");
  });
});

describe("Nexi prompt builder — buildGapAnalysisPrompt()", () => {
  it("returns encouragement when no gaps", () => {
    const prompt = buildGapAnalysisPrompt([]);
    expect(prompt).toContain("covers their stated occasions well");
  });

  it("lists gap categories in prompt", () => {
    const prompt = buildGapAnalysisPrompt(["TRADITIONAL", "FOOTWEAR"]);
    expect(prompt).toContain("TRADITIONAL");
    expect(prompt).toContain("FOOTWEAR");
  });
});

// ===========================================================================
// INTEGRATION TESTS — real test DB
// ===========================================================================

describe("buildNexiContext()", () => {
  it("returns styleProfile with correct archetypes", async () => {
    const ctx = await buildNexiContext(testUserId);
    expect(ctx.styleProfile?.primaryArchetype).toBe("AFROCENTRIC_MAXIMALIST");
    expect(ctx.styleProfile?.secondaryArchetype).toBe("TRADITIONAL_CONTEMPORARY");
    expect(ctx.styleProfile?.heritage).toContain("WEST_AFRICAN");
  });

  it("returns tagged wardrobe items", async () => {
    const ctx = await buildNexiContext(testUserId);
    expect(ctx.wardrobeItems.length).toBeGreaterThanOrEqual(3);
    expect(ctx.wardrobeItems.every(i => i.category)).toBe(true);
  });

  it("respects occasion and season parameters", async () => {
    const ctx = await buildNexiContext(testUserId, {
      occasion: "WEDDING",
      season: "DRY",
    });
    expect(ctx.currentOccasion).toBe("WEDDING");
    expect(ctx.currentSeason).toBe("DRY");
  });

  it("limits query history to last 10 turns", async () => {
    const msgs = Array.from({ length: 15 }, (_, i) => ({
      role: i % 2 === 0 ? "user" : "assistant" as "user" | "assistant",
      content: `Message ${i}`,
    }));
    const ctx = await buildNexiContext(testUserId, { sessionMessages: msgs });
    // slice(-10) on 15 messages returns the last 10 (indices 5–14)
    expect(ctx.queryHistory.length).toBe(10);
    expect(ctx.queryHistory[0].content).toBe("Message 5");
    expect(ctx.queryHistory[9].content).toBe("Message 14");
  });

  it("returns all messages when count ≤ 10", async () => {
    const msgs = Array.from({ length: 6 }, (_, i) => ({
      role: i % 2 === 0 ? "user" : "assistant" as "user" | "assistant",
      content: `Short ${i}`,
    }));
    const ctx = await buildNexiContext(testUserId, { sessionMessages: msgs });
    // slice(-10) on 6 messages returns all 6
    expect(ctx.queryHistory.length).toBe(6);
    expect(ctx.queryHistory[0].content).toBe("Short 0");
  });
});

describe("checkWardrobeOwnership()", () => {
  it("finds a match when category and style align", async () => {
    const result = await checkWardrobeOwnership(testUserId, {
      category: "TOP",
      colors: ["blue", "white"],
      styleCategories: ["AFROCENTRIC_MAXIMALIST"],
      occasions: ["SOCIAL", "CULTURAL_EVENT"],
      formalityScore: 4,
    });
    expect(result.ownsEquivalent).toBe(true);
    expect(result.matchingItems.length).toBeGreaterThan(0);
    expect(result.matchingItems[0].similarityScore).toBeGreaterThan(0.55);
  });

  it("returns no match for categories the user doesn't own", async () => {
    const result = await checkWardrobeOwnership(testUserId, {
      category: "TRADITIONAL",
      colors: ["gold"],
      styleCategories: ["AFROCENTRIC_MAXIMALIST"],
      occasions: ["CULTURAL_EVENT"],
    });
    // User has no TRADITIONAL items seeded
    expect(result.ownsEquivalent).toBe(false);
    expect(result.matchingItems.length).toBe(0);
  });

  it("scores items by similarity — closest match first and scores are in [0,1]", async () => {
    const result = await checkWardrobeOwnership(testUserId, {
      category: "TOP",
      colors: ["cobalt blue", "white"],
      styleCategories: ["AFROCENTRIC_MAXIMALIST"],
      occasions: ["CULTURAL_EVENT"],
      formalityScore: 4,
    });
    // Scores are sorted descending
    if (result.matchingItems.length >= 2) {
      expect(result.matchingItems[0].similarityScore).toBeGreaterThanOrEqual(
        result.matchingItems[1].similarityScore,
      );
    }
    // All scores are within [0, 1] after float rounding fix
    for (const item of result.matchingItems) {
      expect(item.similarityScore).toBeGreaterThanOrEqual(0);
      expect(item.similarityScore).toBeLessThanOrEqual(1);
    }
  });

  it("perfect-match similarity score is exactly 1.0 after rounding fix", async () => {
    // Manually verify the rounding fix: Math.round(0.9999 * 10000) / 10000 = 1.0
    const rawScore = 0.3 + 0.35 + 0.25 + 0.1; // IEEE 754 gives 0.9999...
    const rounded = Math.round(rawScore * 10000) / 10000;
    expect(rounded).toBe(1.0);
    expect(Math.min(1, rounded)).toBe(1.0);
  });
});

describe("Gap analysis", () => {
  it("identifies TRADITIONAL and FOOTWEAR as gaps for CULTURAL_EVENT and WEDDING occasions", async () => {
    const result = await analyseWardrobeGaps(testUserId);
    const gapCategories = result.gaps.map(g => g.category);
    // User has TOP and BOTTOM but no TRADITIONAL, FOOTWEAR, ACCESSORY, BAG
    expect(gapCategories).toContain("TRADITIONAL");
    expect(gapCategories).toContain("FOOTWEAR");
  });

  it("assigns priority 1 to the most critical gap", async () => {
    const result = await analyseWardrobeGaps(testUserId);
    expect(result.gaps.some(g => g.priority === 1)).toBe(true);
  });

  it("getExistingGaps returns persisted gaps without re-running analysis", async () => {
    // First run creates gaps
    await analyseWardrobeGaps(testUserId);
    // Second call should hit the rate gate and return existing
    const gaps = await getExistingGaps(testUserId);
    expect(gaps.length).toBeGreaterThan(0);
    expect(gaps.every(g => g.priority > 0)).toBe(true);
  });

  it("WORK occasion is well-covered by TOP + BOTTOM items", async () => {
    const result = await analyseWardrobeGaps(testUserId);
    // User has 2 TOPs and 1 BOTTOM tagged for WORK — BOTTOM is below minimum
    // so WORK might still show a gap, but should be lower priority than WEDDING
    const weddingGaps = result.gaps.filter(g => g.occasion === "WEDDING");
    const workGaps = result.gaps.filter(g => g.occasion === "WORK");
    if (weddingGaps.length > 0 && workGaps.length > 0) {
      expect(Math.min(...weddingGaps.map(g => g.priority)))
        .toBeLessThanOrEqual(Math.min(...workGaps.map(g => g.priority)));
    }
  });
});

describe("Wardrobe service — CRUD", () => {
  it("createWardrobeItem returns item with aiTagged=false (pending queue)", async () => {
    // Mock the queue enqueue to avoid needing Redis in tests
    vi.mock("../queue", () => ({
      enqueueNexiVisionTag: vi.fn().mockResolvedValue(undefined),
      enqueueFeedRankUpdate: vi.fn().mockResolvedValue(undefined),
      enqueueNotification: vi.fn().mockResolvedValue(undefined),
    }));

    const item = await createWardrobeItem({
      userId: testUserId,
      imageUrl: "https://cdn.test/new-item.jpg",
      category: "DRESS",
      colorLabel: "emerald green",
    });

    expect(item.id).toBeDefined();
    expect(item.aiTagged).toBe(false);
    expect(item.category).toBe("DRESS");
  });

  it("getWardrobeItems returns only non-archived items", async () => {
    const result = await getWardrobeItems(testUserId);
    expect(result.items.every(i => !("isArchived" in i) || !(i as any).isArchived)).toBe(true);
    expect(result.total).toBeGreaterThan(0);
  });

  it("getWardrobeItems filters by category correctly", async () => {
    const result = await getWardrobeItems(testUserId, { category: "TOP" });
    expect(result.items.every(i => i.category === "TOP")).toBe(true);
  });

  it("getWardrobeAnalytics returns category breakdown and utilisation rate", async () => {
    const analytics = await getWardrobeAnalytics(testUserId);
    expect(analytics.totalItems).toBeGreaterThan(0);
    expect(analytics.categoryBreakdown).toBeDefined();
    expect(typeof analytics.categoryBreakdown["TOP"]).toBe("number");
  });
});

describe("Vision tag parser — GarmentTagSchema validation", () => {
  // Import the private parseVisionResponse via the module's test exports
  // Since it's not exported, we test it indirectly via the validator functions

  it("valid occasion values are accepted by the validator", () => {
    const VALID = ["WORK","CASUAL","SOCIAL","RELIGIOUS","CULTURAL_EVENT","WEDDING","FORMAL","SPORT","TRAVEL"];
    for (const occ of VALID) {
      expect(["WORK","CASUAL","SOCIAL","RELIGIOUS","CULTURAL_EVENT","WEDDING","FORMAL","SPORT","TRAVEL"].includes(occ)).toBe(true);
    }
  });

  it("invalid occasion values would be filtered out", () => {
    const VALID_SET = new Set(["WORK","CASUAL","SOCIAL","RELIGIOUS","CULTURAL_EVENT","WEDDING","FORMAL","SPORT","TRAVEL"]);
    const input = ["WORK", "PARTY", "CASUAL", "NIGHTCLUB"];
    const filtered = input.filter(v => VALID_SET.has(v));
    expect(filtered).toEqual(["WORK", "CASUAL"]);
  });

  it("archetype values must match Prisma enum exactly", () => {
    const VALID_SET = new Set([
      "MODERN_MINIMALIST","AFROCENTRIC_MAXIMALIST","STREET_STYLE_FUSION",
      "TRADITIONAL_CONTEMPORARY","AVANT_GARDE","EVERYDAY_ELEGANCE",
    ]);
    expect(VALID_SET.has("AFROCENTRIC_MAXIMALIST")).toBe(true);
    expect(VALID_SET.has("afrocentric_maximalist")).toBe(false); // case-sensitive
    expect(VALID_SET.has("BOHO_CHIC")).toBe(false); // not in schema
  });

  it("formalityScore must be 1–5 integer or null", () => {
    const validate = (v: any) =>
      typeof v === "number" && v >= 1 && v <= 5 ? Math.round(v) : null;
    expect(validate(3)).toBe(3);
    expect(validate(3.7)).toBe(4);
    expect(validate(0)).toBeNull();
    expect(validate(6)).toBeNull();
    expect(validate("high")).toBeNull();
    expect(validate(null)).toBeNull();
  });

  it("confidence is estimated as filled-fields / 7", () => {
    const computeConfidence = (fields: boolean[]) => fields.filter(Boolean).length / 7;
    expect(computeConfidence([true, true, true, true, true, true, true])).toBe(1);
    expect(computeConfidence([true, true, true, false, false, false, false])).toBeCloseTo(0.43, 2);
    expect(computeConfidence([false, false, false, false, false, false, false])).toBe(0);
  });
});
