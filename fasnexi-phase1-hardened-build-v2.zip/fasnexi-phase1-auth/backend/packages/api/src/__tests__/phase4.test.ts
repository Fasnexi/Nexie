// =============================================================================
// FASNEXI — PHASE 4 INTEGRATION TESTS
// packages/api/src/__tests__/phase4.test.ts
//
// Following the same verification standard as the hardening pass:
// concurrency-sensitive paths get concurrent (Promise.allSettled) tests,
// not just happy-path checks.
// =============================================================================

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { db } from "@fasnexi/db";
import { awardPoints, getLoyaltyAccount, computeTier, redeemPoints } from "@fasnexi/api/loyalty/service";
import { createResaleListing, reserveListing, completeSale, withdrawListing } from "@fasnexi/api/resale/service";
import { createPromotedListing, billImpressions } from "@fasnexi/api/promotions/service";
import { runCreatorPayout } from "@fasnexi/api/payouts/service";
import { submitCustomOrderBrief, provideQuote, confirmDepositPaid, updateCustomOrderStatus } from "@fasnexi/api/tailor/service";

const ts = Date.now();
let userA: any, userB: any, vendorUser: any, tailorUser: any, creatorUser: any;
let vendorId: string, tailorId: string, creatorProfileId: string;
let productId: string, wardrobeItemId: string;

beforeAll(async () => {
  [userA, userB, vendorUser, tailorUser, creatorUser] = await Promise.all([
    db.user.create({ data: { email: `p4a-${ts}@t.com`, username: `p4a_${ts}`, displayName: "A", roles: ["CONSUMER"], activeRole: "CONSUMER" } }),
    db.user.create({ data: { email: `p4b-${ts}@t.com`, username: `p4b_${ts}`, displayName: "B", roles: ["CONSUMER"], activeRole: "CONSUMER" } }),
    db.user.create({ data: { email: `p4v-${ts}@t.com`, username: `p4v_${ts}`, displayName: "V", roles: ["CONSUMER","VENDOR"], activeRole: "VENDOR" } }),
    db.user.create({ data: { email: `p4t-${ts}@t.com`, username: `p4t_${ts}`, displayName: "T", roles: ["CONSUMER","TAILOR"], activeRole: "TAILOR" } }),
    db.user.create({ data: { email: `p4c-${ts}@t.com`, username: `p4c_${ts}`, displayName: "C", roles: ["CONSUMER","CREATOR"], activeRole: "CREATOR" } }),
  ]);

  const [vp, tp, cp] = await Promise.all([
    db.vendorProfile.create({ data: { userId: vendorUser.id, businessName: "V", country: "NG", isVerified: true } }),
    db.tailorProfile.create({ data: { userId: tailorUser.id, country: "NG", city: "Lagos", isVerified: true, isAvailable: true } }),
    db.creatorProfile.create({ data: { userId: creatorUser.id, commissionRate: 0.12 } }),
  ]);
  vendorId = vp.id; tailorId = tp.id; creatorProfileId = cp.id;

  const product = await db.product.create({
    data: { vendorId, name: "P4Product", slug: `p4-prod-${ts}`, priceAmount: 5000, priceCurrency: "USD", imageUrls: [], category: "TOP", inventoryCount: 10, isPublished: true, isInStock: true, salesCount: 0 },
  });
  productId = product.id;

  const item = await db.wardrobeItem.create({
    data: { userId: userA.id, imageUrl: "https://cdn.test/resale.jpg", category: "DRESS", aiTagged: false },
  });
  wardrobeItemId = item.id;
});

afterAll(async () => {
  for (const u of [userA, userB, vendorUser, tailorUser, creatorUser]) {
    await db.user.delete({ where: { id: u.id } }).catch(() => {});
  }
  await db.$disconnect();
});

// ---------------------------------------------------------------------------
// LOYALTY
// ---------------------------------------------------------------------------

describe("Loyalty — tier computation", () => {
  it("0 points → BRONZE", () => expect(computeTier(0)).toBe("BRONZE"));
  it("499 points → BRONZE", () => expect(computeTier(499)).toBe("BRONZE"));
  it("500 points → SILVER", () => expect(computeTier(500)).toBe("SILVER"));
  it("1999 points → SILVER", () => expect(computeTier(1999)).toBe("SILVER"));
  it("2000 points → GOLD", () => expect(computeTier(2000)).toBe("GOLD"));
  it("4999 points → GOLD", () => expect(computeTier(4999)).toBe("GOLD"));
  it("5000 points → PLATINUM", () => expect(computeTier(5000)).toBe("PLATINUM"));
});

describe("Loyalty — award and idempotency", () => {
  it("awardPoints increases points and lifetimePoints", async () => {
    const result = await awardPoints({ userId: userA.id, delta: 100, reason: "test", ref: `test-award-${ts}-1` });
    expect(result.awarded).toBe(true);
    expect(result.points).toBeGreaterThanOrEqual(100);
  });

  it("same ref twice → second call is a no-op (awarded: false)", async () => {
    const ref = `test-award-${ts}-dedup`;
    const r1 = await awardPoints({ userId: userA.id, delta: 50, reason: "dup test", ref });
    const r2 = await awardPoints({ userId: userA.id, delta: 50, reason: "dup test", ref });
    expect(r1.awarded).toBe(true);
    expect(r2.awarded).toBe(false);
    expect(r2.points).toBe(r1.points); // unchanged by the duplicate
  });

  it("crossing a tier threshold sets tierChanged=true", async () => {
    const freshUser = await db.user.create({
      data: { email: `p4-tier-${ts}@t.com`, username: `p4tier_${ts}`, displayName: "Tier", roles: ["CONSUMER"], activeRole: "CONSUMER" },
    });
    try {
      const r1 = await awardPoints({ userId: freshUser.id, delta: 499, reason: "almost silver", ref: `tier-${ts}-1` });
      expect(r1.tier).toBe("BRONZE");
      expect(r1.tierChanged).toBe(false);

      const r2 = await awardPoints({ userId: freshUser.id, delta: 1, reason: "cross to silver", ref: `tier-${ts}-2` });
      expect(r2.tier).toBe("SILVER");
      expect(r2.tierChanged).toBe(true);
    } finally {
      await db.user.delete({ where: { id: freshUser.id } }).catch(() => {});
    }
  });

  it("redeemPoints fails when balance insufficient", async () => {
    const freshUser = await db.user.create({
      data: { email: `p4-redeem-${ts}@t.com`, username: `p4redeem_${ts}`, displayName: "R", roles: ["CONSUMER"], activeRole: "CONSUMER" },
    });
    try {
      await awardPoints({ userId: freshUser.id, delta: 10, reason: "seed", ref: `redeem-seed-${ts}` });
      await expect(redeemPoints(freshUser.id, 100, "too much")).rejects.toThrow("Insufficient points");
    } finally {
      await db.user.delete({ where: { id: freshUser.id } }).catch(() => {});
    }
  });

  it("redemption does not reduce lifetimePoints (tier is sticky)", async () => {
    const freshUser = await db.user.create({
      data: { email: `p4-sticky-${ts}@t.com`, username: `p4sticky_${ts}`, displayName: "S", roles: ["CONSUMER"], activeRole: "CONSUMER" },
    });
    try {
      await awardPoints({ userId: freshUser.id, delta: 600, reason: "reach silver", ref: `sticky-${ts}-1` });
      const beforeRedeem = await getLoyaltyAccount(freshUser.id);
      expect(beforeRedeem.tier).toBe("SILVER");

      await redeemPoints(freshUser.id, 550, "spend most of it");
      const afterRedeem = await getLoyaltyAccount(freshUser.id);
      expect(afterRedeem.tier).toBe("SILVER"); // still silver despite low points balance
      expect(afterRedeem.points).toBe(50);
      expect(afterRedeem.lifetimePoints).toBe(600); // unchanged
    } finally {
      await db.user.delete({ where: { id: freshUser.id } }).catch(() => {});
    }
  });
});

// ---------------------------------------------------------------------------
// RESALE — concurrency race + ownership transfer
// ---------------------------------------------------------------------------

describe("Resale — listing lifecycle", () => {
  it("createResaleListing rejects non-owner", async () => {
    await expect(
      createResaleListing({ wardrobeItemId, sellerId: userB.id, askingPrice: 2000, currency: "USD" as any, condition: "GOOD" as any }),
    ).rejects.toThrow("do not own");
  });

  it("createResaleListing succeeds for the actual owner", async () => {
    const listing = await createResaleListing({
      wardrobeItemId, sellerId: userA.id, askingPrice: 2000, currency: "USD" as any, condition: "GOOD" as any,
    });
    expect(listing.status).toBe("LISTED");
    expect(listing.platformFeeAmount).toBe(200); // 10% of 2000
    expect(listing.sellerReceivesAmount).toBe(1800);
  });

  it("two concurrent reservation attempts — only one wins", async () => {
    const item = await db.wardrobeItem.create({
      data: { userId: userA.id, imageUrl: "https://cdn.test/race.jpg", category: "TOP", aiTagged: false },
    });
    const listing = await createResaleListing({
      wardrobeItemId: item.id, sellerId: userA.id, askingPrice: 1000, currency: "USD" as any, condition: "NEW_WITH_TAGS" as any,
    });

    const buyerC = await db.user.create({
      data: { email: `p4-buyerc-${ts}@t.com`, username: `p4buyerc_${ts}`, displayName: "BC", roles: ["CONSUMER"], activeRole: "CONSUMER" },
    });

    try {
      const results = await Promise.allSettled([
        reserveListing(listing.id, userB.id),
        reserveListing(listing.id, buyerC.id),
      ]);

      const reserved = results.filter(r => r.status === "fulfilled" && (r.value as any).reserved);
      expect(reserved.length).toBe(1); // exactly one buyer won the race

      const final = await db.resaleItem.findUniqueOrThrow({ where: { id: listing.id } });
      expect(final.status).toBe("RESERVED");
      expect([userB.id, buyerC.id]).toContain(final.buyerId);
    } finally {
      await db.user.delete({ where: { id: buyerC.id } }).catch(() => {});
      await db.wardrobeItem.delete({ where: { id: item.id } }).catch(() => {});
    }
  });

  it("completeSale transfers wardrobe ownership atomically", async () => {
    const item = await db.wardrobeItem.create({
      data: { userId: userA.id, imageUrl: "https://cdn.test/transfer.jpg", category: "BAG", aiTagged: false },
    });
    const listing = await createResaleListing({
      wardrobeItemId: item.id, sellerId: userA.id, askingPrice: 3000, currency: "USD" as any, condition: "LIKE_NEW" as any,
    });
    await reserveListing(listing.id, userB.id);

    const result = await completeSale(listing.id, `escrow-${ts}`);
    expect(result.alreadyCompleted).toBe(false);

    const updatedItem = await db.wardrobeItem.findUniqueOrThrow({ where: { id: item.id } });
    expect(updatedItem.userId).toBe(userB.id); // ownership transferred

    const updatedListing = await db.resaleItem.findUniqueOrThrow({ where: { id: listing.id } });
    expect(updatedListing.status).toBe("SOLD");
  });

  it("completeSale is idempotent on retry (webhook redelivery safe)", async () => {
    const item = await db.wardrobeItem.create({
      data: { userId: userA.id, imageUrl: "https://cdn.test/idem.jpg", category: "ACCESSORY", aiTagged: false },
    });
    const listing = await createResaleListing({
      wardrobeItemId: item.id, sellerId: userA.id, askingPrice: 500, currency: "USD" as any, condition: "GOOD" as any,
    });
    await reserveListing(listing.id, userB.id);

    const r1 = await completeSale(listing.id, `escrow-idem-${ts}`);
    const r2 = await completeSale(listing.id, `escrow-idem-${ts}`);
    expect(r1.alreadyCompleted).toBe(false);
    expect(r2.alreadyCompleted).toBe(true);

    // Ownership only transferred once, not double-processed
    const updatedItem = await db.wardrobeItem.findUniqueOrThrow({ where: { id: item.id } });
    expect(updatedItem.userId).toBe(userB.id);
  });

  it("withdrawListing fails for a non-owner", async () => {
    const item = await db.wardrobeItem.create({
      data: { userId: userA.id, imageUrl: "https://cdn.test/wd.jpg", category: "TOP", aiTagged: false },
    });
    const listing = await createResaleListing({
      wardrobeItemId: item.id, sellerId: userA.id, askingPrice: 700, currency: "USD" as any, condition: "GOOD" as any,
    });
    await expect(withdrawListing(listing.id, userB.id)).rejects.toThrow();
  });
});

// ---------------------------------------------------------------------------
// PROMOTED LISTINGS — atomic budget guard
// ---------------------------------------------------------------------------

describe("Promoted listings — budget guard", () => {
  it("billImpressions never exceeds budgetAmount under concurrent billing", async () => {
    const promo = await createPromotedListing({
      productId, vendorUserId: vendorUser.id,
      budgetAmount: 1000, dailyBudget: 1000, cpmAmount: 10000, // 10000/1000 = 10 cost per impression
      currency: "USD", startDate: new Date(Date.now() - 1000), endDate: new Date(Date.now() + 86400000),
    });

    // budgetAmount=1000, each impression costs 10 → max 100 impressions billable.
    // Fire 20 concurrent calls each billing 10 impressions (200 total = 2000 cost,
    // double the budget) — the atomic guard must cap total spend at 1000.
    const results = await Promise.allSettled(
      Array.from({ length: 20 }, () => billImpressions(promo.id, 10)),
    );

    const final = await db.promotedProduct.findUniqueOrThrow({ where: { id: promo.id } });
    expect(final.billedAmount).toBeLessThanOrEqual(1000); // NEVER exceeds budget
    expect(final.billedAmount % 10).toBe(0); // clean multiples of per-call cost
  });

  it("createPromotedListing rejects non-owner vendor", async () => {
    await expect(
      createPromotedListing({
        productId, vendorUserId: userA.id, // userA is not the vendor
        budgetAmount: 1000, dailyBudget: 500, cpmAmount: 100,
        currency: "USD", startDate: new Date(), endDate: new Date(Date.now() + 86400000),
      }),
    ).rejects.toThrow("do not own");
  });

  it("createPromotedListing rejects endDate before startDate", async () => {
    await expect(
      createPromotedListing({
        productId, vendorUserId: vendorUser.id,
        budgetAmount: 1000, dailyBudget: 500, cpmAmount: 100,
        currency: "USD", startDate: new Date(Date.now() + 86400000), endDate: new Date(),
      }),
    ).rejects.toThrow("endDate must be after startDate");
  });
});

// ---------------------------------------------------------------------------
// PAYOUTS — double-batch prevention
// ---------------------------------------------------------------------------

describe("Creator payouts — no double-batching", () => {
  it("runCreatorPayout returns null when below minimum threshold", async () => {
    // creatorProfileId has no commissions yet — nothing to batch
    const result = await runCreatorPayout(creatorProfileId);
    expect(result).toBeNull();
  });

  it("commissions are marked PAID after batching — cannot be batched twice", async () => {
    // Seed a CONFIRMED commission above the $20 minimum
    const order = await db.order.create({
      data: {
        userId: userA.id, status: "PAID", totalAmount: 10000, subtotalAmount: 10000,
        shippingAmount: 0, discountAmount: 0, currency: "USD",
        paymentMethod: "STRIPE_CARD", paymentRef: `payout-test-${ts}`,
      },
    });
    await db.creatorCommission.create({
      data: { creatorId: creatorProfileId, orderId: order.id, userId: userA.id, amount: 3000, currency: "USD", rate: 0.12, status: "CONFIRMED" },
    });

    const batch1 = await runCreatorPayout(creatorProfileId);
    expect(batch1).not.toBeNull();
    expect(batch1!.totalAmount).toBe(3000);

    // Second call finds nothing CONFIRMED left (already flipped to PAID)
    const batch2 = await runCreatorPayout(creatorProfileId);
    expect(batch2).toBeNull();
  });

  it("two concurrent payout runs for the same creator never double-batch the same commission", async () => {
    const order = await db.order.create({
      data: {
        userId: userA.id, status: "PAID", totalAmount: 20000, subtotalAmount: 20000,
        shippingAmount: 0, discountAmount: 0, currency: "USD",
        paymentMethod: "STRIPE_CARD", paymentRef: `payout-race-${ts}`,
      },
    });
    await db.creatorCommission.create({
      data: { creatorId: creatorProfileId, orderId: order.id, userId: userA.id, amount: 5000, currency: "USD", rate: 0.12, status: "CONFIRMED" },
    });

    const results = await Promise.allSettled([
      runCreatorPayout(creatorProfileId),
      runCreatorPayout(creatorProfileId),
    ]);

    const batches = results
      .filter(r => r.status === "fulfilled" && r.value !== null)
      .map(r => (r as PromiseFulfilledResult<any>).value);

    // Exactly one of the two concurrent calls should have found and batched
    // the commission; the other finds nothing left (transaction serializes).
    expect(batches.length).toBe(1);
    expect(batches[0].totalAmount).toBe(5000);
  });
});

// ---------------------------------------------------------------------------
// TAILOR — custom order FSM
// ---------------------------------------------------------------------------

describe("Tailor marketplace — order FSM", () => {
  it("full lifecycle: brief → quote → deposit → fulfilling → shipped → delivered", async () => {
    const order = await submitCustomOrderBrief({ tailorId, clientId: userA.id, brief: "Custom agbada, size L" });
    expect(order.status).toBe("PENDING");

    const quoted = await provideQuote({ customOrderId: order.id, tailorUserId: tailorUser.id, quoteAmount: 15000, currency: "USD" });
    expect(quoted.status).toBe("PAYMENT_PROCESSING");

    const confirmed = await confirmDepositPaid(order.id, `deposit-${ts}`);
    expect(confirmed.alreadyConfirmed).toBe(false);

    const fulfilling = await updateCustomOrderStatus(order.id, tailorUser.id, "FULFILLING");
    expect(fulfilling.status).toBe("FULFILLING");

    const shipped = await updateCustomOrderStatus(order.id, tailorUser.id, "SHIPPED");
    expect(shipped.status).toBe("SHIPPED");

    const delivered = await updateCustomOrderStatus(order.id, tailorUser.id, "DELIVERED");
    expect(delivered.status).toBe("DELIVERED");
    expect(delivered.completedAt).not.toBeNull();
  });

  it("cannot skip FULFILLING and go straight from PAID to SHIPPED", async () => {
    const order = await submitCustomOrderBrief({ tailorId, clientId: userA.id, brief: "Skip test" });
    await provideQuote({ customOrderId: order.id, tailorUserId: tailorUser.id, quoteAmount: 5000, currency: "USD" });
    await confirmDepositPaid(order.id, `skip-${ts}`);

    await expect(updateCustomOrderStatus(order.id, tailorUser.id, "SHIPPED")).rejects.toThrow("Cannot transition");
  });

  it("a different tailor cannot quote someone else's order", async () => {
    const otherTailorUser = await db.user.create({
      data: { email: `p4-othertailor-${ts}@t.com`, username: `p4othertailor_${ts}`, displayName: "OT", roles: ["CONSUMER","TAILOR"], activeRole: "TAILOR" },
    });
    await db.tailorProfile.create({ data: { userId: otherTailorUser.id, country: "GH", city: "Accra", isVerified: true, isAvailable: true } });

    try {
      const order = await submitCustomOrderBrief({ tailorId, clientId: userA.id, brief: "Ownership test" });
      await expect(
        provideQuote({ customOrderId: order.id, tailorUserId: otherTailorUser.id, quoteAmount: 1000, currency: "USD" }),
      ).rejects.toThrow("do not own");
    } finally {
      await db.user.delete({ where: { id: otherTailorUser.id } }).catch(() => {});
    }
  });

  it("confirmDepositPaid is idempotent (webhook redelivery safe)", async () => {
    const order = await submitCustomOrderBrief({ tailorId, clientId: userA.id, brief: "Idempotent deposit" });
    await provideQuote({ customOrderId: order.id, tailorUserId: tailorUser.id, quoteAmount: 2000, currency: "USD" });

    const r1 = await confirmDepositPaid(order.id, `idem-deposit-${ts}`);
    const r2 = await confirmDepositPaid(order.id, `idem-deposit-${ts}`);
    expect(r1.alreadyConfirmed).toBe(false);
    expect(r2.alreadyConfirmed).toBe(true);
  });

  it("submitCustomOrderBrief rejects unverified tailor", async () => {
    const unverifiedTailorUser = await db.user.create({
      data: { email: `p4-unverified-${ts}@t.com`, username: `p4unverified_${ts}`, displayName: "UT", roles: ["CONSUMER","TAILOR"], activeRole: "TAILOR" },
    });
    const uvTailor = await db.tailorProfile.create({
      data: { userId: unverifiedTailorUser.id, country: "NG", city: "Abuja", isVerified: false, isAvailable: true },
    });

    try {
      await expect(
        submitCustomOrderBrief({ tailorId: uvTailor.id, clientId: userA.id, brief: "Should fail" }),
      ).rejects.toThrow("not yet verified");
    } finally {
      await db.user.delete({ where: { id: unverifiedTailorUser.id } }).catch(() => {});
    }
  });
});
