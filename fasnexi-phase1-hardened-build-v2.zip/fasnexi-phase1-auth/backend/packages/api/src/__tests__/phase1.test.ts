// =============================================================================
// FASNEXI — PHASE 1 INTEGRATION TESTS
// packages/api/src/__tests__/phase1.test.ts
//
// Runs against a real PostgreSQL test DB (provisioned in ci.yml via Docker).
// Tests the full request→service→DB round-trip for Phase 1 core flows.
// Each describe block manages its own test data and cleans up after itself.
// =============================================================================

import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import { db } from "@fasnexi/db";
import { getPersonalisedFeed, updatePostRankScore } from "../feed/ranking";
import { listProducts, getProduct, decrementInventory } from "../products/catalog";
import { createCheckoutSession } from "../checkout/stripe";

// ---------------------------------------------------------------------------
// TEST SETUP — seed minimal shared data once per suite
// ---------------------------------------------------------------------------

let testUserId: string;
let testVendorId: string;
let testProductId: string;
let testPostId: string;

beforeAll(async () => {
  // Create test user with CONSUMER + VENDOR roles
  const user = await db.user.create({
    data: {
      email: `phase1-test-${Date.now()}@fasnexi.test`,
      username: `testuser_${Date.now()}`,
      displayName: "Phase 1 Test User",
      roles: ["CONSUMER", "VENDOR"],
      activeRole: "CONSUMER",
    },
  });
  testUserId = user.id;

  // Create vendor profile for product tests
  const vendor = await db.vendorProfile.create({
    data: {
      userId: testUserId,
      businessName: "Test Vendor",
      country: "NG",
      isVerified: true,
    },
  });
  testVendorId = vendor.id;

  // Create a published product
  const product = await db.product.create({
    data: {
      vendorId: testVendorId,
      name: "Ankara Test Dress",
      slug: `ankara-test-dress-${Date.now()}`,
      priceAmount: 5000, // $50.00 in cents
      priceCurrency: "USD",
      imageUrls: ["https://res.cloudinary.com/fasnexi/test.jpg"],
      category: "DRESS",
      culturalTags: ["WEST_AFRICAN", "ANKARA"],
      occasions: ["SOCIAL", "CULTURAL_EVENT"],
      inventoryCount: 10,
      isPublished: true,
      isInStock: true,
      salesCount: 0,
    },
  });
  testProductId = product.id;

  // Create a published post
  const post = await db.post.create({
    data: {
      userId: testUserId,
      type: "OUTFIT",
      status: "PUBLISHED",
      caption: "Loving this look",
      mediaUrls: ["https://res.cloudinary.com/fasnexi/post.jpg"],
      culturalTags: ["WEST_AFRICAN"],
      styleCategories: ["AFROCENTRIC_MAXIMALIST"],
      rankScore: 1.0,
      publishedAt: new Date(),
    },
  });
  testPostId = post.id;
});

afterAll(async () => {
  // Cascade-delete cleans up all related records
  await db.user.delete({ where: { id: testUserId } }).catch(() => {});
  await db.$disconnect();
});

// ---------------------------------------------------------------------------
// FEED RANKING
// ---------------------------------------------------------------------------

describe("Feed ranking", () => {
  it("returns published posts excluding the requesting user's own posts", async () => {
    // Create a second user to request a feed that includes the test post
    const viewer = await db.user.create({
      data: {
        email: `viewer-${Date.now()}@fasnexi.test`,
        username: `viewer_${Date.now()}`,
        displayName: "Viewer",
        roles: ["CONSUMER"],
        activeRole: "CONSUMER",
      },
    });

    try {
      const feed = await getPersonalisedFeed({ userId: viewer.id, limit: 10 });
      expect(Array.isArray(feed)).toBe(true);
      // Should not contain the viewer's own posts (none exist in this case)
      expect(feed.every(p => p.userId !== viewer.id)).toBe(true);
    } finally {
      await db.user.delete({ where: { id: viewer.id } });
    }
  });

  it("updatePostRankScore writes a non-zero score to the post", async () => {
    // Give the post some engagement first
    await db.post.update({
      where: { id: testPostId },
      data: { likeCount: 10, commentCount: 3, saveCount: 5 },
    });

    await updatePostRankScore(testPostId);

    const updated = await db.post.findUnique({
      where: { id: testPostId },
      select: { rankScore: true },
    });
    expect(updated?.rankScore).toBeGreaterThan(0);
  });

  it("keyset pagination returns different pages", async () => {
    // Seed 5 extra posts so we have enough to paginate
    const extraPosts = await Promise.all(
      Array.from({ length: 5 }).map((_, i) =>
        db.post.create({
          data: {
            userId: testUserId,
            type: "OUTFIT",
            status: "PUBLISHED",
            caption: `Extra post ${i}`,
            mediaUrls: [],
            culturalTags: [],
            styleCategories: [],
            rankScore: 0.5 - i * 0.05,
            publishedAt: new Date(Date.now() - i * 60_000),
          },
        }),
      ),
    );

    const viewer = await db.user.create({
      data: {
        email: `pager-${Date.now()}@fasnexi.test`,
        username: `pager_${Date.now()}`,
        displayName: "Pager",
        roles: ["CONSUMER"],
        activeRole: "CONSUMER",
      },
    });

    try {
      const page1 = await getPersonalisedFeed({ userId: viewer.id, limit: 3 });
      const page2 = await getPersonalisedFeed({
        userId: viewer.id,
        limit: 3,
        cursor: page1[page1.length - 1]?.id,
      });

      // No overlap between pages
      const page1Ids = new Set(page1.map(p => p.id));
      expect(page2.every(p => !page1Ids.has(p.id))).toBe(true);
    } finally {
      await db.user.delete({ where: { id: viewer.id } });
      await Promise.all(extraPosts.map(p => db.post.delete({ where: { id: p.id } })));
    }
  });
});

// ---------------------------------------------------------------------------
// PRODUCT CATALOG
// ---------------------------------------------------------------------------

describe("Product catalog", () => {
  it("listProducts returns published in-stock products", async () => {
    const result = await listProducts({ limit: 10 });
    expect(result.products.length).toBeGreaterThan(0);
    expect(result.products.every(p => p.isInStock)).toBe(true);
  });

  it("listProducts filters by category", async () => {
    const result = await listProducts({ category: "DRESS", limit: 10 });
    expect(result.products.every(p => p.category === "DRESS")).toBe(true);
  });

  it("listProducts text search finds by name", async () => {
    const result = await listProducts({ query: "Ankara Test", limit: 10 });
    expect(result.products.some(p => p.id === testProductId)).toBe(true);
  });

  it("getProduct returns full product detail", async () => {
    const product = await getProduct(testProductId);
    expect(product).not.toBeNull();
    expect(product!.id).toBe(testProductId);
    expect(product!.reviewStats.count).toBe(0);
  });

  it("getProduct returns null for unknown id", async () => {
    const product = await getProduct("00000000-0000-0000-0000-000000000000");
    expect(product).toBeNull();
  });

  it("decrementInventory reduces stock and marks out-of-stock at zero", async () => {
    // Create a test product with 2 units
    const p = await db.product.create({
      data: {
        vendorId: testVendorId,
        name: "Decrement Test",
        slug: `decrement-test-${Date.now()}`,
        priceAmount: 1000,
        priceCurrency: "USD",
        imageUrls: [],
        category: "TOP",
        inventoryCount: 2,
        isPublished: true,
        isInStock: true,
        salesCount: 0,
      },
    });

    try {
      await decrementInventory(p.id, 2);
      const updated = await db.product.findUnique({ where: { id: p.id } });
      expect(updated?.inventoryCount).toBe(0);
      expect(updated?.isInStock).toBe(false);
    } finally {
      await db.product.delete({ where: { id: p.id } });
    }
  });

  it("decrementInventory throws on insufficient stock", async () => {
    await expect(decrementInventory(testProductId, 9999)).rejects.toThrow("Insufficient inventory");
  });
});

// ---------------------------------------------------------------------------
// CHECKOUT SESSION CREATION (unit-level — no Stripe API call in tests)
// ---------------------------------------------------------------------------

describe("Checkout session", () => {
  it("throws on empty items array", async () => {
    await expect(
      createCheckoutSession({
        userId: testUserId,
        items: [],
        currency: "USD",
        successUrl: "https://fasnexi.com/success",
        cancelUrl: "https://fasnexi.com/cart",
      }),
    ).rejects.toThrow();
  });

  it("throws when product is not found / unpublished", async () => {
    await expect(
      createCheckoutSession({
        userId: testUserId,
        items: [{ productId: "00000000-0000-0000-0000-000000000000", quantity: 1 }],
        currency: "USD",
        successUrl: "https://fasnexi.com/success",
        cancelUrl: "https://fasnexi.com/cart",
      }),
    ).rejects.toThrow("unavailable");
  });

  it("throws when requested quantity exceeds inventory", async () => {
    await expect(
      createCheckoutSession({
        userId: testUserId,
        items: [{ productId: testProductId, quantity: 9999 }],
        currency: "USD",
        successUrl: "https://fasnexi.com/success",
        cancelUrl: "https://fasnexi.com/cart",
      }),
    ).rejects.toThrow("stock");
  });
});
