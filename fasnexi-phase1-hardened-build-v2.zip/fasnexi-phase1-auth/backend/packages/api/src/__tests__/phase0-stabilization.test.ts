import { describe, expect, it } from "vitest";

describe("Phase 0 financial invariants", () => {
  it("vendor revenue is unit amount multiplied by quantity", () => {
    const items = [{ unitAmount: 50000, quantity: 3 }];
    expect(items.reduce((sum, i) => sum + i.unitAmount * i.quantity, 0)).toBe(150000);
  });

  it("does not combine currencies", () => {
    const items = [
      { unitAmount: 50000, quantity: 3, currency: "NGN" },
      { unitAmount: 100, quantity: 2, currency: "USD" },
    ];
    const grouped = items.reduce<Record<string, number>>((a, i) => { a[i.currency] = (a[i.currency] ?? 0) + i.unitAmount * i.quantity; return a; }, {});
    expect(grouped).toEqual({ NGN: 150000, USD: 200 });
  });
});
