// =============================================================================
// FASNEXI — PHASE 2 INTEGRATION TESTS
// packages/api/src/__tests__/phase2.test.ts
// =============================================================================

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { db } from "@fasnexi/db";
import { followUser, unfollowUser, getFollowers, getRelationship } from "../social/graph";
import { toggleLike, createComment, toggleSave } from "../social/engagement";
import { listChallenges, submitChallengeEntry } from "../challenges/service";
import { getVendorDashboardSummary } from "../vendors/dashboard";

let userA: string;
let userB: string;
let vendorUserId: string;
let vendorId: string;
let testPostId: string;
let testChallengeId: string;

beforeAll(async () => {
  const ts = Date.now();

  const [a, b, v] = await Promise.all([
    db.user.create({
      data: { email: `p2a-${ts}@test.com`, username: `p2a_${ts}`, displayName: "P2 User A", roles: ["CONSUMER"], activeRole: "CONSUMER" },
    }),
    db.user.create({
      data: { email: `p2b-${ts}@test.com`, username: `p2b_${ts}`, displayName: "P2 User B", roles: ["CONSUMER", "CREATOR"], activeRole: "CONSUMER" },
    }),
    db.user.create({
      data: { email: `p2v-${ts}@test.com`, username: `p2v_${ts}`, displayName: "P2 Vendor", roles: ["CONSUMER", "VENDOR"], activeRole: "CONSUMER" },
    }),
  ]);
  userA = a.id; userB = b.id; vendorUserId = v.id;

  // Creator profile for userB
  await db.creatorProfile.create({ data: { userId: userB, followerCount: 0 } });

  // Verified vendor profile
  const vp = await db.vendorProfile.create({
    data: { userId: vendorUserId, businessName: "Test Shop", country: "NG", isVerified: true },
  });
  vendorId = vp.id;

  // A post by userB
  const post = await db.post.create({
    data: {
      userId: userB,
      type: "OUTFIT",
      status: "PUBLISHED",
      mediaUrls: [],
      culturalTags: [],
      rankScore: 1.0,
      publishedAt: new Date(),
    },
  });
  testPostId = post.id;

  // An active challenge
  const challenge = await db.challenge.create({
    data: {
      title: "Test Challenge",
      description: "Test",
      status: "ACTIVE",
      startDate: new Date(Date.now() - 3600_000),
      endDate: new Date(Date.now() + 86_400_000),
    },
  });
  testChallengeId = challenge.id;
});

afterAll(async () => {
  await Promise.all([
    db.user.delete({ where: { id: userA } }).catch(() => {}),
    db.user.delete({ where: { id: userB } }).catch(() => {}),
    db.user.delete({ where: { id: vendorUserId } }).catch(() => {}),
    db.challenge.delete({ where: { id: testChallengeId } }).catch(() => {}),
  ]);
  await db.$disconnect();
});

// ---------------------------------------------------------------------------
// SOCIAL GRAPH
// ---------------------------------------------------------------------------

describe("Social graph — follow/unfollow", () => {
  it("userA follows userB — returns followed=true and increments followerCount", async () => {
    const result = await followUser(userA, userB);
    expect(result.followed).toBe(true);
    expect(result.followerCount).toBeGreaterThanOrEqual(1);
  });

  it("following the same user again is idempotent (alreadyActive, no error)", async () => {
    const result = await followUser(userA, userB);
    expect(result.followed).toBe(true);

    // Should still be exactly 1 follow row
    const count = await db.follow.count({ where: { followerId: userA, followingId: userB } });
    expect(count).toBe(1);
  });

  it("getFollowers returns userA in userB's follower list", async () => {
    const { followers } = await getFollowers(userB);
    expect(followers.some(f => f.id === userA)).toBe(true);
  });

  it("getRelationship reflects the follow correctly", async () => {
    const rel = await getRelationship(userA, userB);
    expect(rel.isFollowing).toBe(true);
    expect(rel.isFollowedBy).toBe(false); // B hasn't followed A
  });

  it("cannot follow yourself", async () => {
    await expect(followUser(userA, userA)).rejects.toThrow("Cannot follow yourself");
  });

  it("unfollowing decrements follower count", async () => {
    await unfollowUser(userA, userB);
    const rel = await getRelationship(userA, userB);
    expect(rel.isFollowing).toBe(false);

    const profile = await db.creatorProfile.findUnique({ where: { userId: userB } });
    expect(profile?.followerCount).toBe(0);
  });
});

// ---------------------------------------------------------------------------
// ENGAGEMENT
// ---------------------------------------------------------------------------

describe("Engagement — likes, comments, saves", () => {
  it("toggleLike adds a like and increments likeCount", async () => {
    const result = await toggleLike(userA, testPostId);
    expect(result.liked).toBe(true);
    expect(result.likeCount).toBeGreaterThanOrEqual(1);
  });

  it("toggleLike again removes the like (toggle)", async () => {
    const result = await toggleLike(userA, testPostId);
    expect(result.liked).toBe(false);
  });

  it("createComment on a post returns the comment with user data", async () => {
    const comment = await createComment({
      userId: userA,
      postId: testPostId,
      body: "Love this look!",
    });
    expect(comment.id).toBeDefined();
    expect(comment.body).toBe("Love this look!");
    expect(comment.user.id).toBe(userA);
  });

  it("createComment reply links to parent (max 2 levels)", async () => {
    const parent = await createComment({ userId: userA, postId: testPostId, body: "Top comment" });
    const reply = await createComment({
      userId: userB,
      postId: testPostId,
      body: "Reply",
      parentId: parent.id,
    });
    expect(reply.parentId).toBe(parent.id);
  });

  it("createComment reply to a reply is rejected (max depth 2)", async () => {
    const parent = await createComment({ userId: userA, postId: testPostId, body: "L1" });
    const child = await createComment({ userId: userB, postId: testPostId, body: "L2", parentId: parent.id });
    await expect(
      createComment({ userId: userA, postId: testPostId, body: "L3", parentId: child.id }),
    ).rejects.toThrow("2 levels");
  });

  it("toggleSave saves and unsaves a post", async () => {
    const saved = await toggleSave(userA, testPostId);
    expect(saved.saved).toBe(true);
    const unsaved = await toggleSave(userA, testPostId);
    expect(unsaved.saved).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// CHALLENGES
// ---------------------------------------------------------------------------

describe("Challenges", () => {
  it("listChallenges returns active challenges", async () => {
    const { challenges } = await listChallenges({ status: "ACTIVE" });
    expect(challenges.some(c => c.id === testChallengeId)).toBe(true);
  });

  it("submitChallengeEntry creates a post and entry", async () => {
    const entry = await submitChallengeEntry({
      challengeId: testChallengeId,
      userId: userA,
      caption: "My entry",
      mediaUrls: ["https://cdn.example.com/photo.jpg"],
    });
    expect(entry.id).toBeDefined();
    expect(entry.post.id).toBeDefined();
  });

  it("submitting a second entry to the same challenge is rejected", async () => {
    await expect(
      submitChallengeEntry({
        challengeId: testChallengeId,
        userId: userA,
        caption: "Duplicate",
        mediaUrls: ["https://cdn.example.com/photo2.jpg"],
      }),
    ).rejects.toThrow("already submitted");
  });
});

// ---------------------------------------------------------------------------
// VENDOR DASHBOARD
// ---------------------------------------------------------------------------

describe("Vendor dashboard", () => {
  it("getVendorDashboardSummary returns product and revenue data", async () => {
    const summary = await getVendorDashboardSummary(vendorUserId);
    expect(summary.products).toBeDefined();
    expect(typeof summary.revenue.allTime).toBe("number");
    expect(Array.isArray(summary.recentOrders)).toBe(true);
  });

  it("throws for a user without a vendor profile", async () => {
    await expect(getVendorDashboardSummary(userA)).rejects.toThrow();
  });
});
