// =============================================================================
// FASNEXI — SOCIAL GRAPH SERVICE
// packages/api/src/social/graph.ts
//
// Follow/unfollow with hybrid push/pull feed fan-out strategy:
//
//   PUSH (for creators with ≤ FANOUT_THRESHOLD followers):
//     On post creation, write a FeedItem row for each follower immediately.
//     Cheap at small scale — the follower's feed query is trivially fast.
//
//   PULL (for creators with > FANOUT_THRESHOLD followers, "hot creators"):
//     Follower feeds are assembled at read time by merging:
//       (a) their personalised push-feed (from FeedItem rows)
//       (b) the hot creator's latest posts (pulled from Post directly)
//     This prevents a single viral creator from fanning out to 500k rows.
//
// The threshold is intentionally low (10k) for Phase 2 — revisit at Phase 6
// once we have real data on creator follower distributions.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

const FANOUT_THRESHOLD = 10_000;

// ---------------------------------------------------------------------------
// FOLLOW
// ---------------------------------------------------------------------------
export async function followUser(
  followerId: string,
  followingId: string,
): Promise<{ followed: boolean; followerCount: number }> {
  if (followerId === followingId) {
    throw new Error("Cannot follow yourself");
  }

  // Upsert — idempotent so double-taps from the mobile client don't error
  const existing = await db.follow.findUnique({
    where: { followerId_followingId: { followerId, followingId } },
  });

  if (existing) {
    const profile = await db.creatorProfile.findUnique({
      where: { userId: followingId },
      select: { followerCount: true },
    });
    return { followed: true, followerCount: profile?.followerCount ?? 0 };
  }

  await db.$transaction([
    db.follow.create({ data: { followerId, followingId } }),
    // Increment denormalised follower count on CreatorProfile if it exists
    db.creatorProfile.updateMany({
      where: { userId: followingId },
      data: { followerCount: { increment: 1 } },
    }),
  ]);

  // Notify the followed user (non-blocking)
  await enqueueNotification({
    recipientId: followingId,
    type: "FOLLOW",
    data: { followerId },
  });

  const profile = await db.creatorProfile.findUnique({
    where: { userId: followingId },
    select: { followerCount: true },
  });

  return { followed: true, followerCount: profile?.followerCount ?? 0 };
}

// ---------------------------------------------------------------------------
// UNFOLLOW
// ---------------------------------------------------------------------------
export async function unfollowUser(
  followerId: string,
  followingId: string,
): Promise<{ unfollowed: boolean }> {
  const deleted = await db.follow.deleteMany({
    where: { followerId, followingId },
  });

  if (deleted.count > 0) {
    await db.creatorProfile.updateMany({
      where: { userId: followingId },
      data: { followerCount: { decrement: 1 } },
    });
  }

  return { unfollowed: deleted.count > 0 };
}

// ---------------------------------------------------------------------------
// GET FOLLOWERS / FOLLOWING LISTS
// ---------------------------------------------------------------------------
export async function getFollowers(
  userId: string,
  cursor?: string,
  limit = 30,
) {
  const where = {
    followingId: userId,
    ...(cursor && { followerId: { lt: cursor } }),
  };

  const follows = await db.follow.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    select: {
      followerId: true,
      createdAt: true,
      follower: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          creatorProfile: { select: { followerCount: true } },
        },
      },
    },
  });

  const hasMore = follows.length > limit;
  const items = hasMore ? follows.slice(0, limit) : follows;

  return {
    followers: items.map(f => ({
      ...f.follower,
      followedAt: f.createdAt,
    })),
    nextCursor: hasMore ? items[items.length - 1].followerId : null,
  };
}

export async function getFollowing(
  userId: string,
  cursor?: string,
  limit = 30,
) {
  const where = {
    followerId: userId,
    ...(cursor && { followingId: { lt: cursor } }),
  };

  const follows = await db.follow.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    select: {
      followingId: true,
      createdAt: true,
      following: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          creatorProfile: { select: { followerCount: true } },
        },
      },
    },
  });

  const hasMore = follows.length > limit;
  const items = hasMore ? follows.slice(0, limit) : follows;

  return {
    following: items.map(f => ({
      ...f.following,
      followedAt: f.createdAt,
    })),
    nextCursor: hasMore ? items[items.length - 1].followingId : null,
  };
}

// ---------------------------------------------------------------------------
// CHECK RELATIONSHIP
// ---------------------------------------------------------------------------
export async function getRelationship(
  viewerId: string,
  targetId: string,
): Promise<{ isFollowing: boolean; isFollowedBy: boolean }> {
  const [outgoing, incoming] = await Promise.all([
    db.follow.findUnique({
      where: { followerId_followingId: { followerId: viewerId, followingId: targetId } },
    }),
    db.follow.findUnique({
      where: { followerId_followingId: { followerId: targetId, followingId: viewerId } },
    }),
  ]);

  return {
    isFollowing: !!outgoing,
    isFollowedBy: !!incoming,
  };
}

// ---------------------------------------------------------------------------
// FEED FAN-OUT — called by the post creation worker (BullMQ)
// Determines push vs pull strategy based on follower count.
// ---------------------------------------------------------------------------
export async function fanOutPost(
  postId: string,
  authorId: string,
): Promise<{ strategy: "push" | "pull"; recipientCount: number }> {
  const followerCount = await db.follow.count({ where: { followingId: authorId } });

  if (followerCount > FANOUT_THRESHOLD) {
    // Hot creator — pull strategy. Mark the author as a hot creator so
    // the feed query knows to merge their posts at read time.
    await db.creatorProfile.updateMany({
      where: { userId: authorId },
      data: {},  // Phase 6: add isHotCreator flag to CreatorProfile
    });
    return { strategy: "pull", recipientCount: followerCount };
  }

  // Push strategy — write FeedItem rows for all followers in batches
  let offset = 0;
  const batchSize = 500;
  let totalWritten = 0;

  while (true) {
    const batch = await db.follow.findMany({
      where: { followingId: authorId },
      skip: offset,
      take: batchSize,
      select: { followerId: true },
    });

    if (batch.length === 0) break;

    // FeedItem table not yet in schema (Phase 2 migration adds it)
    // For now, the personalised feed query fetches posts from followed users
    // directly — this function is wired for the Phase 6 fan-out upgrade.
    // TODO Phase 6: db.feedItem.createMany({ data: batch.map(b => ({ userId: b.followerId, postId })) });

    totalWritten += batch.length;
    offset += batchSize;
    if (batch.length < batchSize) break;
  }

  return { strategy: "push", recipientCount: totalWritten };
}
