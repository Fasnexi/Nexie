// =============================================================================
// FASNEXI — ENGAGEMENT SERVICE
// packages/api/src/social/engagement.ts
//
// Handles likes, comments (threaded, 2 levels), and saves.
// All count increments/decrements are atomic via Prisma transactions.
// Feed rank updates are enqueued asynchronously (BullMQ) so engagement
// writes are fast — never blocked by the rank scorer.
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueFeedRankUpdate, enqueueNotification } from "../queue";

// ---------------------------------------------------------------------------
// LIKES
// ---------------------------------------------------------------------------
export async function toggleLike(
  userId: string,
  postId: string,
): Promise<{ liked: boolean; likeCount: number }> {
  const existing = await db.like.findUnique({
    where: { userId_postId: { userId, postId } },
  });

  if (existing) {
    // Unlike
    await db.$transaction([
      db.like.delete({ where: { userId_postId: { userId, postId } } }),
      db.post.update({ where: { id: postId }, data: { likeCount: { decrement: 1 } } }),
    ]);
    const post = await db.post.findUnique({ where: { id: postId }, select: { likeCount: true } });
    await enqueueFeedRankUpdate(postId, "like");
    return { liked: false, likeCount: post?.likeCount ?? 0 };
  }

  // Like
  const [, post] = await db.$transaction([
    db.like.create({ data: { userId, postId } }),
    db.post.update({
      where: { id: postId },
      data: { likeCount: { increment: 1 } },
      select: { likeCount: true, userId: true },
    }),
  ]);

  // Notify post author (skip self-like)
  if (post.userId !== userId) {
    await enqueueNotification({
      recipientId: post.userId,
      type: "LIKE",
      data: { postId, likerId: userId },
    });
  }

  await enqueueFeedRankUpdate(postId, "like");
  return { liked: true, likeCount: post.likeCount };
}

// ---------------------------------------------------------------------------
// COMMENTS
// ---------------------------------------------------------------------------
export interface CreateCommentInput {
  userId: string;
  postId: string;
  body: string;
  parentId?: string; // for replies — max depth 2
}

export async function createComment(input: CreateCommentInput) {
  const { userId, postId, body, parentId } = input;

  if (!body.trim()) throw new Error("Comment body cannot be empty");
  if (body.length > 1000) throw new Error("Comment exceeds 1000 character limit");

  // Validate parent exists and is not itself a reply (max 2 levels)
  if (parentId) {
    const parent = await db.comment.findUnique({
      where: { id: parentId },
      select: { parentId: true, postId: true },
    });
    if (!parent) throw new Error("Parent comment not found");
    if (parent.postId !== postId) throw new Error("Parent comment belongs to a different post");
    if (parent.parentId) throw new Error("Replies cannot be nested beyond 2 levels");
  }

  const [comment, post] = await db.$transaction([
    db.comment.create({
      data: { userId, postId, body: body.trim(), parentId: parentId ?? null },
      select: {
        id: true,
        body: true,
        parentId: true,
        createdAt: true,
        user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      },
    }),
    db.post.update({
      where: { id: postId },
      data: { commentCount: { increment: 1 } },
      select: { userId: true, commentCount: true },
    }),
  ]);

  // Notify post author on top-level comments; notify parent comment author on replies
  const notifyId = parentId
    ? (await db.comment.findUnique({ where: { id: parentId }, select: { userId: true } }))?.userId
    : post.userId;

  if (notifyId && notifyId !== userId) {
    await enqueueNotification({
      recipientId: notifyId,
      type: "COMMENT",
      data: { postId, commentId: comment.id, commenterId: userId },
    });
  }

  await enqueueFeedRankUpdate(postId, "comment");
  return comment;
}

export async function deleteComment(commentId: string, requesterId: string): Promise<void> {
  const comment = await db.comment.findUnique({
    where: { id: commentId },
    select: { userId: true, postId: true, isRemoved: true },
  });
  if (!comment) throw new Error("Comment not found");

  // Allow deletion by the comment author or a MODERATOR/ADMIN
  const requester = await db.user.findUniqueOrThrow({
    where: { id: requesterId },
    select: { roles: true },
  });
  const isStaff = requester.roles.some(r => ["MODERATOR", "ADMIN"].includes(r));

  if (comment.userId !== requesterId && !isStaff) {
    throw new Error("Cannot delete another user's comment");
  }

  // Soft-delete: keeps the thread structure intact for reply context
  await db.$transaction([
    db.comment.update({ where: { id: commentId }, data: { isRemoved: true, body: "[deleted]" } }),
    db.post.update({ where: { id: comment.postId }, data: { commentCount: { decrement: 1 } } }),
  ]);
}

export async function getComments(
  postId: string,
  cursor?: string,
  limit = 20,
) {
  const comments = await db.comment.findMany({
    where: {
      postId,
      parentId: null, // top-level only; replies fetched separately
      ...(cursor && { id: { lt: cursor } }),
    },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    select: {
      id: true,
      body: true,
      isRemoved: true,
      likeCount: true,
      createdAt: true,
      user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      replies: {
        where: { isRemoved: false },
        orderBy: { createdAt: "asc" },
        take: 5, // load first 5 replies inline; "load more" fetches the rest
        select: {
          id: true,
          body: true,
          likeCount: true,
          createdAt: true,
          user: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
        },
      },
    },
  });

  const hasMore = comments.length > limit;
  return {
    comments: hasMore ? comments.slice(0, limit) : comments,
    nextCursor: hasMore ? comments[limit - 1].id : null,
  };
}

// ---------------------------------------------------------------------------
// SAVES
// ---------------------------------------------------------------------------
export async function toggleSave(
  userId: string,
  postId: string,
): Promise<{ saved: boolean; saveCount: number }> {
  const existing = await db.savedPost.findUnique({
    where: { userId_postId: { userId, postId } },
  });

  if (existing) {
    const [, post] = await db.$transaction([
      db.savedPost.delete({ where: { userId_postId: { userId, postId } } }),
      db.post.update({
        where: { id: postId },
        data: { saveCount: { decrement: 1 } },
        select: { saveCount: true },
      }),
    ]);
    return { saved: false, saveCount: post.saveCount };
  }

  const [, post] = await db.$transaction([
    db.savedPost.create({ data: { userId, postId } }),
    db.post.update({
      where: { id: postId },
      data: { saveCount: { increment: 1 } },
      select: { saveCount: true },
    }),
  ]);

  await enqueueFeedRankUpdate(postId, "save");
  return { saved: true, saveCount: post.saveCount };
}
