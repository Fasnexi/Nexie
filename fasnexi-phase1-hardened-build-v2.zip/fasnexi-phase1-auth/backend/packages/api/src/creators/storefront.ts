// =============================================================================
// FASNEXI — CREATOR STOREFRONT SERVICE
// packages/api/src/creators/storefront.ts
//
// Handles creator profile management, storefront pages, and the affiliate
// attribution cookie system. Per White Paper §8.2, creators are "integrated
// economic nodes" — not external influencers — so all monetisation is native.
//
// Attribution model:
//   - 30-day click window stored as a signed JWT in a short-lived cookie
//   - Cookie is set when a user clicks a tagged product in a creator's post
//   - On checkout, the cookie is read server-side and written to the order
//     metadata, which the webhook handler uses to create CreatorCommission
//   - Commission rate is per-creator, defaulting to 12%, stored on CreatorProfile
// =============================================================================

import { db } from "@fasnexi/db";
import { SignJWT, jwtVerify } from "jose";

const ATTRIBUTION_SECRET = new TextEncoder().encode(
  process.env.ATTRIBUTION_SECRET ?? "dev-attribution-secret-replace-in-prod",
);
const ATTRIBUTION_WINDOW_DAYS = 30;

// ---------------------------------------------------------------------------
// CREATOR PROFILE — get or create on first activation
// ---------------------------------------------------------------------------
export async function getCreatorProfile(userId: string) {
  const profile = await db.creatorProfile.findUnique({
    where: { userId },
    include: {
      user: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          bio: true,
          website: true,
          location: true,
        },
      },
    },
  });
  return profile;
}

export async function updateCreatorProfile(
  userId: string,
  data: {
    bio?: string;
    bannerUrl?: string;
    styleNiche?: string[];
    culturalFocus?: string[];
  },
) {
  // Upsert so creators who just activated the role can immediately save
  return db.creatorProfile.upsert({
    where: { userId },
    create: {
      userId,
      bio: data.bio,
      bannerUrl: data.bannerUrl,
      styleNiche: (data.styleNiche as any) ?? [],
      culturalFocus: data.culturalFocus ?? [],
    },
    update: {
      bio: data.bio,
      bannerUrl: data.bannerUrl,
      styleNiche: (data.styleNiche as any) ?? [],
      culturalFocus: data.culturalFocus ?? [],
    },
  });
}

// ---------------------------------------------------------------------------
// STOREFRONT PAGE — public-facing @handle page
// ---------------------------------------------------------------------------
export async function getStorefront(handle: string) {
  const user = await db.user.findUnique({
    where: { username: handle },
    select: {
      id: true,
      username: true,
      displayName: true,
      avatarUrl: true,
      bio: true,
      website: true,
      isVerified: true,
      creatorProfile: {
        select: {
          bio: true,
          bannerUrl: true,
          styleNiche: true,
          culturalFocus: true,
          followerCount: true,
          totalSales: true,
          commissionRate: true,
        },
      },
    },
  });

  if (!user || !user.creatorProfile) return null;

  // Fetch recent posts and featured products in parallel
  const [posts, taggedProducts] = await Promise.all([
    db.post.findMany({
      where: { userId: user.id, status: "PUBLISHED" },
      orderBy: { publishedAt: "desc" },
      take: 12,
      select: {
        id: true,
        type: true,
        mediaUrls: true,
        likeCount: true,
        commentCount: true,
        publishedAt: true,
        taggedProducts: {
          select: {
            product: {
              select: { id: true, name: true, priceAmount: true, priceCurrency: true, imageUrls: true },
            },
          },
        },
      },
    }),
    // All unique products ever tagged by this creator — storefront shop section
    db.postProduct.findMany({
      where: { post: { userId: user.id, status: "PUBLISHED" } },
      distinct: ["productId"],
      take: 16,
      select: {
        product: {
          select: {
            id: true,
            name: true,
            slug: true,
            priceAmount: true,
            priceCurrency: true,
            imageUrls: true,
            category: true,
            isInStock: true,
          },
        },
      },
    }),
  ]);

  return {
    ...user,
    posts,
    featuredProducts: taggedProducts.map(tp => tp.product),
  };
}

// ---------------------------------------------------------------------------
// CREATOR EARNINGS SUMMARY
// ---------------------------------------------------------------------------
export async function getCreatorEarnings(
  userId: string,
  period: "week" | "month" | "all" = "month",
) {
  const since = period === "all" ? undefined : {
    week:  new Date(Date.now() - 7  * 24 * 60 * 60 * 1000),
    month: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
  }[period];

  const profile = await db.creatorProfile.findUnique({
    where: { userId },
    select: { id: true },
  });
  if (!profile) throw new Error("Creator profile not found");

  const commissions = await db.creatorCommission.findMany({
    where: {
      creatorId: profile.id,
      ...(since && { createdAt: { gte: since } }),
    },
    select: { amount: true, currency: true, status: true, settledAt: true },
  });

  const currencies = commissions.reduce<Record<string, { pending: number; confirmed: number; paid: number; total: number }>>((acc, c) => {
    const bucket = acc[c.currency] ?? { pending: 0, confirmed: 0, paid: 0, total: 0 };
    if (c.status === "PENDING") bucket.pending += c.amount;
    if (c.status === "CONFIRMED") bucket.confirmed += c.amount;
    if (c.status === "PAID") bucket.paid += c.amount;
    bucket.total = bucket.pending + bucket.confirmed + bucket.paid;
    acc[c.currency] = bucket;
    return acc;
  }, {});

  return { period, currencies, commissionCount: commissions.length };
}

// ---------------------------------------------------------------------------
// ATTRIBUTION — signed JWT cookie for 30-day click tracking
// ---------------------------------------------------------------------------
export async function generateAttributionToken(
  creatorId: string,
  productId: string,
): Promise<string> {
  return new SignJWT({ creatorId, productId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${ATTRIBUTION_WINDOW_DAYS}d`)
    .sign(ATTRIBUTION_SECRET);
}

export async function verifyAttributionToken(
  token: string,
): Promise<{ creatorId: string; productId: string } | null> {
  try {
    const { payload } = await jwtVerify(token, ATTRIBUTION_SECRET);
    return {
      creatorId: payload.creatorId as string,
      productId: payload.productId as string,
    };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// TOP CREATORS — discovery feed (by follower count, phase 2 default)
// Phase 6 will add algorithmic creator ranking via Style DNA affinity
// ---------------------------------------------------------------------------
export async function getTopCreators(limit = 10) {
  const profiles = await db.creatorProfile.findMany({
    orderBy: { followerCount: "desc" },
    take: limit,
    select: {
      followerCount: true,
      styleNiche: true,
      culturalFocus: true,
      user: {
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          isVerified: true,
        },
      },
    },
  });

  return profiles.map(p => ({ ...p.user, ...p }));
}
