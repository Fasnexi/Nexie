// =============================================================================
// FASNEXI — JOB QUEUE
// packages/api/src/queue/index.ts
//
// BullMQ queues backed by Upstash Redis. All async work goes through here:
//   feed-ranking    — recompute Post.rankScore after engagement events
//   nexi-vision     — Claude Vision garment auto-tagging (Phase 3)
//   notifications   — fan-out push notifications
//   trade-matching  — FSE order book (Phase 7)
//   moderation      — AI content screening (Phase 6)
//
// Worker processes run in apps/worker (separate Fly.io app, not the web app).
// Only the Queue objects (for enqueuing) are exported here so the web app
// can enqueue without importing the processor logic.
// =============================================================================

import { Queue, Worker, type Job } from "bullmq";

const REDIS_CONNECTION = {
  host: process.env.REDIS_URL
    ? new URL(process.env.REDIS_URL).hostname
    : "localhost",
  port: process.env.REDIS_URL
    ? parseInt(new URL(process.env.REDIS_URL).port || "6379")
    : 6379,
  password: process.env.REDIS_URL
    ? new URL(process.env.REDIS_URL).password || undefined
    : undefined,
  tls: process.env.REDIS_URL?.startsWith("rediss://") ? {} : undefined,
};

// ---------------------------------------------------------------------------
// QUEUE DEFINITIONS
// ---------------------------------------------------------------------------

export const feedRankingQueue = new Queue("feed-ranking", {
  connection: REDIS_CONNECTION,
  defaultJobOptions: {
    removeOnComplete: { count: 100 },
    removeOnFail: { count: 500 },
    attempts: 3,
    backoff: { type: "exponential", delay: 1000 },
  },
});

export const nexiVisionQueue = new Queue("nexi-vision", {
  connection: REDIS_CONNECTION,
  defaultJobOptions: {
    removeOnComplete: { count: 50 },
    removeOnFail: { count: 200 },
    attempts: 2,
    backoff: { type: "fixed", delay: 5000 },
  },
});

export const notificationsQueue = new Queue("notifications", {
  connection: REDIS_CONNECTION,
  defaultJobOptions: {
    removeOnComplete: { count: 200 },
    removeOnFail: { count: 1000 },
    attempts: 3,
    backoff: { type: "exponential", delay: 2000 },
  },
});

export const moderationQueue = new Queue("moderation", {
  connection: REDIS_CONNECTION,
  defaultJobOptions: {
    removeOnComplete: { count: 100 },
    removeOnFail: { count: 500 },
    attempts: 2,
  },
});

export const tradeMatchingQueue = new Queue("trade-matching", {
  connection: REDIS_CONNECTION,
  defaultJobOptions: {
    // Trade matching is idempotent per order ID — deduplication key prevents
    // double-processing if the enqueueing web handler is called twice
    removeOnComplete: { count: 200 },
    removeOnFail: { count: 500 },
    attempts: 5,
    backoff: { type: "exponential", delay: 500 },
  },
});

// ---------------------------------------------------------------------------
// TYPED JOB PAYLOADS
// ---------------------------------------------------------------------------

export interface FeedRankingJobData {
  postId: string;
  event: "like" | "comment" | "share" | "save" | "view";
}

export interface NexiVisionJobData {
  wardrobeItemId: string;
  userId: string;
  imageUrl: string;
}

export interface NotificationJobData {
  recipientId: string;
  type: string;
  data: Record<string, unknown>;
}

export interface ModerationJobData {
  postId: string;
  userId: string;
  mediaUrls: string[];
  caption: string | null;
}

export interface TradeMatchingJobData {
  tradeOrderId: string;
  assetId: string;
  side: "BUY" | "SELL";
}

// ---------------------------------------------------------------------------
// ENQUEUE HELPERS — used by web app API routes
// ---------------------------------------------------------------------------

export async function enqueueFeedRankUpdate(postId: string, event: FeedRankingJobData["event"]) {
  await feedRankingQueue.add(
    "update-rank",
    { postId, event } satisfies FeedRankingJobData,
    { jobId: `rank-${postId}-${Date.now()}` },
  );
}

export async function enqueueNexiVisionTag(data: NexiVisionJobData) {
  await nexiVisionQueue.add(
    "tag-garment",
    data,
    { jobId: `vision-${data.wardrobeItemId}`, delay: 0 },
  );
}

export async function enqueueNotification(data: NotificationJobData) {
  await notificationsQueue.add("send", data);
}

export async function enqueueModeration(data: ModerationJobData) {
  await moderationQueue.add(
    "screen",
    data,
    { jobId: `mod-${data.postId}` },
  );
}

export async function enqueueTradeMatch(data: TradeMatchingJobData) {
  await tradeMatchingQueue.add(
    "match",
    data,
    { jobId: `trade-${data.tradeOrderId}`, priority: 1 },
  );
}
