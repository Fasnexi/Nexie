// =============================================================================
// FASNEXI — PROMOTED LISTINGS SERVICE
// packages/api/src/promotions/service.ts
//
// Per White Paper §18.1: vendor/creator paid promotion, billed per impression
// (CPM) up to a daily budget.
//
// CONCURRENCY NOTE: billing an impression against a budget is structurally
// identical to the inventory-decrement race fixed in the hardening pass —
// many concurrent feed renders could each try to bill an impression against
// a budget that has 1 impression-unit of headroom left. Applying the same
// atomic-conditional-update fix: updateMany WHERE billedAmount + cpmCost <=
// dailyBudget guards the increment so spend can never exceed budget even
// under high concurrent read traffic.
// =============================================================================

import { db } from "@fasnexi/db";

// ---------------------------------------------------------------------------
// CREATE CAMPAIGN
// ---------------------------------------------------------------------------
export async function createPromotedListing(input: {
  productId: string;
  vendorUserId: string;
  budgetAmount: number;   // total campaign budget, smallest currency unit
  dailyBudget: number;
  cpmAmount: number;      // cost per 1000 impressions
  currency: string;
  startDate: Date;
  endDate: Date;
}) {
  const product = await db.product.findUnique({
    where: { id: input.productId },
    select: { id: true, vendor: { select: { userId: true } } },
  });
  if (!product) throw new Error("Product not found");
  if (product.vendor.userId !== input.vendorUserId) {
    throw new Error("You do not own this product");
  }
  if (input.endDate <= input.startDate) {
    throw new Error("endDate must be after startDate");
  }
  if (input.budgetAmount <= 0 || input.dailyBudget <= 0 || input.cpmAmount <= 0) {
    throw new Error("budgetAmount, dailyBudget and cpmAmount must be positive");
  }
  if (input.currency !== product.priceCurrency) {
    throw new Error(`Promotion currency ${input.currency} does not match product currency ${product.priceCurrency}`);
  }
  if (input.dailyBudget > input.budgetAmount) {
    throw new Error("dailyBudget cannot exceed total budgetAmount");
  }

  return db.promotedProduct.create({
    data: {
      productId: input.productId,
      vendorId: (await db.vendorProfile.findUniqueOrThrow({ where: { userId: input.vendorUserId }, select: { id: true } })).id,
      budgetAmount: input.budgetAmount,
      dailyBudget: input.dailyBudget,
      cpmAmount: input.cpmAmount,
      currency: input.currency as any,
      startDate: input.startDate,
      endDate: input.endDate,
      isActive: true,
      impressions: 0,
      clicks: 0,
      billedAmount: 0,
    },
  });
}

// ---------------------------------------------------------------------------
// BILL IMPRESSION — atomic budget-guarded increment
//
// Called by the feed rendering path (batched, not per-render — see note at
// bottom) whenever a promoted product card is shown. Uses the same
// conditional-updateMany technique that fixed the inventory overselling bug:
// the WHERE clause re-validates the budget ceiling at write time, so no
// amount of concurrent billing calls can push billedAmount past budgetAmount.
// ---------------------------------------------------------------------------
export async function billImpressions(
  promotedProductId: string,
  impressionCount: number,
): Promise<{ billed: boolean; costBilled: number }> {
  const promo = await db.promotedProduct.findUnique({
    where: { id: promotedProductId },
    select: { cpmAmount: true, budgetAmount: true, dailyBudget: true, billedAmount: true, dailyBilledAmount: true, billingDay: true, isActive: true, endDate: true },
  });
  if (!promo || !promo.isActive) return { billed: false, costBilled: 0 };
  if (new Date() > promo.endDate) {
    await db.promotedProduct.update({ where: { id: promotedProductId }, data: { isActive: false } });
    return { billed: false, costBilled: 0 };
  }

  const cpm = promo.cpmAmount ?? 0;
  const costForImpressions = Math.round((cpm * impressionCount) / 1000);
  if (costForImpressions === 0) {
    // Below billing granularity — just count the impressions, no spend yet
    await db.promotedProduct.update({
      where: { id: promotedProductId },
      data: { impressions: { increment: impressionCount } },
    });
    return { billed: true, costBilled: 0 };
  }

  // ATOMIC GUARD: enforce BOTH total campaign budget and daily budget.
  // billingDay/dailyBilledAmount are updated in the same SQL statement so
  // concurrent feed workers cannot reset a day and overspend it.
  const now = new Date();
  const result = await db.$executeRaw`
    UPDATE "promoted_products"
    SET "billedAmount" = "billedAmount" + ${costForImpressions},
        "dailyBilledAmount" = CASE
          WHEN "billingDay" IS NULL OR ("billingDay" AT TIME ZONE 'UTC')::date <> (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::date
            THEN ${costForImpressions}
          ELSE "dailyBilledAmount" + ${costForImpressions}
        END,
        "billingDay" = ${now},
        "impressions" = "impressions" + ${impressionCount},
        "lastBilledAt" = ${now}
    WHERE "id" = ${promotedProductId}::uuid
      AND "isActive" = true
      AND "billedAmount" + ${costForImpressions} <= "budgetAmount"
      AND (
        ("billingDay" IS NULL OR ("billingDay" AT TIME ZONE 'UTC')::date <> (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::date)
          AND ${costForImpressions} <= "dailyBudget"
        OR
        ("billingDay" IS NOT NULL AND ("billingDay" AT TIME ZONE 'UTC')::date = (CURRENT_TIMESTAMP AT TIME ZONE 'UTC')::date
          AND "dailyBilledAmount" + ${costForImpressions} <= "dailyBudget")
      )
  `;

  if (result === 0) {
    // Budget exhausted — deactivate so the feed stops selecting this promo
    await db.promotedProduct.updateMany({
      where: { id: promotedProductId, isActive: true },
      data: { isActive: false },
    });
    return { billed: false, costBilled: 0 };
  }

  return { billed: true, costBilled: costForImpressions };
}

// ---------------------------------------------------------------------------
// RECORD CLICK — separate from impression billing, simple increment
// (clicks aren't billed under CPM; they're a quality signal for ranking)
// ---------------------------------------------------------------------------
export async function recordClick(promotedProductId: string): Promise<void> {
  await db.promotedProduct.update({
    where: { id: promotedProductId },
    data: { clicks: { increment: 1 } },
  });
}

// ---------------------------------------------------------------------------
// GET ACTIVE PROMOTIONS FOR FEED INJECTION
// ---------------------------------------------------------------------------
export async function getActivePromotions(limit = 5) {
  const now = new Date();
  return db.promotedProduct.findMany({
    where: {
      isActive: true,
      startDate: { lte: now },
      endDate: { gte: now },
      product: { isPublished: true, isInStock: true },
      // Only surface campaigns with budget headroom remaining
    },
    orderBy: { lastBilledAt: "asc" }, // rotate — least-recently-billed first
    take: limit,
    include: {
      product: { select: { id: true, name: true, imageUrls: true, priceAmount: true, priceCurrency: true } },
    },
  });
}

// ---------------------------------------------------------------------------
// VENDOR CAMPAIGN DASHBOARD
// ---------------------------------------------------------------------------
export async function getVendorPromotions(vendorUserId: string) {
  const vendor = await db.vendorProfile.findUniqueOrThrow({
    where: { userId: vendorUserId },
    select: { id: true },
  });
  return db.promotedProduct.findMany({
    where: { vendorId: vendor.id },
    orderBy: { startDate: "desc" },
    include: { product: { select: { name: true, imageUrls: true } } },
  });
}

// -----------------------------------------------------------------------------
// NOTE ON BATCHING: In production, billImpressions should be called from a
// batched worker job (accumulate impression counts in Redis per promo per
// minute, flush to billImpressions once per minute) rather than once per
// feed render, to avoid a DB write on every single scroll event. The atomic
// budget guard here makes that batching safe regardless of batch size or
// concurrent worker instances.
// -----------------------------------------------------------------------------
