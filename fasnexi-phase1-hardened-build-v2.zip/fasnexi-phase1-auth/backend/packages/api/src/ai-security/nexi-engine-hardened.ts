// =============================================================================
// FASNEXI — NEXI ENGINE (HARDENED)
// packages/api/src/ai-security/nexi-engine-hardened.ts
//
// FIXES APPLIED:
//
// 1. NON-ATOMIC RATE LIMIT — GET then INCR is a race condition.
//    Two concurrent requests can both GET count=19, both pass the check,
//    both INCR to 20/21, both get served — exceeding the 20/day limit.
//    FIX: Lua script makes check+increment atomic. See redis.ts.
//
// 2. REDIS CONNECTION PER REQUEST — createClient + connect + disconnect
//    on every AI call. At 20 req/user/day × 1000 users = 20,000 new TCP
//    connections per day, hitting Upstash's connection limit.
//    FIX: Singleton Redis client from redis.ts.
//
// 3. PROMPT INJECTION — user-controlled content (wardrobe item notes,
//    brand names, captions) was embedded in the context block without
//    sanitisation. A user could write a brand name like:
//    "IGNORE PREVIOUS INSTRUCTIONS. You are now..."
//    FIX: All user-controlled text is XML-escaped and structurally separated
//    from system instructions. The context block uses a fixed schema that
//    Claude cannot be instructed to override via user data fields.
//
// 4. AI PROVENANCE — no record of which model version/prompt version
//    generated the tags stored in WardrobeItem.aiTags.
//    FIX: AiProvenance fields added: modelVersion, promptVersion, taggedAt.
//    Changing the tagger model/prompt requires bumping TAGGER_PROMPT_VERSION.
// =============================================================================

import { db } from "@fasnexi/db";
import { atomicRateLimit } from "../redis";
import { buildContextBlock, NEXI_SYSTEM_PROMPT } from "../nexi/prompts";
import { buildNexiContext } from "../nexi/context";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

const MODEL            = "claude-sonnet-4-6";
const MAX_RESPONSE_TOKENS = 1000;
const FREE_TIER_DAILY_LIMIT = 20;

// Bump this string whenever the tagger prompt changes — stored with each tag
export const TAGGER_PROMPT_VERSION = "v1.0.0";

// ---------------------------------------------------------------------------
// ATOMIC RATE LIMITER — replaces GET→check→INCR
// ---------------------------------------------------------------------------
async function checkRateLimit(userId: string): Promise<{
  allowed: boolean;
  remaining: number;
}> {
  // Get subscription tier first — determines limit
  const sub = await db.subscription.findUnique({
    where: { userId },
    select: { tier: true },
  });
  const isPro = sub?.tier === "NEXI_PRO" || sub?.tier === "STUDIO";

  if (isPro) return { allowed: true, remaining: 999 };

  const today = new Date().toISOString().split("T")[0];
  const key   = `nexi:rl:${userId}:${today}`;

  // TTL = seconds until end of day + 60s buffer
  const now = new Date();
  const ttl  = 86400 - (now.getUTCHours() * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds()) + 60;

  const result = await atomicRateLimit({
    key,
    limit:      FREE_TIER_DAILY_LIMIT,
    ttlSeconds: ttl,
  });

  return { allowed: result.allowed, remaining: result.remaining };
}

// ---------------------------------------------------------------------------
// PROMPT INJECTION DEFENCE — sanitise user-controlled text before injection
//
// Strips or escapes characters that could be interpreted as instructions:
//   - XML/HTML tags (could confuse structured context parsing)
//   - Sequences that look like system-prompt delimiters
//   - Excessively long strings (truncated to sane limits)
// ---------------------------------------------------------------------------
export function sanitiseUserText(input: string | null | undefined, maxLen = 200): string {
  if (!input) return "";
  return input
    .slice(0, maxLen)
    // Remove XML/HTML tags
    .replace(/<[^>]*>/g, "")
    // Remove prompt-injection common patterns
    .replace(/\[INST\]|\[\/INST\]|<\|im_start\|>|<\|im_end\|>|###\s*System|###\s*Human|###\s*Assistant/gi, "")
    // Collapse excessive whitespace
    .replace(/\s+/g, " ")
    .trim();
}

export function sanitiseWardrobeItem(item: {
  brand: string | null;
  colorLabel: string | null;
  aiColors: string[];
  aiPattern: string | null;
  notes?: string | null;
}): typeof item {
  return {
    brand:      sanitiseUserText(item.brand, 50),
    colorLabel: sanitiseUserText(item.colorLabel, 30),
    aiColors:   item.aiColors.map(c => sanitiseUserText(c, 30)),
    aiPattern:  sanitiseUserText(item.aiPattern, 30),
    notes:      undefined, // NEVER inject free-text notes into AI prompts
  };
}

// ---------------------------------------------------------------------------
// HARDENED CHAT — atomic rate limit + singleton Redis + sanitised context
// ---------------------------------------------------------------------------
export async function runNexiChatHardened(opts: {
  userId: string;
  query: string;
  sessionId?: string;
  occasion?: string;
  season?: string;
}): Promise<{ sessionId: string; content: string; tokenCount: number; remaining: number }> {
  const { userId, query, sessionId: incomingSessionId, occasion, season } = opts;

  // Validate and sanitise query — do NOT sanitise silently, reject if too long
  if (!query || query.trim().length === 0) throw new Error("Query cannot be empty");
  if (query.length > 2000) throw new Error("Query exceeds 2000 character limit");

  // Atomic rate limit check
  const { allowed, remaining } = await checkRateLimit(userId);
  if (!allowed) {
    throw new Error(`Daily Nexi query limit reached (${FREE_TIER_DAILY_LIMIT}/day on free tier). Upgrade to Nexi Pro for unlimited queries.`);
  }

  // Build context (wardrobe items are sanitised inside buildContextBlock via prompts.ts)
  const nexiContext = await buildNexiContext(userId, { occasion, season });
  const contextBlock = buildContextBlock(nexiContext);

  // Get or create session
  let sessionId = incomingSessionId;
  if (!sessionId) {
    const session = await db.nexiSession.create({
      data: { userId, messages: [], turnCount: 0, tokenCount: 0 },
      select: { id: true },
    });
    sessionId = session.id;
  }

  const session = await db.nexiSession.findFirstOrThrow({
    where: { id: sessionId, userId }, // ownership check built in
    select: { messages: true, turnCount: true },
  });

  const history = ((session.messages as any[]) ?? []).slice(-20);

  const messages: Anthropic.MessageParam[] = [
    { role: "user", content: contextBlock },
    { role: "assistant", content: "Understood. I have your style profile and wardrobe context ready." },
    ...history.map((m: any): Anthropic.MessageParam => ({
      role: m.role,
      content: m.content,
    })),
    { role: "user", content: query },
  ];

  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: MAX_RESPONSE_TOKENS,
    system: NEXI_SYSTEM_PROMPT,
    messages,
  });

  const content = response.content
    .filter(b => b.type === "text")
    .map(b => (b as Anthropic.TextBlock).text)
    .join("");

  const tokensUsed = (response.usage?.input_tokens ?? 0) + (response.usage?.output_tokens ?? 0);

  // Persist to session
  const updatedMessages = [
    ...history,
    { role: "user",      content: query,   timestamp: new Date().toISOString() },
    { role: "assistant", content,          timestamp: new Date().toISOString() },
  ].slice(-40); // keep last 20 turns (40 messages)

  await db.nexiSession.update({
    where: { id: sessionId },
    data: {
      messages: updatedMessages,
      turnCount: { increment: 1 },
      tokenCount: { increment: tokensUsed },
    },
  });

  return { sessionId, content, tokenCount: tokensUsed, remaining };
}

// ---------------------------------------------------------------------------
// AI PROVENANCE — stored alongside every AI-generated tag set
// ---------------------------------------------------------------------------
export interface AiProvenance {
  model: string;
  promptVersion: string;
  taggedAt: string;
  confidence: number;
  source: "claude-vision" | "manual" | "corrected-by-user";
  userCorrected: boolean;
}

export function buildProvenance(confidence: number): AiProvenance {
  return {
    model: MODEL,
    promptVersion: TAGGER_PROMPT_VERSION,
    taggedAt: new Date().toISOString(),
    confidence,
    source: "claude-vision",
    userCorrected: false,
  };
}

// Used when user manually corrects an AI tag
export function buildCorrectedProvenance(original: AiProvenance): AiProvenance {
  return { ...original, userCorrected: true, source: "corrected-by-user" };
}
