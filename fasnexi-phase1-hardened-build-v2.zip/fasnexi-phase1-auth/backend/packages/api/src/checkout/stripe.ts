// =============================================================================
// FASNEXI — CHECKOUT SERVICE
// packages/api/src/checkout/stripe.ts
//
// Handles Stripe Checkout Session creation and webhook processing.
// Multi-currency: USD/EUR/GBP via Stripe; NGN/KES/GHS/ZAR via Paystack
// or Flutterwave (gateway selected by currency at checkout time).
// Creator commission attribution is written to CreatorCommission here,
// so no post-purchase reconciliation job is needed.
// =============================================================================

import Stripe from "stripe";
import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";
import type { Currency, PaymentMethod } from "@prisma/client";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-04-10",
  typescript: true,
});

export interface CheckoutItem {
  productId: string;
  quantity: number;
  size?: string;
  color?: string;
}

export interface CreateCheckoutOptions {
  userId: string;
  items: CheckoutItem[];
  currency: Currency;
  successUrl: string;
  cancelUrl: string;
  creatorId?: string;   // if user arrived via a creator's post — attribution
  couponCode?: string;
}

// ---------------------------------------------------------------------------
// ROUTE: CREATE CHECKOUT SESSION
// ---------------------------------------------------------------------------
export async function createCheckoutSession(options: CreateCheckoutOptions) {
  const { userId, items, currency, successUrl, cancelUrl, creatorId } = options;

  // Validate items and fetch prices in one query
  const productIds = items.map(i => i.productId);
  const products = await db.product.findMany({
    where: { id: { in: productIds }, isPublished: true, isInStock: true },
    select: {
      id: true,
      name: true,
      priceAmount: true,
      priceCurrency: true,
      imageUrls: true,
      inventoryCount: true,
      vendor: { select: { id: true, stripeAccountId: true } },
    },
  });

  if (new Set(productIds).size !== productIds.length) {
    throw new Error("Duplicate products are not allowed in checkout");
  }

  if (products.length !== productIds.length) {
    const found = new Set(products.map(p => p.id));
    const missing = productIds.filter(id => !found.has(id));
    throw new Error(`Products unavailable or out of stock: ${missing.join(", ")}`);
  }

  const mismatched = products.filter(p => p.priceCurrency !== currency);
  if (mismatched.length > 0) {
    throw new Error(`Checkout currency ${currency} does not match product currency for: ${mismatched.map(p => p.name).join(", ")}`);
  }

  // Validate stock for each item
  const productMap = new Map(products.map(p => [p.id, p]));
  for (const item of items) {
    const p = productMap.get(item.productId)!;
    if (p.inventoryCount < item.quantity) {
      throw new Error(`Insufficient stock for "${p.name}" (requested ${item.quantity}, available ${p.inventoryCount})`);
    }
  }

  // Route to the correct gateway based on currency
  const africaCurrencies: Currency[] = ["NGN", "KES", "GHS", "ZAR", "XOF", "XAF"];
  if (africaCurrencies.includes(currency)) {
    return createAfricanGatewaySession(options, products);
  }

  // Build Stripe line items
  const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = items.map(item => {
    const p = productMap.get(item.productId)!;
    return {
      price_data: {
        currency: currency.toLowerCase(),
        product_data: {
          name: p.name,
          images: p.imageUrls.slice(0, 1),
          metadata: { productId: p.id },
        },
        unit_amount: p.priceAmount, // stored in smallest unit (cents/kobo)
      },
      quantity: item.quantity,
    };
  });

  // Build metadata for webhook handler
  const metadata = {
    userId,
    creatorId: creatorId ?? "",
    itemsJson: JSON.stringify(
      items.map(i => ({
        productId: i.productId,
        quantity: i.quantity,
        size: i.size ?? "",
        color: i.color ?? "",
        unitAmount: productMap.get(i.productId)!.priceAmount,
        vendorStripeAccountId: productMap.get(i.productId)!.vendor.stripeAccountId ?? "",
      })),
    ),
  };

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: lineItems,
    success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: cancelUrl,
    customer_email: undefined, // Better Auth session has email — passed via Stripe customer
    currency: currency.toLowerCase(),
    metadata,
    payment_intent_data: {
      metadata,
    },
  });

  return { url: session.url, sessionId: session.id };
}

// ---------------------------------------------------------------------------
// WEBHOOK: CHECKOUT.SESSION.COMPLETED
// Creates Order, OrderItems, decrements inventory, attributes commissions.
// ---------------------------------------------------------------------------
export async function handleCheckoutComplete(
  rawBody: Buffer,
  signature: string,
): Promise<void> {
  const event = stripe.webhooks.constructEvent(
    rawBody,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET!,
  );

  if (event.type === "checkout.session.expired") {
    const expired = event.data.object as Stripe.Checkout.Session;
    const metadata = expired.metadata ?? {};
    if (metadata.kind === "ticket" && metadata.ticketId) {
      await releaseTicketReservationByCheckout(metadata.ticketId, expired.id);
    }
    return;
  }

  if (event.type !== "checkout.session.completed") return;

  const session = event.data.object as Stripe.Checkout.Session;
  const metadata = session.metadata ?? {};

  if (metadata.kind === "ticket" && metadata.ticketId) {
    await db.ticket.updateMany({
      where: { id: metadata.ticketId, paymentRef: session.id },
      data: { paymentRef: String(session.payment_intent ?? session.id) },
    });
    return;
  }

  const { userId, creatorId } = metadata;
  const items: Array<{
    productId: string;
    quantity: number;
    size: string;
    color: string;
    unitAmount: number;
  }> = JSON.parse(metadata.itemsJson ?? "[]");

  if (!userId || items.length === 0) {
    console.error("Webhook missing userId or items", session.id);
    return;
  }

  // Stripe may redeliver checkout.session.completed. The order's unique
  // checkoutSessionId is the durable idempotency key; return the existing
  // order before touching inventory, commissions, or loyalty.
  const existingOrder = await db.order.findUnique({
    where: { checkoutSessionId: session.id },
    select: { id: true },
  });
  if (existingOrder) return;

  await db.$transaction(async tx => {
    // Re-check inside the transaction so concurrent webhook deliveries do not
    // both proceed past the preflight check. The unique constraint on
    // checkoutSessionId is the final database-level guard.
    const concurrentOrder = await tx.order.findUnique({
      where: { checkoutSessionId: session.id },
      select: { id: true },
    });
    if (concurrentOrder) return;

    // 1. Create the Order record
    const order = await tx.order.create({
      data: {
        userId,
        checkoutSessionId: session.id,
        status: "PAID",
        paymentMethod: "STRIPE_CARD" as PaymentMethod,
        paymentRef: session.payment_intent as string,
        subtotalAmount: session.amount_subtotal ?? 0,
        shippingAmount: 0,
        discountAmount: session.total_details?.amount_discount ?? 0,
        totalAmount: session.amount_total ?? 0,
        currency: (session.currency?.toUpperCase() ?? "USD") as Currency,
        items: {
          create: items.map(item => ({
            productId: item.productId,
            quantity: item.quantity,
            unitAmount: item.unitAmount,
            currency: (session.currency?.toUpperCase() ?? "USD") as Currency,
            size: item.size || null,
            color: item.color || null,
          })),
        },
      },
    });

    // 2. Decrement inventory for each item
    for (const item of items) {
      const result = await tx.product.updateMany({
        where: { id: item.productId, inventoryCount: { gte: item.quantity } },
        data: {
          inventoryCount: { decrement: item.quantity },
        },
      });
      if (result.count === 0) {
        throw new Error(`Insufficient inventory for product ${item.productId}`);
      }
      await tx.product.updateMany({
        where: { id: item.productId, inventoryCount: 0 },
        data: { isInStock: false },
      });
    }

    // 3. Update product sales counts
    for (const item of items) {
      await tx.product.update({
        where: { id: item.productId },
        data: { salesCount: { increment: item.quantity } },
      });
    }

    // 4. Creator commission attribution (if referral present)
    if (creatorId) {
      const creator = await tx.creatorProfile.findUnique({
        where: { userId: creatorId },
        select: { id: true, commissionRate: true },
      });
      if (creator) {
        const commissionAmount = Math.round(order.totalAmount * creator.commissionRate);
        await tx.creatorCommission.create({
          data: {
            creatorId: creator.id,
            orderId: order.id,
            userId,
            amount: commissionAmount,
            currency: order.currency,
            rate: creator.commissionRate,
            status: "PENDING",
          },
        });
      }
    }

    // 5. Update buyer loyalty points: 1pt per dollar spent
    const dollarAmount = Math.floor(order.totalAmount / 100);
    if (dollarAmount > 0) {
      await tx.loyaltyAccount.upsert({
        where: { userId },
        create: { userId, points: dollarAmount, lifetimePoints: dollarAmount },
        update: {
          points: { increment: dollarAmount },
          lifetimePoints: { increment: dollarAmount },
        },
      });
    }
  });

  // 6. Send order confirmation notification (outside transaction — fire and forget)
  await enqueueNotification({
    recipientId: userId,
    type: "ORDER_UPDATE",
    data: { status: "PAID", paymentRef: session.payment_intent as string },
  });
}

async function releaseTicketReservationByCheckout(ticketId: string, checkoutSessionId: string): Promise<void> {
  await db.$transaction(async tx => {
    const ticket = await tx.ticket.findFirst({ where: { id: ticketId, paymentRef: checkoutSessionId }, select: { id: true, tierId: true } });
    if (!ticket) return;
    await tx.ticket.delete({ where: { id: ticket.id } });
    await tx.ticketTier.updateMany({ where: { id: ticket.tierId, sold: { gt: 0 } }, data: { sold: { decrement: 1 } } });
  });
}

// ---------------------------------------------------------------------------
// AFRICAN GATEWAY ROUTING
// Paystack for NGN/GHS/ZAR; Flutterwave for KES/XOF/XAF.
// Returns a redirect URL to the gateway's hosted payment page.
// The gateway webhook (separate handler) creates the Order record on success.
// ---------------------------------------------------------------------------
async function createAfricanGatewaySession(
  options: CreateCheckoutOptions,
  products: any[],
): Promise<{ url: string; sessionId: string }> {
  const { currency, userId, successUrl, cancelUrl } = options;
  const productMap = new Map(products.map(p => [p.id, p]));

  const totalAmount = options.items.reduce((sum, item) => {
    return sum + (productMap.get(item.productId)?.priceAmount ?? 0) * item.quantity;
  }, 0);

  const user = await db.user.findUniqueOrThrow({
    where: { id: userId },
    select: { email: true, displayName: true },
  });

  // Paystack handles NGN, GHS, ZAR natively
  const paystackCurrencies: Currency[] = ["NGN", "GHS", "ZAR"];

  if (paystackCurrencies.includes(currency)) {
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: user.email,
        amount: totalAmount, // Paystack expects kobo/pesewa/cents
        currency,
        callback_url: successUrl,
        metadata: {
          userId,
          cancel_action: cancelUrl,
          custom_fields: options.items.map(i => ({
            display_name: productMap.get(i.productId)?.name,
            variable_name: "product_id",
            value: i.productId,
          })),
        },
      }),
    });
    const data = await response.json();
    if (!data.status) throw new Error(`Paystack error: ${data.message}`);
    return { url: data.data.authorization_url, sessionId: data.data.reference };
  }

  // Flutterwave handles KES, XOF, XAF
  const response = await fetch("https://api.flutterwave.com/v3/payments", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      tx_ref: `fasnexi-${userId}-${Date.now()}`,
      amount: totalAmount / 100, // Flutterwave expects whole units
      currency,
      redirect_url: successUrl,
      customer: { email: user.email, name: user.displayName },
      customizations: {
        title: "FasNexi",
        logo: "https://fasnexi.com/logo.png",
      },
    }),
  });
  const data = await response.json();
  if (data.status !== "success") throw new Error(`Flutterwave error: ${data.message}`);
  return { url: data.data.link, sessionId: data.data.flw_ref };
}
