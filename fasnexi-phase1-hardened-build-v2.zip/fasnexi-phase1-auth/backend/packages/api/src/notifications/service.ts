// =============================================================================
// FASNEXI — NOTIFICATIONS SERVICE
// packages/api/src/notifications/service.ts
//
// GAP FIX: the Notification model has existed in schema.prisma since the
// original build, and enqueueNotification() (packages/api/src/queue/index.ts)
// has been called from challenges, tailor, resale, and other services all
// along — but nothing ever consumed the "notifications" BullMQ queue, so no
// Notification row was ever created, and no route existed to read them even
// if there were. This file is the read side (used by the API routes) plus
// the write side used by the new worker processor (apps/worker/src/
// notifications.ts) that actually drains the queue.
// =============================================================================

import { db } from "@fasnexi/db";
import type { NotificationType } from "@prisma/client";

export interface NotificationListResult {
  notifications: Array<{
    id: string;
    type: NotificationType;
    read: boolean;
    data: unknown;
    createdAt: Date;
  }>;
  nextCursor: string | null;
  unreadCount: number;
}

// ---------------------------------------------------------------------------
// LIST — cursor-paginated, matches the convention used by every other list
// endpoint in the codebase (feed, wardrobe, resale, etc.)
// ---------------------------------------------------------------------------
export async function getNotifications(
  userId: string,
  opts: { cursor?: string; limit?: number; unreadOnly?: boolean } = {},
): Promise<NotificationListResult> {
  const { cursor, limit = 30, unreadOnly = false } = opts;

  const where = {
    userId,
    ...(unreadOnly && { read: false }),
    ...(cursor && { id: { lt: cursor } }),
  };

  const [rows, unreadCount] = await Promise.all([
    db.notification.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: limit + 1,
    }),
    db.notification.count({ where: { userId, read: false } }),
  ]);

  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;

  return {
    notifications: items,
    nextCursor: hasMore ? items[items.length - 1].id : null,
    unreadCount,
  };
}

// ---------------------------------------------------------------------------
// MARK ONE READ — ownership enforced via the where clause itself (same
// pattern as wardrobe/resale: a mismatched userId means 0 rows updated,
// which the route treats as "not found", never leaking existence of
// another user's notification).
// ---------------------------------------------------------------------------
export async function markNotificationRead(
  notificationId: string,
  userId: string,
): Promise<{ updated: boolean }> {
  const result = await db.notification.updateMany({
    where: { id: notificationId, userId },
    data: { read: true },
  });
  return { updated: result.count > 0 };
}

// ---------------------------------------------------------------------------
// MARK ALL READ
// ---------------------------------------------------------------------------
export async function markAllNotificationsRead(userId: string): Promise<{ updatedCount: number }> {
  const result = await db.notification.updateMany({
    where: { userId, read: false },
    data: { read: true },
  });
  return { updatedCount: result.count };
}

// ---------------------------------------------------------------------------
// CREATE FROM QUEUE JOB — called by the notifications worker, not by any
// route directly. Intentionally idempotent-agnostic: BullMQ job dedup
// (jobId) is the enqueue side's job, not this function's — this just writes
// what it's told once per job execution. If a job replays, a duplicate
// Notification row is the acceptable cost (unlike financial operations,
// there's no correctness hazard in someone seeing a duplicate "new follower"
// notification — the loyalty/wallet ledger pattern of strict idempotency
// doesn't apply here the same way).
// ---------------------------------------------------------------------------
export async function createNotificationFromJob(job: {
  recipientId: string;
  type: string;
  data: Record<string, unknown>;
}): Promise<{ id: string }> {
  const notification = await db.notification.create({
    data: {
      userId: job.recipientId,
      type: job.type as NotificationType,
      data: job.data as any,
      read: false,
    },
    select: { id: true },
  });
  return notification;
}
