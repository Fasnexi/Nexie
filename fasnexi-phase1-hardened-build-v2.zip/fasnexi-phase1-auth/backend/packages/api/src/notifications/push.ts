// =============================================================================
// FASNEXI — PUSH NOTIFICATION SERVICE
// packages/api/src/notifications/push.ts
//
// GAP FIX: no push-token registration endpoint existed, and the existing
// notifications worker (apps/worker/src/index.ts) had a
// "// TODO Phase 5: send Expo push via @expo/server-sdk" stub instead of
// actually dispatching. This file provides both halves: device token
// CRUD (called from the new /api/push-tokens routes) and the dispatch
// function (called from the worker, see the modified apps/worker/src/
// index.ts in this same delivery).
//
// Uses raw fetch to Expo's push API rather than the @expo/server-sdk package
// to avoid adding a new dependency for what's a single JSON POST — swap to
// the SDK later if receipt-checking / auto token cleanup becomes worth the
// added complexity.
// =============================================================================

import { db } from "@fasnexi/db";

const EXPO_PUSH_ENDPOINT = "https://exp.host/--/api/v2/push/send";
const EXPO_PUSH_BATCH_SIZE = 100; // Expo's documented per-request cap

export type DevicePlatform = "ios" | "android" | "web" | "unknown";

// ---------------------------------------------------------------------------
// REGISTER — upsert on expoToken (unique). A device re-registering after
// reinstall/token-rotation just updates lastUsedAt and userId (handles the
// token-recycled-to-a-different-user edge case Expo docs warn about) rather
// than erroring on the unique constraint.
// ---------------------------------------------------------------------------
export async function registerDeviceToken(input: {
  userId: string;
  expoToken: string;
  platform?: DevicePlatform;
  deviceName?: string;
}): Promise<{ id: string }> {
  if (!input.expoToken.startsWith("ExponentPushToken[") && !input.expoToken.startsWith("ExpoPushToken[")) {
    throw new Error("expoToken does not look like a valid Expo push token");
  }

  const token = await db.deviceToken.upsert({
    where: { expoToken: input.expoToken },
    create: {
      userId: input.userId,
      expoToken: input.expoToken,
      platform: input.platform ?? "unknown",
      deviceName: input.deviceName ?? null,
    },
    update: {
      userId: input.userId, // re-registering under a new account reassigns ownership
      platform: input.platform ?? "unknown",
      deviceName: input.deviceName ?? null,
      lastUsedAt: new Date(),
    },
    select: { id: true },
  });

  return token;
}

// ---------------------------------------------------------------------------
// UNREGISTER — ownership enforced via the where clause, same pattern as
// notifications/service.ts markNotificationRead.
// ---------------------------------------------------------------------------
export async function unregisterDeviceToken(
  deviceTokenId: string,
  userId: string,
): Promise<{ deleted: boolean }> {
  const result = await db.deviceToken.deleteMany({
    where: { id: deviceTokenId, userId },
  });
  return { deleted: result.count > 0 };
}

// ---------------------------------------------------------------------------
// DISPATCH — best-effort push to every device a user has registered.
// Never throws: a push-delivery failure must not fail the notification
// pipeline or roll back the DB write the caller already made. Logs and
// returns a result summary instead.
// ---------------------------------------------------------------------------
export interface DispatchResult {
  attempted: number;
  sent: number;
  invalidTokensRemoved: number;
}

export async function dispatchPushToUser(
  userId: string,
  notification: { title: string; body: string; data?: Record<string, unknown> },
): Promise<DispatchResult> {
  const devices = await db.deviceToken.findMany({
    where: { userId },
    select: { id: true, expoToken: true },
  });

  if (devices.length === 0) {
    return { attempted: 0, sent: 0, invalidTokensRemoved: 0 };
  }

  const messages = devices.map(d => ({
    to: d.expoToken,
    title: notification.title,
    body: notification.body,
    data: notification.data ?? {},
    sound: "default" as const,
  }));

  let sent = 0;
  let invalidTokensRemoved = 0;

  for (let i = 0; i < messages.length; i += EXPO_PUSH_BATCH_SIZE) {
    const batch = messages.slice(i, i + EXPO_PUSH_BATCH_SIZE);

    try {
      const response = await fetch(EXPO_PUSH_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Accept-Encoding": "gzip, deflate",
        },
        body: JSON.stringify(batch),
      });

      if (!response.ok) {
        console.error(`[push] Expo API returned ${response.status} for batch of ${batch.length}`);
        continue;
      }

      const result = await response.json();
      const tickets: Array<{ status: "ok" | "error"; message?: string; details?: { error?: string } }> =
        result.data ?? [];

      for (let t = 0; t < tickets.length; t++) {
        const ticket = tickets[t];
        if (ticket.status === "ok") {
          sent++;
        } else if (ticket.details?.error === "DeviceNotRegistered") {
          // Token is dead (app uninstalled, etc.) — clean it up so future
          // dispatches don't keep paying the round-trip for a dead device.
          const device = devices[i + t];
          if (device) {
            await db.deviceToken.delete({ where: { id: device.id } }).catch(() => {});
            invalidTokensRemoved++;
          }
        } else {
          console.error(`[push] Delivery error for token ${batch[t].to.slice(0, 20)}...: ${ticket.message}`);
        }
      }
    } catch (err: any) {
      // Network/Expo-outage failure — never propagate. The in-app
      // notification (already written to the DB by the caller) is the
      // fallback delivery channel.
      console.error("[push] Dispatch batch failed:", err.message);
    }
  }

  return { attempted: messages.length, sent, invalidTokensRemoved };
}

// ---------------------------------------------------------------------------
// TITLE/BODY MAPPING — the Notification model stores type + a free-form
// data JSON blob, but Expo push needs title/body strings. Centralising the
// mapping here keeps it in one place as NotificationType grows.
// ---------------------------------------------------------------------------
export function notificationToPushCopy(
  type: string,
  data: Record<string, unknown>,
): { title: string; body: string } {
  switch (type) {
    case "LIKE":
      return { title: "New like", body: "Someone liked your post" };
    case "COMMENT":
      return { title: "New comment", body: (data.preview as string) ?? "Someone commented on your post" };
    case "FOLLOW":
      return { title: "New follower", body: "You have a new follower" };
    case "ORDER_UPDATE":
      return { title: "Order update", body: (data.message as string) ?? "Your order status changed" };
    case "NEXI_SUGGESTION":
      return { title: "Nexi has a suggestion", body: (data.message as string) ?? "Check out what Nexi found for you" };
    case "CHALLENGE_ENDING":
      return { title: "Challenge ending soon", body: (data.message as string) ?? "A challenge you entered is ending soon" };
    case "DROP_ALERT":
      return { title: "New drop", body: (data.message as string) ?? "A new drop just went live" };
    case "PAYOUT_PROCESSED":
      return { title: "Payout sent", body: (data.message as string) ?? "Your payout has been processed" };
    case "COMMISSION_EARNED":
      return { title: "Commission earned", body: (data.message as string) ?? "You earned a new commission" };
    case "PRICE_ALERT":
      return { title: "Price alert", body: (data.message as string) ?? "One of your price alerts triggered" };
    default:
      return { title: "FasNexi", body: (data.message as string) ?? "You have a new notification" };
  }
}
