import { db } from "@fasnexi/db";

export interface StyleDnaInput {
  archetype?: { primaryArchetype?: string; secondaryArchetype?: string };
  bodyProfile?: { bodyShape?: string; fitPreferences?: string[]; sizeTopUS?: string; sizeBottomUS?: string; sizeShoeUS?: string; coveragePreferences?: string[] };
  lifestyle?: { primaryOccasions?: string[]; climateZone?: string; activityLevel?: string; preferredColors?: string[]; avoidedColors?: string[]; seasonalPreference?: string };
}

export async function getStyleProfile(userId: string) {
  return db.styleProfile.findUnique({ where: { userId } });
}

export async function upsertStyleProfile(userId: string, input: StyleDnaInput) {
  const a = input.archetype;
  const b = input.bodyProfile;
  const l = input.lifestyle;
  const data: any = { completedAt: new Date() };
  if (a) { if (a.primaryArchetype !== undefined) data.primaryArchetype = a.primaryArchetype; if (a.secondaryArchetype !== undefined) data.secondaryArchetype = a.secondaryArchetype; }
  if (b) {
    if (b.bodyShape !== undefined) data.bodyShape = b.bodyShape;
    if (b.fitPreferences !== undefined) data.fitPreferences = b.fitPreferences;
    if (b.sizeTopUS !== undefined) data.sizeTopUS = b.sizeTopUS;
    if (b.sizeBottomUS !== undefined) data.sizeBottomUS = b.sizeBottomUS;
    if (b.sizeShoeUS !== undefined) data.sizeShoeUS = b.sizeShoeUS;
    if (b.coveragePreferences !== undefined) data.coveragePreferences = b.coveragePreferences;
  }
  if (l) {
    if (l.primaryOccasions !== undefined) data.primaryOccasions = l.primaryOccasions;
    if (l.climateZone !== undefined) data.climateZone = l.climateZone;
    if (l.activityLevel !== undefined) data.activityLevel = l.activityLevel;
    if (l.preferredColors !== undefined) data.preferredColors = l.preferredColors;
    if (l.avoidedColors !== undefined) data.avoidedColors = l.avoidedColors;
    if (l.seasonalPreference !== undefined) data.seasonalPreference = l.seasonalPreference;
  }
  return db.$transaction(async (tx) => {
    const profile = await tx.styleProfile.upsert({
      where: { userId },
      create: { userId, fitPreferences: [], coveragePreferences: [], primaryOccasions: [], preferredColors: [], avoidedColors: [], ...data },
      update: data,
    });

    // Completing Style DNA is the backend source of truth for the auth
    // router's post-signup destination. Keep the profile and user flag atomic.
    await tx.user.update({
      where: { id: userId },
      data: { onboardingDone: true, onboardingStatus: 6 },
    });

    return profile;
  });
}
