// =============================================================================
// FASNEXI — FX RATE SERVICE
// packages/api/src/fx/service.ts
//
// Per White Paper §17.4 Phase 4: currency detection by device locale, FX
// rates refreshed daily via Open Exchange Rates. This is DISPLAY-ONLY
// conversion (e.g. "≈ ₦45,000" shown under a $30 USD-priced product) —
// actual checkout charges always happen in the product's native listed
// currency via the correct payment gateway (Stripe/Paystack/Flutterwave),
// never in a converted amount. Converting at checkout time would create a
// financial-integrity gap: the hardening pass's ledger is authoritative in
// whatever currency was actually charged, not a derived estimate.
// =============================================================================

import { db } from "@fasnexi/db";
import type { Currency } from "@prisma/client";

const SUPPORTED_CURRENCIES: Currency[] = ["USD", "NGN", "KES", "GHS", "ZAR", "GBP", "EUR", "XOF", "XAF", "EGP"];
const STALE_AFTER_HOURS = 24;

// ---------------------------------------------------------------------------
// GET RATE — cache-first, refreshes if stale
// ---------------------------------------------------------------------------
export async function getExchangeRate(base: Currency, target: Currency): Promise<number> {
  if (base === target) return 1;

  const cached = await db.fxRate.findUnique({
    where: { base_target: { base, target } },
  });

  const isStale = !cached ||
    (Date.now() - cached.fetchedAt.getTime()) > STALE_AFTER_HOURS * 60 * 60 * 1000;

  if (!isStale && cached) return cached.rate;

  // Stale or missing — refresh from provider. If the provider call fails and
  // we have a stale cached value, prefer serving the stale rate over
  // throwing (display-only feature — approximate is fine, broken is not).
  try {
    const fresh = await fetchRateFromProvider(base, target);
    await db.fxRate.upsert({
      where: { base_target: { base, target } },
      create: { base, target, rate: fresh, fetchedAt: new Date() },
      update: { rate: fresh, fetchedAt: new Date() },
    });
    return fresh;
  } catch (err) {
    if (cached) return cached.rate; // serve stale rather than fail
    throw new Error(`No FX rate available for ${base}→${target} and provider fetch failed: ${(err as Error).message}`);
  }
}

// ---------------------------------------------------------------------------
// CONVERT — display-only helper
// ---------------------------------------------------------------------------
export async function convertForDisplay(
  amount: number,
  fromCurrency: Currency,
  toCurrency: Currency,
): Promise<{ amount: number; rate: number; isEstimate: true }> {
  const rate = await getExchangeRate(fromCurrency, toCurrency);
  return { amount: Math.round(amount * rate), rate, isEstimate: true };
}

// ---------------------------------------------------------------------------
// REFRESH ALL PAIRS — called by scheduled worker daily
// ---------------------------------------------------------------------------
export async function refreshAllRates(): Promise<{ updated: number; failed: number }> {
  let updated = 0, failed = 0;

  for (const base of SUPPORTED_CURRENCIES) {
    for (const target of SUPPORTED_CURRENCIES) {
      if (base === target) continue;
      try {
        const rate = await fetchRateFromProvider(base, target);
        await db.fxRate.upsert({
          where: { base_target: { base, target } },
          create: { base, target, rate, fetchedAt: new Date() },
          update: { rate, fetchedAt: new Date() },
        });
        updated++;
      } catch {
        failed++;
      }
    }
  }

  return { updated, failed };
}

// ---------------------------------------------------------------------------
// PROVIDER CALL — Open Exchange Rates
// ---------------------------------------------------------------------------
async function fetchRateFromProvider(base: Currency, target: Currency): Promise<number> {
  const apiKey = process.env.OPEN_EXCHANGE_RATES_APP_ID;
  if (!apiKey) throw new Error("OPEN_EXCHANGE_RATES_APP_ID not configured");

  const response = await fetch(
    `https://openexchangerates.org/api/latest.json?app_id=${apiKey}&base=USD&symbols=${base},${target}`,
  );
  if (!response.ok) throw new Error(`FX provider returned ${response.status}`);

  const data = await response.json();
  const usdToBase = data.rates[base];
  const usdToTarget = data.rates[target];
  if (!usdToBase || !usdToTarget) throw new Error(`Missing rate data for ${base} or ${target}`);

  // Convert via USD cross-rate: base→target = (USD→target) / (USD→base)
  return usdToTarget / usdToBase;
}
