// =============================================================================
// FASNEXI — NEXI CONTEXT BUILDER
// packages/api/src/nexi/context.ts
//
// Assembles the structured context vector injected into every Nexi AI call.
// Per White Paper §13.2, Nexi receives:
//   - Style DNA profile (archetype, body, lifestyle, colour, budget, heritage)
//   - Current wardrobe items with AI tags
//   - Occasion + season from request
//   - Query history (last 10 turns for conversational continuity)
//
// This module is the ONLY place that touches the DB for Nexi context data.
// The assembled NexiContext object is passed to nexi/engine.ts, which builds
// the prompt string. Keeping assembly and prompt-building separate makes both
// independently testable without mocking each other.
//
// Cost control:
//   Context is cached in Redis for 10 minutes per user (keyed by userId).
//   Wardrobe items are summarised (not raw JSON) to stay within token budget.
//   Max context tokens: 4000. Max response tokens: 1000. Hard limits.
// =============================================================================

import { db } from "@fasnexi/db";

// ---------------------------------------------------------------------------
// TYPES
// ---------------------------------------------------------------------------

export interface StyleDNAContext {
  primaryArchetype: string | null;
  secondaryArchetype: string | null;
  bodyShape: string | null;
  fitPreferences: string[];
  sizeTop: string | null;
  sizeBottom: string | null;
  primaryOccasions: string[];
  climateZone: string | null;
  preferredColors: string[];
  avoidedColors: string[];
  budgetRange: string | null;
  heritage: string[];
  traditionalPreferences: string[];
  languages: string[];
}

export interface WardrobeItemSummary {
  id: string;
  category: string;
  subcategory: string | null;
  brand: string | null;
  colorLabel: string | null;
  aiColors: string[];
  aiPattern: string | null;
  aiOccasions: string[];
  aiSeasons: string[];
  aiFormalityScore: number | null;
  aiStyleCategories: string[];
  aiCulturalAffinity: string[];
  purchaseDate: Date | null;
}

export interface NexiContext {
  userId: string;
  styleProfile: StyleDNAContext | null;
  wardrobeItems: WardrobeItemSummary[];
  wardrobeCount: number;
  currentOccasion: string | null;
  currentSeason: string | null;
  queryHistory: Array<{ role: "user" | "assistant"; content: string }>;
  builtAt: string; // ISO timestamp — for cache freshness debugging
}

// ---------------------------------------------------------------------------
// CONTEXT BUILDER
// ---------------------------------------------------------------------------

const WARDROBE_ITEM_LIMIT = 60; // max items sent to Nexi (token budget)

export async function buildNexiContext(
  userId: string,
  opts: {
    occasion?: string | null;
    season?: string | null;
    sessionMessages?: Array<{ role: "user" | "assistant"; content: string }>;
  } = {},
): Promise<NexiContext> {
  const { occasion = null, season = null, sessionMessages = [] } = opts;

  // Fetch Style DNA profile and wardrobe in parallel
  const [styleProfile, wardrobeItems, wardrobeCount] = await Promise.all([
    db.styleProfile.findUnique({
      where: { userId },
      select: {
        primaryArchetype: true,
        secondaryArchetype: true,
        bodyShape: true,
        fitPreferences: true,
        sizeTopUS: true,
        sizeBottomUS: true,
        primaryOccasions: true,
        climateZone: true,
        preferredColors: true,
        avoidedColors: true,
        budgetRange: true,
        heritage: true,
        traditionalPreferences: true,
        languages: true,
      },
    }),
    db.wardrobeItem.findMany({
      where: { userId, isArchived: false, aiTagged: true },
      orderBy: { lastWornAt: { sort: "desc", nulls: "last" } },
      take: WARDROBE_ITEM_LIMIT,
      select: {
        id: true,
        category: true,
        subcategory: true,
        brand: true,
        colorLabel: true,
        aiColors: true,
        aiPattern: true,
        aiOccasions: true,
        aiSeasons: true,
        aiFormalityScore: true,
        aiStyleCategories: true,
        aiCulturalAffinity: true,
        purchaseDate: true,
      },
    }),
    db.wardrobeItem.count({ where: { userId, isArchived: false } }),
  ]);

  // Map StyleProfile to context shape
  const styleDNA: StyleDNAContext | null = styleProfile
    ? {
        primaryArchetype: styleProfile.primaryArchetype,
        secondaryArchetype: styleProfile.secondaryArchetype,
        bodyShape: styleProfile.bodyShape,
        fitPreferences: styleProfile.fitPreferences as string[],
        sizeTop: styleProfile.sizeTopUS,
        sizeBottom: styleProfile.sizeBottomUS,
        primaryOccasions: styleProfile.primaryOccasions as string[],
        climateZone: styleProfile.climateZone,
        preferredColors: styleProfile.preferredColors,
        avoidedColors: styleProfile.avoidedColors,
        budgetRange: styleProfile.budgetRange,
        heritage: styleProfile.heritage as string[],
        traditionalPreferences: styleProfile.traditionalPreferences as string[],
        languages: styleProfile.languages,
      }
    : null;

  // Keep last 10 turns for conversational continuity
  const queryHistory = sessionMessages.slice(-10);

  return {
    userId,
    styleProfile: styleDNA,
    wardrobeItems: wardrobeItems as WardrobeItemSummary[],
    wardrobeCount,
    currentOccasion: occasion,
    currentSeason: season,
    queryHistory,
    builtAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// WARDROBE OWNERSHIP CHECK
// Used by "You Already Own X" — checks if the user owns something similar
// to a recommended product before suggesting a purchase.
// Returns matching wardrobe items and a similarity score.
// ---------------------------------------------------------------------------

export interface OwnershipCheckResult {
  ownsEquivalent: boolean;
  matchingItems: Array<{
    id: string;
    category: string;
    brand: string | null;
    colorLabel: string | null;
    aiColors: string[];
    aiStyleCategories: string[];
    similarityScore: number; // 0–1
  }>;
}

export async function checkWardrobeOwnership(
  userId: string,
  productAttributes: {
    category: string;
    colors?: string[];
    styleCategories?: string[];
    occasions?: string[];
    formalityScore?: number;
  },
): Promise<OwnershipCheckResult> {
  const { category, colors = [], styleCategories = [], occasions = [], formalityScore } = productAttributes;

  // Fetch user's items in the same category
  const candidates = await db.wardrobeItem.findMany({
    where: {
      userId,
      isArchived: false,
      category: category as any,
    },
    select: {
      id: true,
      category: true,
      brand: true,
      colorLabel: true,
      aiColors: true,
      aiStyleCategories: true,
      aiOccasions: true,
      aiFormalityScore: true,
    },
  });

  if (candidates.length === 0) {
    return { ownsEquivalent: false, matchingItems: [] };
  }

  // Score each candidate by attribute overlap
  const scored = candidates.map(item => {
    let score = 0;
    let totalSignals = 0;

    // Color overlap (weight: 0.3)
    if (colors.length > 0 && item.aiColors.length > 0) {
      const colorMatches = colors.filter(c =>
        item.aiColors.some(ic => ic.toLowerCase().includes(c.toLowerCase()))
      ).length;
      score += 0.3 * (colorMatches / Math.max(colors.length, item.aiColors.length));
      totalSignals++;
    }

    // Style category overlap (weight: 0.35)
    if (styleCategories.length > 0 && item.aiStyleCategories.length > 0) {
      const styleMatches = styleCategories.filter(s =>
        item.aiStyleCategories.includes(s)
      ).length;
      score += 0.35 * (styleMatches / Math.max(styleCategories.length, item.aiStyleCategories.length));
      totalSignals++;
    }

    // Occasion overlap (weight: 0.25)
    if (occasions.length > 0 && item.aiOccasions.length > 0) {
      const occasionMatches = occasions.filter(o =>
        item.aiOccasions.includes(o)
      ).length;
      score += 0.25 * (occasionMatches / Math.max(occasions.length, item.aiOccasions.length));
      totalSignals++;
    }

    // Formality proximity (weight: 0.1)
    if (formalityScore !== undefined && item.aiFormalityScore !== null) {
      const formalityDiff = Math.abs(formalityScore - item.aiFormalityScore);
      score += 0.1 * Math.max(0, 1 - formalityDiff / 5);
      totalSignals++;
    }

    // Normalise if not all signals present
    const normalisedScore = totalSignals > 0 ? score : 0;

    return {
      id: item.id,
      category: item.category,
      brand: item.brand,
      colorLabel: item.colorLabel,
      aiColors: item.aiColors,
      aiStyleCategories: item.aiStyleCategories,
      // Round to 4dp before capping at 1 to avoid floating-point artefacts
      // (0.3+0.35+0.25+0.1 = 0.9999...999, not 1.0, in IEEE 754)
      similarityScore: Math.min(1, Math.round(normalisedScore * 10000) / 10000),
    };
  });

  // Threshold: 0.55 similarity = "already owns something equivalent"
  const SIMILARITY_THRESHOLD = 0.55;
  const matches = scored
    .filter(s => s.similarityScore >= SIMILARITY_THRESHOLD)
    .sort((a, b) => b.similarityScore - a.similarityScore);

  return {
    ownsEquivalent: matches.length > 0,
    matchingItems: matches,
  };
}
