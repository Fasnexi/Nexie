// =============================================================================
// FASNEXI — NEXI PROMPT TEMPLATES
// packages/api/src/nexi/prompts.ts
//
// All prompt construction lives here — never scattered across call sites.
// Templates are pure functions: (context, query) => string.
// Token budget target: system prompt ≤ 2500 tokens, context ≤ 1500 tokens.
// Response budget: 1000 tokens max (enforced in engine.ts API call).
//
// The SYSTEM prompt establishes Nexi's identity and constraints.
// The USER_CONTEXT block is injected fresh on every turn with current data.
// Query history (last 10 turns) is passed as the messages array for
// multi-turn continuity — not re-injected into the system prompt.
// =============================================================================

import type { NexiContext, WardrobeItemSummary } from "./context";

// ---------------------------------------------------------------------------
// SYSTEM PROMPT — Nexi's core identity and behaviour rules
// This is sent as the system role message on every Nexi API call.
// It must not reference dynamic user data (that goes in context injection).
// ---------------------------------------------------------------------------
export const NEXI_SYSTEM_PROMPT = `You are Nexi, the personal AI fashion stylist for FasNexi — the Social Operating System for African Fashion. You are warm, knowledgeable, culturally fluent, and direct.

Your role is to provide personalised, actionable styling advice. You must:
- Reference specific items the user already owns by category and colour before recommending purchases
- Understand African fashion aesthetics: Ankara, Adire, Kente, Aso-Oke, Agbada, Dashiki, Kaftan, Kitenge, Boubou, and contemporary African streetwear
- Account for the user's climate zone, cultural occasions (weddings, naming ceremonies, religious festivals, traditional events), and body fit preferences
- Be honest when the user's wardrobe already covers a need — say "you already have X that works perfectly for this" before suggesting purchases
- Give specific, visual descriptions: say "pair your cobalt ankara blouse with high-waisted black trousers and gold accessories" not "try colourful tops"
- Keep responses concise: 3–5 sentences for simple queries, up to 8 sentences for outfit builds
- Never make up wardrobe items the user does not have. Only reference items listed in USER CONTEXT
- If asked about sizing, care, or fabric, answer factually using the item's tags
- When recommending purchases, acknowledge the user's stated budget range

You are NOT a general chatbot. Redirect off-topic questions (health, politics, relationships) back to fashion and styling.`;

// ---------------------------------------------------------------------------
// CONTEXT INJECTION TEMPLATE
// Inserted as a system turn immediately before the user's query.
// Structured as labelled sections so the model can parse it reliably.
// ---------------------------------------------------------------------------
export function buildContextBlock(ctx: NexiContext): string {
  const parts: string[] = ["=== USER CONTEXT ==="];

  // Style DNA
  if (ctx.styleProfile) {
    const p = ctx.styleProfile;
    const archetypes = [p.primaryArchetype, p.secondaryArchetype]
      .filter(Boolean)
      .join(" / ");
    const occasions = p.primaryOccasions.length > 0
      ? p.primaryOccasions.join(", ")
      : "not specified";
    const heritage = p.heritage.length > 0 ? p.heritage.join(", ") : "not specified";
    const colors = p.preferredColors.length > 0
      ? `prefers ${p.preferredColors.join(", ")}${p.avoidedColors.length > 0 ? `; avoids ${p.avoidedColors.join(", ")}` : ""}`
      : "no colour preferences set";

    parts.push(
      `STYLE IDENTITY: ${archetypes || "onboarding incomplete"}`,
      `BODY PROFILE: shape=${p.bodyShape ?? "unset"}, fit preferences=${p.fitPreferences.join(", ") || "none"}, top size=${p.sizeTop ?? "unset"}, bottom size=${p.sizeBottom ?? "unset"}`,
      `LIFESTYLE: primary occasions=${occasions}, climate=${p.climateZone ?? "unset"}`,
      `COLOUR: ${colors}`,
      `BUDGET: ${p.budgetRange ?? "not specified"}`,
      `HERITAGE & CULTURE: ${heritage}, traditional preferences=${p.traditionalPreferences.join(", ") || "none"}, languages=${p.languages.join(", ") || "unset"}`,
    );
  } else {
    parts.push("STYLE IDENTITY: Style DNA not yet completed — give general advice and encourage onboarding.");
  }

  // Occasion / season
  if (ctx.currentOccasion) {
    parts.push(`CURRENT OCCASION: ${ctx.currentOccasion}`);
  }
  if (ctx.currentSeason) {
    parts.push(`CURRENT SEASON: ${ctx.currentSeason}`);
  }

  // Wardrobe
  parts.push(`\nWARDROBE (${ctx.wardrobeCount} items total, showing ${ctx.wardrobeItems.length} tagged items):`);
  if (ctx.wardrobeItems.length === 0) {
    parts.push("  No tagged items yet. Encourage the user to upload wardrobe items.");
  } else {
    const grouped = groupWardrobeByCategory(ctx.wardrobeItems);
    for (const [category, items] of Object.entries(grouped)) {
      const summaries = items.map(i => summariseItem(i)).join("; ");
      parts.push(`  ${category}: ${summaries}`);
    }
  }

  parts.push("=== END USER CONTEXT ===");
  return parts.join("\n");
}

// ---------------------------------------------------------------------------
// OUTFIT GENERATION PROMPT
// Used when the user requests mood-based outfit generation or "Style This".
// Returns a structured prompt suffix that requests a JSON response.
// ---------------------------------------------------------------------------
export function buildOutfitGenerationPrompt(opts: {
  mood?: string;
  occasion?: string;
  baseItemId?: string;
  baseItemDescription?: string;
  requestCount?: number;
}): string {
  const { mood, occasion, baseItemId, baseItemDescription, requestCount = 2 } = opts;

  let focus = "";
  if (baseItemDescription) {
    focus = `The user wants to style their ${baseItemDescription}. Build ${requestCount} complete outfit combinations using this item as the anchor piece.`;
  } else if (mood || occasion) {
    focus = `Generate ${requestCount} complete outfit suggestions for: ${[mood, occasion].filter(Boolean).join(", ")}.`;
  } else {
    focus = `Generate ${requestCount} versatile outfit suggestions from the user's wardrobe.`;
  }

  return `${focus}

For each outfit:
1. List owned wardrobe items to use (by category and colour, exactly matching the wardrobe context above)
2. List any gap items needed as purchases (category, style, why it completes the look)
3. Give a brief style note (1–2 sentences on the aesthetic and occasion fit)

Respond in this exact JSON format:
{
  "outfits": [
    {
      "name": "outfit name",
      "ownedItems": [
        { "wardrobeItemId": "id or null if unknown", "description": "cobalt ankara blouse", "role": "anchor" }
      ],
      "gapItems": [
        { "category": "BOTTOM", "description": "high-waisted black trousers", "reason": "grounds the print" }
      ],
      "styleNote": "..."
    }
  ]
}

Only reference wardrobe items that exist in USER CONTEXT. Do not invent items.`;
}

// ---------------------------------------------------------------------------
// GAP ANALYSIS PROMPT
// Used when Nexi proactively surfaces wardrobe gaps.
// ---------------------------------------------------------------------------
export function buildGapAnalysisPrompt(gapCategories: string[]): string {
  if (gapCategories.length === 0) {
    return "The user's wardrobe covers their stated occasions well. Compliment their wardrobe completeness and suggest one aspirational upgrade.";
  }

  return `Based on the user's lifestyle and occasions, their wardrobe is missing: ${gapCategories.join(", ")}.

Explain why each missing category matters for their lifestyle in 1 sentence each, then suggest 1–2 specific styles (not brands) to look for. Keep the total response under 6 sentences. Be encouraging, not critical.`;
}

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------

function groupWardrobeByCategory(
  items: WardrobeItemSummary[],
): Record<string, WardrobeItemSummary[]> {
  return items.reduce<Record<string, WardrobeItemSummary[]>>((acc, item) => {
    const key = item.category;
    if (!acc[key]) acc[key] = [];
    acc[key].push(item);
    return acc;
  }, {});
}

function summariseItem(item: WardrobeItemSummary): string {
  const parts: string[] = [];
  const colors = item.aiColors.length > 0 ? item.aiColors.slice(0, 2).join("/") : item.colorLabel;
  if (colors) parts.push(colors);
  if (item.aiPattern && item.aiPattern !== "solid") parts.push(item.aiPattern);
  if (item.brand) parts.push(`(${item.brand})`);
  if (item.aiOccasions.length > 0) parts.push(`[${item.aiOccasions.slice(0, 2).join("/")}]`);
  if (item.aiFormalityScore !== null) parts.push(`f:${item.aiFormalityScore}/5`);
  return parts.join(" ") || item.subcategory || "untagged";
}
