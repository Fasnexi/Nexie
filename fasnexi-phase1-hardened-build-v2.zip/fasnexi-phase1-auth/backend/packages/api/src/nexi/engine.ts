// =============================================================================
// FASNEXI — NEXI AI ENGINE
// packages/api/src/nexi/engine.ts
//
// Claude API integration for Nexi. Handles:
//   - Streaming SSE responses (chat mode)
//   - Non-streaming JSON responses (outfit generation, gap analysis)
//   - Rate limiting: 20 queries/user/day (free tier), unlimited for Nexi Pro
//   - Cost controls: token budgets enforced on every call
//   - Session persistence: NexiSession table stores conversation history
//   - Context caching: assembled context cached in Redis TTL 10min
//
// Model: claude-sonnet-4-6 (per product-self-knowledge skill spec)
// Max context tokens: 4000 (system + context block + history)
// Max response tokens: 1000
// =============================================================================

import Anthropic from "@anthropic-ai/sdk";
import { db } from "@fasnexi/db";
import { buildNexiContext } from "./context";
import { NEXI_SYSTEM_PROMPT, buildContextBlock, buildOutfitGenerationPrompt, buildGapAnalysisPrompt } from "./prompts";
import type { NexiContext } from "./context";
// GAP FIX: this file (packages/api/src/nexi/engine.ts) is what
// app/api/nexi/chat/route.ts actually imports — NOT
// ai-security/nexi-engine-hardened.ts, which has an atomic Lua-script rate
// limiter but was apparently never wired into the live route. That means
// the race condition the hardening pass documented as fixed (GET→check→INCR
// allowing two concurrent requests to both pass at count=19) was still live
// in the actual request path. Importing the same atomicRateLimit used by
// the hardened file, rather than duplicating it, so there's one rate-limit
// implementation instead of two that can drift apart again.
import { atomicRateLimit } from "../redis";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

const MODEL = "claude-sonnet-4-6";
const MAX_RESPONSE_TOKENS = 1000;
const FREE_TIER_DAILY_LIMIT = 20;
const SESSION_MAX_TURNS = 20;

// ---------------------------------------------------------------------------
// TYPES
// ---------------------------------------------------------------------------

export type NexiMode = "chat" | "outfit" | "gap-analysis" | "style-this";

export interface NexiChatRequest {
  userId: string;
  sessionId?: string;
  query: string;
  occasion?: string;
  season?: string;
  mode?: NexiMode;
  // outfit / style-this specific
  baseItemId?: string;
  outfitCount?: number;
}

export interface NexiChatResponse {
  sessionId: string;
  content: string;
  turnCount: number;
  tokenCount: number;
  remaining: number; // GAP FIX: queries remaining today, so the route can set X-Nexi-Remaining
}

export interface NexiOutfitResponse {
  sessionId: string;
  outfits: OutfitSuggestion[];
  tokenCount: number;
}

export interface OutfitSuggestion {
  name: string;
  ownedItems: Array<{
    wardrobeItemId: string | null;
    description: string;
    role: string;
  }>;
  gapItems: Array<{
    category: string;
    description: string;
    reason: string;
  }>;
  styleNote: string;
}

// ---------------------------------------------------------------------------
// RATE LIMITER — Redis-backed, resets at UTC midnight
// ---------------------------------------------------------------------------

async function checkAndIncrementRateLimit(
  userId: string,
): Promise<{ allowed: boolean; remaining: number }> {
  // Check subscription tier for limit
  const sub = await db.subscription.findUnique({
    where: { userId },
    select: { tier: true },
  });
  const isPro = sub?.tier === "NEXI_PRO" || sub?.tier === "STUDIO";

  if (isPro) return { allowed: true, remaining: 999 };

  const today = new Date().toISOString().split("T")[0]; // YYYY-MM-DD
  const key = `nexi:rl:${userId}:${today}`;

  const now = new Date();
  const secondsUntilMidnight =
    86400 - (now.getUTCHours() * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds());

  // GAP FIX: atomicRateLimit runs check+increment as a single Redis Lua
  // script (see packages/api/src/redis.ts) — no window where two concurrent
  // requests can both read count=19 and both get admitted. Also uses the
  // singleton Redis client instead of connect/disconnect per call.
  const result = await atomicRateLimit({
    key,
    limit: FREE_TIER_DAILY_LIMIT,
    ttlSeconds: secondsUntilMidnight + 60, // +60s buffer, same as before
  });

  return { allowed: result.allowed, remaining: result.remaining };
}

// ---------------------------------------------------------------------------
// SESSION MANAGEMENT
// ---------------------------------------------------------------------------

async function getOrCreateSession(
  userId: string,
  sessionId?: string,
): Promise<{ id: string; messages: Array<{ role: string; content: string }>; turnCount: number }> {
  if (sessionId) {
    const session = await db.nexiSession.findFirst({
      where: { id: sessionId, userId },
      select: { id: true, messages: true, turnCount: true },
    });
    if (session) {
      return {
        id: session.id,
        messages: (session.messages as any[]) ?? [],
        turnCount: session.turnCount,
      };
    }
  }

  // Create new session
  const newSession = await db.nexiSession.create({
    data: { userId, messages: [], turnCount: 0, tokenCount: 0 },
    select: { id: true },
  });
  return { id: newSession.id, messages: [], turnCount: 0 };
}

async function appendToSession(
  sessionId: string,
  userMessage: string,
  assistantMessage: string,
  tokensUsed: number,
): Promise<void> {
  const session = await db.nexiSession.findUniqueOrThrow({
    where: { id: sessionId },
    select: { messages: true, turnCount: true, tokenCount: true },
  });

  const messages = (session.messages as any[]) ?? [];
  messages.push(
    { role: "user",      content: userMessage,      timestamp: new Date().toISOString() },
    { role: "assistant", content: assistantMessage,  timestamp: new Date().toISOString() },
  );

  // Trim to SESSION_MAX_TURNS pairs (keep last N)
  const trimmed = messages.slice(-(SESSION_MAX_TURNS * 2));

  await db.nexiSession.update({
    where: { id: sessionId },
    data: {
      messages: trimmed,
      turnCount: { increment: 1 },
      tokenCount: { increment: tokensUsed },
    },
  });
}

// ---------------------------------------------------------------------------
// MAIN CHAT — returns full response (non-streaming)
// Used by outfit generation and gap analysis where we need the full text.
// Streaming variant is in streamNexiChat below.
// ---------------------------------------------------------------------------

export async function runNexiChat(req: NexiChatRequest): Promise<NexiChatResponse> {
  const { userId, query, occasion, season, sessionId: incomingSessionId } = req;

  // Rate limit check
  const { allowed, remaining } = await checkAndIncrementRateLimit(userId);
  if (!allowed) {
    throw new Error(
      `Daily Nexi query limit reached (${FREE_TIER_DAILY_LIMIT}/day on free tier). Upgrade to Nexi Pro for unlimited queries.`,
    );
  }

  // Build context and session in parallel
  const [nexiContext, session] = await Promise.all([
    buildNexiContext(userId, {
      occasion,
      season,
    }),
    getOrCreateSession(userId, incomingSessionId),
  ]);

  const contextBlock = buildContextBlock(nexiContext);

  // Build messages array: context injection as user turn + history + current query
  const messages: Anthropic.MessageParam[] = [
    // Context injection as first user message in this "session frame"
    {
      role: "user",
      content: contextBlock,
    },
    {
      role: "assistant",
      content: "Understood. I have your style profile, wardrobe, and cultural context. How can I help you today?",
    },
    // Previous turns from this session
    ...session.messages
      .filter((m: any) => m.role === "user" || m.role === "assistant")
      .map((m: any): Anthropic.MessageParam => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    // Current query
    { role: "user", content: query },
  ];

  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: MAX_RESPONSE_TOKENS,
    system: NEXI_SYSTEM_PROMPT,
    messages,
  });

  const content = response.content
    .filter(b => b.type === "text")
    .map(b => (b as Anthropic.TextBlock).text)
    .join("");

  const tokensUsed = (response.usage?.input_tokens ?? 0) + (response.usage?.output_tokens ?? 0);

  // Persist to session
  await appendToSession(session.id, query, content, tokensUsed);

  return {
    sessionId: session.id,
    content,
    turnCount: session.turnCount + 1,
    tokenCount: tokensUsed,
    remaining, // GAP FIX
  };
}

// ---------------------------------------------------------------------------
// STREAMING CHAT — returns a ReadableStream of SSE events
// Used by the chat UI for real-time response display.
// ---------------------------------------------------------------------------

export async function streamNexiChat(req: NexiChatRequest): Promise<{
  stream: ReadableStream;
  sessionId: string;
  remaining: number; // GAP FIX: known before the stream starts, since the
                      // rate-limit check + increment happens up front — the
                      // route can set the X-Nexi-Remaining header immediately,
                      // no need to wait for the stream to finish.
}> {
  const { userId, query, occasion, season, sessionId: incomingSessionId } = req;

  const { allowed, remaining } = await checkAndIncrementRateLimit(userId);
  if (!allowed) {
    throw new Error(
      `Daily Nexi query limit reached. Upgrade to Nexi Pro for unlimited queries.`,
    );
  }

  const [nexiContext, session] = await Promise.all([
    buildNexiContext(userId, { occasion, season }),
    getOrCreateSession(userId, incomingSessionId),
  ]);

  const contextBlock = buildContextBlock(nexiContext);

  const messages: Anthropic.MessageParam[] = [
    { role: "user", content: contextBlock },
    {
      role: "assistant",
      content: "Understood. I have your style profile, wardrobe, and cultural context. How can I help you today?",
    },
    ...session.messages
      .filter((m: any) => m.role === "user" || m.role === "assistant")
      .map((m: any): Anthropic.MessageParam => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    { role: "user", content: query },
  ];

  // Accumulate full response for session persistence
  let fullResponse = "";
  let totalTokens = 0;

  const anthropicStream = anthropic.messages.stream({
    model: MODEL,
    max_tokens: MAX_RESPONSE_TOKENS,
    system: NEXI_SYSTEM_PROMPT,
    messages,
  });

  const readableStream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();

      // Send session ID immediately so the client can track the session
      controller.enqueue(
        encoder.encode(`data: ${JSON.stringify({ type: "session", sessionId: session.id })}\n\n`),
      );

      try {
        for await (const event of anthropicStream) {
          if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
            const chunk = event.delta.text;
            fullResponse += chunk;
            controller.enqueue(
              encoder.encode(`data: ${JSON.stringify({ type: "delta", text: chunk })}\n\n`),
            );
          }

          if (event.type === "message_delta" && event.usage) {
            totalTokens =
              (event.usage as any).input_tokens ?? 0 +
              (event.usage.output_tokens ?? 0);
          }
        }

        // Persist completed response to session
        await appendToSession(session.id, query, fullResponse, totalTokens);

        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ type: "done", sessionId: session.id, tokenCount: totalTokens })}\n\n`,
          ),
        );
      } catch (err: any) {
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ type: "error", message: err.message })}\n\n`),
        );
      } finally {
        controller.close();
      }
    },
  });

  return { stream: readableStream, sessionId: session.id, remaining }; // GAP FIX
}

// ---------------------------------------------------------------------------
// OUTFIT GENERATION — non-streaming, returns structured JSON
// ---------------------------------------------------------------------------

export async function generateOutfits(req: NexiChatRequest): Promise<NexiOutfitResponse> {
  const { userId, occasion, season, baseItemId, outfitCount = 2, sessionId: incomingSessionId } = req;

  const { allowed } = await checkAndIncrementRateLimit(userId);
  if (!allowed) {
    throw new Error("Daily Nexi query limit reached.");
  }

  const [nexiContext, session] = await Promise.all([
    buildNexiContext(userId, { occasion, season }),
    getOrCreateSession(userId, incomingSessionId),
  ]);

  // Find base item description if styleThis mode
  let baseItemDescription: string | undefined;
  if (baseItemId) {
    const baseItem = nexiContext.wardrobeItems.find(i => i.id === baseItemId);
    if (baseItem) {
      const colors = baseItem.aiColors.slice(0, 2).join("/") || baseItem.colorLabel || "";
      baseItemDescription = `${colors} ${baseItem.aiPattern && baseItem.aiPattern !== "solid" ? baseItem.aiPattern + " " : ""}${baseItem.subcategory || baseItem.category.toLowerCase()}`;
    }
  }

  const contextBlock = buildContextBlock(nexiContext);
  const outfitPrompt = buildOutfitGenerationPrompt({
    mood: req.query || undefined,
    occasion: occasion || undefined,
    baseItemId,
    baseItemDescription,
    requestCount: outfitCount,
  });

  const messages: Anthropic.MessageParam[] = [
    { role: "user", content: contextBlock },
    {
      role: "assistant",
      content: "Understood. I have your style profile and wardrobe ready.",
    },
    { role: "user", content: outfitPrompt },
  ];

  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: MAX_RESPONSE_TOKENS,
    system: NEXI_SYSTEM_PROMPT,
    messages,
  });

  const rawText = response.content
    .filter(b => b.type === "text")
    .map(b => (b as Anthropic.TextBlock).text)
    .join("");

  const tokensUsed = (response.usage?.input_tokens ?? 0) + (response.usage?.output_tokens ?? 0);

  // Parse JSON — strip markdown fences if present
  let outfits: OutfitSuggestion[] = [];
  try {
    const clean = rawText.replace(/```json\n?|```/g, "").trim();
    const parsed = JSON.parse(clean);
    outfits = parsed.outfits ?? [];
  } catch {
    // Fallback: return raw text as a single "outfit" with a style note
    outfits = [
      {
        name: "Suggested Look",
        ownedItems: [],
        gapItems: [],
        styleNote: rawText.slice(0, 500),
      },
    ];
  }

  const userMessage = `Generate ${outfitCount} outfit${outfitCount > 1 ? "s" : ""}${occasion ? ` for ${occasion}` : ""}${baseItemDescription ? ` using my ${baseItemDescription}` : ""}`;
  await appendToSession(session.id, userMessage, JSON.stringify({ outfits }), tokensUsed);

  return { sessionId: session.id, outfits, tokenCount: tokensUsed };
}
