import { db } from "@fasnexi/db";
import type { OrderStatus } from "@prisma/client";

const orderSelect = {
  id: true, status: true, paymentMethod: true, paymentRef: true, subtotalAmount: true, shippingAmount: true, discountAmount: true, totalAmount: true, currency: true,
  shippingName: true, shippingLine1: true, shippingLine2: true, shippingCity: true, shippingCountry: true, shippingPostal: true,
  trackingNumber: true, trackingCarrier: true, shippedAt: true, deliveredAt: true, createdAt: true, updatedAt: true,
  items: { select: { id: true, productId: true, quantity: true, unitAmount: true, currency: true, size: true, color: true, product: { select: { id: true, name: true, imageUrls: true } } } },
} as const;

export async function getConsumerOrders(userId: string, options: { status?: OrderStatus; cursor?: string; limit?: number } = {}) {
  const limit = Math.min(Math.max(options.limit ?? 20, 1), 50);
  const orders = await db.order.findMany({ where: { userId, ...(options.status ? { status: options.status } : {}), ...(options.cursor ? { id: { lt: options.cursor } } : {}) }, orderBy: [{ createdAt: "desc" }, { id: "desc" }], take: limit + 1, select: orderSelect });
  const hasMore = orders.length > limit;
  const page = hasMore ? orders.slice(0, limit) : orders;
  return { orders: page, nextCursor: hasMore ? page[page.length - 1].id : null };
}

export async function getConsumerOrder(userId: string, orderId: string) {
  return db.order.findFirst({ where: { id: orderId, userId }, select: orderSelect });
}

export async function getConsumerOrderByCheckoutSession(userId: string, checkoutSessionId: string) {
  return db.order.findFirst({ where: { checkoutSessionId, userId }, select: orderSelect });
}
