// =============================================================================
// FASNEXI — CHALLENGES SERVICE (HARDENED)
// packages/api/src/concurrency/challenges-hardened.ts
//
// ROOT CAUSES FIXED:
//
// 1. VOTE UNIQUENESS — Redis was the authoritative source.
//    Problem: if Redis fails or is restarted, all vote uniqueness data is lost.
//    Problem: Redis GET then SET is non-atomic under concurrent requests.
//    FIX: PostgreSQL ChallengeVote table with UNIQUE(challengeId, voterId).
//    Redis may still cache vote counts for display but is never authoritative.
//
// 2. CHALLENGE ENTRY LIMITS — count → check → insert race condition.
//    Problem: two concurrent requests both see count < maxEntries and both insert.
//    FIX: SELECT FOR UPDATE on the challenge row serialises entry creation.
//    The row-level lock prevents a second transaction from seeing a stale count.
//
// 3. VOTE COUNT — Redis tracked vote counts independently of PostgreSQL.
//    Problem: Redis and PostgreSQL counts can diverge.
//    FIX: voteCount is always derived from PostgreSQL. Redis used only for
//    rate-limiting vote attempts per user per hour (not for uniqueness).
// =============================================================================

import { db } from "@fasnexi/db";
import { enqueueNotification } from "../queue";

// ---------------------------------------------------------------------------
// MIGRATION REQUIRED: Add ChallengeVote table to schema.prisma
// See: packages/db/prisma/migrations/20260101000005_challenge_vote/migration.sql
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// SUBMIT ENTRY — uses SELECT FOR UPDATE to prevent race on maxEntries
// ---------------------------------------------------------------------------
export async function submitChallengeEntryHardened(input: {
  challengeId: string;
  userId: string;
  caption: string;
  mediaUrls: string[];
  culturalTags?: string[];
}) {
  const { challengeId, userId, caption, mediaUrls, culturalTags = [] } = input;

  return db.$transaction(async tx => {
    // Lock the challenge row for the duration of this transaction.
    // Any concurrent submitChallengeEntry call will block here until this
    // transaction commits or rolls back — preventing the race condition.
    const challenge = await tx.$queryRaw<Array<{
      id: string;
      status: string;
      endDate: Date;
      maxEntries: number | null;
      _entryCount: bigint;
    }>>`
      SELECT c.id, c.status, c."endDate", c."maxEntries",
             (SELECT COUNT(*) FROM challenge_entries ce WHERE ce."challengeId" = c.id) as "_entryCount"
      FROM challenges c
      WHERE c.id = ${challengeId}::uuid
      FOR UPDATE
    `;

    if (challenge.length === 0) throw new Error("Challenge not found");
    const ch = challenge[0];

    if (ch.status !== "ACTIVE") throw new Error("Challenge is not currently accepting entries");
    if (new Date() > ch.endDate) throw new Error("Challenge entry period has closed");
    if (ch.maxEntries !== null && Number(ch._entryCount) >= ch.maxEntries) {
      throw new Error("Challenge has reached its maximum entries");
    }

    // Check for duplicate entry WITHIN the transaction (consistent read)
    const existing = await tx.challengeEntry.findUnique({
      where: { challengeId_userId: { challengeId, userId } },
      select: { id: true },
    });
    if (existing) throw new Error("You have already submitted an entry to this challenge");

    // Create post + entry atomically
    const entry = await tx.challengeEntry.create({
      data: {
        challengeId,
        userId,
        voteCount: 0,
        post: {
          create: {
            userId,
            type: "CHALLENGE_ENTRY",
            status: "PUBLISHED",
            caption,
            mediaUrls,
            culturalTags,
            challengeId,
            publishedAt: new Date(),
            rankScore: 0,
          },
        },
      },
      include: { post: { select: { id: true } } },
    });

    return entry;
  }, {
    // Serializable isolation ensures the count we see is accurate even
    // under concurrent transactions
    isolationLevel: "Serializable",
    timeout: 10_000,
  });
}

// ---------------------------------------------------------------------------
// VOTE FOR ENTRY — PostgreSQL authoritative, unique constraint enforces dedup
// ---------------------------------------------------------------------------
export async function voteForEntryHardened(
  challengeId: string,
  entryId: string,
  voterId: string,
): Promise<{ voteCount: number }> {
  return db.$transaction(async tx => {
    // Validate challenge is in VOTING phase
    const challenge = await tx.challenge.findUnique({
      where: { id: challengeId },
      select: { status: true, votingEnds: true },
    });
    if (!challenge) throw new Error("Challenge not found");
    if (challenge.status !== "VOTING") throw new Error("Challenge is not in the voting phase");
    if (challenge.votingEnds && new Date() > challenge.votingEnds) {
      throw new Error("Voting period has ended");
    }

    // Validate entry belongs to this challenge and is not voter's own
    const entry = await tx.challengeEntry.findUnique({
      where: { id: entryId },
      select: { challengeId: true, userId: true },
    });
    if (!entry || entry.challengeId !== challengeId) throw new Error("Entry not in this challenge");
    if (entry.userId === voterId) throw new Error("Cannot vote for your own entry");

    // INSERT into ChallengeVote — UNIQUE(challengeId, voterId) constraint
    // will throw P2002 (unique constraint violation) on duplicate vote.
    // This is atomic and race-safe without any Redis involvement.
    try {
      await tx.$executeRaw`
        INSERT INTO challenge_votes ("challengeId", "voterId", "entryId", "createdAt")
        VALUES (${challengeId}::uuid, ${voterId}::uuid, ${entryId}::uuid, NOW())
      `;
    } catch (err: any) {
      // Prisma wraps PG unique constraint violations as P2002
      if (err.code === "P2002" || err.message?.includes("unique constraint")) {
        throw new Error("You have already voted in this challenge");
      }
      throw err;
    }

    // Increment the denormalised vote count on ChallengeEntry
    const updated = await tx.challengeEntry.update({
      where: { id: entryId },
      data: { voteCount: { increment: 1 } },
      select: { voteCount: true, userId: true },
    });

    // Milestone notification outside the transaction (fire-and-forget)
    if (updated.voteCount % 10 === 0) {
      // Use setImmediate to ensure this runs after transaction commits
      setImmediate(() => {
        enqueueNotification({
          recipientId: updated.userId,
          type: "SYSTEM",
          data: { message: `Your entry reached ${updated.voteCount} votes!`, challengeId, entryId },
        }).catch(console.error);
      });
    }

    return { voteCount: updated.voteCount };
  });
}
