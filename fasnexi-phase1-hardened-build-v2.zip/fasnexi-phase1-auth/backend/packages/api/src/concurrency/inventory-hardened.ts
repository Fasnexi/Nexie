// =============================================================================
// FASNEXI — INVENTORY SERVICE (HARDENED)
// packages/api/src/concurrency/inventory-hardened.ts
//
// ROOT CAUSE: decrementInventory used findUnique + update inside a transaction,
// but WITHOUT a row lock. Two concurrent transactions could both read
// inventoryCount=1, both check 1 >= 1 (pass), and both decrement to 0 — but
// one of them would succeed and the other would have decremented past 0.
//
// In READ COMMITTED isolation (PostgreSQL default), the second transaction
// re-reads the row before update, so it would see count=0 and block.
// BUT: between the findUnique read and the update, another transaction can
// commit a change. The correct fix is either:
//   a) SELECT FOR UPDATE (pessimistic lock), or
//   b) Optimistic concurrency with a WHERE clause that fails if count changed
//
// We use approach (b) — optimistic with WHERE constraint — because it's
// non-blocking and naturally retries on conflict. It also works with
// PgBouncer transaction pooling where FOR UPDATE can cause issues.
// =============================================================================

import { db } from "@fasnexi/db";

export async function decrementInventoryHardened(
  productId: string,
  quantity: number,
): Promise<void> {
  // Atomic conditional update: only succeeds if inventoryCount >= quantity.
  // If two concurrent requests both try to decrement by 1 when count=1,
  // only one will match the WHERE condition; the other returns count=0.
  const result = await db.product.updateMany({
    where: {
      id: productId,
      inventoryCount: { gte: quantity }, // ← atomic guard
    },
    data: {
      inventoryCount: { decrement: quantity },
    },
  });

  if (result.count === 0) {
    // Either product doesn't exist or insufficient inventory
    const product = await db.product.findUnique({
      where: { id: productId },
      select: { inventoryCount: true },
    });
    if (!product) throw new Error(`Product ${productId} not found`);
    throw new Error(
      `Insufficient inventory for product ${productId}: ` +
      `requested ${quantity}, available ${product.inventoryCount}`,
    );
  }

  // Update isInStock flag based on new count (separate update, non-critical)
  // This could briefly show wrong isInStock if it fails, but that's cosmetic.
  // The inventory count itself is the authoritative stock indicator.
  const updated = await db.product.findUnique({
    where: { id: productId },
    select: { inventoryCount: true },
  });
  if (updated && updated.inventoryCount <= 0) {
    await db.product.update({
      where: { id: productId },
      data: { isInStock: false },
    });
  }
}

// ---------------------------------------------------------------------------
// RESERVE INVENTORY — for checkout sessions (prevents overselling during
// the window between checkout created and payment confirmed)
// ---------------------------------------------------------------------------
export async function reserveInventory(
  productId: string,
  quantity: number,
  reservationId: string,
): Promise<{ reserved: boolean }> {
  // Phase 4: full reservation system. For now, use atomic decrement.
  // TODO: add InventoryReservation table with TTL for cart-hold scenarios.
  try {
    await decrementInventoryHardened(productId, quantity);
    return { reserved: true };
  } catch {
    return { reserved: false };
  }
}
