// =============================================================================
// FASNEXI — STRIPE CONNECT TRANSFERS
// packages/api/src/financial/stripe-transfers.ts
//
// Isolated from payments.ts (checkout/webhook concerns) since transfers are
// a distinct Stripe capability (Connect payouts to creators/vendors) with
// their own idempotency requirements. Called by payouts/service.ts.
// =============================================================================

import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

export interface TransferResult {
  id: string;
  amount: number;
  currency: string;
  destination: string;
}

export async function stripeTransferToConnectAccount(input: {
  destinationAccountId: string;
  amount: number;
  currency: string;
  metadata: Record<string, string>;
}): Promise<TransferResult> {
  // idempotencyKey ties this exact transfer request to the payout batch —
  // if the network call is retried (e.g. our own timeout + retry logic),
  // Stripe deduplicates server-side rather than creating a second transfer.
  const idempotencyKey = `transfer-${input.metadata.payoutBatchId}`;

  const transfer = await stripe.transfers.create(
    {
      amount: input.amount,
      currency: input.currency.toLowerCase(),
      destination: input.destinationAccountId,
      metadata: input.metadata,
    },
    { idempotencyKey },
  );

  return {
    id: transfer.id,
    amount: transfer.amount,
    currency: transfer.currency,
    destination: input.destinationAccountId,
  };
}
