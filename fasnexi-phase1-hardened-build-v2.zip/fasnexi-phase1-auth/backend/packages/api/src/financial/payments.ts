// =============================================================================
// FASNEXI — PAYMENT PROVIDER ABSTRACTION & FINANCIAL LEDGER
// packages/api/src/financial/payments.ts
//
// ROOT CAUSES FIXED:
//
// 1. NO WEBHOOK IDEMPOTENCY — handleCheckoutComplete had no check for
//    duplicate webhook delivery. Stripe retries webhooks for up to 72 hours.
//    A duplicate webhook would create a second Order with the same paymentRef,
//    double the inventory decrement, and double the commission.
//    FIX: ProcessedWebhookEvent table with UNIQUE(provider, eventId).
//
// 2. NO PAYMENT PROVIDER ABSTRACTION — business logic was directly coupled
//    to Stripe's API objects (session.payment_intent, session.amount_subtotal).
//    FIX: PaymentProvider interface isolates provider-specific shapes.
//
// 3. MUTABLE WALLET BALANCE — Wallet.balance was the source of truth.
//    FIX: Balance is always derived from LedgerEntry rows. Wallet.balance
//    is a cached value updated transactionally, never the authoritative figure.
//
// 4. NON-IDEMPOTENT COMMISSION CREATION — CreatorCommission was created
//    inside the webhook handler without checking if it already existed.
//    FIX: upsert on (orderId, creatorId) with no-op on conflict.
// =============================================================================

import { db } from "@fasnexi/db";
import type { Currency, PaymentMethod } from "@prisma/client";

// ---------------------------------------------------------------------------
// PAYMENT PROVIDER INTERFACE
// ---------------------------------------------------------------------------

export interface PaymentIntent {
  id: string;           // provider's payment reference
  amount: number;       // in smallest unit (cents/kobo)
  currency: Currency;
  status: "pending" | "succeeded" | "failed" | "refunded";
  metadata: Record<string, string>;
}

export interface PaymentProvider {
  name: string;
  createPayment(opts: {
    amount: number;
    currency: Currency;
    metadata: Record<string, string>;
    successUrl: string;
    cancelUrl: string;
  }): Promise<{ redirectUrl: string; paymentIntentId: string }>;

  verifyWebhook(rawBody: Buffer, signature: string): Promise<{
    eventId: string;
    eventType: string;
    paymentIntent: PaymentIntent | null;
  }>;

  refundPayment(paymentIntentId: string, amount?: number): Promise<{ refundId: string }>;
}

// ---------------------------------------------------------------------------
// IDEMPOTENT WEBHOOK PROCESSING
// ---------------------------------------------------------------------------

export interface ProcessWebhookResult {
  orderId: string | null;
  alreadyProcessed: boolean;
}

export async function processPaymentWebhookIdempotent(opts: {
  provider: string;
  eventId: string;
  eventType: string;
  paymentIntent: PaymentIntent;
}): Promise<ProcessWebhookResult> {
  const { provider, eventId, eventType, paymentIntent } = opts;

  // IDEMPOTENCY GATE — atomic upsert prevents double-processing
  // If this eventId was already processed, return immediately.
  const lockResult = await db.$executeRaw`
    INSERT INTO processed_webhook_events ("provider", "eventId", "processedAt")
    VALUES (${provider}, ${eventId}, NOW())
    ON CONFLICT ("provider", "eventId") DO NOTHING
    RETURNING id
  `;

  // lockResult is the number of rows affected. 0 = already processed.
  if (lockResult === 0) {
    const existing = await db.order.findFirst({
      where: { paymentRef: paymentIntent.id },
      select: { id: true },
    });
    return { orderId: existing?.id ?? null, alreadyProcessed: true };
  }

  if (eventType !== "payment.succeeded" && eventType !== "checkout.session.completed") {
    return { orderId: null, alreadyProcessed: false };
  }

  // Check if order already exists for this payment ref (belt-and-suspenders)
  const existingOrder = await db.order.findFirst({
    where: { paymentRef: paymentIntent.id },
    select: { id: true },
  });
  if (existingOrder) {
    return { orderId: existingOrder.id, alreadyProcessed: true };
  }

  // ---------------------------------------------------------------------------
  // RESALE PURCHASE BRANCH
  // Phase 4 checkout/resale/[id]/purchase/route.ts tags the Stripe session
  // with metadata.kind="resale" + resaleItemId instead of the product
  // itemsJson shape. Route here BEFORE the product-order parsing below,
  // which assumes itemsJson exists and would otherwise silently produce an
  // empty order (or throw on missing userId/items) for resale payments —
  // charging the buyer with no wardrobe transfer and no sale record.
  // completeSale() itself is idempotent (checks status==="SOLD" first), so
  // this branch is safe under webhook redelivery exactly like the product path.
  // ---------------------------------------------------------------------------
  if (paymentIntent.metadata.kind === "resale") {
    const resaleItemId = paymentIntent.metadata.resaleItemId;
    if (!resaleItemId) {
      throw new Error(`Webhook ${eventId}: kind=resale but missing resaleItemId in metadata`);
    }

    const { completeSale } = await import("../resale/service");
    await completeSale(resaleItemId, paymentIntent.id);

    // Award loyalty points to the buyer on resale purchases too, using the
    // same idempotent-by-ref pattern as product orders below.
    const buyerId = paymentIntent.metadata.buyerId;
    if (buyerId) {
      const { awardPoints } = await import("../loyalty/service");
      const dollarAmount = Math.floor(paymentIntent.amount / 100);
      if (dollarAmount > 0) {
        await awardPoints({
          userId: buyerId,
          delta: dollarAmount,
          reason: `Resale purchase ${resaleItemId}`,
          ref: `resale:${resaleItemId}`,
        });
      }
    }

    // Resale purchases don't produce an Order row (no Product/OrderItem
    // involved) — orderId stays null, callers should check resaleItemId
    // via the ProcessedWebhookEvent record if they need a receipt reference.
    return { orderId: null, alreadyProcessed: false };
  }

  // ---------------------------------------------------------------------------
  // TAILOR DEPOSIT BRANCH — GAP FIX
  // apps/web/app/api/tailor/[id]/deposit/route.ts tags its Stripe session
  // with metadata.kind="tailor_deposit" + customOrderId, the same way the
  // resale branch above tags kind="resale". Routed here BEFORE the
  // product-order parsing below for the identical reason the resale branch
  // was added during the hardening pass: without this, a successful deposit
  // payment would fall through to itemsJson parsing (which doesn't exist for
  // a deposit), either throwing on missing metadata or — worse — silently
  // producing a malformed order, charging the client with the CustomOrder
  // never actually confirmed and the tailor never notified to start
  // production. confirmDepositPaid() is already idempotent (checks
  // depositPaid first), so this is safe under webhook redelivery exactly
  // like every other branch here.
  // ---------------------------------------------------------------------------
  if (paymentIntent.metadata.kind === "tailor_deposit") {
    const customOrderId = paymentIntent.metadata.customOrderId;
    if (!customOrderId) {
      throw new Error(`Webhook ${eventId}: kind=tailor_deposit but missing customOrderId in metadata`);
    }

    const { confirmDepositPaid } = await import("../tailor/service");
    await confirmDepositPaid(customOrderId, paymentIntent.id);

    // No Order row for a tailor deposit (no Product/OrderItem involved,
    // same as resale) — orderId stays null.
    return { orderId: null, alreadyProcessed: false };
  }

  // Parse line items from metadata
  const items: Array<{
    productId: string;
    quantity: number;
    size: string;
    color: string;
    unitAmount: number;
  }> = JSON.parse(paymentIntent.metadata.itemsJson ?? "[]");

  const userId = paymentIntent.metadata.userId;
  const creatorId = paymentIntent.metadata.creatorId || null;

  if (!userId || items.length === 0) {
    throw new Error(`Webhook ${eventId}: missing userId or items in metadata`);
  }

  // Create Order atomically with all side-effects
  const order = await db.$transaction(async tx => {
    const newOrder = await tx.order.create({
      data: {
        userId,
        status: "PAID",
        paymentMethod: mapProviderToMethod(provider),
        paymentRef: paymentIntent.id,
        checkoutSessionId: paymentIntent.id,
        subtotalAmount: paymentIntent.amount,
        shippingAmount: 0,
        discountAmount: 0,
        totalAmount: paymentIntent.amount,
        currency: paymentIntent.currency,
        items: {
          create: items.map(i => ({
            productId: i.productId,
            quantity: i.quantity,
            unitAmount: i.unitAmount,
            currency: paymentIntent.currency,
            size: i.size || null,
            color: i.color || null,
          })),
        },
      },
    });

    // Atomic inventory decrements
    for (const item of items) {
      const result = await tx.product.updateMany({
        where: { id: item.productId, inventoryCount: { gte: item.quantity } },
        data: { inventoryCount: { decrement: item.quantity } },
      });
      if (result.count === 0) {
        throw new Error(`Insufficient inventory for product ${item.productId} during webhook ${eventId}`);
      }
      await tx.product.update({
        where: { id: item.productId, inventoryCount: { lte: 0 } },
        data: { isInStock: false },
      }).catch(() => {}); // non-critical
    }

    // Sales count increment
    for (const item of items) {
      await tx.product.update({
        where: { id: item.productId },
        data: { salesCount: { increment: item.quantity } },
      });
    }

    // Commission — idempotent upsert
    if (creatorId) {
      const creator = await tx.creatorProfile.findUnique({
        where: { userId: creatorId },
        select: { id: true, commissionRate: true },
      });
      if (creator) {
        const commissionAmount = Math.round(newOrder.totalAmount * creator.commissionRate);
        await tx.creatorCommission.upsert({
          where: {
            // Unique constraint on (creatorId, orderId) prevents duplicate commissions
            creatorId_orderId: { creatorId: creator.id, orderId: newOrder.id },
          },
          create: {
            creatorId: creator.id,
            orderId: newOrder.id,
            userId,
            amount: commissionAmount,
            currency: newOrder.currency,
            rate: creator.commissionRate,
            status: "PENDING",
          },
          update: {}, // no-op on conflict
        });
      }
    }

    // Loyalty points — idempotent via orderId check
    const dollarAmount = Math.floor(newOrder.totalAmount / 100);
    if (dollarAmount > 0) {
      const existingTx = await tx.loyaltyTransaction.findFirst({
        where: { ref: newOrder.id },
      });
      if (!existingTx) {
        await tx.loyaltyAccount.upsert({
          where: { userId },
          create: {
            userId,
            points: dollarAmount,
            lifetimePoints: dollarAmount,
          },
          update: {
            points: { increment: dollarAmount },
            lifetimePoints: { increment: dollarAmount },
          },
        });
        await tx.loyaltyTransaction.create({
          data: {
            account: { connect: { userId } },
            delta: dollarAmount,
            reason: `Purchase ${newOrder.id}`,
            ref: newOrder.id,
          },
        });
      }
    }

    return newOrder;
  });

  return { orderId: order.id, alreadyProcessed: false };
}

// ---------------------------------------------------------------------------
// LEDGER — append-only, balance derived from entries
// ---------------------------------------------------------------------------

export async function creditWallet(opts: {
  userId: string;
  amount: number;
  currency: Currency;
  description: string;
  ref?: string;
}): Promise<void> {
  const { userId, amount, currency, description, ref } = opts;

  await db.$transaction(async tx => {
    // Get or create wallet
    const wallet = await tx.wallet.upsert({
      where: { userId },
      create: { userId, balance: 0, currency },
      update: {},
      select: { id: true, balance: true },
    });

    // Lock the wallet row for the rest of this transaction, then re-read
    // its balance. Same reasoning as debitWallet: without an explicit lock,
    // two concurrent credits can both read the same pre-credit balance and
    // one credit's cached balance / ledger snapshot gets lost.
    const locked = await tx.$queryRaw<[{ balance: number }]>`
      SELECT balance FROM wallets WHERE id = ${wallet.id}::uuid FOR UPDATE
    `;
    const currentBalance = locked[0]?.balance ?? wallet.balance;
    const newBalance = currentBalance + amount;

    // Append ledger entry FIRST (authoritative)
    await tx.ledgerEntry.create({
      data: {
        walletId: wallet.id,
        type: "CREDIT",
        amount,
        currency,
        balance: newBalance,
        description,
        ref: ref ?? null,
      },
    });

    // Update cached balance AFTER ledger entry
    await tx.wallet.update({
      where: { id: wallet.id },
      data: { balance: newBalance },
    });
  });
}

export async function debitWallet(opts: {
  userId: string;
  amount: number;
  currency: Currency;
  description: string;
  ref?: string;
}): Promise<void> {
  const { userId, amount, currency, description, ref } = opts;

  await db.$transaction(async tx => {
    const wallet = await tx.wallet.findUniqueOrThrow({
      where: { userId },
      select: { id: true, balance: true },
    });

    // Lock the wallet row for the rest of this transaction. Without this,
    // two concurrent debitWallet() calls on the same wallet can each read
    // the ledger sum before either commits, both see sufficient balance,
    // and both succeed — a double-spend race. This blocks the second
    // transaction until the first commits (or rolls back), so its
    // subsequent ledger read below is guaranteed to see the first debit.
    await tx.$queryRaw`SELECT id FROM wallets WHERE id = ${wallet.id}::uuid FOR UPDATE`;

    // Re-derive balance from ledger to ensure consistency
    // Derive authoritative balance from ledger entries (not the cached Wallet.balance field)
    const ledgerBalance = await tx.$queryRaw<[{ balance: number }]>`
      SELECT COALESCE(
        SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE -amount END), 0
      )::integer as balance
      FROM ledger_entries
      WHERE "walletId" = ${wallet.id}::uuid
    `;
    const authoritative = ledgerBalance[0]?.balance ?? 0;

    if (authoritative < amount) {
      throw new Error(
        `Insufficient wallet balance: have ${authoritative}, need ${amount}`,
      );
    }

    const newBalance = authoritative - amount;

    await tx.ledgerEntry.create({
      data: {
        walletId: wallet.id,
        type: "DEBIT",
        amount,
        currency,
        balance: newBalance,
        description,
        ref: ref ?? null,
      },
    });

    // Sync cached balance
    await tx.wallet.update({
      where: { id: wallet.id },
      data: { balance: newBalance },
    });
  });
}

// ---------------------------------------------------------------------------
// HELPERS
// ---------------------------------------------------------------------------

function mapProviderToMethod(provider: string): PaymentMethod {
  const map: Record<string, PaymentMethod> = {
    stripe: "STRIPE_CARD",
    paystack: "PAYSTACK",
    flutterwave: "FLUTTERWAVE",
    mpesa: "MPESA",
    mtn_momo: "MTN_MOMO",
  };
  return map[provider.toLowerCase()] ?? "STRIPE_CARD";
}
