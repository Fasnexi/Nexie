// =============================================================================
// FASNEXI — TRANSACTIONAL OUTBOX
// packages/api/src/events/outbox.ts
//
// ROOT CAUSE: Every service did:
//   await db.$transaction(...)   ← commits DB changes
//   await enqueueXxx(...)        ← enqueues BullMQ job
//
// If the process crashes between these two lines (or BullMQ is momentarily
// unavailable), the DB change is committed but the job is never enqueued.
// Result: silent data loss — a notification never sent, a feed rank never
// updated, a vision tag never triggered.
//
// FIX: Transactional Outbox pattern.
//   1. Write an OutboxEvent row INSIDE the DB transaction.
//   2. A polling publisher (apps/worker) reads pending outbox events and
//      enqueues them to BullMQ, then marks them processed.
//   3. If BullMQ publish fails, the row stays unprocessed and is retried.
//   4. Worker is idempotent (BullMQ jobId deduplication).
//
// This does NOT require a new message broker — it uses the existing
// PostgreSQL + BullMQ infrastructure.
//
// Schema: OutboxEvent table (see migration below).
// Publisher: apps/worker/src/outboxPublisher.ts
// =============================================================================

import { db } from "@fasnexi/db";
import { v4 as uuid } from "uuid";

// ---------------------------------------------------------------------------
// OUTBOX EVENT TYPES — subset of BullMQ queues that need outbox guarantee
// High-value events only: order-critical and financial events.
// Engagement events (feed-ranking) are best-effort — losing one rank update
// is acceptable. Losing an order confirmation is not.
// ---------------------------------------------------------------------------
export type OutboxEventType =
  | "order.completed"
  | "commission.created"
  | "wallet.credited"
  | "wallet.debited"
  | "vision.tag.requested"
  | "notification.send"
  | "challenge.entry.submitted";

export interface OutboxEvent {
  id: string;
  type: OutboxEventType;
  payload: Record<string, unknown>;
  correlationId: string;
  createdAt: Date;
}

// ---------------------------------------------------------------------------
// PRISMA TX INTERFACE — concrete type for the transaction client passed to
// writeOutboxEvent. Parameters<> is too brittle; this captures exactly what
// the outbox writer needs from the Prisma transaction object.
// ---------------------------------------------------------------------------
export interface PrismaTx {
  $executeRaw(strings: TemplateStringsArray, ...values: unknown[]): Promise<number>;
  $queryRaw<T = unknown>(strings: TemplateStringsArray, ...values: unknown[]): Promise<T>;
}

// ---------------------------------------------------------------------------
// WRITE OUTBOX EVENT — always called INSIDE a db.$transaction
// ---------------------------------------------------------------------------
export async function writeOutboxEvent(
  tx: PrismaTx,
  type: OutboxEventType,
  payload: Record<string, unknown>,
  correlationId?: string,
): Promise<string> {
  const id = uuid();
  await tx.$executeRaw`
    INSERT INTO outbox_events (id, type, payload, "correlationId", "createdAt", status)
    VALUES (
      ${id}::uuid,
      ${type},
      ${JSON.stringify(payload)}::jsonb,
      ${correlationId ?? id},
      NOW(),
      'PENDING'
    )
  `;
  return id;
}

// ---------------------------------------------------------------------------
// OUTBOX PUBLISHER — runs in apps/worker on a tight polling loop
// Reads pending events, enqueues to BullMQ, marks as processed.
// ---------------------------------------------------------------------------
export async function publishPendingOutboxEvents(): Promise<number> {
  // Claim a batch of events atomically (SELECT FOR UPDATE SKIP LOCKED
  // prevents concurrent publishers from double-processing)
  const events = await db.$queryRaw<Array<{
    id: string;
    type: string;
    payload: Record<string, unknown>;
    correlationId: string;
  }>>`
    SELECT id, type, payload, "correlationId"
    FROM outbox_events
    WHERE status = 'PENDING'
    ORDER BY "createdAt" ASC
    LIMIT 50
    FOR UPDATE SKIP LOCKED
  `;

  if (events.length === 0) return 0;

  let published = 0;

  for (const event of events) {
    try {
      await publishSingleEvent(event.type as OutboxEventType, event.payload, event.correlationId);

      await db.$executeRaw`
        UPDATE outbox_events
        SET status = 'PUBLISHED', "publishedAt" = NOW()
        WHERE id = ${event.id}::uuid
      `;
      published++;
    } catch (err: any) {
      // Mark as FAILED with error detail — will be retried on next poll
      // After 5 failures, mark as DEAD_LETTER for human review
      await db.$executeRaw`
        UPDATE outbox_events
        SET
          "failureCount" = "failureCount" + 1,
          "lastError" = ${err.message},
          status = CASE
            WHEN "failureCount" + 1 >= 5 THEN 'DEAD_LETTER'
            ELSE 'PENDING'
          END
        WHERE id = ${event.id}::uuid
      `;
      console.error(`[outbox] Failed to publish event ${event.id}:`, err.message);
    }
  }

  return published;
}

// ---------------------------------------------------------------------------
// EVENT → QUEUE MAPPING
// ---------------------------------------------------------------------------
async function publishSingleEvent(
  type: OutboxEventType,
  payload: Record<string, unknown>,
  correlationId: string,
): Promise<void> {
  const { feedRankingQueue, nexiVisionQueue, notificationsQueue } = await import("../queue");

  switch (type) {
    case "vision.tag.requested":
      await nexiVisionQueue.add("tag-garment", payload, {
        jobId: `vision-${payload.wardrobeItemId}`, // BullMQ deduplication
        deduplication: { id: correlationId },
      } as any);
      break;

    case "notification.send":
      await notificationsQueue.add("send", payload, {
        jobId: `notif-${correlationId}`,
      });
      break;

    case "order.completed":
    case "commission.created":
      // These trigger downstream notifications
      await notificationsQueue.add("send", {
        recipientId: payload.userId,
        type: type === "order.completed" ? "ORDER_UPDATE" : "COMMISSION_EARNED",
        data: payload,
      }, {
        jobId: `${type}-${correlationId}`,
      });
      break;

    case "wallet.credited":
    case "wallet.debited":
      // Financial events are logged but don't drive queue jobs currently.
      // Phase 7: will trigger FSE portfolio rebalancing.
      console.log(`[outbox] Financial event: ${type} correlationId=${correlationId}`);
      break;

    case "challenge.entry.submitted":
      await notificationsQueue.add("send", {
        recipientId: payload.userId,
        type: "SYSTEM",
        data: { message: "Your challenge entry was submitted!", ...payload },
      }, {
        jobId: `challenge-entry-${correlationId}`,
      });
      break;

    default:
      throw new Error(`Unknown outbox event type: ${type}`);
  }
}
