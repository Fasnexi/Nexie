// =============================================================================
// FASNEXI — MULTI-ROLE PLUGIN
// packages/auth/src/plugins/multi-role.ts
//
// Better Auth plugin that adds:
//   POST /auth/roles/activate     — add a role to the user's roles[] array
//   POST /auth/roles/deactivate   — remove a role (CONSUMER cannot be removed)
//   POST /auth/roles/switch       — change activeRole (which dashboard renders)
//   GET  /auth/roles/mine         — list roles + verification status
//
// Verification-gated roles (Vendor, Designer, Tailor, EventOrganizer,
// SustainablePartner) are added to roles[] immediately on application but
// write access to their commerce resources stays locked behind
// profile.isVerified=true until a moderator approves. This lets users see
// their dashboard shell and fill out their application without a confusing
// "role doesn't exist yet" state during review.
// =============================================================================

import { createAuthEndpoint } from "better-auth/api";
import { APIError } from "better-auth/api";
import { db } from "@fasnexi/db";
import {
  type Role, canSelfActivate, requiresVerification, STAFF_ONLY_ROLES,
} from "../permissions/matrix";

interface MultiRolePluginOptions {
  roles: readonly Role[];
}

export function multiRolePlugin(options: MultiRolePluginOptions) {
  const validRoles = new Set(options.roles);

  return {
    id: "multi-role",
    endpoints: {

      // -----------------------------------------------------------------------
      activateRole: createAuthEndpoint("/roles/activate", { method: "POST" }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) throw new APIError("UNAUTHORIZED", { message: "Not signed in" });

        const { role } = ctx.body as { role: string };

        if (!validRoles.has(role as Role))
          throw new APIError("BAD_REQUEST", { message: `Unknown role: ${role}` });

        if (STAFF_ONLY_ROLES.includes(role as Role))
          throw new APIError("FORBIDDEN", { message: "Staff roles cannot be self-activated." });

        const user = await db.user.findUniqueOrThrow({
          where: { id: session.userId },
          select: { roles: true },
        });

        // Idempotent — already holding the role is a no-op success
        if (user.roles.includes(role as Role))
          return ctx.json({ roles: user.roles, alreadyActive: true });

        const updatedRoles = [...user.roles, role as Role];
        await db.user.update({ where: { id: session.userId }, data: { roles: updatedRoles } });

        // Verification-required roles get an unverified profile shell created
        // immediately so the dashboard has something to render (empty state +
        // "complete your application" CTA) without a race condition.
        if (requiresVerification(role as Role))
          await createUnverifiedProfileShell(session.userId, role as Role);

        return ctx.json({
          roles: updatedRoles,
          alreadyActive: false,
          requiresVerification: requiresVerification(role as Role),
        });
      }),

      // -----------------------------------------------------------------------
      deactivateRole: createAuthEndpoint("/roles/deactivate", { method: "POST" }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) throw new APIError("UNAUTHORIZED", { message: "Not signed in" });

        const { role } = ctx.body as { role: string };

        if (role === "CONSUMER")
          throw new APIError("BAD_REQUEST", { message: "CONSUMER is the base role and cannot be deactivated." });

        const user = await db.user.findUniqueOrThrow({
          where: { id: session.userId },
          select: { roles: true, activeRole: true },
        });

        const updatedRoles = user.roles.filter(r => r !== role);
        // Never let activeRole point at a role the user no longer holds
        const newActiveRole = user.activeRole === role ? "CONSUMER" : user.activeRole;

        await db.user.update({
          where: { id: session.userId },
          data: { roles: updatedRoles.length > 0 ? updatedRoles : ["CONSUMER"], activeRole: newActiveRole },
        });

        return ctx.json({ roles: updatedRoles, activeRole: newActiveRole });
      }),

      // -----------------------------------------------------------------------
      switchActiveRole: createAuthEndpoint("/roles/switch", { method: "POST" }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) throw new APIError("UNAUTHORIZED", { message: "Not signed in" });

        const { role } = ctx.body as { role: string };
        const user = await db.user.findUniqueOrThrow({
          where: { id: session.userId }, select: { roles: true },
        });

        if (!user.roles.includes(role as Role))
          throw new APIError("FORBIDDEN", {
            message: `Cannot switch to ${role} — activate it first via /roles/activate.`,
          });

        await db.user.update({ where: { id: session.userId }, data: { activeRole: role as Role } });
        return ctx.json({ activeRole: role });
      }),

      // -----------------------------------------------------------------------
      myRoles: createAuthEndpoint("/roles/mine", { method: "GET" }, async (ctx) => {
        const session = ctx.context.session;
        if (!session) throw new APIError("UNAUTHORIZED", { message: "Not signed in" });

        const user = await db.user.findUniqueOrThrow({
          where: { id: session.userId },
          select: {
            roles: true, activeRole: true,
            vendorProfile:  { select: { isVerified: true } },
            designerProfile: { select: { isVerified: true } },
            tailorProfile:  { select: { isVerified: true } },
          },
        });

        const verificationStatus: Record<string, boolean> = {};
        if (user.roles.includes("VENDOR"))    verificationStatus.VENDOR    = user.vendorProfile?.isVerified ?? false;
        if (user.roles.includes("DESIGNER"))  verificationStatus.DESIGNER  = user.designerProfile?.isVerified ?? false;
        if (user.roles.includes("TAILOR"))    verificationStatus.TAILOR    = user.tailorProfile?.isVerified ?? false;

        return ctx.json({ roles: user.roles, activeRole: user.activeRole, verificationStatus });
      }),
    },

    hooks: {
      before: [{
        matcher: (ctx: any) => ctx.path === "/roles/activate",
        handler: async (ctx: any) => {
          const { role } = ctx.body as { role: string };
          if (!canSelfActivate(role as Role) && !requiresVerification(role as Role))
            throw new APIError("FORBIDDEN", { message: `${role} cannot be self-activated.` });
        },
      }],
    },
  };
}

// -----------------------------------------------------------------------------
// Create empty profile shell for verification-required roles.
// Upsert (not create) so deactivate → reactivate doesn't wipe existing data.
// -----------------------------------------------------------------------------
async function createUnverifiedProfileShell(userId: string, role: Role) {
  switch (role) {
    case "VENDOR":
      await db.vendorProfile.upsert({
        where: { userId }, create: { userId, businessName: "", country: "", isVerified: false }, update: {},
      }); break;
    case "DESIGNER":
      await db.designerProfile.upsert({
        where: { userId }, create: { userId, brandName: "", isVerified: false }, update: {},
      }); break;
    case "TAILOR":
      await db.tailorProfile.upsert({
        where: { userId }, create: { userId, country: "", city: "", isVerified: false }, update: {},
      }); break;
    case "EVENT_ORGANIZER":
      await db.eventOrganizerProfile.upsert({
        where: { userId }, create: { userId, orgName: "" }, update: {},
      }); break;
    case "SUSTAINABLE_PARTNER":
      await db.sustainablePartnerProfile.upsert({
        where: { userId }, create: { userId, orgName: "" }, update: {},
      }); break;
  }
}
