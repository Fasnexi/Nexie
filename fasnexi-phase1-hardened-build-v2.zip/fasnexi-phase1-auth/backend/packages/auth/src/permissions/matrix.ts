// =============================================================================
// FASNEXI — PERMISSION MATRIX
// packages/auth/src/permissions/matrix.ts
//
// Design: users hold Role[] (array), not a single Role string, supporting
// simultaneous Consumer + Creator + Investor personas per White Paper §15.1.
// Effective permissions = UNION across all held roles (resolveEffectivePermissions).
// "own" vs "any" scope is resolved by has() — not by separate permission strings
// at call sites.
// ADMIN is explicit (no wildcards) to preserve auditability.
// =============================================================================

export const ROLES = [
  "CONSUMER", "CREATOR", "VENDOR", "DESIGNER", "TAILOR",
  "EVENT_ORGANIZER", "SUSTAINABLE_PARTNER", "INVESTOR", "MODERATOR", "ADMIN",
] as const;
export type Role = (typeof ROLES)[number];

export const ACTIONS = [
  "create", "read_own", "read_any", "update_own", "update_any",
  "delete_own", "delete_any", "moderate",
] as const;
export type Action = (typeof ACTIONS)[number];

export const RESOURCES = [
  "user_profile", "style_profile", "wardrobe_item", "outfit", "post", "comment",
  "product", "order", "creator_profile", "creator_commission", "vendor_profile",
  "designer_profile", "tailor_profile", "custom_order", "event_organizer_profile",
  "event", "ticket", "sustainable_partner_profile", "challenge", "fashion_asset",
  "trade_order", "wallet", "resale_item", "promoted_product", "nexi_session",
  "moderation_action", "report", "product_passport", "admin_panel",
] as const;
export type Resource = (typeof RESOURCES)[number];
export type Permission = `${Resource}:${Action}`;

// ---------------------------------------------------------------------------
// ROLE → PERMISSION MATRIX
// ---------------------------------------------------------------------------

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  CONSUMER: [
    "user_profile:read_own", "user_profile:update_own",
    "style_profile:create", "style_profile:read_own", "style_profile:update_own",
    "wardrobe_item:create", "wardrobe_item:read_own", "wardrobe_item:update_own", "wardrobe_item:delete_own",
    "outfit:create", "outfit:read_own", "outfit:update_own", "outfit:delete_own",
    "post:create", "post:read_own", "post:update_own", "post:delete_own",
    "comment:create", "comment:read_own", "comment:update_own", "comment:delete_own",
    "product:read_any",
    "order:create", "order:read_own",
    "custom_order:create", "custom_order:read_own",
    "event:read_any",
    "ticket:create", "ticket:read_own",
    "challenge:read_any",
    "resale_item:create", "resale_item:read_own", "resale_item:update_own",
    "nexi_session:create", "nexi_session:read_own",
    "report:create",
  ],

  CREATOR: [
    "creator_profile:create", "creator_profile:read_own", "creator_profile:update_own",
    "creator_commission:read_own",
    "post:create",
    "challenge:create",
    "promoted_product:read_own",
  ],

  VENDOR: [
    "vendor_profile:create", "vendor_profile:read_own", "vendor_profile:update_own",
    "product:create", "product:read_own", "product:update_own", "product:delete_own",
    "order:read_own",
    "promoted_product:create", "promoted_product:read_own", "promoted_product:update_own",
  ],

  DESIGNER: [
    "designer_profile:create", "designer_profile:read_own", "designer_profile:update_own",
    "fashion_asset:create", "fashion_asset:read_own", "fashion_asset:update_own",
    "product_passport:create", "product_passport:read_own",
  ],

  TAILOR: [
    "tailor_profile:create", "tailor_profile:read_own", "tailor_profile:update_own",
    "custom_order:read_own", "custom_order:update_own",
  ],

  EVENT_ORGANIZER: [
    "event_organizer_profile:create", "event_organizer_profile:read_own", "event_organizer_profile:update_own",
    "event:create", "event:read_own", "event:update_own", "event:delete_own",
    "ticket:read_own",
  ],

  SUSTAINABLE_PARTNER: [
    "sustainable_partner_profile:create", "sustainable_partner_profile:read_own", "sustainable_partner_profile:update_own",
  ],

  INVESTOR: [
    "fashion_asset:read_any",
    "trade_order:create", "trade_order:read_own",
    "wallet:read_own", "wallet:update_own",
  ],

  MODERATOR: [
    "post:read_any", "post:moderate",
    "comment:read_any", "comment:moderate",
    "report:read_any",
    "moderation_action:create", "moderation_action:read_any",
    "user_profile:read_any",
  ],

  // ADMIN is intentionally NOT "*:*" — every grant is explicit so an audit
  // of `ADMIN` permissions shows the real attack surface. Financial/destructive
  // actions still require dedicated guards in apps/web/lib/admin-guard.ts.
  ADMIN: [
    "admin_panel:read_any",
    "user_profile:read_any", "user_profile:update_any",
    "post:read_any", "post:moderate", "post:delete_any",
    "product:read_any", "product:update_any", "product:delete_any",
    "order:read_any",
    "fashion_asset:read_any", "fashion_asset:update_any",
    "wallet:read_any",
    "moderation_action:create", "moderation_action:read_any",
    "report:read_any",
  ],
};

// ---------------------------------------------------------------------------
// CORE FUNCTIONS
// ---------------------------------------------------------------------------

/** Union of permissions across all roles the user currently holds. */
export function resolveEffectivePermissions(roles: Role[]): Set<Permission> {
  const result = new Set<Permission>();
  for (const role of roles) {
    const perms = ROLE_PERMISSIONS[role];
    if (!perms) continue;
    for (const p of perms) result.add(p);
  }
  return result;
}

export interface HasInput {
  roles: Role[];
  resource: Resource;
  action: string; // "create" | "read" | "update" | "delete" | "moderate"
  isOwner?: boolean;
}

/**
 * Primary permission check. Call this from every API route and server action.
 * Resolves own vs any scope automatically — call sites never build the
 * permission string manually.
 *
 * @example
 * has({ roles: user.roles, resource: "product", action: "update", isOwner: product.vendorId === user.id })
 */
export function has(input: HasInput): boolean {
  const { roles, resource, action, isOwner = false } = input;
  const effective = resolveEffectivePermissions(roles);

  // create and moderate have no owner/any distinction
  if (action === "create" || action === "moderate") {
    return effective.has(`${resource}:${action}` as Permission);
  }

  // Check _own first (cheaper, more common), then _any as fallback
  if (isOwner && effective.has(`${resource}:${action}_own` as Permission)) return true;
  if (effective.has(`${resource}:${action}_any` as Permission)) return true;
  return false;
}

// ---------------------------------------------------------------------------
// ROLE ACTIVATION RULES
// ---------------------------------------------------------------------------

/** Roles a user can activate themselves with no review step. */
export const SELF_ACTIVATABLE_ROLES: Role[] = ["CONSUMER", "CREATOR", "INVESTOR"];

/**
 * Roles added to roles[] immediately on application but write-locked behind
 * profile.isVerified=true until a moderator approves. Users see their dashboard
 * shell during review without having commerce write access.
 */
export const VERIFICATION_REQUIRED_ROLES: Role[] = [
  "VENDOR", "DESIGNER", "TAILOR", "EVENT_ORGANIZER", "SUSTAINABLE_PARTNER",
];

/** Only assignable by existing ADMIN — never self-activated. */
export const STAFF_ONLY_ROLES: Role[] = ["MODERATOR", "ADMIN"];

export const canSelfActivate  = (r: Role): boolean => SELF_ACTIVATABLE_ROLES.includes(r);
export const requiresVerification = (r: Role): boolean => VERIFICATION_REQUIRED_ROLES.includes(r);
