// =============================================================================
// FASNEXI — PERMISSION MATRIX UNIT TESTS
// packages/auth/src/permissions/__tests__/matrix.test.ts
// Run: pnpm turbo test  (Vitest, no DB required)
// 48 assertions covering: role union, scope, cross-role, self-activation,
// verification gating, and matrix completeness invariants.
// =============================================================================
import { describe, it, expect } from "vitest";
import {
  has, resolveEffectivePermissions, canSelfActivate, requiresVerification,
  ROLE_PERMISSIONS, ROLES, type Role,
} from "../matrix";

describe("resolveEffectivePermissions", () => {
  it("returns CONSUMER-only permissions for a single role user", () => {
    const p = resolveEffectivePermissions(["CONSUMER"]);
    expect(p.has("wardrobe_item:create")).toBe(true);
    expect(p.has("product:create")).toBe(false);
  });
  it("unions permissions across CONSUMER + CREATOR", () => {
    const p = resolveEffectivePermissions(["CONSUMER", "CREATOR"]);
    expect(p.has("wardrobe_item:create")).toBe(true);
    expect(p.has("creator_profile:create")).toBe(true);
    expect(p.has("challenge:create")).toBe(true);
  });
  it("CONSUMER+CREATOR does NOT gain VENDOR permissions", () => {
    const p = resolveEffectivePermissions(["CONSUMER", "CREATOR"]);
    expect(p.has("product:create")).toBe(false);
    expect(p.has("vendor_profile:create")).toBe(false);
  });
  it("triple role CONSUMER+VENDOR+INVESTOR gets full union", () => {
    const p = resolveEffectivePermissions(["CONSUMER", "VENDOR", "INVESTOR"]);
    expect(p.has("wardrobe_item:create")).toBe(true);
    expect(p.has("product:create")).toBe(true);
    expect(p.has("trade_order:create")).toBe(true);
  });
  it("empty roles returns empty set", () => expect(resolveEffectivePermissions([]).size).toBe(0));
  it("unknown role is ignored, no throw", () => expect(resolveEffectivePermissions(["X" as Role]).size).toBe(0));
});

describe("has() — own vs any scope", () => {
  it("CONSUMER read_own wardrobe_item", () => expect(has({roles:["CONSUMER"],resource:"wardrobe_item",action:"read",isOwner:true})).toBe(true));
  it("CONSUMER cannot read_any wardrobe_item", () => expect(has({roles:["CONSUMER"],resource:"wardrobe_item",action:"read",isOwner:false})).toBe(false));
  it("ADMIN read_any user_profile without isOwner", () => expect(has({roles:["ADMIN"],resource:"user_profile",action:"read",isOwner:false})).toBe(true));
  it("ADMIN read_any also satisfies isOwner=true", () => expect(has({roles:["ADMIN"],resource:"user_profile",action:"read",isOwner:true})).toBe(true));
  it("VENDOR update_own product", () => expect(has({roles:["VENDOR"],resource:"product",action:"update",isOwner:true})).toBe(true));
  it("VENDOR cannot update non-owned product", () => expect(has({roles:["VENDOR"],resource:"product",action:"update",isOwner:false})).toBe(false));
  it("CONSUMER cannot moderate", () => expect(has({roles:["CONSUMER"],resource:"post",action:"moderate"})).toBe(false));
  it("MODERATOR can moderate", () => expect(has({roles:["MODERATOR"],resource:"post",action:"moderate"})).toBe(true));
  it("create ignores isOwner=false", () => expect(has({roles:["CONSUMER"],resource:"wardrobe_item",action:"create",isOwner:false})).toBe(true));
  it("create ignores isOwner=true", () => expect(has({roles:["CONSUMER"],resource:"wardrobe_item",action:"create",isOwner:true})).toBe(true));
});

describe("has() — cross-role scenarios", () => {
  const crv: Role[] = ["CONSUMER","CREATOR","VENDOR"];
  it("CREATOR+VENDOR can create challenge", () => expect(has({roles:crv,resource:"challenge",action:"create"})).toBe(true));
  it("CREATOR+VENDOR can create product", () => expect(has({roles:crv,resource:"product",action:"create"})).toBe(true));
  it("INVESTOR alone cannot create product", () => expect(has({roles:["INVESTOR"],resource:"product",action:"create"})).toBe(false));
  it("INVESTOR can read_any fashion_asset", () => expect(has({roles:["INVESTOR"],resource:"fashion_asset",action:"read",isOwner:false})).toBe(true));
  it("CONSUMER cannot read fashion_asset", () => expect(has({roles:["CONSUMER"],resource:"fashion_asset",action:"read",isOwner:false})).toBe(false));
  it("DESIGNER read_own fashion_asset", () => expect(has({roles:["DESIGNER"],resource:"fashion_asset",action:"read",isOwner:true})).toBe(true));
  it("DESIGNER cannot read_any fashion_asset alone", () => expect(has({roles:["DESIGNER"],resource:"fashion_asset",action:"read",isOwner:false})).toBe(false));
  it("DESIGNER+INVESTOR can read_any fashion_asset", () => expect(has({roles:["DESIGNER","INVESTOR"],resource:"fashion_asset",action:"read",isOwner:false})).toBe(true));
});

describe("canSelfActivate", () => {
  it("CONSUMER, CREATOR, INVESTOR are self-activatable", () => {
    expect(canSelfActivate("CONSUMER")).toBe(true);
    expect(canSelfActivate("CREATOR")).toBe(true);
    expect(canSelfActivate("INVESTOR")).toBe(true);
  });
  it("commerce roles are NOT self-activatable", () => {
    expect(canSelfActivate("VENDOR")).toBe(false);
    expect(canSelfActivate("DESIGNER")).toBe(false);
    expect(canSelfActivate("TAILOR")).toBe(false);
  });
  it("staff roles are NOT self-activatable", () => {
    expect(canSelfActivate("MODERATOR")).toBe(false);
    expect(canSelfActivate("ADMIN")).toBe(false);
  });
});

describe("requiresVerification", () => {
  it("commerce/service roles require verification", () => {
    for (const r of ["VENDOR","DESIGNER","TAILOR","EVENT_ORGANIZER","SUSTAINABLE_PARTNER"] as Role[])
      expect(requiresVerification(r)).toBe(true);
  });
  it("CONSUMER, CREATOR, INVESTOR do not require verification", () => {
    for (const r of ["CONSUMER","CREATOR","INVESTOR"] as Role[])
      expect(requiresVerification(r)).toBe(false);
  });
});

describe("matrix completeness invariants", () => {
  it("every role in ROLES has a ROLE_PERMISSIONS entry", () => {
    for (const r of ROLES) expect(ROLE_PERMISSIONS[r]).toBeDefined();
  });
  it("ADMIN permissions contain no wildcard '*'", () => {
    expect(ROLE_PERMISSIONS.ADMIN.every(p => !p.includes("*"))).toBe(true);
  });
  it("all permission strings match resource:action pattern", () => {
    const pattern = /^[a-z_]+:[a-z_]+$/;
    for (const role of ROLES)
      for (const perm of ROLE_PERMISSIONS[role])
        expect(perm).toMatch(pattern);
  });
  it("CONSUMER has a substantial base permission set (>10)", () => {
    expect(ROLE_PERMISSIONS.CONSUMER.length).toBeGreaterThan(10);
  });
});
