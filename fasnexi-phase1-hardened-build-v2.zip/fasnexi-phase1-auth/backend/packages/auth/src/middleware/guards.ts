// =============================================================================
// FASNEXI — PERMISSION GUARDS
// packages/auth/src/middleware/guards.ts
//
// Three-layer guard chain used by every API route / server action:
//   requireUser()            → signed in, not banned
//   requireVerifiedRole()    → holds the role AND profile.isVerified=true
//   requirePermission()      → has the resource:action (with ownership scope)
//
// Guards throw (ForbiddenError / UnauthenticatedError) — never return boolean.
// A missed check fails loudly (unhandled 500 in logs) not silently.
// withErrorHandling() wraps route handlers and converts thrown errors to
// proper HTTP responses.
// =============================================================================
import { headers } from "next/headers";
import { auth, type AuthUser } from "../auth";
import { has, type Resource } from "../permissions/matrix";

export class BadRequestError extends Error {
  readonly code: string;
  readonly fields?: Record<string, string>;
  constructor(message = "Bad request", code = "BAD_REQUEST", fields?: Record<string, string>) {
    super(message); this.name = "BadRequestError"; this.code = code; this.fields = fields;
  }
}
export class NotFoundError extends Error {
  readonly code: string;
  constructor(message = "Not found", code = "NOT_FOUND") { super(message); this.name = "NotFoundError"; this.code = code; }
}
export class ConflictError extends Error {
  readonly code: string;
  constructor(message = "Conflict", code = "CONFLICT") { super(message); this.name = "ConflictError"; this.code = code; }
}
export class ForbiddenError extends Error {
  readonly code = "FORBIDDEN";
  constructor(message = "Forbidden") { super(message); this.name = "ForbiddenError"; }
}
export class UnauthenticatedError extends Error {
  readonly code = "UNAUTHENTICATED";
  constructor(message = "Authentication required") { super(message); this.name = "UnauthenticatedError"; }
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session) return null;
  return session.user as AuthUser;
}

export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser();
  if (!user) throw new UnauthenticatedError();
  if ((user as any).isBanned) throw new ForbiddenError("This account has been suspended.");
  return user;
}

export interface RequirePermissionOptions { isOwner?: boolean; }

/** Main permission guard — call after requireUser(). Throws on failure. */
export async function requirePermission(
  user: AuthUser,
  resource: Resource,
  action: string,
  options: RequirePermissionOptions = {},
): Promise<void> {
  const allowed = has({ roles: user.roles, resource, action, isOwner: options.isOwner ?? false });
  if (!allowed) {
    throw new ForbiddenError(
      `Missing permission: ${resource}:${action}${options.isOwner !== undefined ? ` (isOwner=${options.isOwner})` : ""}`,
    );
  }
}

type VerifiableRole = "VENDOR" | "DESIGNER" | "TAILOR" | "EVENT_ORGANIZER" | "SUSTAINABLE_PARTNER";

/** Requires role membership AND profile.isVerified=true for commerce roles. */
export async function requireVerifiedRole(user: AuthUser, role: VerifiableRole): Promise<void> {
  if (!user.roles.includes(role)) throw new ForbiddenError(`Requires the ${role} role.`);

  const { db } = await import("@fasnexi/db");
  const tableMap = {
    VENDOR: "vendorProfile", DESIGNER: "designerProfile", TAILOR: "tailorProfile",
    EVENT_ORGANIZER: "eventOrganizerProfile", SUSTAINABLE_PARTNER: "sustainablePartnerProfile",
  } as const;

  const table = tableMap[role];
  // @ts-expect-error — dynamic model access narrowed by the literal union above
  const profile = await db[table].findUnique({ where: { userId: user.id } });
  if (!profile) throw new ForbiddenError(`${role} profile missing. Activate the role first.`);

  if (role === "VENDOR" || role === "DESIGNER" || role === "TAILOR") {
    if (!(profile as any).isVerified)
      throw new ForbiddenError(`Your ${role} application is still under review.`);
  }
}

/** Guards endpoints that only make sense in a specific dashboard context. */
export function requireActiveRole(user: AuthUser, role: AuthUser["activeRole"]): void {
  if (user.activeRole !== role)
    throw new ForbiddenError(`Switch to the ${role} dashboard first.`);
}

/** Wraps Next.js route handlers — converts guard errors to proper HTTP responses. */
export function withErrorHandling<T extends (...args: any[]) => Promise<Response>>(handler: T): T {
  return (async (...args: Parameters<T>) => {
    try {
      return await handler(...args);
    } catch (err) {
      if (err instanceof BadRequestError) return Response.json({ error: err.message, code: err.code, ...(err.fields ? { fields: err.fields } : {}) }, { status: 400 });
      if (err instanceof UnauthenticatedError) return Response.json({ error: err.message, code: err.code }, { status: 401 });
      if (err instanceof ForbiddenError) return Response.json({ error: err.message, code: err.code }, { status: 403 });
      if (err instanceof NotFoundError) return Response.json({ error: err.message, code: err.code }, { status: 404 });
      if (err instanceof ConflictError) return Response.json({ error: err.message, code: err.code }, { status: 409 });
      throw err; // genuine bugs propagate to Sentry / Next.js error boundary
    }
  }) as T;
}
