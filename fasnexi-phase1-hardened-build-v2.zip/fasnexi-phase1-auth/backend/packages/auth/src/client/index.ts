// =============================================================================
// FASNEXI — AUTH CLIENT
// packages/auth/src/client/index.ts
// Shared between apps/web (browser cookies) and apps/mobile (SecureStore).
// =============================================================================
import { createAuthClient } from "better-auth/react";
import { adminClient } from "better-auth/client/plugins";
import type { Role } from "../permissions/matrix";

export interface AuthClientConfig {
  baseURL: string;
  storage?: {
    getItem: (key: string) => string | null | Promise<string | null>;
    setItem: (key: string, value: string) => void | Promise<void>;
  };
}

export function createFasNexiAuthClient(config: AuthClientConfig) {
  return createAuthClient({
    baseURL: config.baseURL,
    plugins: [adminClient()],
    fetchOptions: {
      ...(config.storage && {
        auth: {
          type: "Bearer",
          token: async () => {
            const t = await config.storage!.getItem("fasnexi_session_token");
            return t ?? "";
          },
        },
      }),
    },
  });
}

/** Role management helpers — thin wrappers over the multi-role plugin endpoints. */
export function createRoleHelpers(baseURL: string) {
  const call = async (path: string, method: string, body?: object) => {
    const res = await fetch(`${baseURL}/api/auth${path}`, {
      method, credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  };

  return {
    activateRole:   (role: Role) => call("/roles/activate",   "POST", { role }) as Promise<{ roles: Role[]; alreadyActive: boolean; requiresVerification?: boolean }>,
    deactivateRole: (role: Role) => call("/roles/deactivate", "POST", { role }) as Promise<{ roles: Role[]; activeRole: Role }>,
    switchRole:     (role: Role) => call("/roles/switch",     "POST", { role }) as Promise<{ activeRole: Role }>,
    myRoles:        ()           => call("/roles/mine",       "GET")             as Promise<{ roles: Role[]; activeRole: Role; verificationStatus: Record<string, boolean> }>,
  };
}
