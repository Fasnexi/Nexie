// =============================================================================
// FASNEXI — BETTER AUTH SERVER CONFIG
// packages/auth/src/auth.ts
// Imported by: apps/web/app/api/auth/[...all]/route.ts
// =============================================================================
import { betterAuth } from "better-auth";
import { expo } from "@better-auth/expo";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { admin as adminPlugin } from "better-auth/plugins";
import { db } from "@fasnexi/db";
import { multiRolePlugin } from "./plugins/multi-role";
import { ROLES, type Role } from "./permissions/matrix";

const isProduction = process.env.FASNEXI_ENVIRONMENT === "production";

export const auth = betterAuth({
  appName: "FasNexi",
  database: prismaAdapter(db, { provider: "postgresql" }),
  secret: process.env.NEXTAUTH_SECRET!,
  baseURL: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",

  emailAndPassword: {
    enabled: true,
    requireEmailVerification: isProduction,
    minPasswordLength: 10,
    autoSignIn: true,
    sendResetPassword: async ({ user, url }) => {
      const { sendTransactionalEmail } = await import("@fasnexi/notifications");
      await sendTransactionalEmail({
        to: user.email,
        template: "password-reset",
        data: { resetUrl: url, displayName: user.name },
      });
    },
  },

  emailVerification: {
    sendOnSignUp: true,
    autoSignInAfterVerification: true,
    sendVerificationEmail: async ({ user, url }) => {
      const { sendTransactionalEmail } = await import("@fasnexi/notifications");
      await sendTransactionalEmail({
        to: user.email,
        template: "verify-email",
        data: { verifyUrl: url, displayName: user.name },
      });
    },
  },

  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
    apple: {
      clientId: process.env.APPLE_CLIENT_ID!,
      clientSecret: process.env.APPLE_CLIENT_SECRET!,
      appBundleIdentifier: "com.fasnexi.app",
    },
  },

  session: {
    expiresIn: 60 * 60 * 24 * 7,        // 7 days
    updateAge: 60 * 60 * 24,             // refresh once per active day
    cookieCache: { enabled: true, maxAge: 60 * 5 }, // 5-min edge cache
  },

  rateLimit: {
    enabled: true,
    window: 60,
    max: 10,
    customRules: {
      "/sign-in/email":  { window: 60,  max: 5 },
      "/sign-up/email":  { window: 60,  max: 3 },
      "/forget-password":{ window: 300, max: 3 },
    },
  },

  trustedOrigins: [
    "fasnexi://",
    process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
    ...(isProduction ? [] : ["http://localhost:8081"]),
  ],

  advanced: {
    crossSubDomainCookies: { enabled: isProduction, domain: ".fasnexi.com" },
    defaultCookieAttributes: { secure: isProduction, sameSite: "lax" },
  },

  user: {
    additionalFields: {
      username:         { type: "string",   required: true, unique: true },
      roles:            { type: "string[]", required: false, defaultValue: ["CONSUMER"], input: false },
      activeRole:       { type: "string",   required: false, defaultValue: "CONSUMER" },
      onboardingStatus: { type: "number",   required: false, defaultValue: 0 },
      onboardingDone:   { type: "boolean",  required: false, defaultValue: false },
    },
  },

  plugins: [
    expo(),
    // Built-in admin plugin: used ONLY for ban/unban/impersonate session
    // primitives. Role/permission logic lives entirely in multiRolePlugin.
    adminPlugin({
      defaultBanReason: "Violation of FasNexi Community Guidelines",
      bannedUserMessage: "This account has been suspended. Contact support@fasnexi.com to appeal.",
      impersonationSessionDuration: 60 * 30,
    }),
    multiRolePlugin({ roles: ROLES }),
  ],
});

export type Session  = typeof auth.$Infer.Session;
export type AuthUser = Session["user"] & { roles: Role[]; activeRole: Role };
