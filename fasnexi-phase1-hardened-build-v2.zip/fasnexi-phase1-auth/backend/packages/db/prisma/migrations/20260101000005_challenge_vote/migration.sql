-- =============================================================================
-- FASNEXI — CHALLENGE VOTE TABLE
-- packages/db/prisma/migrations/20260101000005_challenge_vote/migration.sql
--
-- FIX: Replace Redis-based vote deduplication with PostgreSQL constraint.
-- The UNIQUE(challengeId, voterId) constraint is enforced atomically by the DB.
-- No amount of concurrent requests can insert two votes for the same voter.
-- =============================================================================

CREATE TABLE IF NOT EXISTS "challenge_votes" (
  "id"          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "challengeId" UUID NOT NULL REFERENCES "challenges"("id") ON DELETE CASCADE,
  "voterId"     UUID NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "entryId"     UUID NOT NULL REFERENCES "challenge_entries"("id") ON DELETE CASCADE,
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- THE KEY CONSTRAINT: one vote per voter per challenge (not per entry)
CREATE UNIQUE INDEX "challenge_votes_challengeId_voterId_uidx"
  ON "challenge_votes" ("challengeId", "voterId");

CREATE INDEX "challenge_votes_entryId_idx" ON "challenge_votes" ("entryId");
CREATE INDEX "challenge_votes_voterId_idx" ON "challenge_votes" ("voterId");

-- Backfill existing vote counts from the denormalised field (no-op if table was new)
-- voteCount on challenge_entries remains as a denormalised cache for display performance.
-- It is incremented transactionally alongside the vote insert, so it stays consistent.
