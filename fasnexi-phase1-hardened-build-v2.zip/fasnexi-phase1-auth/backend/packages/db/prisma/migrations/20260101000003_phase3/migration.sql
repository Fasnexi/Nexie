-- =============================================================================
-- FASNEXI — PHASE 3 MIGRATION
-- Adds: NexiSession conversation table, wardrobe AI tag columns,
--       gap recommendation → product many-to-many, voice input placeholder
-- =============================================================================

-- NexiSession — stores Nexi conversation history per user
-- (messages stored as JSONB array of {role, content, timestamp})
CREATE TABLE IF NOT EXISTS "nexi_sessions" (
  "id"              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId"          UUID NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "messages"        JSONB[] NOT NULL DEFAULT '{}',
  "contextSnapshot" JSONB,
  "tokenCount"      INTEGER NOT NULL DEFAULT 0,
  "turnCount"       INTEGER NOT NULL DEFAULT 0,
  "createdAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX "nexi_sessions_userId_idx"        ON "nexi_sessions" ("userId");
CREATE INDEX "nexi_sessions_createdAt_idx"     ON "nexi_sessions" ("createdAt" DESC);

-- Wardrobe item AI tag columns (if not already added by schema.prisma baseline)
ALTER TABLE "wardrobe_items"
  ADD COLUMN IF NOT EXISTS "aiTagged"          BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS "aiTaggedAt"        TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS "aiColors"          TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "aiPattern"         TEXT,
  ADD COLUMN IF NOT EXISTS "aiSilhouette"      TEXT,
  ADD COLUMN IF NOT EXISTS "aiOccasions"       TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "aiSeasons"         TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "aiFormalityScore"  INTEGER,
  ADD COLUMN IF NOT EXISTS "aiFabricType"      TEXT,
  ADD COLUMN IF NOT EXISTS "aiStyleCategories" TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "aiCulturalAffinity" TEXT[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "aiConfidence"      DOUBLE PRECISION;

-- Index AI-tagged items for feed gap relevance queries
CREATE INDEX IF NOT EXISTS "wardrobe_items_userId_aiTagged_idx"
  ON "wardrobe_items" ("userId", "aiTagged");
CREATE INDEX IF NOT EXISTS "wardrobe_items_category_userId_idx"
  ON "wardrobe_items" ("category", "userId");

-- GapRecommendation → Product many-to-many join table
CREATE TABLE IF NOT EXISTS "_GapProducts" (
  "A" UUID NOT NULL REFERENCES "gap_recommendations"("id") ON DELETE CASCADE,
  "B" UUID NOT NULL REFERENCES "products"("id") ON DELETE CASCADE,
  PRIMARY KEY ("A", "B")
);
CREATE INDEX IF NOT EXISTS "_GapProducts_B_index" ON "_GapProducts" ("B");

-- GapRecommendation: add resolvedAt if not present
ALTER TABLE "gap_recommendations"
  ADD COLUMN IF NOT EXISTS "resolvedAt" TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS "gap_recommendations_userId_resolvedAt_idx"
  ON "gap_recommendations" ("userId", "resolvedAt");

-- NexiSession updatedAt trigger
CREATE OR REPLACE FUNCTION update_nexi_session_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW."updatedAt" = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS nexi_sessions_updated_at ON "nexi_sessions";
CREATE TRIGGER nexi_sessions_updated_at
  BEFORE UPDATE ON "nexi_sessions"
  FOR EACH ROW EXECUTE FUNCTION update_nexi_session_updated_at();
