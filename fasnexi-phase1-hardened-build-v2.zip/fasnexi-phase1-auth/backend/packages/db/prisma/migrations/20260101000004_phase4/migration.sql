-- =============================================================================
-- FASNEXI — PHASE 4 MIGRATION
-- Adds: LoyaltyTransaction history, tailor order messaging thread,
--       resale escrow columns, promoted listing impression tracking,
--       creator payout batches, FX rate cache table
--
-- MIGRATION ORDERING NOTE:
-- packages/api/src/financial/payments.ts (as shipped in this Phase 4 output)
-- includes the resale-purchase webhook branch, which depends on the
-- idempotency gate `INSERT INTO processed_webhook_events ...` introduced by
-- the hardening pass's migration 20260101000006_processed_webhook_events.
-- That migration is numbered AFTER this one but this code requires it to
-- exist. If deploying Phase 4 and the hardening pass together, apply
-- migrations in this order regardless of timestamp:
--   1. 20260101000004_phase4 (this file)
--   2. 20260101000005_challenge_vote
--   3. 20260101000006_processed_webhook_events   ← MUST run before payments.ts
--      handles its first webhook, or every checkout/webhook call throws.
-- If Phase 4 is deployed standalone (hardening pass not yet applied), the
-- processed_webhook_events table must be created here instead — see the
-- inlined fallback table definition at the bottom of this file.
-- =============================================================================

-- Loyalty transaction history (LoyaltyAccount already exists from baseline)
CREATE TABLE IF NOT EXISTS "loyalty_transactions" (
  "id"        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "accountId" UUID NOT NULL REFERENCES "loyalty_accounts"("id") ON DELETE CASCADE,
  "delta"     INTEGER NOT NULL,           -- positive = earn, negative = redeem
  "reason"    TEXT    NOT NULL,
  "ref"       TEXT,                       -- order id, challenge id, etc.
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX "loyalty_transactions_accountId_idx"
  ON "loyalty_transactions" ("accountId", "createdAt" DESC);

-- Loyalty tier thresholds (denormalise for fast tier-check queries)
ALTER TABLE "loyalty_accounts"
  ADD COLUMN IF NOT EXISTS "tier"          TEXT NOT NULL DEFAULT 'BRONZE',
  ADD COLUMN IF NOT EXISTS "points"        INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "lifetimePoints" INTEGER NOT NULL DEFAULT 0;

-- Creator payout batch — groups commissions settled in one Stripe payout
CREATE TABLE IF NOT EXISTS "creator_payout_batches" (
  "id"              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "creatorId"       UUID NOT NULL REFERENCES "creator_profiles"("id") ON DELETE CASCADE,
  "totalAmount"     INTEGER NOT NULL,
  "currency"        TEXT NOT NULL DEFAULT 'USD',
  "stripePayoutId"  TEXT,
  "status"          TEXT NOT NULL DEFAULT 'PENDING',  -- PENDING | PROCESSING | PAID | FAILED
  "commissionIds"   UUID[] NOT NULL DEFAULT '{}',
  "createdAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "settledAt"       TIMESTAMPTZ
);
CREATE INDEX "creator_payout_batches_creatorId_idx"
  ON "creator_payout_batches" ("creatorId", "createdAt" DESC);

-- Tailor order — in-app message thread (threadId on Message already exists)
-- Just need to link custom_orders to a thread
ALTER TABLE "custom_orders"
  ADD COLUMN IF NOT EXISTS "threadId" UUID,
  ADD COLUMN IF NOT EXISTS "deadline" TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS "completedAt" TIMESTAMPTZ;

-- Resale escrow reference on resale_items
ALTER TABLE "resale_items"
  ADD COLUMN IF NOT EXISTS "platformFeeAmount" INTEGER,
  ADD COLUMN IF NOT EXISTS "sellerReceivesAmount" INTEGER;

-- Promoted listing impression + click tracking
ALTER TABLE "promoted_products"
  ADD COLUMN IF NOT EXISTS "billedAmount"    INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "lastBilledAt"    TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS "dailyBudget"     INTEGER,
  ADD COLUMN IF NOT EXISTS "impressionGoal"  INTEGER;

CREATE INDEX IF NOT EXISTS "promoted_products_isActive_endDate_idx"
  ON "promoted_products" ("isActive", "endDate");

-- FX rate cache — refreshed daily by scheduled job
CREATE TABLE IF NOT EXISTS "fx_rates" (
  "id"        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "base"      TEXT NOT NULL,   -- e.g. 'USD'
  "target"    TEXT NOT NULL,   -- e.g. 'NGN'
  "rate"      DOUBLE PRECISION NOT NULL,
  "fetchedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX "fx_rates_base_target_uidx" ON "fx_rates" ("base", "target");

-- Subscription tier: add missing columns if schema migration missed them
ALTER TABLE "subscriptions"
  ADD COLUMN IF NOT EXISTS "tier"             TEXT NOT NULL DEFAULT 'FREE',
  ADD COLUMN IF NOT EXISTS "currentPeriodEnd" TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS "cancelledAt"      TIMESTAMPTZ;

-- Wallet ledger: ensure balance column exists for audit trail
ALTER TABLE "ledger_entries"
  ADD COLUMN IF NOT EXISTS "balance" INTEGER NOT NULL DEFAULT 0;

-- =============================================================================
-- FALLBACK: processed_webhook_events
-- Required by packages/api/src/financial/payments.ts's idempotency gate.
-- Guarded with IF NOT EXISTS so this is a safe no-op if the hardening pass's
-- 20260101000006_processed_webhook_events migration already created it
-- (e.g. when both migrations are applied together in the recommended order
-- documented at the top of this file). Included here so Phase 4 also works
-- as a standalone deployment without a hard dependency on the hardening pass.
-- =============================================================================
CREATE TABLE IF NOT EXISTS "processed_webhook_events" (
  "id"          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "provider"    TEXT NOT NULL,
  "eventId"     TEXT NOT NULL,
  "processedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS "processed_webhook_events_provider_eventId_uidx"
  ON "processed_webhook_events" ("provider", "eventId");

-- Also required by payments.ts's idempotent commission upsert
ALTER TABLE "creator_commissions"
  DROP CONSTRAINT IF EXISTS "creator_commissions_creatorId_orderId_key";
ALTER TABLE "creator_commissions"
  ADD CONSTRAINT "creator_commissions_creatorId_orderId_key"
  UNIQUE ("creatorId", "orderId");
