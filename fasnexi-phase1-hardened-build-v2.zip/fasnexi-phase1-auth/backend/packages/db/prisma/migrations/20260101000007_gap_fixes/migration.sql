-- =============================================================================
-- FASNEXI — GAP-FIX MIGRATION
-- Adds: device_tokens table (push notification registration), and three
-- columns on custom_orders that packages/api/src/tailor/service.ts already
-- reads/writes (threadId, deadline, completedAt) but were never added to
-- schema.prisma or migrated — a pre-existing drift discovered while wiring
-- the tailor deposit checkout route. Without this, submitCustomOrderBrief
-- (deadline), sendCustomOrderMessage/getCustomOrderMessages (threadId), and
-- updateCustomOrderStatus's DELIVERED transition (completedAt) all throw at
-- runtime today — this isn't new breakage, it's exposing an existing bug.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- DEVICE TOKENS — Expo push token registration, one row per device per user.
-- A user can have multiple devices; unregistering removes exactly one row.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS "device_tokens" (
  "id"          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId"      UUID NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "expoToken"   TEXT NOT NULL,
  "platform"    TEXT NOT NULL DEFAULT 'unknown',  -- 'ios' | 'android' | 'web' | 'unknown'
  "deviceName"  TEXT,
  "lastUsedAt"  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT "device_tokens_expoToken_key" UNIQUE ("expoToken")
);

CREATE INDEX IF NOT EXISTS "device_tokens_userId_idx" ON "device_tokens"("userId");

-- ---------------------------------------------------------------------------
-- CUSTOM ORDERS — add the three columns service.ts already assumes exist
-- ---------------------------------------------------------------------------
ALTER TABLE "custom_orders" ADD COLUMN IF NOT EXISTS "threadId" UUID;
ALTER TABLE "custom_orders" ADD COLUMN IF NOT EXISTS "deadline" TIMESTAMPTZ;
ALTER TABLE "custom_orders" ADD COLUMN IF NOT EXISTS "completedAt" TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS "custom_orders_threadId_idx" ON "custom_orders"("threadId");
