-- =============================================================================
-- PROCESSED WEBHOOK EVENTS — idempotency table for payment provider callbacks
-- UNIQUE(provider, eventId) prevents double-processing of retried webhooks
-- =============================================================================
CREATE TABLE IF NOT EXISTS "processed_webhook_events" (
  "id"          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "provider"    TEXT NOT NULL,
  "eventId"     TEXT NOT NULL,
  "processedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX "processed_webhook_events_provider_eventId_uidx"
  ON "processed_webhook_events" ("provider", "eventId");

-- Also add composite unique constraint to creator_commissions for idempotent upsert
ALTER TABLE "creator_commissions"
  DROP CONSTRAINT IF EXISTS "creator_commissions_creatorId_orderId_key";
ALTER TABLE "creator_commissions"
  ADD CONSTRAINT "creator_commissions_creatorId_orderId_key"
  UNIQUE ("creatorId", "orderId");

-- Outbox events table for transactional event reliability
CREATE TABLE IF NOT EXISTS "outbox_events" (
  "id"            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "type"          TEXT NOT NULL,
  "payload"       JSONB NOT NULL DEFAULT '{}',
  "correlationId" TEXT,
  "status"        TEXT NOT NULL DEFAULT 'PENDING',
  "failureCount"  INTEGER NOT NULL DEFAULT 0,
  "lastError"     TEXT,
  "createdAt"     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "processedAt"   TIMESTAMPTZ,
  "deadLetteredAt" TIMESTAMPTZ
);
CREATE INDEX "outbox_events_status_createdAt_idx" ON "outbox_events" ("status", "createdAt");
CREATE INDEX "outbox_events_correlationId_idx"    ON "outbox_events" ("correlationId");
