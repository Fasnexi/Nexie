-- =============================================================================
-- FASNEXI — PHASE 2 MIGRATION
-- Adds: StoryItem, style badges on UserProfile, message threads,
--       Notification index improvements, Challenge vote tracking reference
-- Note: Follow, Post, Comment, Like, SavedPost, Challenge, ChallengeEntry
--       are already in the Phase 0 baseline migration from schema.prisma.
--       This migration adds what Phase 2 runtime actually needs beyond that.
-- =============================================================================

-- StoryItem — ephemeral 24h content (Redis tracks active TTL, PG holds metadata)
CREATE TABLE "story_items" (
  "id"              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId"          UUID NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "mediaUrl"        TEXT NOT NULL,
  "mediaType"       TEXT NOT NULL DEFAULT 'image', -- 'image' | 'video'
  "durationSeconds" INTEGER NOT NULL DEFAULT 5,
  "expiresAt"       TIMESTAMPTZ NOT NULL,
  "createdAt"       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX "story_items_userId_expiresAt_idx" ON "story_items" ("userId", "expiresAt");
CREATE INDEX "story_items_expiresAt_idx" ON "story_items" ("expiresAt");

-- Message threads — in-app messaging (Phase 2 basic: 1:1 only)
-- Messages table already exists via schema.prisma; this just adds a thread
-- index to make threadId queries fast.
CREATE INDEX IF NOT EXISTS "messages_threadId_idx" ON "messages" ("threadId");
CREATE INDEX IF NOT EXISTS "messages_createdAt_idx" ON "messages" ("createdAt" DESC);

-- Style badges — enum stored on user row via jsonb (avoids a separate table
-- for Phase 2; Phase 6 moves this to a proper UserBadge table if count grows)
ALTER TABLE "users"
  ADD COLUMN IF NOT EXISTS "styleBadges" TEXT[] DEFAULT '{}';

-- Improve notification query performance (read + userId + recency)
CREATE INDEX IF NOT EXISTS "notifications_userId_read_createdAt_idx"
  ON "notifications" ("userId", "read", "createdAt" DESC);

-- Creator profile follower count — initialise to actual follow count for
-- any creator profiles created before this migration ran
UPDATE "creator_profiles" cp
SET "followerCount" = (
  SELECT COUNT(*) FROM "follows" f WHERE f."followingId" = cp."userId"
)
WHERE "followerCount" = 0;

-- Challenge entries: ensure the unique constraint exists
ALTER TABLE "challenge_entries"
  DROP CONSTRAINT IF EXISTS "challenge_entries_challengeId_userId_key";
ALTER TABLE "challenge_entries"
  ADD CONSTRAINT "challenge_entries_challengeId_userId_key"
  UNIQUE ("challengeId", "userId");

-- Add postId FK to ChallengeEntry (links entry to the CHALLENGE_ENTRY post)
ALTER TABLE "challenge_entries"
  ADD COLUMN IF NOT EXISTS "postId" UUID REFERENCES "posts"("id") ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS "challenge_entries_postId_idx" ON "challenge_entries" ("postId");

-- Attribution token lookup index (creator commission tracking)
CREATE INDEX IF NOT EXISTS "creator_commissions_creatorId_status_idx"
  ON "creator_commissions" ("creatorId", "status");
