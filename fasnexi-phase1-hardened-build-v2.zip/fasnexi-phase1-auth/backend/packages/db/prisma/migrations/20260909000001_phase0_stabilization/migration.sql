-- FasNexi Phase 0: promotion billing fields + checkout session lookup
ALTER TABLE "promoted_products" ADD COLUMN "dailyBudget" INTEGER;
ALTER TABLE "promoted_products" ADD COLUMN "billedAmount" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "promoted_products" ADD COLUMN "dailyBilledAmount" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "promoted_products" ADD COLUMN "billingDay" TIMESTAMP(3);
ALTER TABLE "promoted_products" ADD COLUMN "lastBilledAt" TIMESTAMP(3);

-- Existing campaigns: preserve the safest known ceiling. If production has
-- campaigns, operators should review daily budgets before enabling billing.
UPDATE "promoted_products" SET "dailyBudget" = "budgetAmount" WHERE "dailyBudget" IS NULL;
ALTER TABLE "promoted_products" ALTER COLUMN "dailyBudget" SET NOT NULL;

ALTER TABLE "orders" ADD COLUMN "checkoutSessionId" TEXT;
CREATE UNIQUE INDEX "orders_checkoutSessionId_key" ON "orders"("checkoutSessionId");
