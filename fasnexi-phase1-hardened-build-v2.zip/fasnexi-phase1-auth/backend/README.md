# FasNexi Backend — Consolidated Repo

This is the full backend application code (Next.js API routes, service layer, Prisma schema/migrations, worker) merged into one clean tree from the uploaded repo, with all four requested gap fixes applied directly rather than delivered as a separate patch set.

## What's in here vs. what isn't

**Included:** `apps/web/app/api/**` (57 routes), `packages/api/src/**` (service layer), `packages/auth/src/**` (Better Auth config, guards, permission matrix, client), `packages/db/prisma/**` (schema + all 6 migrations), `apps/worker/src/**`.

**Not included:** CI/CD workflows, Terraform, and deployment scripts. The uploaded archive's infra files didn't self-document their target paths the way every `.ts` file did (each `.ts` file has a header comment stating its own intended path — that's how this consolidation was done reliably), so placing them with confidence wasn't possible without guessing. If you want those consolidated too, point me at the archive's terraform/`.github` structure directly and I'll do the same treatment.

## How this was built (so you can trust it, not just take it on faith)

Two reliable sources, no guessing:
1. **51 API route files** whose full directory paths survived the original upload intact (`apps/web/app/api/**/route.ts` across the `fasnexi-auth`/`fasnexi-phase1..5`/`fasnexi-hardening` folders).
2. **Every other `.ts` file**, which turned out to self-document its own intended path in a header comment (e.g. `// packages/api/src/checkout/stripe.ts`) — the codebase's own convention, not something I imposed. That let every one of the ~35 flat, un-pathed files from the original upload get placed correctly by reading its own first line rather than guessing from filename alone.

One real collision surfaced doing this: **`apps/web/app/api/products/[id]/route.ts` existed as two separate files** — one with only `GET` (from the `fasnexi-phase1` upload), one with only `PATCH`/`DELETE` (from `fasnexi-auth`). Since Next.js allows exactly one `route.ts` per path, these are merged into one file exporting all three methods — not a guess, both halves' logic is preserved verbatim.

One more thing worth knowing: a **third, orphaned version of the products list route** (`GET /api/products`) turned up as a flat file during this pass — nearly identical to the one built for Gap #1, but without the input validation and using slightly different query param names (`sort`/`inStock` vs. this delivery's `sortBy`/`inStockOnly`). It was never in the properly-pathed route directories, so it was dead code, not a live duplicate — the gap-fix version (with validation) is what's in this consolidated tree. Flagging it so you're not surprised if you come across the orphaned copy separately.

## Verification performed

- Brace/paren balance across all 111 `.ts` files (one flagged pair in `inventory-hardened.ts` is a false positive from lettered-list prose in a comment — `a) ... b) ...` — not a real syntax issue, and it's a pre-existing file, not one touched by this delivery)
- Every `@fasnexi/api/*` and `@fasnexi/auth/*` import across all 111 files resolved against an actual file in this tree — zero unresolved imports
- Route count reconciles exactly: 50 unique original routes (51 files, one pair merged) + 7 new = 57

## Gap fixes applied directly (not a separate patch)

All four originally-requested gaps, plus two more found while implementing them — full detail in the companion `fasnexi-api-contract-reference.md` (now updated to mark these resolved). Short version:

1. `GET /api/products` — list/search, wraps the pre-existing `listProducts()`
2. `GET`/`PATCH /api/notifications`, `PATCH /api/notifications/:id` — read side; the write side (worker creating `Notification` rows) already existed
3. `POST /api/uploads/sign` (Cloudinary), `POST`/`DELETE /api/push-tokens` + real Expo push dispatch (replacing a `TODO` stub in the existing worker), `POST /api/tailor/:id/deposit` + a webhook branch calling the previously-orphaned `confirmDepositPaid()`
4. `X-Nexi-Remaining` header — and, while tracing it, found the live route was using a non-atomic rate limiter in a *different* file than the one the hardening pass had already fixed; pointed it at the same atomic limiter instead of maintaining two

Bonus: `CustomOrder.threadId`/`deadline`/`completedAt` — referenced by `tailor/service.ts` but never added to the schema, meaning several already-shipped tailor endpoints were throwing at runtime independent of anything in this delivery. Added via the new migration.

## Before deploying

1. Run migration `20260101000007_gap_fixes`
2. Set `CLOUDINARY_API_SECRET`, `CLOUDINARY_API_KEY`, `CLOUDINARY_CLOUD_NAME`
3. Deploy order: DB migration → worker → web app (worker needs to be ahead so it can pick up the push-dispatch code before traffic hits routes that enqueue notifications)
