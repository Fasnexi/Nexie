/**
 * React Native injects __DEV__ as a global at the bundler level. It's
 * normally typed via @types/react-native or React Native's own type defs,
 * pulled in once this scaffold has real node_modules installed. Declared
 * here so this file type-checks standalone in the meantime.
 */
declare const __DEV__: boolean;
