/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './packages/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        black: '#0B0B0B',
        cream: '#F5F1EA',
        gold: '#C8A45D',
        'gold-muted': '#D6C7B2',
        beige: '#E8DCCB',
      },
      fontFamily: {
        heading: ['PlayfairDisplay_600SemiBold'],
        body: ['Inter_400Regular'],
      },
    },
  },
  plugins: [],
};
