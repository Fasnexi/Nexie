# FasNexi Frontend — Phase 2, Step 1: Foundation

This is the foundation slice from the build plan (§7, step 1) — not the
full app. Spot-checked two load-bearing claims from the plan against the
actual backend source (`fasnexi-backend-consolidated.zip`) before building
on them:

- **Auth guard chain** (`requireUser → requireVerifiedRole → requirePermission`,
  throw-based, `withErrorHandling` maps to 401/403) — confirmed by reading
  `packages/auth/src/middleware/guards.ts` directly.
- **Payment gateway routing by currency** — confirmed by reading
  `packages/api/src/checkout/stripe.ts`; comment says NGN/KES/GHS/ZAR route
  through Paystack-or-Flutterwave rather than the exact three-way split the
  planning doc states, so treat `GATEWAY_BY_CURRENCY` in
  `packages/api-contracts/src/common.ts` as a first draft to re-verify
  against the actual `checkout/stripe.ts` routing logic before Shop (step 4)
  ships, not as double-confirmed fact.

Everything else in the plan (57 routes, 48 models, the other five §0 gap
fixes) wasn't independently re-verified line-by-line here — the plan's
account is detailed and internally consistent, but "the planning doc says
it's confirmed" and "I confirmed it" aren't the same thing, and this
scaffold doesn't blur that.

## What's here

- `app/` — Expo Router file-based nav: auth stack, 5-tab shell
  (Home/Discover/Nexi/Shop/Profile — no Wallet tab, per §1.5b), Console
  route stub for the web admin surface.
- `packages/api-contracts/` — Zod schemas: error envelope (backend sends
  flat `{error}`, we normalize to `{error, code?, fields?}` client-side),
  cursor pagination, auth/roles, a first products schema.
- `packages/api-client/` — one function per endpoint, Better Auth header
  injection (cookie on web, Bearer token on native), Zod-validated
  responses, `ApiClientError` for a single error shape UI can pattern-match
  on.
- `packages/ui/src/tokens/` — the corrected brand colors and typography
  from plan §1.5 (Playfair Display / Inter, `#0B0B0B`/`#F5F1EA`/`#C8A45D`).
- `lib/useNexiStream.ts` — SSE parsing over `fetch`, works on both native
  and web without needing native `EventSource`.
- `lib/ApiErrorBoundary.tsx` — the per-screen error pattern from §5.3.
- Discover tab wired live to `GET /api/products` demonstrating the
  three required list states (skeleton / empty / pagination-in-flight).

## Not done yet (see plan §7 for the rest of the sequence)

Onboarding, Home feed, Shop/checkout, Wardrobe uploads, full Nexi UI,
Loyalty, Resale/Tailor, Video, role dashboards, Console. Also un-wired:
the real Better Auth client import in `lib/auth-wiring.ts` points at
`@fasnexi/auth/client`, which needs to resolve to the actual package once
this scaffold sits inside the real monorepo — right now it's a stub import.

## Step 2: Onboarding (Style DNA flow)

Built the full 6-step flow (Welcome → Archetype → Body Profile → Lifestyle
→ Wardrobe Snapshot → Preview) with a progress indicator, back navigation,
zustand wizard state, and the "no step blocks on an optional action" rule
applied to Wardrobe Snapshot (skip-only for now, since upload isn't wired
until step 5).

**Blocker found during validation, not in the plan's §0 list:** grepped
every `db.styleProfile` call site in the backend
(`feed/ranking.ts`, `gaps/analyser.ts`, `nexi/context.ts`) — all three are
reads (`findUnique`). None of the 57 routes create or update a
`StyleProfile`. So onboarding has nowhere to actually persist its answers
yet. `packages/api-client/src/endpoints/onboarding.ts` is a deliberate,
clearly-labeled stub (dev-mode console warning, no network call) rather
than a guess at a URL that doesn't exist. The UI flow and local state are
fully built and testable; wiring it to the backend needs either a new
route (e.g. `POST /api/style-profile`) or folding it into an existing
profile-update route — a backend decision, not something to invent here.

Field names and enum values in `packages/api-contracts/src/style-dna.ts`
are transcribed directly from `schema.prisma`'s `StyleProfile` model, not
guessed.

## Validation notes

Ran `tsc --noEmit` against every file after each step (this sandbox has no
network, so `npm install` was never run — no `node_modules`). Two
categories of diagnostics show up and it's worth knowing which is which:

- **Real bugs, fixed:** an `Authorization` header type mismatch in
  `auth-wiring.ts`, a missing `React.ReactNode` import in
  `ApiErrorBoundary.tsx`, several implicit-`any` callback params, and a
  zustand multi-field object selector in `preview.tsx` that returned a new
  object every render (fixed with `useShallow` — otherwise a real
  `useSyncExternalStore` footgun in React 18).
- **Expected noise, not bugs:** "cannot find module" for zustand/expo-router/
  react-native, JSX `children`/`key` prop errors, and `set`/`get` implicit-
  any in the store — all downstream of no `node_modules` being installed
  here. They resolve once a real `npm install` runs inside the actual
  monorepo. Don't chase these further; re-run `tsc --noEmit` after install
  to confirm they're gone, not before.

## Step 3: Home + Discover

Feed, Stories, product/creator/challenge browse, search+filters, and the
challenge vote flow, all wired to real endpoints — with corrections found
by reading source instead of trusting the plan's summary:

- **`GET /api/products`'s actual response is `{products, nextCursor,
  total}`**, not the `{items, nextCursor}` shape Step 1 assumed from the
  plan's prose (which claimed cursor pagination was "confirmed consistent...
  no normalization needed"). The search param is `q`, not `query`.
  `ProductSummary` has `slug`/`category`/`isInStock`/`salesCount`/`vendor`,
  not the invented `inventoryCount`. Rewrote
  `packages/api-contracts/src/products.ts` and the products endpoint
  client against the real `catalog.ts` + `schema.prisma` — this was a
  load-bearing bug in Step 1's own foundation, not a Step 3 issue.
- **`GET /api/feed` returns `{posts, count}`**, no `nextCursor` field at
  all — cursor is keyset on the last post's `id`. The Home feed derives
  its own cursor and infers "more pages" from `posts.length === limit`.
- **`GET /api/creators` returns a bare array**, not `{creators: [...]}`,
  and has no pagination — just `limit`. Confirmed from
  `creators/storefront.ts`, not guessed.
- **Vote errors don't follow the plan's "confirmed everywhere" error
  shape.** `voteForEntry()`'s business-logic failures (wrong phase, voting
  closed, entry not found) are plain `throw new Error(...)`, and
  `withErrorHandling` only catches `UnauthenticatedError`/`ForbiddenError`
  — so these surface as raw, uncaught 500s. The challenge vote UI shows a
  generic message for 500s rather than fabricating a specific reason the
  response doesn't reliably carry.

Also fixed two structural bugs found while validating, unrelated to any
single step: a wrong relative-import depth in the onboarding stub, and a
dangling `Stack.Screen` reference to `console` (an empty directory since
Step 1 with no route file behind it) — both would have broken at runtime.

Product detail (`app/product/[slug].tsx`) and the web admin Console
(`app/console/index.tsx`) are honest placeholders, not built out — they
exist only so in-app navigation doesn't dead-end before their real build
steps (Shop = step 4, Console = step 11).

Validation this round: `tsc --noEmit` after every batch of files (same two
no-`node_modules` noise categories as before, no new ones), plus a script
checking every relative import in the project actually resolves to a real
file on disk (caught the onboarding stub's wrong `../..` depth) and that
every route referenced in `app/_layout.tsx` has a backing file (caught the
dangling `console` reference).
## Step 4: Shop (catalog → cart → checkout)

Built catalog, product detail with add-to-cart, a client-only cart
(Zustand — no `/api/cart` route exists anywhere in the backend), and
checkout wired to the real `POST /api/checkout` contract. Order
confirmation and order history are honest placeholders, not fake data —
see the gap below.

**Audit findings this round** (done before writing any Shop code, since
this step's whole point is money moving correctly):

- **I was wrong to doubt the gateway routing in Step 1.** A fuller read of
  `checkout/stripe.ts` this time confirms the plan's claim exactly:
  Stripe for USD/EUR/GBP, Paystack for NGN/GHS/ZAR, Flutterwave for
  KES/XOF/XAF. `EGP` does have a code path too (falls through to Stripe,
  since it's not in the explicit African-currency list) — the earlier
  `GATEWAY_BY_CURRENCY: EGP -> null` was itself a mistake, now fixed.
  Correcting an over-cautious flag is as much a validation job as
  catching a real bug — worth recording both directions.
- **Confirmed gap, not in the plan's §0 list: no consumer order-read
  endpoint exists at all.** Grepped every `db.order` reference in the
  backend — only `vendors/dashboard.ts` (vendor-side fulfillment) and
  `financial/payments.ts` (internal webhook idempotency checks). No
  route, no service function, nothing to wire "order confirmation" or
  "order history" to, despite both being named in the plan's own Shop
  build order. `app/orders/success.tsx` and `app/orders/history.tsx` say
  so plainly instead of faking data.
- **`priceAmount` is stored in the smallest currency unit** (confirmed
  from schema.prisma's comment, cross-checked against checkout/stripe.ts
  dividing by 100 uniformly) — and Step 3's Discover screen was
  displaying it raw (a $50.00 item would've shown "USD 5000"). Fixed at
  the source with a shared `lib/money.ts` formatter and swept every
  existing display site rather than patching just the new Shop screens.
- **`createCheckoutSession` never validates a product's own
  `priceCurrency` against the checkout `currency` the buyer selects** —
  it charges `priceAmount` at face value in whatever currency is passed,
  so a mismatched currency would silently charge the wrong amount. The
  cart works around this by refusing to mix currencies in one cart rather
  than exercising a gap the backend doesn't guard against — see
  `cart-store.ts` and `common.ts`'s contract notes.
- **Removed dead code with a false claim baked into it:** `common.ts` had
  an unused `cursorPageSchema` helper asserting pagination was "confirmed
  consistent... no normalization needed" across every list endpoint —
  falsified by Step 3's own findings (feed, creators) and never actually
  called anywhere. Deleted rather than left as a misleading landmine for
  whoever reads this contract file next.

Validation this round: same `tsc --noEmit` + import-resolution-on-disk
pass as prior steps, plus a new check cross-referencing every
`router.push`/`router.replace` call in the app against files that
actually exist on disk (tsc alone can't catch a route-string typo) — all
resolve correctly, including the `/(tabs)/shop` group-qualified pattern
for navigating into a specific tab from outside the tab navigator.
## Step 5: Wardrobe (Cloudinary uploads, AI tags, gap analysis)

Grid view, upload flow, item detail with AI tags/record-wear/re-tag/
archive, and gap analysis — all against contracts read directly from
`wardrobe/service.ts`, all three wardrobe route files, `uploads/
cloudinary.ts`, `gaps/analyser.ts`, and `schema.prisma`, not the plan's
summary. Findings from this pass:

- **`purchasePrice` is a `Decimal(10,2)` column, not an Int in minor
  units like `Product.priceAmount`.** Prisma's default Decimal
  serialization returns it as a STRING (e.g. `"49.99"`) on raw list/detail
  responses — but the analytics endpoint (`?view=analytics`) explicitly
  runs it through `Number()` server-side first, so `totalValue` and
  `topCostPerWear[].purchasePrice` on THAT endpoint are real numbers. Two
  different types for conceptually-the-same field depending which route
  you call — modeled as two different schemas rather than picking one and
  hoping it's close enough. Do NOT run this through `lib/money.ts` (that
  divides by 100, which is wrong for an already-major-unit decimal).
- **`GapItem` has no `id` field on the wire, confirmed from the actual
  TS interface** — `getExistingGaps`'s `.map()` selects `id` from the DB
  row but never includes it in what it returns. The gaps screen keys its
  list by `category::occasion` instead of reaching for `gap.id`, which
  would silently be `undefined`.
- **`POST /api/gaps`'s 24h rate limit doesn't reject the request** — it
  silently returns the previous analysis again, with `wellCoveredOccasions:
  []` (not recomputed) and the OLD `analysedAt`. No error, no flag. The
  gaps screen compares the returned `analysedAt` against what it already
  had to detect this and say so, rather than claiming a fresh analysis
  ran when it didn't.
- **Confirmed the same uncaught-500 pattern from Step 3/4 recurs here
  too:** `retriggerTagging`'s "not found" and `archiveWardrobeItem`'s
  "not found" are both plain `throw new Error(...)` with no route-level
  catch (the DELETE route only special-cases the "resale listing"
  substring, not "not found"). This is now confirmed in three unrelated
  places (challenges/vote, wardrobe tag, wardrobe archive) — it's a
  systemic gap in how `withErrorHandling` is used project-wide, not
  something isolated to any one route. Every screen that can hit it shows
  a generic message rather than fabricating a specific one.
- **Found and fixed a real client-library bug before it shipped:**
  `apiRequest` would have failed on any 204 No Content response (like
  wardrobe archive's DELETE) — `safeJson` degrades to `{}` on an
  unparseable body, and `{}` fails a `z.void()` schema. Fixed at the
  shared `client.ts` level (checks `res.status === 204` before attempting
  to parse a body at all), so every future 204-returning endpoint is
  covered, not just this one.
- **No thumbnail-generation convention exists anywhere server-side** —
  `thumbnailUrl` is purely client-supplied. The upload helper derives one
  using Cloudinary's standard on-the-fly URL transformation syntax
  (`/upload/w_300,h_300,c_fill,q_auto/`), which is a genuine documented
  Cloudinary capability requiring no server config — flagged as a
  client-side choice, not something confirmed against this backend's
  actual Cloudinary account settings (no such config exists to check).
- **"You Already Own X" isn't built.** No distinct endpoint for it exists
  anywhere in wardrobe, gaps, or nexi routes — it reads like a UI
  treatment on top of Nexi's outfit-generation output, but that's an
  educated guess, not a confirmed contract. Left out rather than faked;
  flagged for whoever builds Nexi's outfit flow (step 6) to confirm for
  real.
- **Checked something I couldn't fully verify, and said so explicitly**:
  `ImagePicker.MediaTypeOptions.Images` — no network access in this
  sandbox to `npm install` and check the actual installed API surface, so
  this is flagged in-code as an assumption to confirm for real, unlike
  every backend contract above, which was read directly from source.

Registered `expo-image-picker` (with iOS permission strings in `app.json`
— required for App Store review, easy to forget) since Wardrobe's upload
flow needs it and Step 1 didn't anticipate that.

Validation this round: same `tsc --noEmit`, import-resolution, and
route/navigation-path checks as every prior step — all clean (remaining
`tsc` diagnostics are exclusively the already-documented no-`node_modules`
categories, now including a new but equivalent instance: destructured
property access on a zod-response type that resolves to `unknown` without
the zod package installed).
## Step 6: Nexi (streaming chat, outfit generation, Style This)

Every contract here read directly from `nexi/engine.ts` and all three
route files before writing any UI — and it's a good thing, because Step
1's original `useNexiStream` (built from the plan's prose, before this
project's source-first discipline was established) had two bugs that
would have made it completely non-functional:

- **Wrong request field.** It sent `{message, sessionId, stream}`; the
  real route requires `query`, not `message` — every call would have hit
  a 400 ("query is required").
- **Wrong SSE frame format, and this one's subtle.** It looked for a
  separate `event:` line per SSE frame (standard SSE convention) and a
  `data:` line for the payload. The real backend sends only a single
  `data: {"type":"delta",...}` line — the discriminator lives inside the
  JSON payload, there's no `event:` line at all. The old parser's
  delta-handling branch could never have matched anything; the chat UI
  would have rendered nothing, forever, while looking like it was
  streaming correctly. Verified the fix isn't just "looks right" — wrote
  a standalone Python simulation of the exact documented frame format and
  ran it through the same parsing logic before calling this done.
- **No auth headers at all.** The original hook made a bare `fetch` with
  `credentials: 'include'` but no Bearer token — every native-app call
  would have hit `requireUser()`'s 401 the moment a real backend was
  connected. Fixed by exporting `getApiBaseUrl()`/`getConfiguredAuthHeaders()`
  from the shared `client.ts` so this hook (and any future one that needs
  raw `fetch` for a streaming body) pulls from the same single
  configured source `apiRequest` uses, rather than needing its own
  separately-wired copy that's easy to leave stale or incomplete.

New gaps found building outfit generation / Style This:

- **`generateOutfits()` consumes a rate-limited query but its response
  has no `remaining` field at all** — unlike chat. The outfit/Style This
  screen doesn't display or imply a remaining-count after generating,
  rather than show a number that's silently wrong the moment it runs.
- **Style-this's "item still tagging" case returns HTTP 202 with an
  `{error}` body** — 202 passes `fetch`'s `res.ok` check, so a normal
  success-schema validation would have crashed with a confusing Zod error
  instead of showing the intended message. Added `apiRequestRaw` as a
  reusable low-level primitive in `client.ts` for exactly this class of
  problem (a 2xx status that isn't the normal success shape), rather than
  a one-off special case bolted onto `nexi/style-this` alone.
- **"Style This" is gated on `item.aiTagged` client-side too**, matching
  the backend's own precondition, so the button reflects the real
  constraint instead of always being tappable and then failing.

Validation this round: the usual `tsc --noEmit` + import-resolution +
navigation-path checks (widened this time to also catch the object-form
`router.push({pathname, params})` used for the Style This deep-link, not
just string/template-literal pushes), plus the SSE-format simulation
above — a case where "confirm everything" meant confirming the parsing
logic against real sample data, not just re-reading the code and
eyeballing it.
## Step 7: Profile core (Notifications, Settings, push registration)

Notifications inbox (list/mark-read/mark-all-read), Settings (role
switcher + push notification toggle), and a live unread-count badge on
the Profile entry point — all contracts confirmed against
`notifications/service.ts`, both notification route files, and
`notifications/push.ts` before writing UI.

- **Confirmed a real unknown, not guessed around it:** `Notification.data`
  is a `Json` column that almost certainly varies by `type`, but there is
  no code anywhere in this backend that constructs a Notification row —
  only consumption exists (list/markRead/markAllRead). The "notifications
  worker" the plan's §0 describes as already writing notifications isn't
  present in what's readable here. Rather than invent a plausible-looking
  per-type field schema, `data` is typed `z.unknown()` and the inbox
  renders generically (type label + timestamp) — a guessed schema here
  would have been fabricating a contract, not confirming one.
- **Push tokens must be real Expo push tokens**
  (`ExponentPushToken[...]`/`ExpoPushToken[...]`), confirmed from
  `registerDeviceToken`'s validation — not a raw FCM/APNs token, so the
  client has to go through `expo-notifications`'s
  `getExpoPushTokenAsync()`, not any native push SDK directly. Also
  confirmed `DELETE /api/push-tokens/:id` takes the DB row's own `id`
  (returned at registration), not the raw token string — the settings
  screen persists that `id`, not the token, for unregistering later.
- **`getExpoPushTokenAsync()` requires an EAS `projectId`, and none is
  configured anywhere in this scaffold's `app.json`** — there's no real
  EAS project behind this build. Rather than fabricate a placeholder id
  that would fail in a confusing way deep inside the Expo SDK,
  `registerForPushNotifications()` checks for it explicitly and returns a
  typed `not-configured` result with the real reason, which Settings
  displays honestly instead of a toggle that silently does nothing.
- **Web is explicitly unsupported for push** (needs separate VAPID
  credentials, not set up here) — same treatment as the Step 5 wardrobe
  web-upload gap: flagged and short-circuited, not faked.
- **Caught and fixed a config bug before it could break a real build:**
  the `expo-notifications` plugin entry in `app.json` originally
  referenced `./assets/notification-icon.png`, which doesn't exist
  anywhere in this scaffold. A real Expo prebuild would have failed on a
  missing asset. Removed the (optional) `icon` key rather than leave a
  reference to a file that isn't there.
- **Sign-out is an honest stub, not a fake button** — `lib/auth-wiring.ts`'s
  Better Auth client import has been a placeholder since Step 1
  (`@fasnexi/auth/client`, meant to resolve once this scaffold sits in the
  real monorepo). Settings says so directly rather than wiring a button
  that does nothing when tapped.

Validation this round: same `tsc --noEmit` + import-resolution +
navigation-path checks as every prior step, plus this time actually
isolating the diagnostics touching only this step's new/changed files
(rather than trusting the aggregate count) to make sure nothing new was
hiding under an existing filter category — caught and fixed 3 genuine
implicit-`any` params that had slipped past a first pass. Also validated
`app.json` and `package.json` as parseable JSON after editing them by
hand, since a syntax slip in either would silently break the whole build
in a way `tsc` alone wouldn't catch (neither file is TypeScript).
## Step 7: Profile core (Notifications, Settings/role switcher, push tokens)

Notifications inbox, Settings (role switcher + push notification
registration), and push-token registration — all against contracts
confirmed from source. Findings:

- **`Notification.data` has no confirmed shape.** It's a Prisma `Json`
  column that almost certainly varies by `NotificationType`, but there is
  no notification-*creation* code anywhere in this codebase — grepped for
  `NotificationType\.` across all of `packages/api/src` and found nothing.
  Only consumption (get/markRead/markAllRead) exists. Modeled `data` as
  `z.unknown()` and the inbox renders generically by type + timestamp
  rather than fabricating per-type field access.
- **Validated the Step 1 role-switching contract against real source for
  the first time** — Step 1 built it from the plan's prose (though it did
  check `guards.ts`). It turned out to be a Better Auth **plugin**
  (`multi-role.ts`), not a set of ordinary Next.js routes — there's no
  `app/api/auth/roles/*/route.ts` at all, only the catch-all handler. The
  request/response shapes held up exactly as originally built. But this
  surfaced two things Step 1 couldn't have known:
  - **`ADMIN`/`MODERATOR` can never be self-activated** — confirmed from
    `STAFF_ONLY_ROLES` in `permissions/matrix.ts`; the plugin's `before`
    hook 403s unconditionally for them. The Settings screen excludes them
    from the offerable list (still shows them if a real admin already
    holds the role — just never offers "Activate" as an option that's
    guaranteed to fail).
  - **Better Auth's own error-serialization shape is unverified.** These
    are Better Auth plugin endpoints, not this backend's usual
    `Response.json({error}, {status})` routes — their errors are thrown
    as Better Auth's `APIError`, and no `better-auth` package source was
    available anywhere in this sandbox to check how that actually
    serializes over HTTP. Genuinely unknown, not assumed either way. The
    Settings screen's role-switching error handling deliberately shows a
    generic retry message rather than trying to extract and display a
    specific error string from a shape that was never confirmed.
- **EAS `projectId` doesn't exist in this scaffold.** Push token
  registration needs one (`Constants.expoConfig.extra.eas.projectId`) to
  call `getExpoPushTokenAsync()`, and none is configured — there's no
  real EAS project behind this build. Rather than fabricate a placeholder
  that would fail confusingly deep in the Expo SDK, `registerForPush
  Notifications()` returns a typed `not-configured` result with the real
  reason, and Settings surfaces it honestly.
- **Two Expo client APIs flagged, not asserted with full confidence** —
  `Constants.expoConfig?.extra?.eas?.projectId` and `Constants.deviceName`
  — same class of caveat as Step 5's `ImagePicker.MediaTypeOptions`: no
  network in this sandbox to `npm install` and check the actual installed
  API surface, unlike every backend contract, which was read from real
  source. `deviceName` is optional and degrades gracefully if wrong;
  `projectId`'s path is Expo's standard documented location but "standard
  documented" isn't source-verified.
- Push notifications are skipped entirely on web (no VAPID setup exists
  here either) — same "don't fake it" treatment as Step 5's web upload
  gap.

Validation this round: same `tsc --noEmit` + import-resolution +
navigation-path checks as every prior step, plus explicitly re-verifying
a Step 1 contract against real source now that it had a real consumer —
worth doing given how much of this project has turned up gaps in things
that "looked" confirmed the first time.
## Step 8: Loyalty (balance/tier, history, redemption)

Overview + redeem screen and a paginated history screen, both against a
contract confirmed from `loyalty/service.ts` + `schema.prisma`. This was
a comparatively clean step — no uncaught-500 gaps this time (`redeemPoints`'s
"Insufficient points" error IS properly caught and translated to a real
400 `{error}` by the route, unlike vote/wardrobe-archive/wardrobe-tag), and
no field-shape surprises.

Two things worth recording anyway:

- **The tier-progress UI needed a constant the API doesn't return.**
  `GET /api/loyalty` gives `nextTier.pointsNeeded` (points remaining) but
  not the current tier's own threshold, which a progress bar needs to
  show position *within* the current bracket. Hardcoded the four
  thresholds (Bronze 0 / Silver 500 / Gold 2000 / Platinum 5000) from the
  confirmed constant in `loyalty/service.ts` rather than inventing them —
  flagged as a stable program-design constant, not the kind of thing
  likely to drift the way currency/gateway logic could, and a stale
  progress bar is a minor display issue, not a financial-correctness one
  the way getting `priceAmount` wrong was.
- **Confirmed tier is monotonic and redemption never demotes it** —
  `lifetimePoints` only increases on earning, never decreases on
  redemption (the service function's own comment: "spending doesn't
  demote you"). The redeem screen says this explicitly rather than
  leaving it to be discovered by a confused user watching their tier not
  change after redeeming.

Validation: same `tsc --noEmit` + import-resolution + navigation-path
checks as every prior step — all clean, no new bug categories.
## Step 9: Resale + Tailor Marketplace

Confirmed contracts from `resale/service.ts`, `tailor/service.ts`, all
eight route files, and `schema.prisma` before writing any UI. This step
turned up more real gaps than any since Step 3-4, and one genuine bug in
my own contract file:

- **Confirmed the plan's own flagged open item (§0 #7) at the
  implementation level.** `resale/[id]/purchase` hardcodes a raw
  `new Stripe(...)` checkout session directly — bypassing the
  multi-gateway `createCheckoutSession` entirely, regardless of the
  listing's own currency. It's not alone: `tailor/[id]/deposit` does the
  *exact* same thing (its own comment says it mirrors resale purchase
  and, per that comment, tickets purchase too — a systemic pattern
  across three "one-off" checkout paths, not one isolated case). Both
  purchase/deposit UIs gate on `GATEWAY_BY_CURRENCY` and only offer a
  working button for Stripe-routed currencies (USD/EUR/GBP/EGP), with an
  honest explanation for everything else, rather than let a buyer hit an
  opaque Stripe-API failure.
- **`browseResaleListings` accepts a `category` filter param that's
  never used in the actual `where` clause** — confirmed by reading the
  full function body. No category filter is offered in the browse UI;
  building one would be a control that looks functional but silently
  does nothing.
- **No "my listings" endpoint exists anywhere** for a seller to manage
  listings they've already created — only browse (LISTED items from
  everyone), purchase, and withdraw. The list-item flow shows the new
  listing with a Withdraw button immediately after creation, since
  that's the only moment the client reliably has the id to act on it —
  flagged rather than inventing a client-only tracking scheme that
  wouldn't survive an app restart or sync across devices.
- **No single-tailor detail endpoint exists at all.** Every
  `tailor/[id]/*` route's `:id` is a CustomOrder id, not a TailorProfile
  id (confirmed by the quote route's own comment) — there's no
  `GET /api/tailor/:id`. The browse-tailors screen shows a tailor's full
  profile + brief form in an in-place modal using data already fetched
  by the list, instead of navigating to a route with nothing to fetch or
  fabricating a way to pass complex nested data (specialties array,
  portfolio URLs) through route params.
- **`TailorSpecialty` doesn't exist as an enum at all** — the route's own
  `specialty as any` cast was a clue. The real type is
  `TraditionalPreference[]` (Agbada, Dashiki, Kente, etc.) — confirmed
  from `schema.prisma`, not assumed from the route's variable naming.
- **Custom order attachments are intentionally not built.** Re-checked
  `uploads/sign`'s `VALID_FOLDERS` before adding an attachment picker to
  the brief form — it's a hard-capped set (`wardrobe`, `posts`, `video`,
  `avatars`), confirmed by reading the route directly, with no `tailor`
  option. Adding one would need a backend change; the brief form is
  text + deadline only rather than silently 400ing on every attachment.
- **`GET /api/tailor/orders` is role-aware** (TAILOR sees a fulfillment
  queue via a different service function; everyone else sees their own
  client history via `getClientCustomOrders`) — this step only builds
  the client-side shape. The TAILOR-role queue view belongs to Role
  dashboards (step 11), consistent with how the plan's own screen
  taxonomy splits "Tailor Marketplace" (client-facing) from "Role
  dashboards → Tailor dashboard" (fulfillment-side), not a split
  invented here.
- **Caught a real bug in my own contract file before it shipped**:
  `tailor.ts` imported `currencySchema` from `./checkout`, but it's
  actually defined in `./common` — `checkout.ts` imports it too but never
  re-exports it. `tsc` caught this immediately (`TS2459: ... declares
  'currencySchema' locally, but it is not exported`) — exactly the kind
  of mistake the validation pass exists to catch before it reaches a
  screen.
- The recurring uncaught-500 pattern is present here too (e.g. resale
  purchase's "Listing not found" and create-listing's "Wardrobe item not
  found" aren't in either route's caught-substring list) — handled the
  same way as every other step: real caught errors (which both resale and
  tailor routes have plenty of — this codebase is inconsistent about it
  rather than uniformly bad) are shown verbatim, uncaught ones get a
  generic fallback.

Validation this round: same `tsc --noEmit` + import-resolution +
navigation-path checks as every prior step, plus explicitly verifying the
9-field object-form route param passed from the resale browse screen
matches exactly what the detail screen destructures (a mismatch there
wouldn't show up in `tsc` at all, since `useLocalSearchParams`'s generic
type argument is asserted, not inferred from the caller).
## Step 10: Video (dedicated feed + posting)

Confirmed from `video/service.ts` + the route file before building.
Cleaner step than most (no uncaught-500 surprises, no dead params), but
caught one real bug in my own shared upload helper before it shipped:

- **Video posts share the same `Post` model as the main feed** (filtered
  by `type: "VIDEO"`), but `GET /api/video`'s own `select` returns a
  narrower, different field set than `/api/feed`'s — no `saveCount`/
  `culturalTags`/`rankScore` here. Modeled as its own schema rather than
  reusing `feedPostSchema`, which would have silently asserted fields
  this endpoint doesn't return.
- **Confirmed the video feed excludes your own videos** —
  `userId: { not: userId }` in the query, real and intentional, not
  something to "fix." Documented clearly so it doesn't look like a bug
  when testing (post a video, don't see it in your own feed — correct).
- **This endpoint DOES return a real `nextCursor`** — unlike `/api/feed`,
  which returns none at all. Worth stating explicitly given how much this
  project's pagination shape has varied endpoint-to-endpoint; nothing here
  should be assumed consistent with feed's approach just because they
  share an underlying table.
- **Found and fixed a real bug in the shared Cloudinary upload helper
  before it shipped**: `deriveThumbnailUrl` (built in Step 5 for wardrobe
  photos) inserted a resize transformation into the delivery URL as-is.
  For video, that produces a *transformed video clip*, not a static
  thumbnail frame — Cloudinary only returns a still image when the
  extension is also swapped to `.jpg`. Every video post would have shipped
  with a broken "thumbnail" (actually another video) if this had been
  reused unchanged. Fixed at the shared helper level with an `isVideo`
  branch, not patched only in the video screen.
- **Duration comes from Cloudinary's own upload response**
  (`result.duration`), not a client-side metadata read — more reliable,
  and it's literally what the backend validates against
  (`MAX_VIDEO_DURATION_SECONDS = 180`, confirmed from source). Extended
  the shared upload helper's return type to surface this rather than
  inventing a separate duration-measurement path.
- Playback is a thumbnail grid + full-screen modal player per video,
  not continuous scroll-driven autoplay — a deliberate scope trade-off
  (autoplay-on-scroll is fragile and genuinely hard to get right without
  a device to test on) rather than an oversight, called out as such
  rather than silently shipped as "the video feed."
- Same web-upload gap as Step 5 (no blob-conversion step implemented) —
  video posting only works on iOS/Android in this build.

Validation this round: same `tsc --noEmit` + import-resolution +
navigation-path checks as every prior step, all clean.
## Step 11: Role dashboards + Console

Creator earnings, Vendor dashboard/orders/inventory, Promoted listings,
the TAILOR-role queue (deferred from Step 9), and a Console web shell —
all confirmed from `creators/storefront.ts`, `vendors/dashboard.ts`,
`promotions/service.ts`, `tailor/service.ts`, and every relevant route
file. This step found the most serious backend bug in the whole project:

- **`POST /api/promotions` is completely broken, unconditionally.**
  `createPromotedListing`'s `data` object writes `dailyBudget` and
  `billedAmount` — neither field exists on the `PromotedProduct` Prisma
  model (confirmed by reading the full model: only id, productId,
  vendorId, budgetAmount, currency, cpmAmount, impressions, clicks,
  startDate, endDate, isActive). Every call throws a Prisma validation
  error, and — compounding it — the route's own catch block doesn't
  recognize that error shape, so it surfaces as an uncaught 500 on top of
  being fundamentally non-functional. This needs a database migration;
  nothing on the frontend can work around it. The campaign-creation form
  is still built (legitimate UI, ready the moment the backend is fixed)
  but leads with this caveat instead of hiding it.
- **Two separate, confirmed currency-mixing aggregation bugs**, one worse
  than the other: `getCreatorEarnings` sums a creator's commissions
  across ALL currencies with no grouping, then labels the total with
  whichever currency happened to be on the first commission row —
  mislabeled but at least labeled. `getVendorDashboardSummary`'s revenue
  aggregates do the same currency-blind summing but don't even attempt a
  currency label — the response has none at all. Neither is fixable from
  the frontend (both only return pre-aggregated sums, not the raw records
  needed to redo the math per currency); both screens display the raw
  numbers with an explicit, visible caveat rather than silently trusting
  them or hiding the problem.
- **Corrected a real error from my own earlier work**: Step 7 claimed "no
  notification-creation code exists anywhere," based on a grep pattern
  (`NotificationType\.`) that only matched dot-accessed enum references —
  missing 17 real `enqueueNotification()` call sites that use plain
  string literals instead. Re-searched properly, sampled 9 call sites,
  and found every `SYSTEM` notification includes a `message` field while
  `FOLLOW`/`LIKE`/`COMMENT` never do and `ORDER_UPDATE` is inconsistent
  even within itself. Upgraded the Notifications inbox to prefer
  `data.message` when present instead of rendering everything generically
  — a real improvement grounded in evidence, not a guess, but still
  honest that the actual persisting worker isn't in this codebase to
  verify against.
- **`getTailorOrders` (the TAILOR-role queue) has no `client` info at
  all** — no `include`, unlike the client-side `getClientCustomOrders`.
  The queue screen shows the raw `clientId` rather than fabricating a
  name lookup that doesn't exist in the response.
- **Found and fixed a real bug in my own Console implementation before
  it shipped**: the plan calls for reusing the same Vendor
  dashboard/orders/promotions components inside a desktop-shell wrapper
  ("same components, same API client, different shell chrome"). Doing
  that naively — literally importing and rendering the existing mobile
  screen components — carried over `VendorDashboardScreen`'s internal
  `router.push('/(tabs)/profile/dashboards/vendor/orders')` link
  unchanged. Tapping it inside Console would have navigated the *entire
  app* out of the Console shell into the mobile tab flow, defeating the
  point of a desktop shell. Fixed by giving that component an optional
  `onViewOrders` callback prop (defaults to the original route push for
  its normal standalone use, overridden by Console to just switch
  internal section state instead).
- **Made the same import mistake twice**: `vendor-dashboard.ts` imported
  `currencySchema` from `./checkout` instead of `./common` — the exact
  same error already caught and fixed once in `tailor.ts` during Step 9.
  Worth naming plainly rather than glossing over: repeating a known
  mistake is itself a finding, and the fix is identical (`tsc` catches it
  immediately either way).
- Console's breakpoint is a real `useWindowDimensions` width check
  (900px), not just `Platform.OS === 'web'` — a narrow browser window
  correctly falls back to directing the person to the mobile dashboard
  flow instead of squeezing a sidebar into a phone-width screen. One
  accepted inefficiency, stated rather than hidden: switching sections in
  Console unmounts/remounts the embedded screen components, so each
  switch re-fetches its data from scratch — a real trade-off of the
  component-reuse approach, not something masked as "it just works."

**Process note on this step specifically**: partway through, the sandbox
filesystem reset (documented, expected behavior between tasks) after a
large amount of unsaved work — the notifications correction and most of
this step's files had to be reconstructed from the conversation itself
rather than lost outright, but it's why this step involved rebuilding
several files verbatim before finishing. Checkpointed by rebuilding and
presenting the zip immediately after, rather than continuing to
accumulate more unsaved work.

Validation this round: same `tsc --noEmit`, import-resolution, and
navigation-path checks as every prior step, plus a manual unfiltered scan
of every remaining `tsc` diagnostic (not just a pattern-matched count) to
confirm nothing new was hiding behind the established noise categories.
## Final full-app audit

A dedicated audit pass across every tab, screen, button, navigation path,
and response contract in the finished app (not just the step being
built) — this is where most of the gaps found weren't in any single
step's own code, but in what never got built across steps. Findings:

### Confirmed unused backend routes → real missing features
Cross-referenced all 57 backend routes against every reference in the
frontend. `checkout/webhook`, both payment callbacks, and `health` are
correctly never called (server-only infrastructure) — but four route
groups were real, confirmed gaps with full backend support and zero
frontend surface:

- **`social` / `social/[userId]` / `social/engagement`** — the single
  biggest gap in the project. Follow/unfollow, followers/following
  lists, and like/save/comment on posts had complete backend support
  and were never built anywhere, despite the Home feed showing
  `likeCount`/`commentCount` on every post since Step 3. Built: like +
  save buttons on Home's feed cards (optimistic, revert-on-failure), a
  Comments screen (view + add), and a User Profile screen with a follow
  button. Confirmed quirk while building this: `followerCount` is
  denormalized on `CreatorProfile` only — it reads `0` for any user
  without one, even if they have real followers in the `Follow` table.
- **`creators/[handle]` (storefront)** had no consumer entry point either
  — used as the backing data for the new User Profile screen, with a
  confirmed, honest limitation: it 404s for any non-Creator, and there is
  no general "view any user's profile" endpoint anywhere in the backend.
  The profile screen falls back to a minimal username-only header for
  that case rather than fabricate a general profile fetch that doesn't
  exist.
- **`challenges/[id]/entries`** — Step 3 built challenge *voting* but not
  *entering*, despite the plan's own screens table calling for "Vote/entry
  flow" as one feature. Built an entry-submission screen reusing the same
  Cloudinary upload flow as Wardrobe (folder "posts").
- **`promotions/[id]/click`** — confirmed still unaddressed. Consumer-side
  promoted-product surfacing (showing promoted items distinctly in
  Discover/Shop and firing this click-tracking beacon) was never built in
  Steps 3-4, and wasn't added in this audit pass either — scoped out
  given everything else already found; noted here as a real remaining gap
  rather than silently left off the list.
- **`events`, `events/[id]/go-live`, `events/[id]/tickets`, `tickets`,
  `tickets/[id]/purchase`, `tickets/scan`** — confirmed real, working
  backend features (per the plan's own §1.3: "Events / Tickets:
  Confirmed real") that were never scheduled in the plan's own 11-step
  build order and were never built here either. This is the largest
  remaining gap in the project — an entire feature area with working
  backend support and zero frontend surface. Not built in this pass
  given the scope of everything else found; flagged as the top priority
  for whoever continues this project.

### Systemic gaps found by auditing patterns, not individual endpoints
- **Zero animations anywhere in the app.** No `react-native-reanimated`,
  no `Animated` API usage. Every transition is instant. Not fixed in this
  pass — retrofitting animation is a design decision as much as an
  engineering one, and doing it well needs more than a mechanical sweep.
- **Zero safe-area handling anywhere**, confirmed by grepping for
  `SafeAreaView`/`useSafeAreaInsets` across the whole app and finding
  nothing. On a device with a notch or gesture bar, content on any
  `headerShown: false` screen (most tab roots, modals, chat/upload flows)
  could render under the status bar. Added `react-native-safe-area-context`,
  wrapped the root layout in `SafeAreaProvider`, and applied real
  `useSafeAreaInsets` padding to the 5 tab roots (Home, Discover, Nexi,
  Shop, Profile) and the video player modal's close button — which had
  been using a hardcoded `top: 48` guess instead of a real inset. Not
  every screen in the app got this treatment (a full retrofit without a
  device to visually verify against risks introducing more bugs than it
  fixes) — the highest-traffic entry points did.
- **No global search, no 404 route, no offline-state detection** — all
  three are explicitly named in the plan's own "System" screens list
  (§3) and none existed. Added Expo Router's `+not-found.tsx` convention
  (trivial, high value). Global search and offline detection are real,
  larger gaps left for a future pass — a unified cross-entity search
  (products + creators + challenges + users) doesn't have an obvious
  single backend endpoint to build it against, and would need its own
  research pass rather than a guess bolted onto Discover's existing
  product-only search.
- **`feedPostSchema` was missing two real fields** (`styleCategories`,
  `viewCount`) present in the actual backend select — zod silently
  strips unknown response fields rather than erroring, so this was never
  a crash, just data the backend provides that the UI could never show.
  Confirmed and fixed while re-verifying the feed contract during this
  pass.

### Bugs caught and fixed during the audit itself, before they shipped
- **A genuine file-creation mistake**: a shell heredoc's bracket-escaping
  produced a file literally named `\[username\].tsx` (with backslashes in
  the filename) instead of `[username].tsx`. Caught by `tsc` failing to
  find the file it expected, not by inspection — a good example of why
  the validation step runs after every batch, not just at the end.
- **A real file-based-routing structural bug**: had both
  `app/challenge/[id].tsx` (a file) and `app/challenge/[id]/enter.tsx`
  (a directory of the same name) at the same level — an ambiguous
  pattern most file-based routers, Expo Router included, don't reliably
  support. Fixed by converting the leaf file to `[id]/index.tsx`,
  consistent with every other nested route in this project
  (`wardrobe/`, `dashboards/`, `tailor/`), and fixed the relative import
  depths that moving it one level deeper required.
- **A missing import**: `engagementApi` was used in Home's `FeedPostCard`
  but never imported — caught immediately by `tsc`.
- **A TS2698 spread-type error** in the new Comments screen, investigated
  rather than assumed: confirmed to be the same root cause as every other
  `unknown`-typed response in this project (no `node_modules` in this
  sandbox), just manifesting as a different error code because it's the
  first place an API response was spread directly instead of destructured.

### What a full audit did NOT find
Worth stating plainly: every screen already had proper loading and error
states (checked mechanically — grepped every data-fetching screen for
`ActivityIndicator` and `ApiErrorView`/`catch`, both present everywhere
except Profile's lightweight badge fetch, which correctly doesn't block
the screen on a spinner for a secondary enhancement). No empty `onPress`
handlers, no debug `console.log` leftovers, no missing `keyExtractor`s,
no unused imports found via mechanical sweep, no hardcoded secrets. The
gaps in this project were almost entirely about *scope* (entire feature
areas never built) rather than *carelessness* within the screens that
were built.
