import { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, ActivityIndicator, Image, Pressable, FlatList } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { storefrontApi } from '../../packages/api-client/src/endpoints/storefront';
import { socialApi } from '../../packages/api-client/src/endpoints/social';
import type { z } from 'zod';
import type { storefrontResponseSchema } from '../../packages/api-contracts/src/storefront';
import { ApiClientError } from '../../packages/api-client/src/client';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

type Storefront = z.infer<typeof storefrontResponseSchema>['storefront'];

/**
 * User profile — found missing in a full-app audit: no way to view
 * another user's profile or follow them anywhere in the app, despite
 * full backend support (social/graph.ts + creators/storefront.ts).
 *
 * CONFIRMED LIMITATION, not solved here because there's nothing to solve
 * it with: GET /api/creators/:handle returns 404 for any user without a
 * CreatorProfile — there is NO general "view any user's profile"
 * endpoint anywhere in the backend. For a non-creator, this screen falls
 * back to a minimal header (username only, from the route param) plus
 * the follow button and relationship state, which don't require the
 * storefront endpoint at all.
 */
export default function UserProfileScreen() {
  const { username } = useLocalSearchParams<{ username: string }>();
  const [storefront, setStorefront] = useState<Storefront | null>(null);
  const [isCreatorProfile, setIsCreatorProfile] = useState(true);
  const [relationship, setRelationship] = useState<{ isFollowing: boolean; isFollowedBy: boolean } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [followBusy, setFollowBusy] = useState(false);

  const load = useCallback(async () => {
    if (!username) return;
    setLoading(true);
    setError(null);
    try {
      const result = await storefrontApi.get(username);
      setStorefront(result.storefront);
      setIsCreatorProfile(true);
      // Relationship lookup needs a user id, which the storefront gives us.
      const rel = await socialApi.relationship(result.storefront.id).catch(() => null);
      setRelationship(rel);
    } catch (err) {
      if (err instanceof ApiClientError && err.apiError.status === 404) {
        // Not a creator — no storefront to show, but the screen still
        // renders a minimal header. No relationship lookup here since we
        // don't have a user id without the storefront response.
        setIsCreatorProfile(false);
        setStorefront(null);
      } else {
        setError(err);
      }
    } finally {
      setLoading(false);
    }
  }, [username]);

  useEffect(() => {
    load();
  }, [load]);

  const toggleFollow = async () => {
    if (!storefront || followBusy) return;
    setFollowBusy(true);
    const wasFollowing = relationship?.isFollowing ?? false;
    try {
      if (wasFollowing) {
        await socialApi.unfollow(storefront.id);
        setRelationship((r) => (r ? { ...r, isFollowing: false } : r));
      } else {
        await socialApi.follow(storefront.id);
        setRelationship((r) => (r ? { ...r, isFollowing: true } : { isFollowing: true, isFollowedBy: false }));
      }
    } catch {
      // leave state unchanged on failure
    } finally {
      setFollowBusy(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <Text style={{ color: colors.goldMuted }}>Couldn't load this profile.</Text>
      </View>
    );
  }

  if (!isCreatorProfile || !storefront) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, padding: 24 }}>
        <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl }}>@{username}</Text>
        <Text style={{ color: colors.goldMuted, marginTop: 8 }}>
          This is a consumer account — there's no public profile page to
          show beyond a username, since the backend only builds full
          storefronts for Creators.
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }}>
      {storefront.creatorProfile.bannerUrl && (
        <Image source={{ uri: storefront.creatorProfile.bannerUrl }} style={{ width: '100%', height: 120 }} />
      )}
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          {storefront.avatarUrl && <Image source={{ uri: storefront.avatarUrl }} style={{ width: 64, height: 64, borderRadius: 32 }} />}
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg }}>{storefront.displayName}</Text>
            <Text style={{ color: colors.goldMuted }}>@{storefront.username} · {storefront.creatorProfile.followerCount} followers</Text>
          </View>
        </View>

        {storefront.bio && <Text style={{ color: colors.cream, marginTop: 12 }}>{storefront.bio}</Text>}
        {storefront.creatorProfile.styleNiche && (
          <Text style={{ color: colors.gold, fontSize: 12, marginTop: 4 }}>{storefront.creatorProfile.styleNiche}</Text>
        )}

        <Pressable
          onPress={toggleFollow}
          disabled={followBusy || !relationship}
          style={{
            marginTop: 16, paddingVertical: 10, borderRadius: 8, alignItems: 'center',
            backgroundColor: relationship?.isFollowing ? 'transparent' : colors.gold,
            borderWidth: relationship?.isFollowing ? 1 : 0, borderColor: colors.gold,
          }}
        >
          <Text style={{ color: relationship?.isFollowing ? colors.gold : colors.black, fontWeight: '700' }}>
            {followBusy ? '…' : relationship?.isFollowing ? 'Following' : 'Follow'}
          </Text>
        </Pressable>

        {storefront.featuredProducts.length > 0 && (
          <View style={{ marginTop: 24 }}>
            <Text style={{ color: colors.cream, fontWeight: '600', marginBottom: 10 }}>Shop</Text>
            <FlatList
              horizontal
              showsHorizontalScrollIndicator={false}
              data={storefront.featuredProducts}
              keyExtractor={(p) => p.id}
              renderItem={({ item }) => (
                <Pressable onPress={() => router.push(`/product/${item.slug}`)} style={{ width: 100, marginRight: 10 }}>
                  {item.imageUrls[0] && <Image source={{ uri: item.imageUrls[0] }} style={{ width: 100, height: 100, borderRadius: 8 }} />}
                  <Text numberOfLines={1} style={{ color: colors.cream, fontSize: 12, marginTop: 4 }}>{item.name}</Text>
                  <Text style={{ color: colors.gold, fontSize: 12 }}>{formatMoney(item.priceAmount, item.priceCurrency)}</Text>
                </Pressable>
              )}
            />
          </View>
        )}

        {storefront.posts.length > 0 && (
          <View style={{ marginTop: 24 }}>
            <Text style={{ color: colors.cream, fontWeight: '600', marginBottom: 10 }}>Posts</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4 }}>
              {storefront.posts.map((post) => (
                <Image key={post.id} source={{ uri: post.mediaUrls[0] }} style={{ width: '32%', aspectRatio: 1, borderRadius: 4 }} />
              ))}
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
}
