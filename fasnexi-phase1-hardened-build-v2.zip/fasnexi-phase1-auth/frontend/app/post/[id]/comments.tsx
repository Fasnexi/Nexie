import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, TextInput, Pressable, KeyboardAvoidingView, Platform } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { engagementApi } from '../../../packages/api-client/src/endpoints/social';
import type { Comment } from '../../../packages/api-contracts/src/social';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { colors } from '../../../packages/ui/src/tokens/colors';

/**
 * Comments screen — found missing in a full-app audit: the Home feed
 * (Step 3) and Video feed (Step 10) both display commentCount on every
 * post but there was no way to actually view or add comments anywhere,
 * despite full backend support (social/engagement.ts). Confirmed
 * `createComment` returns the bare comment object, not wrapped — see
 * social.ts's contract notes.
 */
export default function CommentsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [comments, setComments] = useState<Comment[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const page = await engagementApi.comments(id, undefined, 30);
      setComments(page.comments);
      setCursor(page.nextCursor ?? undefined);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const loadMore = async () => {
    if (!id || !cursor) return;
    try {
      const page = await engagementApi.comments(id, cursor, 30);
      setComments((prev: Comment[]) => [...prev, ...page.comments]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    }
  };

  const send = async () => {
    if (!id || !draft.trim()) return;
    setSending(true);
    try {
      const comment = await engagementApi.addComment(id, draft.trim());
      setComments((prev: Comment[]) => [{ ...comment, isRemoved: false, likeCount: 0, replies: [] }, ...prev]);
      setDraft('');
    } catch {
      // leave the draft in place so the user can retry
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.black }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <FlatList
        data={comments}
        keyExtractor={(item: Comment) => item.id}
        onEndReached={loadMore}
        onEndReachedThreshold={0.4}
        ListEmptyComponent={
          <View style={{ padding: 32, alignItems: 'center' }}>
            <Text style={{ color: colors.goldMuted }}>No comments yet — be the first.</Text>
          </View>
        }
        renderItem={({ item }: { item: Comment }) => (
          <View style={{ padding: 14, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
            <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center', marginBottom: 4 }}>
              {item.user.avatarUrl && <Image source={{ uri: item.user.avatarUrl }} style={{ width: 24, height: 24, borderRadius: 12 }} />}
              <Text style={{ color: colors.cream, fontWeight: '600', fontSize: 13 }}>{item.user.displayName}</Text>
            </View>
            <Text style={{ color: item.isRemoved ? colors.goldMuted : colors.cream, fontStyle: item.isRemoved ? 'italic' : 'normal' }}>
              {item.isRemoved ? 'Comment removed' : item.body}
            </Text>
            {item.replies.length > 0 && (
              <View style={{ marginTop: 8, marginLeft: 16, gap: 8 }}>
                {item.replies.map((r) => (
                  <View key={r.id}>
                    <Text style={{ color: colors.cream, fontWeight: '600', fontSize: 12 }}>{r.user.displayName}</Text>
                    <Text style={{ color: colors.cream, fontSize: 13 }}>{r.body}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        )}
      />
      <View style={{ flexDirection: 'row', gap: 8, padding: 16 }}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          placeholder="Add a comment…"
          placeholderTextColor={colors.goldMuted}
          style={{ flex: 1, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 10, color: colors.cream }}
        />
        <Pressable
          onPress={send}
          disabled={sending || !draft.trim()}
          style={{ justifyContent: 'center', paddingHorizontal: 16, backgroundColor: colors.gold, borderRadius: 8, opacity: sending || !draft.trim() ? 0.5 : 1 }}
        >
          <Text style={{ color: colors.black, fontWeight: '700' }}>Post</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
