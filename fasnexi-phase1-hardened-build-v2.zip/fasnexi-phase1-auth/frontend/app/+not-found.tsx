import { View, Text, Pressable } from 'react-native';
import { router, Stack } from 'expo-router';
import { colors } from '../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../packages/ui/src/tokens/typography';

/**
 * Found missing in a full-app audit: Expo Router's own convention for
 * handling unmatched routes (`+not-found.tsx` at the app root) was never
 * created, meaning a broken deep link or mistyped URL would fall through
 * to Expo Router's unstyled default rather than something on-brand.
 */
export default function NotFoundScreen() {
  return (
    <>
      <Stack.Screen options={{ title: 'Not found' }} />
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <Text style={{ color: colors.gold, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'], marginBottom: 12 }}>
          Page not found
        </Text>
        <Text style={{ color: colors.goldMuted, textAlign: 'center', marginBottom: 20 }}>
          That link doesn't lead anywhere in FasNexi.
        </Text>
        <Pressable onPress={() => router.replace('/(tabs)/home')}>
          <Text style={{ color: colors.gold }}>Back to Home</Text>
        </Pressable>
      </View>
    </>
  );
}
