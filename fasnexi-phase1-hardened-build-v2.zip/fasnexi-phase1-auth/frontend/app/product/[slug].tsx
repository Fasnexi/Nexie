import { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, Image, Pressable, ActivityIndicator, Alert } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { productsApi } from '../../packages/api-client/src/endpoints/products';
import type { z } from 'zod';
import type { productDetailSchema } from '../../packages/api-contracts/src/products';
import { useCartStore, type CartState } from '../../lib/cart-store';
import { ApiErrorView } from '../../lib/ApiErrorBoundary';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

type ProductDetail = z.infer<typeof productDetailSchema>;

export default function ProductDetailScreen() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const addItem = useCartStore((s: CartState) => s.addItem);

  const load = useCallback(async () => {
    if (!slug) return;
    setLoading(true);
    setError(null);
    try {
      const { product: p } = await productsApi.detail(slug);
      setProduct(p);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [slug]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error || !product) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  const onAddToCart = () => {
    const result = addItem(
      {
        id: product.id, name: product.name, slug: product.slug,
        priceAmount: product.priceAmount, priceCurrency: product.priceCurrency,
        imageUrls: product.imageUrls, category: product.category,
        isInStock: product.isInStock, salesCount: product.salesCount,
        vendor: { id: product.vendor.id, businessName: product.vendor.businessName },
      },
      { size: selectedSize, color: selectedColor },
    );
    if (!result.ok) {
      Alert.alert('Different currency in cart', result.reason);
      return;
    }
    router.push('/cart');
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }}>
      {product.imageUrls[0] && (
        <Image source={{ uri: product.imageUrls[0] }} style={{ width: '100%', aspectRatio: 0.9 }} />
      )}
      <View style={{ padding: 16 }}>
        <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl }}>{product.name}</Text>
        <Text style={{ color: colors.gold, fontSize: fontSize.lg, marginTop: 4 }}>
          {formatMoney(product.priceAmount, product.priceCurrency)}
        </Text>
        <Text style={{ color: colors.goldMuted, marginTop: 2 }}>{product.vendor.businessName}</Text>

        {!product.isInStock && (
          <Text style={{ color: '#e0654f', marginTop: 8 }}>Out of stock</Text>
        )}

        {product.sizes.length > 0 && (
          <PickerRow label="Size" options={product.sizes} selected={selectedSize} onSelect={setSelectedSize} />
        )}
        {product.colors.length > 0 && (
          <PickerRow label="Color" options={product.colors} selected={selectedColor} onSelect={setSelectedColor} />
        )}

        {product.description && (
          <Text style={{ color: colors.cream, marginTop: 16, lineHeight: 20 }}>{product.description}</Text>
        )}

        {product.reviewStats.count > 0 && (
          <Text style={{ color: colors.goldMuted, marginTop: 12 }}>
            ★ {product.reviewStats.average.toFixed(1)} ({product.reviewStats.count} reviews)
          </Text>
        )}

        <Pressable
          onPress={onAddToCart}
          disabled={!product.isInStock}
          style={{
            marginTop: 24, backgroundColor: colors.gold, paddingVertical: 14,
            borderRadius: 8, alignItems: 'center', opacity: product.isInStock ? 1 : 0.4,
          }}
        >
          <Text style={{ color: colors.black, fontWeight: '700' }}>Add to cart</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function PickerRow({ label, options, selected, onSelect }: { label: string; options: string[]; selected?: string; onSelect: (v: string) => void }) {
  return (
    <View style={{ marginTop: 14 }}>
      <Text style={{ color: colors.cream, marginBottom: 6, fontWeight: '600' }}>{label}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {options.map((opt) => (
          <Pressable
            key={opt}
            onPress={() => onSelect(opt)}
            style={{
              paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16,
              borderWidth: 1, borderColor: selected === opt ? colors.gold : colors.goldMuted,
              backgroundColor: selected === opt ? 'rgba(200,164,93,0.12)' : 'transparent',
            }}
          >
            <Text style={{ color: selected === opt ? colors.gold : colors.cream, fontSize: 12 }}>{opt}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
