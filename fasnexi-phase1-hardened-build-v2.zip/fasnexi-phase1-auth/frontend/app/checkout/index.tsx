import { useState } from 'react';
import { View, Text, TextInput, ActivityIndicator, Linking, Platform } from 'react-native';
import { useCartStore, cartSubtotal, type CartState, type CartLine } from '../../lib/cart-store';
import { checkoutApi } from '../../packages/api-client/src/endpoints/checkout';
import { ApiClientError } from '../../packages/api-client/src/client';
import { GATEWAY_BY_CURRENCY } from '../../packages/api-contracts/src/common';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';
import { PrimaryButton } from '../../lib/onboarding/OnboardingLayout';

/**
 * Checkout (currency/gateway selection, per plan §3) — currency isn't a
 * free picker here: the cart already enforces a single currency per cart
 * (see cart-store.ts, working around the backend's unvalidated
 * priceCurrency-vs-checkout-currency gap), so "selection" is really
 * "confirm which gateway this checkout will use," shown for transparency.
 *
 * IMPORTANT — not fully solvable at this layer: `successUrl`/`cancelUrl`
 * sent to POST /api/checkout are built from an HTTP `origin` header
 * server-side, defaulting to https://fasnexi.com. That's a web redirect
 * target. Whether the gateway's hosted checkout page can hand control
 * back to this *native* app after payment depends on universal
 * links/app links being configured for that domain — infra outside this
 * frontend code slice, not something to fake working here.
 */
export default function CheckoutScreen() {
  const lines = useCartStore((s: CartState) => s.lines);
  const [couponCode, setCouponCode] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currency = lines[0]?.product.priceCurrency;
  const subtotal = cartSubtotal(lines);
  const gateway = currency ? GATEWAY_BY_CURRENCY[currency] : undefined;

  if (lines.length === 0 || !currency) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: colors.cream }}>Your cart is empty.</Text>
      </View>
    );
  }

  const submit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const { url } = await checkoutApi.createSession({
        items: lines.map((l: CartLine) => ({
          productId: l.product.id,
          quantity: l.quantity,
          size: l.size,
          color: l.color,
        })),
        currency,
        couponCode: couponCode || undefined,
      });
      // Keep the cart until the payment webhook confirms the order. This makes
      // cancelled/failed payments recoverable instead of silently emptying the cart.
      if (Platform.OS === 'web') {
        window.location.href = url;
      } else {
        await Linking.openURL(url);
      }
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : 'Could not start checkout. Please try again.';
      setError(message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, padding: 16 }}>
      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl, marginBottom: 16 }}>
        Checkout
      </Text>

      <Row label="Items" value={String(lines.reduce((n: number, l: CartLine) => n + l.quantity, 0))} />
      <Row label="Currency" value={currency} />
      <Row label="Payment via" value={gateway ? gateway[0].toUpperCase() + gateway.slice(1) : '—'} />
      <Row label="Subtotal" value={formatMoney(subtotal, currency)} bold />

      <TextInput
        value={couponCode}
        onChangeText={setCouponCode}
        placeholder="Coupon code (optional)"
        placeholderTextColor={colors.goldMuted}
        autoCapitalize="characters"
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, marginVertical: 16 }}
      />

      {error && <Text style={{ color: '#e0654f', marginBottom: 12 }}>{error}</Text>}

      {submitting ? (
        <ActivityIndicator color={colors.gold} />
      ) : (
        <PrimaryButton label={`Pay with ${gateway ?? 'gateway'}`} onPress={submit} />
      )}

      <Text style={{ color: colors.goldMuted, fontSize: 11, marginTop: 12 }}>
        You'll be redirected to a secure payment page to complete your order.
      </Text>
    </View>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
      <Text style={{ color: colors.goldMuted }}>{label}</Text>
      <Text style={{ color: colors.cream, fontWeight: bold ? '700' : '400' }}>{value}</Text>
    </View>
  );
}
