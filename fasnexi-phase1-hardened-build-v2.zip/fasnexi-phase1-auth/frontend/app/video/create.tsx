import { useState } from 'react';
import { View, Text, Image, Pressable, TextInput, ActivityIndicator, Platform, ScrollView } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { uploadToCloudinary } from '../../lib/cloudinary-upload';
import { videoApi } from '../../packages/api-client/src/endpoints/video';
import { MAX_VIDEO_DURATION_SECONDS } from '../../packages/api-contracts/src/video';
import { ApiClientError } from '../../packages/api-client/src/client';
import { colors } from '../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../lib/onboarding/OnboardingLayout';

/**
 * Video post creation. Duration comes from Cloudinary's own upload
 * response (`result.duration`), not a locally-measured value — more
 * reliable than trying to read local file metadata, and it's what the
 * backend actually validates against (MAX_VIDEO_DURATION_SECONDS = 180,
 * confirmed from video/service.ts).
 */
export default function CreateVideoScreen() {
  const [pickedUri, setPickedUri] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pickVideo = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Allow photo library access to pick a video.');
      return;
    }
    // Same caveat as every other Expo client API flagged in this
    // project (ImagePicker.MediaTypeOptions.Images in the wardrobe
    // upload screen, Constants.expoConfig in push-notifications.ts):
    // `MediaTypeOptions.Videos` and `videoMaxDuration` are used per
    // Expo's documented API, not independently confirmed against the
    // actually-installed package version — no network in this sandbox
    // to check. Confirm once `npm install` runs for real.
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      quality: 1,
      videoMaxDuration: MAX_VIDEO_DURATION_SECONDS,
    });
    if (!result.canceled && result.assets[0]) {
      setPickedUri(result.assets[0].uri);
      setError(null);
    }
  };

  const submit = async () => {
    if (!pickedUri) {
      setError('Pick a video first.');
      return;
    }
    if (Platform.OS === 'web') {
      setError('Web upload needs a blob-conversion step not yet implemented — see cloudinary-upload.ts / the wardrobe upload screen for the same gap.');
      return;
    }
    setUploading(true);
    setError(null);
    try {
      const fileName = pickedUri.split('/').pop() ?? 'video.mp4';
      const upload = await uploadToCloudinary('video', { uri: pickedUri, name: fileName, type: 'video/mp4' });

      if (!upload.durationSeconds) {
        throw new Error("Couldn't read the video's duration from the upload — try a different file.");
      }
      if (upload.durationSeconds > MAX_VIDEO_DURATION_SECONDS) {
        throw new Error(`This video is ${Math.round(upload.durationSeconds)}s — the limit is ${MAX_VIDEO_DURATION_SECONDS}s (3 minutes).`);
      }

      await videoApi.create({
        videoUrl: upload.secureUrl,
        thumbnailUrl: upload.thumbnailUrl,
        durationSeconds: upload.durationSeconds,
        caption: caption || undefined,
      });
      router.replace('/video');
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : err instanceof Error ? err.message : 'Upload failed.';
      setError(message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      <Pressable
        onPress={pickVideo}
        style={{
          aspectRatio: 0.7, borderRadius: 12, borderWidth: 1, borderColor: colors.goldMuted,
          alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 20,
        }}
      >
        {pickedUri ? (
          <Image source={{ uri: pickedUri }} style={{ width: '100%', height: '100%' }} />
        ) : (
          <Text style={{ color: colors.goldMuted }}>Tap to choose a video (max {MAX_VIDEO_DURATION_SECONDS / 60} min)</Text>
        )}
      </Pressable>

      <TextInput
        value={caption}
        onChangeText={setCaption}
        placeholder="Caption (optional)"
        placeholderTextColor={colors.goldMuted}
        multiline
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, minHeight: 70, marginBottom: 20 }}
      />

      {error && <Text style={{ color: '#e0654f', marginBottom: 12 }}>{error}</Text>}

      {uploading ? <ActivityIndicator color={colors.gold} /> : <PrimaryButton label="Post video" onPress={submit} />}
    </ScrollView>
  );
}
