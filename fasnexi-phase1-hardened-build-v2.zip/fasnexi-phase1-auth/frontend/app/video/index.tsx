import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, Pressable, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Video, ResizeMode } from 'expo-av';
import { router } from 'expo-router';
import { videoApi } from '../../packages/api-client/src/endpoints/video';
import { engagementApi } from '../../packages/api-client/src/endpoints/social';
import type { VideoFeedItem } from '../../packages/api-contracts/src/video';
import { ApiErrorView } from '../../lib/ApiErrorBoundary';
import { colors } from '../../packages/ui/src/tokens/colors';

const PAGE_LIMIT = 20;

/**
 * Dedicated video feed (plan §7 step 10 — "real feature, not gated on
 * anything"). Confirmed this EXCLUDES the current user's own videos
 * server-side (`userId: { not: userId }` in getVideoFeed) — not
 * something to "fix" here, just worth knowing before it looks broken.
 *
 * Playback design: rather than attempt scroll-driven multi-item autoplay
 * (fragile, hard to get right without a device to actually test on, and
 * easy to ship with edge-case bugs — items playing after being scrolled
 * off, audio overlap, etc.), this shows a thumbnail grid and opens one
 * video at a time in a full-screen modal player. Simpler and more
 * robust, at the cost of not being the TikTok-style continuous-scroll
 * experience the plan's tone implies — a scope trade-off, not an
 * oversight.
 *
 * Found and fixed in a full-app audit: this player had no like/comment
 * access at all despite video posts sharing the same Post model and the
 * same working engagement API as the Home feed — and the modal's close
 * button used a hardcoded `top: 48` guess instead of the device's real
 * safe-area inset.
 */
export default function VideoFeedScreen() {
  const insets = useSafeAreaInsets();
  const [videos, setVideos] = useState<VideoFeedItem[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [playing, setPlaying] = useState<VideoFeedItem | null>(null);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [likeBusy, setLikeBusy] = useState(false);

  const loadInitial = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const page = await videoApi.feed({ limit: PAGE_LIMIT });
      setVideos(page.videos);
      setCursor(page.nextCursor ?? undefined);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInitial();
  }, [loadInitial]);

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await videoApi.feed({ cursor, limit: PAGE_LIMIT });
      setVideos((prev: VideoFeedItem[]) => [...prev, ...page.videos]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore]);

  const openVideo = (item: VideoFeedItem) => {
    setPlaying(item);
    setLiked(false); // /api/video has no likedByMe field either — same as feed, see feed.ts's contract notes
    setLikeCount(item.likeCount);
  };

  const toggleLike = async () => {
    if (!playing || likeBusy) return;
    setLikeBusy(true);
    const prevLiked = liked;
    const prevCount = likeCount;
    setLiked(!prevLiked);
    setLikeCount(prevLiked ? prevCount - 1 : prevCount + 1);
    try {
      const result = await engagementApi.toggleLike(playing.id);
      setLiked(result.liked);
      setLikeCount(result.likeCount);
    } catch {
      setLiked(prevLiked);
      setLikeCount(prevCount);
    } finally {
      setLikeBusy(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={loadInitial} />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, paddingTop: insets.top }}>
      <Pressable onPress={() => router.push('/video/create')} style={{ padding: 14, alignItems: 'flex-end' }}>
        <Text style={{ color: colors.gold, fontWeight: '700' }}>+ Post a video</Text>
      </Pressable>

      <FlatList
        data={videos}
        keyExtractor={(item: VideoFeedItem) => item.id}
        numColumns={3}
        columnWrapperStyle={{ gap: 4, paddingHorizontal: 8 }}
        onEndReached={loadMore}
        onEndReachedThreshold={0.5}
        ListEmptyComponent={
          <View style={{ padding: 32, alignItems: 'center' }}>
            <Text style={{ color: colors.goldMuted }}>No videos yet.</Text>
          </View>
        }
        ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
        renderItem={({ item }: { item: VideoFeedItem }) => (
          <Pressable onPress={() => openVideo(item)} style={{ flex: 1 / 3, aspectRatio: 0.65, marginBottom: 4 }}>
            <Image source={{ uri: item.thumbnailUrl }} style={{ width: '100%', height: '100%', borderRadius: 4 }} />
            {item.videoDuration !== null && (
              <Text style={{ position: 'absolute', bottom: 4, right: 4, color: colors.cream, fontSize: 10, backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 4, borderRadius: 3 }}>
                {Math.floor(item.videoDuration / 60)}:{String(Math.round(item.videoDuration % 60)).padStart(2, '0')}
              </Text>
            )}
          </Pressable>
        )}
      />

      <Modal visible={playing !== null} animationType="fade" onRequestClose={() => setPlaying(null)}>
        <View style={{ flex: 1, backgroundColor: colors.black }}>
          {playing && (
            <>
              <Video
                source={{ uri: playing.videoUrl }}
                style={{ flex: 1 }}
                resizeMode={ResizeMode.CONTAIN}
                useNativeControls
                shouldPlay
              />
              <Pressable onPress={() => setPlaying(null)} style={{ position: 'absolute', top: insets.top + 8, left: 16, padding: 8 }}>
                <Text style={{ color: colors.cream, fontSize: 16 }}>✕</Text>
              </Pressable>
              <View style={{ position: 'absolute', bottom: 24, left: 16, right: 16 }}>
                <Text style={{ color: colors.cream, fontWeight: '600' }}>{playing.user.displayName}</Text>
                {playing.caption && <Text style={{ color: colors.cream, marginTop: 4 }}>{playing.caption}</Text>}
                <View style={{ flexDirection: 'row', gap: 20, marginTop: 8 }}>
                  <Pressable onPress={toggleLike} disabled={likeBusy}>
                    <Text style={{ color: liked ? colors.gold : colors.cream }}>{liked ? '♥' : '♡'} {likeCount}</Text>
                  </Pressable>
                  <Pressable onPress={() => router.push(`/post/${playing.id}/comments`)}>
                    <Text style={{ color: colors.cream }}>💬 {playing.commentCount}</Text>
                  </Pressable>
                </View>
              </View>
            </>
          )}
        </View>
      </Modal>
    </View>
  );
}
