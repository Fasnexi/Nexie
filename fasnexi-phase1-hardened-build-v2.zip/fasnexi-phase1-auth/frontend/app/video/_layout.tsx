import { Stack } from 'expo-router';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function VideoLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Video' }} />
      <Stack.Screen name="create" options={{ title: 'Post a video' }} />
    </Stack>
  );
}
