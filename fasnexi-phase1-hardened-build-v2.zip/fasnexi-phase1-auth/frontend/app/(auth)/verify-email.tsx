import { useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import { authClient } from '../../lib/auth-client';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

export default function VerifyEmailScreen() {
  const { data: session } = authClient.useSession();
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const resend = async () => {
    if (!session?.user.email) return;
    setError('');
    setSubmitting(true);
    const result = await authClient.sendVerificationEmail({ email: session.user.email });
    setSubmitting(false);
    if (result.error) return setError(result.error.message ?? 'Unable to resend verification email.');
    setSent(true);
  };

  return (
    <View style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.brand}>FASNEXI</Text>
        <Text style={styles.title}>Check your email.</Text>
        <Text style={styles.subtitle}>We need to verify {session?.user.email ?? 'your email'} before you continue.</Text>
        {!!error && <Text style={styles.error}>{error}</Text>}
        {sent && <Text style={styles.success}>Verification email sent.</Text>}
        <Pressable style={styles.primary} onPress={resend} disabled={submitting}>
          {submitting ? <ActivityIndicator color={colors.black} /> : <Text style={styles.primaryText}>Resend email</Text>}
        </Pressable>
        <Pressable onPress={() => authClient.signOut().then(() => router.replace('/(auth)/login'))}><Text style={styles.link}>Use another account</Text></Pressable>
      </View>
    </View>
  );
}

const styles = {
  screen: { flex: 1, backgroundColor: colors.black, padding: 24 },
  content: { flex: 1, justifyContent: 'center', gap: 18 },
  brand: { color: colors.gold, fontFamily: fontFamily.headingBold, fontSize: 14, letterSpacing: 3 },
  title: { color: colors.cream, fontFamily: fontFamily.headingBold, fontSize: fontSize['3xl'] },
  subtitle: { color: colors.goldMuted, fontSize: fontSize.base, lineHeight: 22 },
  primary: { minHeight: 52, borderRadius: 12, backgroundColor: colors.gold, alignItems: 'center', justifyContent: 'center' },
  primaryText: { color: colors.black, fontFamily: fontFamily.headingBold, fontSize: 16 },
  link: { color: colors.gold, textAlign: 'center', fontSize: 14 },
  error: { color: '#F28B82', fontSize: 13 },
  success: { color: '#8FD694', fontSize: 13 },
};
