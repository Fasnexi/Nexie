import { useState } from 'react';
import { ActivityIndicator, Pressable, Text, TextInput, View } from 'react-native';
import { Link, router } from 'expo-router';
import { authClient } from '../../lib/auth-client';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    setError('');
    if (!email.trim() || !password) return setError('Enter your email and password.');
    setSubmitting(true);
    const result = await authClient.signIn.email({ email: email.trim().toLowerCase(), password });
    setSubmitting(false);
    if (result.error) return setError(result.error.message ?? 'Unable to sign in.');
    const user = result.data?.user as (typeof result.data.user & { onboardingDone?: boolean }) | undefined;
    router.replace(user?.onboardingDone ? '/(tabs)/home' : '/(auth)/onboarding/welcome');
  };

  return (
    <View style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.brand}>FASNEXI</Text>
        <Text style={styles.title}>Welcome back.</Text>
        <Text style={styles.subtitle}>Sign in to your style world.</Text>

        <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />

        {!!error && <Text style={styles.error}>{error}</Text>}

        <Pressable style={styles.primary} onPress={submit} disabled={submitting}>
          {submitting ? <ActivityIndicator color={colors.black} /> : <Text style={styles.primaryText}>Sign in</Text>}
        </Pressable>

        <Link href="/(auth)/forgot-password" style={styles.link}>Forgot password?</Link>

        <View style={styles.footer}>
          <Text style={styles.muted}>New to FasNexi?</Text>
          <Link href="/(auth)/signup" style={styles.link}> Create account</Link>
        </View>
      </View>
    </View>
  );
}

function Field(props: React.ComponentProps<typeof TextInput> & { label: string }) {
  const { label, ...inputProps } = props;
  return (
    <View style={{ gap: 7 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput {...inputProps} placeholderTextColor={colors.goldMuted} style={styles.input} />
    </View>
  );
}

const styles = {
  screen: { flex: 1, backgroundColor: colors.black, padding: 24 },
  content: { flex: 1, justifyContent: 'center', gap: 18 },
  brand: { color: colors.gold, fontFamily: fontFamily.headingBold, fontSize: 14, letterSpacing: 3 },
  title: { color: colors.cream, fontFamily: fontFamily.headingBold, fontSize: fontSize['4xl'], marginTop: 8 },
  subtitle: { color: colors.goldMuted, fontSize: fontSize.base, marginBottom: 18 },
  label: { color: colors.cream, fontSize: 13 },
  input: { backgroundColor: '#151515', borderWidth: 1, borderColor: '#292929', borderRadius: 12, color: colors.cream, paddingHorizontal: 15, paddingVertical: 14 },
  primary: { minHeight: 52, borderRadius: 12, backgroundColor: colors.gold, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  primaryText: { color: colors.black, fontFamily: fontFamily.headingBold, fontSize: 16 },
  link: { color: colors.gold, textAlign: 'center', fontSize: 14 },
  error: { color: '#F28B82', fontSize: 13 },
  muted: { color: colors.goldMuted, fontSize: 14 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 10 },
};
