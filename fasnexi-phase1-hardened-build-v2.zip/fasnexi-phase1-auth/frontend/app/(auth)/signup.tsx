import { useState } from 'react';
import { ActivityIndicator, Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { authClient } from '../../lib/auth-client';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

export default function SignupScreen() {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    setError('');
    if (!name.trim() || !username.trim() || !email.trim() || password.length < 10) {
      return setError('Enter your name, username, email and a password of at least 10 characters.');
    }
    setSubmitting(true);
    const result = await authClient.signUp.email({
      name: name.trim(),
      username: username.trim().toLowerCase(),
      email: email.trim().toLowerCase(),
      password,
    });
    setSubmitting(false);
    if (result.error) return setError(result.error.message ?? 'Unable to create your account.');
    const user = result.data?.user as (typeof result.data.user & { emailVerified?: boolean }) | undefined;
    router.replace(user?.emailVerified ? '/(auth)/onboarding/welcome' : '/(auth)/verify-email');
  };

  return (
    <View style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.brand}>FASNEXI</Text>
        <Text style={styles.title}>Create your account.</Text>
        <Text style={styles.subtitle}>Your personal style journey starts here.</Text>
        <Field label="Name" value={name} onChangeText={setName} autoCapitalize="words" />
        <Field label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" />
        <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        {!!error && <Text style={styles.error}>{error}</Text>}
        <Pressable style={styles.primary} onPress={submit} disabled={submitting}>
          {submitting ? <ActivityIndicator color={colors.black} /> : <Text style={styles.primaryText}>Create account</Text>}
        </Pressable>
        <Pressable onPress={() => router.back()}><Text style={styles.link}>Already have an account? Sign in</Text></Pressable>
      </View>
    </View>
  );
}

function Field(props: React.ComponentProps<typeof TextInput> & { label: string }) {
  const { label, ...inputProps } = props;
  return <View style={{ gap: 7 }}><Text style={styles.label}>{label}</Text><TextInput {...inputProps} placeholderTextColor={colors.goldMuted} style={styles.input} /></View>;
}

const styles = {
  screen: { flex: 1, backgroundColor: colors.black, padding: 24 },
  content: { flex: 1, justifyContent: 'center', gap: 14 },
  brand: { color: colors.gold, fontFamily: fontFamily.headingBold, fontSize: 14, letterSpacing: 3 },
  title: { color: colors.cream, fontFamily: fontFamily.headingBold, fontSize: fontSize['3xl'], marginTop: 8 },
  subtitle: { color: colors.goldMuted, fontSize: fontSize.base, marginBottom: 12 },
  label: { color: colors.cream, fontSize: 13 },
  input: { backgroundColor: '#151515', borderWidth: 1, borderColor: '#292929', borderRadius: 12, color: colors.cream, paddingHorizontal: 15, paddingVertical: 13 },
  primary: { minHeight: 52, borderRadius: 12, backgroundColor: colors.gold, alignItems: 'center', justifyContent: 'center', marginTop: 5 },
  primaryText: { color: colors.black, fontFamily: fontFamily.headingBold, fontSize: 16 },
  link: { color: colors.gold, textAlign: 'center', fontSize: 14, marginTop: 8 },
  error: { color: '#F28B82', fontSize: 13 },
};
