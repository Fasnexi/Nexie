import { useState } from 'react';
import { ActivityIndicator, Pressable, Text, TextInput, View } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { authClient } from '../../lib/auth-client';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

export default function ResetPasswordScreen() {
  const { token } = useLocalSearchParams<{ token?: string }>();
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    setError('');
    if (!token) return setError('This reset link is missing or invalid.');
    if (password.length < 10) return setError('Use at least 10 characters.');
    if (password !== confirmation) return setError('Passwords do not match.');
    setSubmitting(true);
    const result = await authClient.resetPassword({ newPassword: password, token });
    setSubmitting(false);
    if (result.error) return setError(result.error.message ?? 'Unable to reset your password.');
    setDone(true);
  };

  return (
    <View style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.brand}>FASNEXI</Text>
        <Text style={styles.title}>{done ? 'Password updated.' : 'Choose a new password.'}</Text>
        <Text style={styles.subtitle}>{done ? 'Your password has been changed. You can sign in now.' : 'Use a strong password with at least 10 characters.'}</Text>
        {!done && <>
          <TextInput value={password} onChangeText={setPassword} secureTextEntry placeholder="New password" placeholderTextColor={colors.goldMuted} style={styles.input} />
          <TextInput value={confirmation} onChangeText={setConfirmation} secureTextEntry placeholder="Confirm password" placeholderTextColor={colors.goldMuted} style={styles.input} />
          {!!error && <Text style={styles.error}>{error}</Text>}
          <Pressable style={styles.primary} onPress={submit} disabled={submitting}>
            {submitting ? <ActivityIndicator color={colors.black} /> : <Text style={styles.primaryText}>Update password</Text>}
          </Pressable>
        </>}
        {done && <Pressable style={styles.primary} onPress={() => router.replace('/(auth)/login')}><Text style={styles.primaryText}>Sign in</Text></Pressable>}
      </View>
    </View>
  );
}

const styles = {
  screen: { flex: 1, backgroundColor: colors.black, padding: 24 },
  content: { flex: 1, justifyContent: 'center', gap: 16 },
  brand: { color: colors.gold, fontFamily: fontFamily.headingBold, fontSize: 14, letterSpacing: 3 },
  title: { color: colors.cream, fontFamily: fontFamily.headingBold, fontSize: fontSize['3xl'] },
  subtitle: { color: colors.goldMuted, fontSize: fontSize.base, lineHeight: 22 },
  input: { backgroundColor: '#151515', borderWidth: 1, borderColor: '#292929', borderRadius: 12, color: colors.cream, paddingHorizontal: 15, paddingVertical: 14 },
  primary: { minHeight: 52, borderRadius: 12, backgroundColor: colors.gold, alignItems: 'center', justifyContent: 'center' },
  primaryText: { color: colors.black, fontFamily: fontFamily.headingBold, fontSize: 16 },
  error: { color: '#F28B82', fontSize: 13 },
};
