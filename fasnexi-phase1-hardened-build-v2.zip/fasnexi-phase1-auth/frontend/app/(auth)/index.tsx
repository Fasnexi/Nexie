import { ActivityIndicator, View } from 'react-native';
import { Redirect } from 'expo-router';
import { authClient } from '../../lib/auth-client';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function AuthIndex() {
  const { data: session, isPending } = authClient.useSession();
  const user = session?.user as typeof session.user & { onboardingDone?: boolean };

  if (isPending) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.black }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (!session) return <Redirect href="/(auth)/login" />;

  return <Redirect href={user.onboardingDone ? '/(tabs)/home' : '/(auth)/onboarding/welcome'} />;
}
