import { useState } from 'react';
import { ActivityIndicator, Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { authClient } from '../../lib/auth-client';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const submit = async () => {
    setError('');
    if (!email.trim()) return setError('Enter your email address.');
    setSubmitting(true);
    const result = await authClient.requestPasswordReset({
      email: email.trim().toLowerCase(),
      redirectTo: 'fasnexi://reset-password',
    });
    setSubmitting(false);
    if (result.error) return setError(result.error.message ?? 'Unable to send the reset email.');
    setSent(true);
  };

  return (
    <View style={styles.screen}>
      <View style={styles.content}>
        <Text style={styles.brand}>FASNEXI</Text>
        <Text style={styles.title}>Reset your password.</Text>
        <Text style={styles.subtitle}>{sent ? 'If an account exists for that email, we sent reset instructions.' : 'Enter your email and we’ll send you a secure reset link.'}</Text>
        {!sent && <TextInput value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" placeholder="you@example.com" placeholderTextColor={colors.goldMuted} style={styles.input} />}
        {!!error && <Text style={styles.error}>{error}</Text>}
        {!sent ? (
          <Pressable style={styles.primary} onPress={submit} disabled={submitting}>
            {submitting ? <ActivityIndicator color={colors.black} /> : <Text style={styles.primaryText}>Send reset link</Text>}
          </Pressable>
        ) : null}
        <Pressable onPress={() => router.replace('/(auth)/login')}><Text style={styles.link}>Back to sign in</Text></Pressable>
      </View>
    </View>
  );
}

const styles = {
  screen: { flex: 1, backgroundColor: colors.black, padding: 24 },
  content: { flex: 1, justifyContent: 'center', gap: 18 },
  brand: { color: colors.gold, fontFamily: fontFamily.headingBold, fontSize: 14, letterSpacing: 3 },
  title: { color: colors.cream, fontFamily: fontFamily.headingBold, fontSize: fontSize['3xl'], marginTop: 8 },
  subtitle: { color: colors.goldMuted, fontSize: fontSize.base, lineHeight: 22 },
  input: { backgroundColor: '#151515', borderWidth: 1, borderColor: '#292929', borderRadius: 12, color: colors.cream, paddingHorizontal: 15, paddingVertical: 14 },
  primary: { minHeight: 52, borderRadius: 12, backgroundColor: colors.gold, alignItems: 'center', justifyContent: 'center' },
  primaryText: { color: colors.black, fontFamily: fontFamily.headingBold, fontSize: 16 },
  link: { color: colors.gold, textAlign: 'center', fontSize: 14 },
  error: { color: '#F28B82', fontSize: 13 },
};
