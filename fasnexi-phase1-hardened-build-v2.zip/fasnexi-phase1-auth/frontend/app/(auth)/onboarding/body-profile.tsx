import { useState } from 'react';
import { View, Text, Pressable, TextInput } from 'react-native';
import { router } from 'expo-router';
import { OnboardingLayout, PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';
import { useOnboardingStore, type OnboardingState } from '../../../lib/onboarding-store';
import { colors } from '../../../packages/ui/src/tokens/colors';

/** Exact values from BodyShape / FitPreference / CoveragePreference enums, schema.prisma */
const BODY_SHAPES = ['HOURGLASS', 'PEAR', 'APPLE', 'RECTANGLE', 'INVERTED_TRIANGLE'] as const;
const FIT_PREFS = ['FITTED', 'RELAXED', 'OVERSIZED', 'TAILORED', 'FLOWY'] as const;
const COVERAGE_PREFS = ['MINIMAL', 'MODERATE', 'FULL', 'FLEXIBLE'] as const;

function label(value: string) {
  return value.charAt(0) + value.slice(1).toLowerCase().replace(/_/g, ' ');
}

function Chip({ text, selected, onPress }: { text: string; selected: boolean; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        paddingVertical: 8,
        paddingHorizontal: 14,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: selected ? colors.gold : colors.goldMuted,
        backgroundColor: selected ? 'rgba(200,164,93,0.12)' : 'transparent',
      }}
    >
      <Text style={{ color: selected ? colors.gold : colors.cream, fontSize: 13 }}>{text}</Text>
    </Pressable>
  );
}

function toggle(list: string[], value: string): string[] {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

export default function BodyProfileScreen() {
  const setBodyProfile = useOnboardingStore((s: OnboardingState) => s.setBodyProfile);
  const [bodyShape, setBodyShape] = useState<string | undefined>(undefined);
  const [fitPreferences, setFitPreferences] = useState<string[]>([]);
  const [coveragePreferences, setCoveragePreferences] = useState<string[]>([]);
  const [sizeTopUS, setSizeTopUS] = useState('');
  const [sizeBottomUS, setSizeBottomUS] = useState('');
  const [sizeShoeUS, setSizeShoeUS] = useState('');

  return (
    <OnboardingLayout
      stepIndex={2}
      title="Body & fit"
      subtitle="All optional — skip anything you're not sure about."
      onBack={() => router.back()}
    >
      <View style={{ gap: 20, flex: 1 }}>
        <View>
          <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Body shape</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {BODY_SHAPES.map((v) => (
              <Chip key={v} text={label(v)} selected={bodyShape === v} onPress={() => setBodyShape(bodyShape === v ? undefined : v)} />
            ))}
          </View>
        </View>

        <View>
          <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Fit preference</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {FIT_PREFS.map((v) => (
              <Chip key={v} text={label(v)} selected={fitPreferences.includes(v)} onPress={() => setFitPreferences(toggle(fitPreferences, v))} />
            ))}
          </View>
        </View>

        <View>
          <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Coverage preference</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {COVERAGE_PREFS.map((v) => (
              <Chip key={v} text={label(v)} selected={coveragePreferences.includes(v)} onPress={() => setCoveragePreferences(toggle(coveragePreferences, v))} />
            ))}
          </View>
        </View>

        <View style={{ flexDirection: 'row', gap: 10 }}>
          <SizeInput placeholder="Top (US)" value={sizeTopUS} onChangeText={setSizeTopUS} />
          <SizeInput placeholder="Bottom (US)" value={sizeBottomUS} onChangeText={setSizeBottomUS} />
          <SizeInput placeholder="Shoe (US)" value={sizeShoeUS} onChangeText={setSizeShoeUS} />
        </View>
      </View>

      <PrimaryButton
        label="Continue"
        onPress={() => {
          setBodyProfile({
            bodyShape,
            fitPreferences,
            coveragePreferences,
            sizeTopUS: sizeTopUS || undefined,
            sizeBottomUS: sizeBottomUS || undefined,
            sizeShoeUS: sizeShoeUS || undefined,
          });
          router.push('/onboarding/lifestyle');
        }}
      />
    </OnboardingLayout>
  );
}

function SizeInput({ placeholder, value, onChangeText }: { placeholder: string; value: string; onChangeText: (v: string) => void }) {
  return (
    <TextInput
      placeholder={placeholder}
      placeholderTextColor={colors.goldMuted}
      value={value}
      onChangeText={onChangeText}
      style={{ flex: 1, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 6, padding: 10, color: colors.cream }}
    />
  );
}
