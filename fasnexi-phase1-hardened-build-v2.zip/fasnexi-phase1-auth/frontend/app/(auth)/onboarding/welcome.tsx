import { View, Text } from 'react-native';
import { router } from 'expo-router';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';
import { PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';
import { useOnboardingStore, type OnboardingState } from '../../../lib/onboarding-store';

export default function WelcomeScreen() {
  const goToStep = useOnboardingStore((s: OnboardingState) => s.goToStep);

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, padding: 20, justifyContent: 'space-between' }}>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <Text style={{ color: colors.cream, fontFamily: fontFamily.headingBold, fontSize: fontSize['4xl'] }}>
          Let's find your Style DNA
        </Text>
        <Text style={{ color: colors.goldMuted, marginTop: 12, fontSize: fontSize.base }}>
          A few quick questions — archetype, fit, and lifestyle — so Nexi and
          your feed feel tailored to you from day one. Takes about 2 minutes.
        </Text>
      </View>
      <PrimaryButton
        label="Get started"
        onPress={() => {
          goToStep('archetype');
          router.push('/onboarding/archetype');
        }}
      />
    </View>
  );
}
