import { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { OnboardingLayout, PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';
import { useOnboardingStore, type OnboardingState } from '../../../lib/onboarding-store';
import { colors } from '../../../packages/ui/src/tokens/colors';

/** Exact values from Occasion / ClimateZone / ActivityLevel enums, schema.prisma */
const OCCASIONS = ['WORK', 'CASUAL', 'SOCIAL', 'RELIGIOUS', 'CULTURAL_EVENT', 'WEDDING'] as const;
const CLIMATE_ZONES = ['TROPICAL', 'SEMI_ARID', 'ARID', 'HUMID', 'TEMPERATE'] as const;
const ACTIVITY_LEVELS = ['LOW', 'MODERATE', 'HIGH'] as const;

function label(value: string) {
  return value.charAt(0) + value.slice(1).toLowerCase().replace(/_/g, ' ');
}

function Chip({ text, selected, onPress }: { text: string; selected: boolean; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        paddingVertical: 8,
        paddingHorizontal: 14,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: selected ? colors.gold : colors.goldMuted,
        backgroundColor: selected ? 'rgba(200,164,93,0.12)' : 'transparent',
      }}
    >
      <Text style={{ color: selected ? colors.gold : colors.cream, fontSize: 13 }}>{text}</Text>
    </Pressable>
  );
}

function toggle(list: string[], value: string): string[] {
  return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
}

export default function LifestyleScreen() {
  const setLifestyle = useOnboardingStore((s: OnboardingState) => s.setLifestyle);
  const [primaryOccasions, setPrimaryOccasions] = useState<string[]>([]);
  const [climateZone, setClimateZone] = useState<string | undefined>(undefined);
  const [activityLevel, setActivityLevel] = useState<string | undefined>(undefined);

  return (
    <OnboardingLayout
      stepIndex={3}
      title="Lifestyle"
      subtitle="Helps Nexi weight recommendations to how you actually live."
      onBack={() => router.back()}
    >
      <View style={{ gap: 20, flex: 1 }}>
        <View>
          <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Where do you dress for most?</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {OCCASIONS.map((v) => (
              <Chip key={v} text={label(v)} selected={primaryOccasions.includes(v)} onPress={() => setPrimaryOccasions(toggle(primaryOccasions, v))} />
            ))}
          </View>
        </View>

        <View>
          <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Climate</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {CLIMATE_ZONES.map((v) => (
              <Chip key={v} text={label(v)} selected={climateZone === v} onPress={() => setClimateZone(climateZone === v ? undefined : v)} />
            ))}
          </View>
        </View>

        <View>
          <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Activity level</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {ACTIVITY_LEVELS.map((v) => (
              <Chip key={v} text={label(v)} selected={activityLevel === v} onPress={() => setActivityLevel(activityLevel === v ? undefined : v)} />
            ))}
          </View>
        </View>
      </View>

      <PrimaryButton
        label="Continue"
        onPress={() => {
          setLifestyle({
            primaryOccasions,
            climateZone,
            activityLevel,
            preferredColors: [],
            avoidedColors: [],
          });
          router.push('/onboarding/wardrobe-snapshot');
        }}
      />
    </OnboardingLayout>
  );
}
