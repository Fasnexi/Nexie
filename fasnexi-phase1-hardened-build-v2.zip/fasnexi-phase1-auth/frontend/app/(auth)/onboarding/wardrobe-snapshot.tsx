import { View, Text } from 'react-native';
import { router } from 'expo-router';
import { OnboardingLayout, PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';
import { useOnboardingStore, type OnboardingState } from '../../../lib/onboarding-store';
import { colors } from '../../../packages/ui/src/tokens/colors';

/**
 * Must not block on an optional action, per the plan's stated UX
 * requirement (driven by the >70% completion goal). The real upload flow
 * (Cloudinary, signed via POST /api/uploads/sign — §1.5a) is a later
 * build step (§7 step 5); this screen only records skip/defer for now.
 */
export default function WardrobeSnapshotScreen() {
  const setWardrobeSnapshot = useOnboardingStore((s: OnboardingState) => s.setWardrobeSnapshot);

  const proceed = (skipped: boolean) => {
    setWardrobeSnapshot({ skipped, uploadedItemIds: [] });
    router.push('/onboarding/preview');
  };

  return (
    <OnboardingLayout
      stepIndex={4}
      title="Snap a few pieces you own"
      subtitle="Optional — Nexi uses this for 'you already own X' suggestions. Add more anytime from your Wardrobe tab."
      onBack={() => router.back()}
    >
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: colors.goldMuted, textAlign: 'center' }}>
          Wardrobe upload isn't wired up yet in this build — that lands in a
          later step. Skipping is the only option right now.
        </Text>
      </View>

      <PrimaryButton label="Skip for now — I'll add items later" onPress={() => proceed(true)} />
    </OnboardingLayout>
  );
}
