import { Stack } from 'expo-router';
import { colors } from '../../../packages/ui/src/tokens/colors';

export default function OnboardingLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: colors.black },
      }}
    />
  );
}
