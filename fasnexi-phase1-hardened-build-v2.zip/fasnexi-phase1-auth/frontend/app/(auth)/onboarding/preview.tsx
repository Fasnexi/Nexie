import { useState } from 'react';
import { Alert } from 'react-native';
import { View, Text, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { OnboardingLayout, PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';
import { useOnboardingStore, type OnboardingState } from '../../../lib/onboarding-store';
import { useShallow } from 'zustand/react/shallow';
import { submitStyleDnaAnswers } from '../../../packages/api-client/src/endpoints/onboarding';
import { colors } from '../../../packages/ui/src/tokens/colors';

function label(value?: string) {
  if (!value) return '—';
  return value.charAt(0) + value.slice(1).toLowerCase().replace(/_/g, ' ');
}

export default function PreviewScreen() {
  const { archetype, bodyProfile, lifestyle, wardrobeSnapshot, reset } = useOnboardingStore(
    useShallow((s: OnboardingState) => ({
      archetype: s.archetype,
      bodyProfile: s.bodyProfile,
      lifestyle: s.lifestyle,
      wardrobeSnapshot: s.wardrobeSnapshot,
      reset: s.reset,
    })),
  );
  const [submitting, setSubmitting] = useState(false);

  const finish = async () => {
    setSubmitting(true);
    try {
      await submitStyleDnaAnswers({ archetype, bodyProfile, lifestyle, wardrobeSnapshot });
      reset();
      router.replace('/(tabs)/home');
    } catch (error) {
      Alert.alert('Could not save your Style DNA', error instanceof Error ? error.message : 'Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <OnboardingLayout stepIndex={5} title="Here's your Style DNA" onBack={() => router.back()}>
      <View style={{ gap: 14, flex: 1 }}>
        <SummaryRow label="Primary style" value={label(archetype?.primaryArchetype)} />
        <SummaryRow label="Body shape" value={label(bodyProfile?.bodyShape)} />
        <SummaryRow label="Fit preference" value={(bodyProfile?.fitPreferences ?? []).map(label).join(', ') || '—'} />
        <SummaryRow label="Occasions" value={(lifestyle?.primaryOccasions ?? []).map(label).join(', ') || '—'} />
        <SummaryRow label="Climate" value={label(lifestyle?.climateZone)} />
        <SummaryRow label="Wardrobe items added" value={wardrobeSnapshot?.skipped ? 'Skipped — add later' : String(wardrobeSnapshot?.uploadedItemIds.length ?? 0)} />

        <Text style={{ color: colors.goldMuted, fontSize: 12, marginTop: 8 }}>
          Your Style DNA will be saved securely to your FasNexi account so
          Gap Analysis and NEXI can personalize your experience.
        </Text>
      </View>

      {submitting ? (
        <ActivityIndicator color={colors.gold} />
      ) : (
        <PrimaryButton label="Enter FasNexi" onPress={finish} />
      )}
    </OnboardingLayout>
  );
}

function SummaryRow({ label: l, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: colors.goldMuted, paddingBottom: 8 }}>
      <Text style={{ color: colors.goldMuted }}>{l}</Text>
      <Text style={{ color: colors.cream }}>{value}</Text>
    </View>
  );
}
