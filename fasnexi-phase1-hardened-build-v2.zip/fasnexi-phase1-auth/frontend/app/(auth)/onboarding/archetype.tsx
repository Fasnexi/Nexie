import { useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { OnboardingLayout, PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';
import { useOnboardingStore, type OnboardingState } from '../../../lib/onboarding-store';
import { colors } from '../../../packages/ui/src/tokens/colors';

/** Exact 6 values from StyleArchetype enum, schema.prisma */
const ARCHETYPES = [
  { value: 'MODERN_MINIMALIST', label: 'Modern Minimalist' },
  { value: 'AFROCENTRIC_MAXIMALIST', label: 'Afrocentric Maximalist' },
  { value: 'STREET_STYLE_FUSION', label: 'Street Style Fusion' },
  { value: 'TRADITIONAL_CONTEMPORARY', label: 'Traditional Contemporary' },
  { value: 'AVANT_GARDE', label: 'Avant-Garde' },
  { value: 'EVERYDAY_ELEGANCE', label: 'Everyday Elegance' },
] as const;

export default function ArchetypeScreen() {
  const setArchetype = useOnboardingStore((s: OnboardingState) => s.setArchetype);
  const [primary, setPrimary] = useState<string | undefined>(undefined);

  return (
    <OnboardingLayout
      stepIndex={1}
      title="Pick your primary style"
      subtitle="Choose the one that feels most like you. You can add a secondary later."
      onBack={() => router.back()}
    >
      <View style={{ gap: 10, flex: 1 }}>
        {ARCHETYPES.map((a) => {
          const selected = primary === a.value;
          return (
            <Pressable
              key={a.value}
              onPress={() => setPrimary(a.value)}
              style={{
                padding: 14,
                borderRadius: 8,
                borderWidth: 1,
                borderColor: selected ? colors.gold : colors.goldMuted,
                backgroundColor: selected ? 'rgba(200,164,93,0.12)' : 'transparent',
              }}
            >
              <Text style={{ color: selected ? colors.gold : colors.cream }}>{a.label}</Text>
            </Pressable>
          );
        })}
      </View>
      <PrimaryButton
        label="Continue"
        disabled={!primary}
        onPress={() => {
          if (!primary) return;
          setArchetype({ primaryArchetype: primary });
          router.push('/onboarding/body-profile');
        }}
      />
    </OnboardingLayout>
  );
}
