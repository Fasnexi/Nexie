import { Stack } from 'expo-router';
import { colors } from '../../packages/ui/src/tokens/colors';

/** Authentication and onboarding routes. */
export default function AuthLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: colors.black },
      }}
    />
  );
}
