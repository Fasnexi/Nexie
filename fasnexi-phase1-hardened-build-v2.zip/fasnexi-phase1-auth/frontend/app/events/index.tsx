import { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import { eventsApi } from '../../packages/api-client/src/endpoints/events';
import type { z } from 'zod';
import { eventSchema } from '../../packages/api-contracts/src/events';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function EventsScreen() {
  const [events, setEvents] = useState<z.infer<typeof eventSchema>[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { eventsApi.list().then((r) => setEvents(r.events as any)).finally(() => setLoading(false)); }, []);
  if (loading) return <View style={{ flex: 1, backgroundColor: colors.black, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator color={colors.gold} /></View>;
  return <FlatList style={{ flex: 1, backgroundColor: colors.black, padding: 16 }} data={events} keyExtractor={(e) => e.id} ListHeaderComponent={<Text style={{ color: colors.cream, fontSize: 28, fontWeight: '700', marginBottom: 14 }}>Events</Text>} ListEmptyComponent={<Text style={{ color: colors.goldMuted }}>No upcoming events yet.</Text>} renderItem={({ item }) => <Pressable onPress={() => router.push(`/events/${item.id}`)} style={{ marginBottom: 14, backgroundColor: '#151515', borderRadius: 12, overflow: 'hidden' }}>{item.coverUrl ? <Image source={{ uri: item.coverUrl }} style={{ width: '100%', height: 190 }} /> : null}<View style={{ padding: 12 }}><Text style={{ color: colors.cream, fontSize: 18, fontWeight: '700' }}>{item.title}</Text><Text style={{ color: colors.goldMuted, marginTop: 5 }}>{item.city ?? item.venue ?? 'Online'} · {new Date(item.startDate).toLocaleString()}</Text></View></Pressable>} />;
}
