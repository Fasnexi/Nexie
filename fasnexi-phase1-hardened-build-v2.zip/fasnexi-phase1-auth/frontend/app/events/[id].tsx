import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, Text, View } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { eventsApi } from '../../packages/api-client/src/endpoints/events';
import type { z } from 'zod';
import { eventSchema } from '../../packages/api-contracts/src/events';
import { colors } from '../../packages/ui/src/tokens/colors';
import { formatMoney } from '../../lib/money';

export default function EventDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [event, setEvent] = useState<z.infer<typeof eventSchema> | null>(null);
  const [buying, setBuying] = useState<string | null>(null);
  useEffect(() => { if (id) eventsApi.detail(id).then((r) => setEvent(r.event)); }, [id]);
  if (!event) return <View style={{ flex: 1, backgroundColor: colors.black, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator color={colors.gold} /></View>;
  const buy = async (tierId: string) => { setBuying(tierId); try { const r = await eventsApi.purchase(tierId); router.push({ pathname: '/tickets/success', params: { ticketId: r.ticketId, checkoutUrl: r.url } }); } catch (e) { Alert.alert('Unable to purchase', e instanceof Error ? e.message : 'Please try again.'); } finally { setBuying(null); } };
  return <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ paddingBottom: 30 }}>{event.coverUrl ? <Image source={{ uri: event.coverUrl }} style={{ width: '100%', height: 250 }} /> : null}<View style={{ padding: 16 }}><Text style={{ color: colors.cream, fontSize: 28, fontWeight: '700' }}>{event.title}</Text><Text style={{ color: colors.goldMuted, marginTop: 8 }}>{new Date(event.startDate).toLocaleString()} · {event.city ?? event.venue ?? 'Online'}</Text>{event.description ? <Text style={{ color: colors.cream, lineHeight: 22, marginTop: 16 }}>{event.description}</Text> : null}<Text style={{ color: colors.cream, fontSize: 20, fontWeight: '700', marginTop: 24, marginBottom: 10 }}>Tickets</Text>{event.ticketTiers.map((tier) => { const remaining = Math.max(tier.capacity - tier.sold, 0); return <View key={tier.id} style={{ backgroundColor: '#151515', borderRadius: 10, padding: 14, marginBottom: 10 }}><Text style={{ color: colors.cream, fontWeight: '700', fontSize: 16 }}>{tier.name}</Text><Text style={{ color: colors.gold, marginTop: 4 }}>{formatMoney(tier.priceAmount, tier.currency)}</Text><Text style={{ color: colors.goldMuted, marginTop: 3 }}>{remaining} remaining</Text><Pressable disabled={remaining === 0 || buying === tier.id} onPress={() => buy(tier.id)} style={{ marginTop: 10, backgroundColor: remaining === 0 ? '#333' : colors.gold, padding: 11, borderRadius: 8, alignItems: 'center' }}><Text style={{ color: remaining === 0 ? colors.goldMuted : colors.black, fontWeight: '700' }}>{buying === tier.id ? 'Preparing checkout…' : remaining === 0 ? 'Sold out' : 'Buy ticket'}</Text></Pressable></View>; })}<Pressable onPress={() => router.push('/tickets')} style={{ marginTop: 8 }}><Text style={{ color: colors.gold }}>View my tickets</Text></Pressable></View></ScrollView>;
}
