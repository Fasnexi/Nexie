import { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Text, View } from 'react-native';
import { eventsApi } from '../../packages/api-client/src/endpoints/events';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function TicketsScreen() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { eventsApi.tickets().then((r) => setTickets(r.tickets)).finally(() => setLoading(false)); }, []);
  if (loading) return <View style={{ flex: 1, backgroundColor: colors.black, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator color={colors.gold} /></View>;
  return <FlatList style={{ flex: 1, backgroundColor: colors.black, padding: 16 }} data={tickets} keyExtractor={(t) => t.id} ListHeaderComponent={<Text style={{ color: colors.cream, fontSize: 28, fontWeight: '700', marginBottom: 14 }}>My Tickets</Text>} ListEmptyComponent={<Text style={{ color: colors.goldMuted }}>You have no tickets yet.</Text>} renderItem={({ item }) => <View style={{ backgroundColor: '#151515', borderRadius: 12, padding: 14, marginBottom: 12 }}>{item.event.coverUrl ? <Image source={{ uri: item.event.coverUrl }} style={{ width: '100%', height: 150, borderRadius: 8 }} /> : null}<Text style={{ color: colors.cream, fontSize: 18, fontWeight: '700', marginTop: 10 }}>{item.event.title}</Text><Text style={{ color: colors.goldMuted }}>{item.tier.name} · {new Date(item.event.startDate).toLocaleString()}</Text><Text style={{ color: item.usedAt ? '#ff8080' : colors.gold, marginTop: 8 }}>{item.usedAt ? 'Used' : 'Valid'}</Text><Text selectable style={{ color: colors.cream, marginTop: 10, fontSize: 11 }}>Ticket ID: {item.id}</Text></View>} />;
}
