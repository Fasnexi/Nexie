import { useEffect } from 'react';
import { Linking, Text, View, Pressable } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function TicketSuccessScreen() {
  const { checkoutUrl } = useLocalSearchParams<{ checkoutUrl?: string }>();
  useEffect(() => { if (checkoutUrl) Linking.openURL(checkoutUrl); }, [checkoutUrl]);
  return <View style={{ flex: 1, backgroundColor: colors.black, justifyContent: 'center', padding: 24 }}><Text style={{ color: colors.gold, fontSize: 28, fontWeight: '700' }}>Ticket checkout</Text><Text style={{ color: colors.cream, marginTop: 12, lineHeight: 22 }}>Complete payment in the secure checkout page. Your ticket will appear in My Tickets after payment is confirmed.</Text><Pressable onPress={() => router.replace('/tickets')} style={{ backgroundColor: colors.gold, padding: 13, borderRadius: 8, marginTop: 24, alignItems: 'center' }}><Text style={{ color: colors.black, fontWeight: '700' }}>My Tickets</Text></Pressable></View>;
}
