import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, Pressable, Alert } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { challengesApi } from '../../../packages/api-client/src/endpoints/discover';
import type { ChallengeListItem } from '../../../packages/api-contracts/src/discover';
import { ApiClientError } from '../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';

type ChallengeDetail = ChallengeListItem & {
  entries: Array<{
    id: string;
    voteCount: number;
    rank: number | null;
    user: { id: string; username: string; displayName: string; avatarUrl: string | null };
    post: { id: string; mediaUrls: string[]; caption: string | null; likeCount: number };
  }>;
};
type ChallengeEntryItem = ChallengeDetail['entries'][number];

/**
 * Challenge detail + Vote/entry flow (plan §3).
 *
 * Vote errors need special handling: business-logic failures in
 * voteForEntry() (wrong phase, voting closed, entry not found) are thrown
 * as plain Errors and NOT caught by withErrorHandling — they surface as
 * raw 500s, not the flat {error} shape most routes use. So we can't show
 * the server's actual reason to the user here; the message below is
 * deliberately generic rather than inventing specifics the response
 * doesn't reliably provide. See discover.ts contract notes.
 */
export default function ChallengeDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [challenge, setChallenge] = useState<ChallengeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [votingEntryId, setVotingEntryId] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const { challenge: c } = await challengesApi.detail(id);
      setChallenge(c as ChallengeDetail);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const vote = async (entryId: string) => {
    if (!id || votingEntryId) return;
    setVotingEntryId(entryId);
    try {
      await challengesApi.vote(id, entryId);
      await load();
    } catch (err) {
      const status = err instanceof ApiClientError ? err.apiError.status : undefined;
      const message = status === 500
        ? "Couldn't record your vote — voting may be closed for this challenge, or something went wrong. Try again."
        : err instanceof ApiClientError ? err.apiError.error : "Couldn't record your vote.";
      Alert.alert('Vote not recorded', message);
    } finally {
      setVotingEntryId(null);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error || !challenge) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={challenge.entries}
      keyExtractor={(item: ChallengeEntryItem) => item.id}
      ListHeaderComponent={
        <View>
          {challenge.coverUrl && (
            <Image source={{ uri: challenge.coverUrl }} style={{ width: '100%', aspectRatio: 1.8 }} />
          )}
          <View style={{ padding: 16 }}>
            <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'] }}>
              {challenge.title}
            </Text>
            {challenge.description && (
              <Text style={{ color: colors.goldMuted, marginTop: 6 }}>{challenge.description}</Text>
            )}
            <Text style={{ color: colors.gold, marginTop: 10, fontSize: 12 }}>
              {challenge.status} · {challenge._count.entries} entries
              {challenge.status !== 'VOTING' && ' · voting not open yet'}
            </Text>
            {challenge.status === 'ACTIVE' && (
              <Pressable
                onPress={() => router.push(`/challenge/${challenge.id}/enter`)}
                style={{ marginTop: 12, backgroundColor: colors.gold, paddingVertical: 10, borderRadius: 8, alignItems: 'center' }}
              >
                <Text style={{ color: colors.black, fontWeight: '700' }}>Enter this challenge</Text>
              </Pressable>
            )}
          </View>
        </View>
      }
      renderItem={({ item }: { item: ChallengeEntryItem }) => (
        <View style={{ flexDirection: 'row', padding: 12, gap: 12, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
          {item.post.mediaUrls[0] && (
            <Image source={{ uri: item.post.mediaUrls[0] }} style={{ width: 72, height: 72, borderRadius: 8 }} />
          )}
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.cream }}>{item.user.displayName}</Text>
            {item.post.caption && (
              <Text numberOfLines={2} style={{ color: colors.goldMuted, fontSize: 12 }}>{item.post.caption}</Text>
            )}
            <Text style={{ color: colors.gold, fontSize: 12, marginTop: 4 }}>{item.voteCount} votes</Text>
          </View>
          <Pressable
            onPress={() => vote(item.id)}
            disabled={votingEntryId !== null || challenge.status !== 'VOTING'}
            style={{
              alignSelf: 'center', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 6,
              backgroundColor: colors.gold, opacity: challenge.status !== 'VOTING' ? 0.4 : 1,
            }}
          >
            {votingEntryId === item.id ? (
              <ActivityIndicator color={colors.black} size="small" />
            ) : (
              <Text style={{ color: colors.black, fontWeight: '700' }}>Vote</Text>
            )}
          </Pressable>
        </View>
      )}
    />
  );
}
