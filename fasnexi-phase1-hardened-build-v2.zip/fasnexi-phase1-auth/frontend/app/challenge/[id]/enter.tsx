import { useState } from 'react';
import { View, Text, Image, Pressable, TextInput, ActivityIndicator, Alert, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useLocalSearchParams, router } from 'expo-router';
import { uploadToCloudinary } from '../../../lib/cloudinary-upload';
import { challengesApi } from '../../../packages/api-client/src/endpoints/discover';
import { ApiClientError } from '../../../packages/api-client/src/client';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';

/**
 * Entry submission — found missing in a full-app audit alongside voting
 * (Step 3 only built half of the plan's own "Vote/entry flow"). Reuses
 * the same Cloudinary upload flow as Wardrobe (Step 5), folder "posts".
 */
export default function ChallengeEnterScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [pickedUri, setPickedUri] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Allow photo library access to enter this challenge.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setPickedUri(result.assets[0].uri);
      setError(null);
    }
  };

  const submit = async () => {
    if (!id || !pickedUri) {
      setError('Add a photo first.');
      return;
    }
    if (Platform.OS === 'web') {
      setError('Web upload needs a blob-conversion step not yet implemented — see cloudinary-upload.ts.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const fileName = pickedUri.split('/').pop() ?? 'entry.jpg';
      const upload = await uploadToCloudinary('posts', { uri: pickedUri, name: fileName, type: 'image/jpeg' });
      await challengesApi.submitEntry(id, { mediaUrls: [upload.secureUrl], caption: caption || undefined });
      router.back();
    } catch (err) {
      // Every business-logic failure here ("not accepting entries",
      // "already submitted", "reached maximum") is an uncaught 500 —
      // see submitEntryResponseSchema's contract notes. Generic fallback.
      const message = err instanceof ApiClientError && err.apiError.status !== 500
        ? err.apiError.error
        : "Couldn't submit your entry — this challenge may not be accepting entries right now, or you may have already entered.";
      Alert.alert('Not submitted', message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, padding: 16 }}>
      <Pressable
        onPress={pickImage}
        style={{
          aspectRatio: 1, borderRadius: 12, borderWidth: 1, borderColor: colors.goldMuted,
          alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 20,
        }}
      >
        {pickedUri ? (
          <Image source={{ uri: pickedUri }} style={{ width: '100%', height: '100%' }} />
        ) : (
          <Text style={{ color: colors.goldMuted }}>Tap to choose a photo</Text>
        )}
      </Pressable>

      <TextInput
        value={caption}
        onChangeText={setCaption}
        placeholder="Caption (optional)"
        placeholderTextColor={colors.goldMuted}
        multiline
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, minHeight: 70, marginBottom: 20 }}
      />

      {error && <Text style={{ color: '#e0654f', marginBottom: 12 }}>{error}</Text>}

      {submitting ? <ActivityIndicator color={colors.gold} /> : <PrimaryButton label="Submit entry" onPress={submit} />}
    </View>
  );
}
