import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { searchApi } from '../../packages/api-client/src/endpoints/search';
import type { SearchResponse, SearchType } from '../../packages/api-contracts/src/search';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';

type Section = { title: string; kind: 'products' | 'vendors' | 'creators' | 'users' | 'events'; items: any[] };
const tabs: { key: SearchType; label: string }[] = [
  { key: 'all', label: 'All' }, { key: 'products', label: 'Products' }, { key: 'vendors', label: 'Vendors' },
  { key: 'creators', label: 'Creators' }, { key: 'users', label: 'People' }, { key: 'events', label: 'Events' },
];

function SectionItem({ kind, item }: { kind: Section['kind']; item: any }) {
  if (kind === 'products') return <Pressable onPress={() => router.push(`/product/${item.slug}`)} style={{ width: 170, marginRight: 12 }}><Image source={{ uri: item.imageUrls[0] }} style={{ width: 170, height: 170, borderRadius: 10 }} /><Text numberOfLines={1} style={{ color: colors.cream, marginTop: 6 }}>{item.name}</Text><Text style={{ color: colors.gold }}>{formatMoney(item.priceAmount, item.priceCurrency)}</Text></Pressable>;
  if (kind === 'vendors') return <View style={{ padding: 12, borderRadius: 10, backgroundColor: '#151515', marginBottom: 8 }}><Text style={{ color: colors.cream, fontWeight: '700' }}>{item.businessName}</Text><Text style={{ color: colors.goldMuted }}>{item.country}{item.isVerified ? ' · Verified' : ''}</Text></View>;
  if (kind === 'creators') return <Pressable onPress={() => router.push(`/user/${item.user.username}`)} style={{ flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: '#151515', borderRadius: 10, marginBottom: 8 }}>{item.user.avatarUrl ? <Image source={{ uri: item.user.avatarUrl }} style={{ width: 44, height: 44, borderRadius: 22 }} /> : <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.goldMuted }} />}<View style={{ marginLeft: 10 }}><Text style={{ color: colors.cream, fontWeight: '700' }}>{item.user.displayName}</Text><Text style={{ color: colors.goldMuted }}>@{item.user.username} · {item.followerCount} followers</Text></View></Pressable>;
  if (kind === 'users') return <Pressable onPress={() => router.push(`/user/${item.username}`)} style={{ padding: 10, backgroundColor: '#151515', borderRadius: 10, marginBottom: 8 }}><Text style={{ color: colors.cream, fontWeight: '700' }}>{item.displayName}</Text><Text style={{ color: colors.goldMuted }}>@{item.username}</Text></Pressable>;
  return <Pressable onPress={() => router.push(`/events/${item.id}` as any)} style={{ flexDirection: 'row', marginBottom: 10, backgroundColor: '#151515', borderRadius: 10, overflow: 'hidden' }}>{item.coverUrl ? <Image source={{ uri: item.coverUrl }} style={{ width: 100, height: 100 }} /> : null}<View style={{ padding: 10, flex: 1 }}><Text style={{ color: colors.cream, fontWeight: '700' }}>{item.title}</Text><Text style={{ color: colors.goldMuted, marginTop: 4 }}>{item.city ?? item.venue ?? 'Online'} · {new Date(item.startDate).toLocaleString()}</Text></View></Pressable>;
}

export default function SearchScreen() {
  const [text, setText] = useState('');
  const [q, setQ] = useState('');
  const [type, setType] = useState<SearchType>('all');
  const [result, setResult] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(async () => {
      const value = q.trim();
      if (value.length < 2) { setResult(null); return; }
      setLoading(true); setError(null);
      try { setResult(await searchApi.query(value, type)); } catch (e) { setError(e instanceof Error ? e.message : 'Search failed'); } finally { setLoading(false); }
    }, 300);
    return () => clearTimeout(timer);
  }, [q, type]);

  const sections = useMemo<Section[]>(() => {
    if (!result) return [];
    const all: Section[] = [
      { title: 'Products', kind: 'products', items: result.products },
      { title: 'Vendors', kind: 'vendors', items: result.vendors },
      { title: 'Creators', kind: 'creators', items: result.creators },
      { title: 'People', kind: 'users', items: result.users },
      { title: 'Events', kind: 'events', items: result.events },
    ];
    return type === 'all' ? all : all.filter((s) => s.kind === type);
  }, [result, type]);

  return <View style={{ flex: 1, backgroundColor: colors.black, padding: 16 }}>
    <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'], marginBottom: 12 }}>Search</Text>
    <TextInput value={text} onChangeText={(v) => { setText(v); setQ(v); }} placeholder="Search products, people, vendors, events..." placeholderTextColor={colors.goldMuted} autoCapitalize="none" style={{ backgroundColor: '#151515', color: colors.cream, borderRadius: 10, padding: 13, borderWidth: 1, borderColor: colors.goldMuted }} />
    <FlatList horizontal showsHorizontalScrollIndicator={false} data={tabs} keyExtractor={(t) => t.key} style={{ maxHeight: 54, marginVertical: 10 }} renderItem={({ item }) => <Pressable onPress={() => setType(item.key)} style={{ paddingHorizontal: 14, paddingVertical: 9, borderRadius: 18, backgroundColor: type === item.key ? colors.gold : '#151515', marginRight: 8 }}><Text style={{ color: type === item.key ? colors.black : colors.cream }}>{item.label}</Text></Pressable>} />
    {loading ? <ActivityIndicator color={colors.gold} style={{ marginTop: 20 }} /> : error ? <Text style={{ color: '#ff8080', marginTop: 20 }}>{error}</Text> : q.trim().length < 2 ? <Text style={{ color: colors.goldMuted, marginTop: 20 }}>Type at least 2 characters to search.</Text> : sections.every((s) => s.items.length === 0) ? <Text style={{ color: colors.goldMuted, marginTop: 20 }}>No results for “{result?.query}”.</Text> : <FlatList data={sections} keyExtractor={(s) => s.title} renderItem={({ item }) => <View style={{ marginBottom: 18 }}><Text style={{ color: colors.cream, fontWeight: '700', fontSize: 17, marginBottom: 8 }}>{item.title}</Text>{item.kind === 'products' ? <FlatList horizontal showsHorizontalScrollIndicator={false} data={item.items} keyExtractor={(i) => i.id} renderItem={({ item: i }) => <SectionItem kind={item.kind} item={i} />} /> : item.items.map((i) => <SectionItem key={i.id} kind={item.kind} item={i} />)}</View>} />}
  </View>;
}
