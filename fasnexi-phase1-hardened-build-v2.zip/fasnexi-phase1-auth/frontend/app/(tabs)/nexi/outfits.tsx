import { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { nexiApi } from '../../../packages/api-client/src/endpoints/nexi';
import type { OutfitSuggestion } from '../../../packages/api-contracts/src/nexi';
import { ApiClientError } from '../../../packages/api-client/src/client';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../lib/onboarding/OnboardingLayout';

/**
 * Outfit generation (plan §7 step 6) — mood/occasion form for the
 * general case, or auto-triggered "Style This" mode when reached with a
 * `wardrobeItemId` param (deep-linked from a wardrobe item's detail
 * screen). Both hit the same underlying generateOutfits() and return the
 * same OutfitSuggestion[] shape server-side.
 *
 * NOTE: neither endpoint returns an updated remaining-query count (see
 * nexi.ts's contract notes) — this screen doesn't display or imply one,
 * rather than show a number that's silently wrong the moment this runs.
 */
export default function OutfitIdeasScreen() {
  const { wardrobeItemId } = useLocalSearchParams<{ wardrobeItemId?: string }>();
  const [mood, setMood] = useState('');
  const [occasion, setOccasion] = useState('');
  const [loading, setLoading] = useState(false);
  const [pendingMessage, setPendingMessage] = useState<string | null>(null);
  const [outfits, setOutfits] = useState<OutfitSuggestion[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runStyleThis = async (itemId: string) => {
    setLoading(true);
    setError(null);
    setPendingMessage(null);
    try {
      const result = await nexiApi.styleThis({ wardrobeItemId: itemId, count: 3 });
      if (result.status === 'pending') {
        setPendingMessage(result.message);
      } else {
        setOutfits(result.outfits);
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.apiError.error : 'Could not generate outfit ideas.');
    } finally {
      setLoading(false);
    }
  };

  const runOutfitGeneration = async () => {
    if (!mood.trim() && !occasion.trim()) {
      setError('Enter a mood or an occasion.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await nexiApi.outfit({ mood: mood || undefined, occasion: occasion || undefined, count: 3 });
      setOutfits(result.outfits);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.apiError.error : 'Could not generate outfit ideas.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (wardrobeItemId) runStyleThis(wardrobeItemId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wardrobeItemId]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      {!wardrobeItemId && (
        <View style={{ marginBottom: 20 }}>
          <TextInput
            value={mood}
            onChangeText={setMood}
            placeholder="Mood (e.g. 'confident and relaxed')"
            placeholderTextColor={colors.goldMuted}
            style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, marginBottom: 10 }}
          />
          <TextInput
            value={occasion}
            onChangeText={setOccasion}
            placeholder="Occasion (e.g. 'work', 'wedding')"
            placeholderTextColor={colors.goldMuted}
            style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, marginBottom: 14 }}
          />
          <PrimaryButton label={loading ? 'Generating…' : 'Generate outfit ideas'} onPress={runOutfitGeneration} disabled={loading} />
        </View>
      )}

      {loading && <ActivityIndicator color={colors.gold} />}

      {pendingMessage && (
        <Text style={{ color: colors.goldMuted, textAlign: 'center', marginTop: 12 }}>{pendingMessage}</Text>
      )}
      {error && <Text style={{ color: '#e0654f', textAlign: 'center', marginTop: 12 }}>{error}</Text>}

      {outfits?.map((outfit, i) => (
        <View key={i} style={{ marginBottom: 20, padding: 14, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 10 }}>
          <Text style={{ color: colors.gold, fontWeight: '700', marginBottom: 6 }}>{outfit.name}</Text>
          <Text style={{ color: colors.cream, marginBottom: 10, fontStyle: 'italic' }}>{outfit.styleNote}</Text>

          {outfit.ownedItems.length > 0 && (
            <View style={{ marginBottom: 8 }}>
              <Text style={{ color: colors.goldMuted, fontSize: 12, marginBottom: 4 }}>From your wardrobe</Text>
              {outfit.ownedItems.map((item, j) => (
                <Text key={j} style={{ color: colors.cream, fontSize: 13 }}>• {item.description} ({item.role})</Text>
              ))}
            </View>
          )}

          {outfit.gapItems.length > 0 && (
            <View>
              <Text style={{ color: colors.goldMuted, fontSize: 12, marginBottom: 4 }}>You'd need to shop for</Text>
              {outfit.gapItems.map((gap, j) => (
                <Text key={j} style={{ color: colors.goldMuted, fontSize: 13 }}>• {gap.description} — {gap.reason}</Text>
              ))}
            </View>
          )}
        </View>
      ))}
    </ScrollView>
  );
}
