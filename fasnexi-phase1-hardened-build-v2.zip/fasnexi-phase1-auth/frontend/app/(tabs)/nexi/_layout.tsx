import { Stack } from 'expo-router';
import { colors } from '../../../packages/ui/src/tokens/colors';

export default function NexiLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="outfits" options={{ title: 'Outfit ideas' }} />
    </Stack>
  );
}
