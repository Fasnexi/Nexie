import { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useNexiStream } from '../../../lib/useNexiStream';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';

interface Turn {
  role: 'user' | 'assistant';
  text: string;
}

/**
 * Nexi: AI stylist chat (streaming), plus entry points into outfit
 * generation and gap analysis (plan §7 step 6). Rewritten against the
 * corrected useNexiStream — see that file for what Step 1 got wrong.
 */
export default function NexiChatScreen() {
  const insets = useSafeAreaInsets();
  const [input, setInput] = useState('');
  const [turns, setTurns] = useState<Turn[]>([]);
  const sessionIdRef = useRef<string | undefined>(undefined);
  const { text, isStreaming, remaining, error, rateLimited, sessionId, send } = useNexiStream();

  const onSend = () => {
    if (!input.trim() || isStreaming) return;
    setTurns((t) => [...t, { role: 'user', text: input.trim() }]);
    send(input.trim(), sessionIdRef.current);
    setInput('');
  };

  // Commit the streamed response into turn history once it finishes, and
  // remember the session id so the next message continues the same
  // server-side conversation instead of starting a new one each time.
  // Done via effect (not inline during render) to avoid the fragile
  // "setState while rendering" pattern — this only fires on the actual
  // transition of isStreaming/text, not on every render.
  useEffect(() => {
    if (!isStreaming && text) {
      setTurns((t) => (t[t.length - 1]?.role === 'assistant' ? t : [...t, { role: 'assistant', text }]));
    }
  }, [isStreaming, text]);

  useEffect(() => {
    if (sessionId) sessionIdRef.current = sessionId;
  }, [sessionId]);

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.black, paddingTop: insets.top }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16 }}>
        <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl }}>Nexi</Text>
        <View style={{ flexDirection: 'row', gap: 16 }}>
          <Pressable onPress={() => router.push('/(tabs)/nexi/outfits')}>
            <Text style={{ color: colors.gold, fontSize: 13 }}>Outfit ideas</Text>
          </Pressable>
          <Pressable onPress={() => router.push('/(tabs)/profile/wardrobe/gaps')}>
            <Text style={{ color: colors.gold, fontSize: 13 }}>Gap analysis</Text>
          </Pressable>
        </View>
      </View>

      <ScrollView style={{ flex: 1, paddingHorizontal: 16 }}>
        {turns.length === 0 && !isStreaming && (
          <Text style={{ color: colors.goldMuted, marginTop: 20 }}>
            Ask Nexi for styling help, or try "Outfit ideas" above for structured suggestions.
          </Text>
        )}
        {turns.map((t, i) => (
          <View key={i} style={{ marginBottom: 14, alignItems: t.role === 'user' ? 'flex-end' : 'flex-start' }}>
            <View style={{
              maxWidth: '85%', padding: 10, borderRadius: 10,
              backgroundColor: t.role === 'user' ? colors.gold : 'rgba(214,199,178,0.12)',
            }}>
              <Text style={{ color: t.role === 'user' ? colors.black : colors.cream }}>{t.text}</Text>
            </View>
          </View>
        ))}
        {isStreaming && (
          <View style={{ marginBottom: 14, alignItems: 'flex-start' }}>
            <View style={{ maxWidth: '85%', padding: 10, borderRadius: 10, backgroundColor: 'rgba(214,199,178,0.12)' }}>
              <Text style={{ color: colors.cream }}>{text || '…'}</Text>
            </View>
          </View>
        )}
      </ScrollView>

      {remaining !== null && (
        <Text style={{ color: colors.goldMuted, fontSize: 11, textAlign: 'center' }}>{remaining} queries left today</Text>
      )}
      {error && (
        <Text style={{ color: rateLimited ? colors.gold : '#e0654f', fontSize: 12, textAlign: 'center', marginTop: 4, paddingHorizontal: 16 }}>
          {error}
        </Text>
      )}

      <View style={{ flexDirection: 'row', gap: 8, padding: 16 }}>
        <TextInput
          value={input}
          onChangeText={setInput}
          placeholder="Message Nexi…"
          placeholderTextColor={colors.goldMuted}
          style={{ flex: 1, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream }}
          onSubmitEditing={onSend}
        />
        <Pressable
          disabled={isStreaming || !input.trim()}
          onPress={onSend}
          style={{ justifyContent: 'center', paddingHorizontal: 18, backgroundColor: colors.gold, borderRadius: 8, opacity: isStreaming || !input.trim() ? 0.5 : 1 }}
        >
          <Text style={{ color: colors.black, fontWeight: '700' }}>Send</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
