import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { feedApi, storiesApi } from '../../../packages/api-client/src/endpoints/feed';
import { engagementApi } from '../../../packages/api-client/src/endpoints/social';
import type { FeedPost, StoryFeedItem } from '../../../packages/api-contracts/src/feed';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';

const PAGE_LIMIT = 20;

/**
 * Home: Feed (Style DNA-weighted) + Stories.
 *
 * Pagination note: GET /api/feed returns {posts, count} with no
 * nextCursor field — cursor is keyset on the last post's id, so "more
 * pages exist" is inferred from `posts.length === PAGE_LIMIT` rather than
 * a server-provided flag. See packages/api-contracts/src/feed.ts.
 */
export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [stories, setStories] = useState<StoryFeedItem[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const loadInitial = useCallback(async () => {
    setError(null);
    try {
      const [feedPage, storiesPage] = await Promise.all([
        feedApi.list({ limit: PAGE_LIMIT }),
        storiesApi.list(),
      ]);
      setPosts(feedPage.posts);
      setHasMore(feedPage.posts.length === PAGE_LIMIT);
      setStories(storiesPage.stories);
    } catch (err) {
      setError(err);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    loadInitial().finally(() => setLoading(false));
  }, [loadInitial]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadInitial();
    setRefreshing(false);
  }, [loadInitial]);

  const loadMore = useCallback(async () => {
    if (!hasMore || loadingMore || posts.length === 0) return;
    setLoadingMore(true);
    try {
      const lastPostId = posts[posts.length - 1].id;
      const page = await feedApi.list({ cursor: lastPostId, limit: PAGE_LIMIT });
      setPosts((prev: FeedPost[]) => [...prev, ...page.posts]);
      setHasMore(page.posts.length === PAGE_LIMIT);
    } catch {
      // pagination errors are non-fatal — leave the existing list intact
    } finally {
      setLoadingMore(false);
    }
  }, [hasMore, loadingMore, posts]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={() => { setLoading(true); loadInitial().finally(() => setLoading(false)); }} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black, paddingTop: insets.top }}
      data={posts}
      keyExtractor={(item: FeedPost) => item.id}
      onEndReached={loadMore}
      onEndReachedThreshold={0.4}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.gold} />}
      ListHeaderComponent={
        <View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingTop: 16, paddingBottom: 8 }}>
            <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'] }}>
              FasNexi
            </Text>
            <Pressable onPress={() => router.push('/video')}>
              <Text style={{ color: colors.gold, fontSize: 13 }}>Video</Text>
            </Pressable>
          </View>
          {stories.length > 0 && <StoriesRow stories={stories} />}
        </View>
      }
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted, textAlign: 'center' }}>
            Your feed will fill in as you follow creators and set your Style DNA.
          </Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: FeedPost }) => <FeedPostCard post={item} />}
    />
  );
}

function StoriesRow({ stories }: { stories: StoryFeedItem[] }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingVertical: 8 }}>
      {stories.map((s: StoryFeedItem) => (
        <Pressable key={s.userId} style={{ alignItems: 'center', width: 72, marginHorizontal: 6 }}>
          <View
            style={{
              width: 60, height: 60, borderRadius: 30,
              borderWidth: 2,
              borderColor: s.hasUnviewed ? colors.gold : colors.goldMuted,
              alignItems: 'center', justifyContent: 'center',
            }}
          >
            {s.user.avatarUrl ? (
              <Image source={{ uri: s.user.avatarUrl }} style={{ width: 52, height: 52, borderRadius: 26 }} />
            ) : (
              <Text style={{ color: colors.cream }}>{s.user.username[0]?.toUpperCase()}</Text>
            )}
          </View>
          <Text numberOfLines={1} style={{ color: colors.cream, fontSize: 11, marginTop: 4 }}>
            {s.user.username}
          </Text>
        </Pressable>
      ))}
    </ScrollView>
  );
}

function FeedPostCard({ post }: { post: FeedPost }) {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  // NOTE: this card doesn't know the viewer's own like/save state on
  // mount — /api/feed's response has no `likedByMe`/`savedByMe` field
  // (confirmed from feed/ranking.ts's select). Starts unliked/unsaved
  // every load and only reflects state changes made in this session,
  // rather than fabricate an initial state the API doesn't provide.
  const toggleLike = async () => {
    if (busy) return;
    setBusy(true);
    const prevLiked = liked;
    const prevCount = likeCount;
    setLiked(!prevLiked);
    setLikeCount(prevLiked ? prevCount - 1 : prevCount + 1);
    try {
      const result = await engagementApi.toggleLike(post.id);
      setLiked(result.liked);
      setLikeCount(result.likeCount);
    } catch {
      setLiked(prevLiked);
      setLikeCount(prevCount);
    } finally {
      setBusy(false);
    }
  };

  const toggleSave = async () => {
    if (busy) return;
    setBusy(true);
    const prevSaved = saved;
    setSaved(!prevSaved);
    try {
      const result = await engagementApi.toggleSave(post.id);
      setSaved(result.saved);
    } catch {
      setSaved(prevSaved);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
      <Pressable
        onPress={() => router.push(`/user/${post.user.username}`)}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}
      >
        {post.user.avatarUrl && (
          <Image source={{ uri: post.user.avatarUrl }} style={{ width: 28, height: 28, borderRadius: 14 }} />
        )}
        <Text style={{ color: colors.cream, fontWeight: '600' }}>{post.user.displayName}</Text>
      </Pressable>
      {post.mediaUrls[0] && (
        <Image source={{ uri: post.mediaUrls[0] }} style={{ width: '100%', aspectRatio: 1, borderRadius: 8 }} />
      )}
      {post.caption && <Text style={{ color: colors.cream, marginTop: 8 }}>{post.caption}</Text>}

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 20, marginTop: 10 }}>
        <Pressable onPress={toggleLike} disabled={busy}>
          <Text style={{ color: liked ? colors.gold : colors.goldMuted, fontSize: 13 }}>
            {liked ? '♥' : '♡'} {likeCount}
          </Text>
        </Pressable>
        <Pressable onPress={() => router.push(`/post/${post.id}/comments`)}>
          <Text style={{ color: colors.goldMuted, fontSize: 13 }}>💬 {post.commentCount}</Text>
        </Pressable>
        <Pressable onPress={toggleSave} disabled={busy}>
          <Text style={{ color: saved ? colors.gold : colors.goldMuted, fontSize: 13 }}>{saved ? 'Saved' : 'Save'}</Text>
        </Pressable>
      </View>
    </View>
  );
}
