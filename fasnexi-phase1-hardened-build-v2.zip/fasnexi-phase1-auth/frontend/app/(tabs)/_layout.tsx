import { Tabs } from 'expo-router';
import { Home, Compass, Sparkles, ShoppingBag, User } from 'lucide-react-native';
import { colors } from '../../packages/ui/src/tokens/colors';

/**
 * 5-tab structure, confirmed against the backend — no API changes
 * required (Wardrobe/Nexi endpoints are user-scoped, not route-scoped).
 * Deviates intentionally from the original white-paper spec (Wardrobe as
 * standalone tab, Nexi as floating overlay) — see plan §2.
 *
 * "Wallet" is deliberately absent: it's Investor-only Phase 7 tooling for
 * the unbuilt Fashion Stock Exchange, not a general consumer feature.
 */
export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.gold,
        tabBarInactiveTintColor: colors.goldMuted,
        tabBarStyle: { backgroundColor: colors.black, borderTopColor: colors.goldMuted },
      }}
    >
      <Tabs.Screen name="home" options={{ title: 'Home', tabBarIcon: ({ color, size }: { color: string; size: number }) => <Home color={color} size={size} /> }} />
      <Tabs.Screen name="discover" options={{ title: 'Discover', tabBarIcon: ({ color, size }: { color: string; size: number }) => <Compass color={color} size={size} /> }} />
      <Tabs.Screen name="nexi" options={{ title: 'Nexi', tabBarIcon: ({ color, size }: { color: string; size: number }) => <Sparkles color={color} size={size} /> }} />
      <Tabs.Screen name="shop" options={{ title: 'Shop', tabBarIcon: ({ color, size }: { color: string; size: number }) => <ShoppingBag color={color} size={size} /> }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: ({ color, size }: { color: string; size: number }) => <User color={color} size={size} /> }} />
    </Tabs>
  );
}
