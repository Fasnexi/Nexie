import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Pressable, RefreshControl } from 'react-native';
import { notificationsApi } from '../../../packages/api-client/src/endpoints/notifications';
import { extractNotificationMessage } from '../../../packages/api-contracts/src/notifications';
import type { NotificationItem, NotificationType } from '../../../packages/api-contracts/src/notifications';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { colors } from '../../../packages/ui/src/tokens/colors';

const PAGE_LIMIT = 30;

/**
 * Notifications inbox (plan §3/§7 step 7 — "list + mark-read routes now
 * live").
 *
 * CORRECTED during the Step 11 audit: this originally claimed no
 * notification-creation code exists anywhere and rendered purely
 * generically. That was wrong — a narrow grep pattern missed 17 real
 * `enqueueNotification()` call sites across the backend. Now prefers
 * `data.message` when present (confirmed real for every SYSTEM
 * notification sampled, and some ORDER_UPDATE ones), falling back to the
 * generic per-type label otherwise (covers FOLLOW/LIKE/COMMENT, which
 * are structured-only and never carry a message). See
 * notifications.ts's contract notes for exactly what was sampled and
 * the one caveat that still genuinely holds — the worker that persists
 * the final `Notification.data` isn't in this codebase to double-check
 * against.
 */
const TYPE_LABELS: Record<NotificationType, string> = {
  LIKE: 'liked your post',
  COMMENT: 'commented on your post',
  FOLLOW: 'started following you',
  ORDER_UPDATE: 'Order update',
  NEXI_SUGGESTION: 'Nexi has a suggestion for you',
  CHALLENGE_ENDING: 'A challenge you entered is ending soon',
  DROP_ALERT: 'New drop alert',
  PAYOUT_PROCESSED: 'Your payout was processed',
  COMMISSION_EARNED: 'You earned a commission',
  PRICE_ALERT: 'Price alert',
  SYSTEM: 'FasNexi',
};

export default function NotificationsScreen() {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const loadInitial = useCallback(async () => {
    setError(null);
    try {
      const page = await notificationsApi.list({ limit: PAGE_LIMIT });
      setItems(page.notifications);
      setCursor(page.nextCursor ?? undefined);
      setUnreadCount(page.unreadCount);
    } catch (err) {
      setError(err);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    loadInitial().finally(() => setLoading(false));
  }, [loadInitial]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadInitial();
    setRefreshing(false);
  }, [loadInitial]);

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await notificationsApi.list({ cursor, limit: PAGE_LIMIT });
      setItems((prev: NotificationItem[]) => [...prev, ...page.notifications]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore]);

  const onMarkRead = async (item: NotificationItem) => {
    if (item.read) return;
    setItems((prev: NotificationItem[]) => prev.map((n) => (n.id === item.id ? { ...n, read: true } : n)));
    setUnreadCount((c: number) => Math.max(0, c - 1));
    try {
      await notificationsApi.markRead(item.id);
    } catch {
      // revert optimistic update on failure
      setItems((prev: NotificationItem[]) => prev.map((n) => (n.id === item.id ? { ...n, read: false } : n)));
      setUnreadCount((c: number) => c + 1);
    }
  };

  const onMarkAllRead = async () => {
    const previousItems = items;
    const previousCount = unreadCount;
    setItems((prev: NotificationItem[]) => prev.map((n) => ({ ...n, read: true })));
    setUnreadCount(0);
    try {
      await notificationsApi.markAllRead();
    } catch {
      setItems(previousItems);
      setUnreadCount(previousCount);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={() => { setLoading(true); loadInitial().finally(() => setLoading(false)); }} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={items}
      keyExtractor={(item: NotificationItem) => item.id}
      onEndReached={loadMore}
      onEndReachedThreshold={0.4}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.gold} />}
      ListHeaderComponent={
        unreadCount > 0 ? (
          <Pressable onPress={onMarkAllRead} style={{ padding: 14, alignItems: 'flex-end' }}>
            <Text style={{ color: colors.gold, fontSize: 13 }}>Mark all {unreadCount} as read</Text>
          </Pressable>
        ) : null
      }
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No notifications yet.</Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: NotificationItem }) => (
        <Pressable
          onPress={() => onMarkRead(item)}
          style={{
            flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14,
            borderBottomWidth: 1, borderBottomColor: colors.goldMuted,
            backgroundColor: item.read ? 'transparent' : 'rgba(200,164,93,0.08)',
          }}
        >
          {!item.read && <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: colors.gold }} />}
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.cream }}>{extractNotificationMessage(item.data) ?? TYPE_LABELS[item.type]}</Text>
            <Text style={{ color: colors.goldMuted, fontSize: 11, marginTop: 2 }}>
              {new Date(item.createdAt).toLocaleString()}
            </Text>
          </View>
        </Pressable>
      )}
    />
  );
}
