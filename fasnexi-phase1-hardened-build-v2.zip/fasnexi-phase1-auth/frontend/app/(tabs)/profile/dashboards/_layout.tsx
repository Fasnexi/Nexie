import { Stack } from 'expo-router';
import { colors } from '../../../../packages/ui/src/tokens/colors';

export default function DashboardsLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Role dashboards' }} />
      <Stack.Screen name="creator" options={{ title: 'Creator earnings' }} />
      <Stack.Screen name="vendor/index" options={{ title: 'Vendor dashboard' }} />
      <Stack.Screen name="vendor/orders" options={{ title: 'Vendor orders' }} />
      <Stack.Screen name="promotions" options={{ title: 'Promoted listings' }} />
      <Stack.Screen name="tailor" options={{ title: 'Tailor queue' }} />
    </Stack>
  );
}
