import { useCallback, useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Pressable, ScrollView } from 'react-native';
import { creatorDashboardApi } from '../../../../packages/api-client/src/endpoints/vendor-dashboard';
import type { CreatorEarnings } from '../../../../packages/api-contracts/src/vendor-dashboard';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../../lib/money';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../../packages/ui/src/tokens/typography';

const PERIODS: Array<'week' | 'month' | 'all'> = ['week', 'month', 'all'];

export default function CreatorEarningsScreen() {
  const [period, setPeriod] = useState<'week' | 'month' | 'all'>('month');
  const [earnings, setEarnings] = useState<CreatorEarnings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);

  const load = useCallback(async (p: 'week' | 'month' | 'all') => {
    setLoading(true);
    setError(null);
    try {
      setEarnings(await creatorDashboardApi.earnings(p));
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(period);
  }, [load, period]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error || !earnings) {
    return <ApiErrorView error={error} onRetry={() => load(period)} />;
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 20 }}>
        {PERIODS.map((p) => (
          <Pressable
            key={p}
            onPress={() => setPeriod(p)}
            style={{
              paddingVertical: 6, paddingHorizontal: 14, borderRadius: 16,
              borderWidth: 1, borderColor: period === p ? colors.gold : colors.goldMuted,
              backgroundColor: period === p ? 'rgba(200,164,93,0.12)' : 'transparent',
            }}
          >
            <Text style={{ color: period === p ? colors.gold : colors.cream, fontSize: 12 }}>{p}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={{ color: colors.goldMuted, marginBottom: 12 }}>{earnings.commissionCount} commissions</Text>
      {Object.entries(earnings.currencies).map(([currency, values]) => (
        <View key={currency} style={{ marginBottom: 20 }}>
          <Text style={{ color: colors.gold, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'] }}>{formatMoney(values.total, currency as any)}</Text>
          <Row label="Pending" value={formatMoney(values.pending, currency as any)} />
          <Row label="Confirmed" value={formatMoney(values.confirmed, currency as any)} />
          <Row label="Paid" value={formatMoney(values.paid, currency as any)} />
        </View>
      ))}
    </ScrollView>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
      <Text style={{ color: colors.goldMuted }}>{label}</Text>
      <Text style={{ color: colors.cream }}>{value}</Text>
    </View>
  );
}
