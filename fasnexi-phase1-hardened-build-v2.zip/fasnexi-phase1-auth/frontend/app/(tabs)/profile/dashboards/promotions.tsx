import { useCallback, useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Image, Pressable, TextInput, Alert, ScrollView } from 'react-native';
import { promotionsApi } from '../../../../packages/api-client/src/endpoints/promotions';
import { vendorDashboardApi } from '../../../../packages/api-client/src/endpoints/vendor-dashboard';
import type { Promotion } from '../../../../packages/api-contracts/src/promotions';
import { vendorTopProductSchema } from '../../../../packages/api-contracts/src/vendor-dashboard';
import type { z } from 'zod';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../../lib/money';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../../packages/ui/src/tokens/typography';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

type TopProduct = z.infer<typeof vendorTopProductSchema>;


export default function PromotionsScreen() {
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [products, setProducts] = useState<TopProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [selectedProduct, setSelectedProduct] = useState<TopProduct | null>(null);
  const [budgetAmount, setBudgetAmount] = useState('');
  const [dailyBudget, setDailyBudget] = useState('');
  const [cpmAmount, setCpmAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [promoResult, productsResult] = await Promise.all([
        promotionsApi.list(),
        vendorDashboardApi.topProducts(),
      ]);
      setPromotions(promoResult.promotions);
      setProducts(productsResult.products);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const submit = async () => {
    if (!selectedProduct || !budgetAmount || !dailyBudget || !cpmAmount) {
      Alert.alert('Missing details', 'Pick a product and fill in all budget fields.');
      return;
    }
    setSubmitting(true);
    try {
      const now = new Date();
      const in30Days = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      await promotionsApi.create({
        productId: selectedProduct.id,
        budgetAmount: Math.round(parseFloat(budgetAmount) * 100),
        dailyBudget: Math.round(parseFloat(dailyBudget) * 100),
        cpmAmount: Math.round(parseFloat(cpmAmount) * 100),
        currency: selectedProduct.priceCurrency,
        startDate: now.toISOString(),
        endDate: in30Days.toISOString(),
      });
      await load();
      setSelectedProduct(null);
      setBudgetAmount('');
      setDailyBudget('');
      setCpmAmount('');
    } catch (err) {
      const message = err instanceof ApiClientError
        ? err.apiError.error
        : "Could not create the campaign. Please try again.";
      Alert.alert('Campaign not created', message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg, marginBottom: 10 }}>
        Your campaigns
      </Text>
      {promotions.length === 0 && <Text style={{ color: colors.goldMuted, marginBottom: 16 }}>No campaigns yet.</Text>}
      {promotions.map((promo) => (
        <View key={promo.id} style={{ flexDirection: 'row', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
          {promo.product.imageUrls[0] && <Image source={{ uri: promo.product.imageUrls[0] }} style={{ width: 44, height: 44, borderRadius: 6 }} />}
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.cream }}>{promo.product.name}</Text>
            <Text style={{ color: colors.goldMuted, fontSize: 12 }}>
              {promo.impressions} impressions · {promo.clicks} clicks · {formatMoney(promo.budgetAmount, promo.currency)} budget
            </Text>
          </View>
        </View>
      ))}

      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg, marginTop: 24, marginBottom: 10 }}>
        New campaign
      </Text>
      <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Product</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
        {products.map((p) => (
          <Pressable
            key={p.id}
            onPress={() => setSelectedProduct(p)}
            style={{
              marginRight: 10, padding: 6, borderRadius: 8, borderWidth: 1,
              borderColor: selectedProduct?.id === p.id ? colors.gold : colors.goldMuted,
            }}
          >
            {p.imageUrls[0] && <Image source={{ uri: p.imageUrls[0] }} style={{ width: 60, height: 60, borderRadius: 6 }} />}
            <Text numberOfLines={1} style={{ color: colors.cream, fontSize: 11, width: 60, marginTop: 4 }}>{p.name}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <BudgetInput label={`Total budget${selectedProduct ? ` (${selectedProduct.priceCurrency})` : ''}`} value={budgetAmount} onChangeText={setBudgetAmount} />
      <BudgetInput label="Daily budget" value={dailyBudget} onChangeText={setDailyBudget} />
      <BudgetInput label="CPM (cost per 1,000 impressions)" value={cpmAmount} onChangeText={setCpmAmount} />

      {submitting ? <ActivityIndicator color={colors.gold} /> : <PrimaryButton label="Create campaign" onPress={submit} />}
    </ScrollView>
  );
}

function BudgetInput({ label, value, onChangeText }: { label: string; value: string; onChangeText: (v: string) => void }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={{ color: colors.goldMuted, fontSize: 12, marginBottom: 4 }}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        keyboardType="decimal-pad"
        placeholder="0.00"
        placeholderTextColor={colors.goldMuted}
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 10, color: colors.cream }}
      />
    </View>
  );
}
