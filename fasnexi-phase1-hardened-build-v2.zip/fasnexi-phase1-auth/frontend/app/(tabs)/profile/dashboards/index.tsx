import { useCallback, useEffect, useState } from 'react';
import { View, Text, Pressable, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { authApi } from '../../../../packages/api-client/src/endpoints/auth';
import type { Role } from '../../../../packages/api-contracts/src/auth';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../../packages/ui/src/tokens/typography';

/**
 * Role dashboards hub (plan §7 step 11). Only shows a dashboard entry
 * for a role the user actually holds — reuses the roles data already
 * fetched by Settings' role switcher (Step 7) rather than a new concept.
 */
export default function DashboardsHubScreen() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await authApi.myRoles();
      setRoles(result.roles);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  const hasCreator = roles.includes('CREATOR');
  const hasVendor = roles.includes('VENDOR');
  const hasTailor = roles.includes('TAILOR');

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, padding: 16 }}>
      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl, marginBottom: 16 }}>
        Role dashboards
      </Text>

      {hasCreator && <Row label="Creator earnings" onPress={() => router.push('/(tabs)/profile/dashboards/creator')} />}
      {hasVendor && <Row label="Vendor dashboard" onPress={() => router.push('/(tabs)/profile/dashboards/vendor')} />}
      {hasVendor && <Row label="Promoted listings" onPress={() => router.push('/(tabs)/profile/dashboards/promotions')} />}
      {hasTailor && <Row label="Tailor order queue" onPress={() => router.push('/(tabs)/profile/dashboards/tailor')} />}

      {!hasCreator && !hasVendor && !hasTailor && (
        <Text style={{ color: colors.goldMuted }}>
          You don't hold a Creator, Vendor, or Tailor role yet — activate
          one from Settings to see a dashboard here.
        </Text>
      )}
    </View>
  );
}

function Row({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
      <Text style={{ color: colors.cream }}>{label}</Text>
    </Pressable>
  );
}
