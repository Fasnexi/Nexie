import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Pressable, TextInput, Alert } from 'react-native';
import { tailorDashboardApi } from '../../../../packages/api-client/src/endpoints/tailor';
import type { TailorQueueOrder } from '../../../../packages/api-contracts/src/tailor';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../../lib/money';
import { colors } from '../../../../packages/ui/src/tokens/colors';

/**
 * TAILOR-role queue (deferred from Step 9, built here per the plan's own
 * split between client-facing "Tailor Marketplace" and "Role dashboards
 * → Tailor dashboard"). Confirmed no client name/username is available
 * in this response (see tailor.ts's contract notes) — shows the raw
 * clientId rather than fabricating a name lookup.
 */
export default function TailorQueueScreen() {
  const [orders, setOrders] = useState<TailorQueueOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [quotingId, setQuotingId] = useState<string | null>(null);
  const [quoteAmount, setQuoteAmount] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await tailorDashboardApi.queue();
      setOrders(result.orders);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const submitQuote = async (order: TailorQueueOrder) => {
    const amount = Math.round(parseFloat(quoteAmount) * 100);
    if (!amount || amount <= 0) {
      Alert.alert('Enter an amount', 'What should this order cost?');
      return;
    }
    setBusyId(order.id);
    try {
      await tailorDashboardApi.provideQuote(order.id, amount, order.currency);
      setQuotingId(null);
      setQuoteAmount('');
      await load();
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : "Couldn't send the quote.";
      Alert.alert('Not sent', message);
    } finally {
      setBusyId(null);
    }
  };

  const advanceStatus = async (order: TailorQueueOrder, status: 'FULFILLING' | 'SHIPPED' | 'DELIVERED') => {
    setBusyId(order.id);
    try {
      await tailorDashboardApi.updateStatus(order.id, status);
      await load();
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : "Couldn't update this order.";
      Alert.alert('Not updated', message);
    } finally {
      setBusyId(null);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={orders}
      keyExtractor={(item: TailorQueueOrder) => item.id}
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No orders in your queue.</Text>
        </View>
      }
      renderItem={({ item }: { item: TailorQueueOrder }) => (
        <View style={{ padding: 14, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
          <Text numberOfLines={2} style={{ color: colors.cream }}>{item.brief}</Text>
          <Text style={{ color: colors.goldMuted, fontSize: 11, marginTop: 2 }}>from client {item.clientId.slice(0, 8)}…</Text>
          <Text style={{ color: colors.gold, fontSize: 12, marginTop: 4 }}>{item.status}</Text>

          {item.status === 'PENDING' && quotingId !== item.id && (
            <Pressable onPress={() => setQuotingId(item.id)} style={{ marginTop: 8 }}>
              <Text style={{ color: colors.gold }}>Send a quote</Text>
            </Pressable>
          )}
          {item.status === 'PENDING' && quotingId === item.id && (
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, alignItems: 'center' }}>
              <TextInput
                value={quoteAmount}
                onChangeText={setQuoteAmount}
                placeholder={`Amount (${item.currency})`}
                placeholderTextColor={colors.goldMuted}
                keyboardType="decimal-pad"
                style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 6, padding: 8, color: colors.cream, flex: 1 }}
              />
              <Pressable onPress={() => submitQuote(item)} disabled={busyId === item.id}>
                <Text style={{ color: colors.gold }}>{busyId === item.id ? '…' : 'Send'}</Text>
              </Pressable>
            </View>
          )}

          {item.status === 'PAID' && (
            <Pressable onPress={() => advanceStatus(item, 'FULFILLING')} disabled={busyId === item.id} style={{ marginTop: 8 }}>
              <Text style={{ color: colors.gold }}>{busyId === item.id ? '…' : 'Start production'}</Text>
            </Pressable>
          )}
          {item.status === 'FULFILLING' && (
            <Pressable onPress={() => advanceStatus(item, 'SHIPPED')} disabled={busyId === item.id} style={{ marginTop: 8 }}>
              <Text style={{ color: colors.gold }}>{busyId === item.id ? '…' : 'Mark shipped'}</Text>
            </Pressable>
          )}
          {item.status === 'SHIPPED' && (
            <Pressable onPress={() => advanceStatus(item, 'DELIVERED')} disabled={busyId === item.id} style={{ marginTop: 8 }}>
              <Text style={{ color: colors.gold }}>{busyId === item.id ? '…' : 'Mark delivered'}</Text>
            </Pressable>
          )}

          {item.quoteAmount !== null && (
            <Text style={{ color: colors.goldMuted, fontSize: 12, marginTop: 4 }}>
              Quoted: {formatMoney(item.quoteAmount, item.currency)}
            </Text>
          )}
        </View>
      )}
    />
  );
}
