import { Stack } from 'expo-router';
import { colors } from '../../../../packages/ui/src/tokens/colors';

export default function WardrobeLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Wardrobe' }} />
      <Stack.Screen name="upload" options={{ title: 'Add item' }} />
      <Stack.Screen name="[id]" options={{ title: 'Item' }} />
      <Stack.Screen name="gaps" options={{ title: 'Gap analysis' }} />
    </Stack>
  );
}
