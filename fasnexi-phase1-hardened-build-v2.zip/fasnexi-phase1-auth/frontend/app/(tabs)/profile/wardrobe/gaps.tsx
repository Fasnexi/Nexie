import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Pressable } from 'react-native';
import { gapsApi } from '../../../../packages/api-client/src/endpoints/gaps';
import type { GapItem } from '../../../../packages/api-contracts/src/gaps';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

/**
 * GapItem has no `id` field on the wire (confirmed — see gaps.ts contract
 * notes), so list keys use category+occasion instead.
 */
function gapKey(g: GapItem) {
  return `${g.category}::${g.occasion}`;
}

export default function GapAnalysisScreen() {
  const [gaps, setGaps] = useState<GapItem[]>([]);
  const [analysedAt, setAnalysedAt] = useState<string | null>(null);
  const [wellCovered, setWellCovered] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [rateLimitNotice, setRateLimitNotice] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await gapsApi.current();
      setGaps(result.gaps);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const analyze = async () => {
    setAnalyzing(true);
    setRateLimitNotice(false);
    const previousAnalysedAt = analysedAt;
    try {
      const result = await gapsApi.analyze();
      setGaps(result.gaps);
      setWellCovered(result.wellCoveredOccasions);
      // The backend silently returns the previous analysis unchanged if
      // called again within 24h (no error, no flag) — the only way to
      // tell is comparing timestamps ourselves. See gaps.ts contract notes.
      if (previousAnalysedAt && result.analysedAt === previousAnalysedAt) {
        setRateLimitNotice(true);
      }
      setAnalysedAt(result.analysedAt);
    } catch (err) {
      setError(err);
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={gaps}
      keyExtractor={gapKey}
      ListHeaderComponent={
        <View style={{ padding: 16 }}>
          <PrimaryButton
            label={analyzing ? 'Analyzing…' : 'Run fresh analysis'}
            onPress={analyze}
            disabled={analyzing}
          />
          {rateLimitNotice && (
            <Text style={{ color: colors.goldMuted, fontSize: 12, marginTop: 8 }}>
              Gap analysis only refreshes once every 24 hours — showing your
              last result{analysedAt ? ` from ${new Date(analysedAt).toLocaleString()}` : ''}.
            </Text>
          )}
          {wellCovered.length > 0 && (
            <Text style={{ color: colors.gold, marginTop: 12, fontSize: 13 }}>
              Well covered: {wellCovered.join(', ')}
            </Text>
          )}
        </View>
      }
      ListEmptyComponent={
        <View style={{ padding: 24 }}>
          <Text style={{ color: colors.goldMuted, textAlign: 'center' }}>
            No gaps to show. This is also what you'll see if your Style DNA
            occasions haven't been set yet — onboarding's answers aren't
            wired to a real profile endpoint yet, so gap analysis has
            nothing to compare your wardrobe against until that's fixed.
          </Text>
        </View>
      }
      renderItem={({ item }: { item: GapItem }) => (
        <View style={{ padding: 14, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
          <Text style={{ color: colors.cream, fontWeight: '600' }}>
            {item.category} for {item.occasion}
          </Text>
          <Text style={{ color: colors.goldMuted, fontSize: 13, marginTop: 2 }}>{item.reason}</Text>
          <Text style={{ color: colors.gold, fontSize: 12, marginTop: 4 }}>
            {item.currentCount}/{item.minimumNeeded} · priority {item.priority}
          </Text>
        </View>
      )}
    />
  );
}
