import { useState } from 'react';
import { View, Text, Image, Pressable, ActivityIndicator, ScrollView, TextInput, Alert, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { uploadToCloudinary } from '../../../../lib/cloudinary-upload';
import { wardrobeApi } from '../../../../packages/api-client/src/endpoints/wardrobe';
import type { GarmentCategory } from '../../../../packages/api-contracts/src/products';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

const CATEGORIES: GarmentCategory[] = ['TOP', 'BOTTOM', 'DRESS', 'OUTERWEAR', 'FOOTWEAR', 'ACCESSORY', 'BAG', 'TRADITIONAL', 'ACTIVEWEAR', 'SWIMWEAR', 'UNDERWEAR'];

/**
 * Upload flow (Cloudinary, plan §1.5a): pick a photo -> direct-to-Cloudinary
 * signed upload -> POST the resulting URL to /api/wardrobe.
 *
 * Web note, not solved here: `uploadToCloudinary`'s FormData usage assumes
 * React Native's {uri, name, type} file-object convention. On the Expo web
 * target, `expo-image-picker`'s result asset has a `uri` that's a blob:
 * URL, not a filesystem path — appending it into FormData the RN way
 * doesn't work in a browser; it needs `fetch(uri).then(r => r.blob())`
 * first. Flagged rather than silently broken: this screen works on
 * iOS/Android as built; web upload needs that extra step added.
 */
export default function WardrobeUploadScreen() {
  const [pickedUri, setPickedUri] = useState<string | null>(null);
  const [category, setCategory] = useState<GarmentCategory | undefined>(undefined);
  const [brand, setBrand] = useState('');
  const [colorLabel, setColorLabel] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Photo access needed', 'Allow photo library access to add wardrobe items.');
      return;
    }
    // NOT independently verified against installed package source (no
    // network in this sandbox to npm install and check) — unlike every
    // backend contract in this project, which was read directly. expo-
    // image-picker has been migrating away from `MediaTypeOptions` toward
    // a `mediaTypes: ['images']` array API across recent SDK versions;
    // `MediaTypeOptions.Images` has stayed backward-compatible through
    // that migration in every version I'm aware of, but confirm this
    // against the actual installed version once `npm install` runs for
    // real, rather than trusting this comment.
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      setPickedUri(result.assets[0].uri);
    }
  };

  const submit = async () => {
    if (!pickedUri || !category) {
      setError('Add a photo and pick a category first.');
      return;
    }
    setUploading(true);
    setError(null);
    try {
      if (Platform.OS === 'web') {
        throw new Error('Web upload needs a blob-conversion step not yet implemented — see this screen\'s header comment.');
      }
      const fileName = pickedUri.split('/').pop() ?? 'wardrobe-item.jpg';
      const upload = await uploadToCloudinary('wardrobe', {
        uri: pickedUri,
        name: fileName,
        type: 'image/jpeg',
      });
      await wardrobeApi.create({
        imageUrl: upload.secureUrl,
        thumbnailUrl: upload.thumbnailUrl,
        category,
        brand: brand || undefined,
        colorLabel: colorLabel || undefined,
      });
      router.replace('/(tabs)/profile/wardrobe');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      <Pressable
        onPress={pickImage}
        style={{
          aspectRatio: 1, borderRadius: 12, borderWidth: 1, borderColor: colors.goldMuted,
          alignItems: 'center', justifyContent: 'center', overflow: 'hidden', marginBottom: 20,
        }}
      >
        {pickedUri ? (
          <Image source={{ uri: pickedUri }} style={{ width: '100%', height: '100%' }} />
        ) : (
          <Text style={{ color: colors.goldMuted }}>Tap to choose a photo</Text>
        )}
      </Pressable>

      <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Category</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        {CATEGORIES.map((c) => (
          <Pressable
            key={c}
            onPress={() => setCategory(c)}
            style={{
              paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16,
              borderWidth: 1, borderColor: category === c ? colors.gold : colors.goldMuted,
              backgroundColor: category === c ? 'rgba(200,164,93,0.12)' : 'transparent',
            }}
          >
            <Text style={{ color: category === c ? colors.gold : colors.cream, fontSize: 12 }}>{c}</Text>
          </Pressable>
        ))}
      </View>

      <TextInput
        value={brand}
        onChangeText={setBrand}
        placeholder="Brand (optional)"
        placeholderTextColor={colors.goldMuted}
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, marginBottom: 12 }}
      />
      <TextInput
        value={colorLabel}
        onChangeText={setColorLabel}
        placeholder="Color (optional)"
        placeholderTextColor={colors.goldMuted}
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, marginBottom: 20 }}
      />

      {error && <Text style={{ color: '#e0654f', marginBottom: 12 }}>{error}</Text>}

      {uploading ? (
        <ActivityIndicator color={colors.gold} />
      ) : (
        <PrimaryButton label="Add to wardrobe" onPress={submit} />
      )}

      <Text style={{ color: colors.goldMuted, fontSize: 11, marginTop: 12, textAlign: 'center' }}>
        AI tagging runs automatically in the background after upload.
      </Text>
    </ScrollView>
  );
}
