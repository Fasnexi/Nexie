import { useCallback, useEffect, useState } from 'react';
import { View, Text, Image, ScrollView, Pressable, ActivityIndicator, Alert, TextInput } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { wardrobeApi } from '../../../../packages/api-client/src/endpoints/wardrobe';
import type { z } from 'zod';
import type { wardrobeItemDetailSchema } from '../../../../packages/api-contracts/src/wardrobe';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../../packages/ui/src/tokens/typography';

type WardrobeItemDetail = z.infer<typeof wardrobeItemDetailSchema>;

export default function WardrobeItemDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [item, setItem] = useState<WardrobeItemDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState<'wear' | 'retag' | 'archive' | 'notes' | null>(null);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const { item: i } = await wardrobeApi.detail(id);
      setItem(i);
      setNotes(i.notes ?? '');
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const recordWear = async () => {
    if (!id) return;
    setBusy('wear');
    try {
      await wardrobeApi.recordWear(id);
      await load();
    } catch {
      Alert.alert('Could not record wear', 'Please try again.');
    } finally {
      setBusy(null);
    }
  };

  const retag = async () => {
    if (!id) return;
    setBusy('retag');
    try {
      const { message } = await wardrobeApi.retag(id);
      Alert.alert('Re-tagging queued', message);
    } catch {
      Alert.alert("Couldn't queue re-tagging", 'Please try again.');
    } finally {
      setBusy(null);
    }
  };

  const saveNotes = async () => {
    if (!id) return;
    setBusy('notes');
    try {
      await wardrobeApi.update(id, { notes });
      await load();
    } catch {
      Alert.alert("Couldn't save notes", 'Please try again.');
    } finally {
      setBusy(null);
    }
  };

  const archive = async () => {
    if (!id) return;
    Alert.alert('Remove from wardrobe?', 'This archives the item — it stays in your order/outfit history.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove', style: 'destructive', onPress: async () => {
          setBusy('archive');
          try {
            await wardrobeApi.archive(id);
            router.back();
          } catch (err) {
            // The backend translates "active resale listing" to a real 409
            // with a real message — surface that verbatim. Anything else
            // (including the "item not found" case, which is an uncaught
            // 500 server-side — see wardrobe.ts contract notes) gets a
            // generic message rather than a fabricated specific reason.
            const status = err instanceof ApiClientError ? err.apiError.status : undefined;
            const message = status === 409 && err instanceof ApiClientError
              ? err.apiError.error
              : "Couldn't remove this item. Please try again.";
            Alert.alert('Not removed', message);
          } finally {
            setBusy(null);
          }
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error || !item) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }}>
      <Image source={{ uri: item.imageUrl }} style={{ width: '100%', aspectRatio: 1 }} />
      <View style={{ padding: 16 }}>
        <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl }}>
          {item.brand ?? item.category}
        </Text>
        <Text style={{ color: colors.goldMuted, marginTop: 2 }}>
          {[item.category, item.subcategory, item.colorLabel, item.size].filter(Boolean).join(' · ')}
        </Text>

        <View style={{ marginTop: 16 }}>
          {item.aiTagged ? (
            <View>
              <Text style={{ color: colors.gold, fontWeight: '600', marginBottom: 6 }}>AI tags</Text>
              {item.aiColors.length > 0 && <TagLine label="Colors" values={item.aiColors} />}
              {item.aiPattern && <TagLine label="Pattern" values={[item.aiPattern]} />}
              {item.aiOccasions.length > 0 && <TagLine label="Occasions" values={item.aiOccasions} />}
              {item.aiSeasons.length > 0 && <TagLine label="Seasons" values={item.aiSeasons} />}
              {item.aiStyleCategories.length > 0 && <TagLine label="Style" values={item.aiStyleCategories} />}
              {item.aiFormalityScore !== null && <TagLine label="Formality" values={[`${item.aiFormalityScore}/5`]} />}
            </View>
          ) : (
            <Text style={{ color: colors.goldMuted }}>AI tagging in progress — check back shortly.</Text>
          )}
          <Pressable onPress={retag} disabled={busy !== null} style={{ marginTop: 10 }}>
            <Text style={{ color: colors.gold, fontSize: 12 }}>{busy === 'retag' ? 'Queuing…' : 'Re-run AI tagging'}</Text>
          </Pressable>
        </View>

        <View style={{ marginTop: 16, flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: colors.cream }}>Worn {item.wearCount} time{item.wearCount === 1 ? '' : 's'}</Text>
          <Pressable onPress={recordWear} disabled={busy !== null}>
            <Text style={{ color: colors.gold }}>{busy === 'wear' ? 'Saving…' : "I wore this today"}</Text>
          </Pressable>
        </View>

        <Pressable
          onPress={() => router.push({ pathname: '/(tabs)/nexi/outfits', params: { wardrobeItemId: item.id } })}
          disabled={!item.aiTagged}
          style={{
            marginTop: 16, backgroundColor: colors.gold, paddingVertical: 12, borderRadius: 8,
            alignItems: 'center', opacity: item.aiTagged ? 1 : 0.4,
          }}
        >
          <Text style={{ color: colors.black, fontWeight: '700' }}>
            {item.aiTagged ? 'Style This' : 'Style This (waiting on AI tags)'}
          </Text>
        </Pressable>

        <Pressable
          onPress={() => router.push({
            pathname: '/(tabs)/profile/resale/list-item',
            params: { wardrobeItemId: item.id, imageUrl: item.imageUrl, category: item.category },
          })}
          style={{
            marginTop: 10, borderWidth: 1, borderColor: colors.gold, paddingVertical: 12, borderRadius: 8,
            alignItems: 'center',
          }}
        >
          <Text style={{ color: colors.gold, fontWeight: '700' }}>List for resale</Text>
        </Pressable>

        {item.outfitItems.length > 0 && (
          <View style={{ marginTop: 16 }}>
            <Text style={{ color: colors.cream, fontWeight: '600', marginBottom: 6 }}>Used in outfits</Text>
            {item.outfitItems.map((oi, idx) => (
              <Text key={oi.outfit.id ?? idx} style={{ color: colors.goldMuted, fontSize: 13 }}>
                {oi.outfit.name ?? oi.outfit.occasion ?? 'Outfit'}
              </Text>
            ))}
          </View>
        )}

        <Text style={{ color: colors.cream, marginTop: 20, marginBottom: 6, fontWeight: '600' }}>Notes</Text>
        <TextInput
          value={notes}
          onChangeText={setNotes}
          onBlur={saveNotes}
          multiline
          placeholder="Add a note…"
          placeholderTextColor={colors.goldMuted}
          style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, minHeight: 60 }}
        />

        <Pressable onPress={archive} disabled={busy !== null} style={{ marginTop: 24, alignItems: 'center' }}>
          <Text style={{ color: '#e0654f' }}>{busy === 'archive' ? 'Removing…' : 'Remove from wardrobe'}</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function TagLine({ label, values }: { label: string; values: string[] }) {
  return (
    <Text style={{ color: colors.goldMuted, fontSize: 13, marginBottom: 2 }}>
      {label}: <Text style={{ color: colors.cream }}>{values.join(', ')}</Text>
    </Text>
  );
}
