import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, Pressable, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { wardrobeApi } from '../../../../packages/api-client/src/endpoints/wardrobe';
import type { WardrobeItemSummary } from '../../../../packages/api-contracts/src/wardrobe';
import type { GarmentCategory } from '../../../../packages/api-contracts/src/products';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';

const PAGE_LIMIT = 40;
const CATEGORIES: GarmentCategory[] = ['TOP', 'BOTTOM', 'DRESS', 'OUTERWEAR', 'FOOTWEAR', 'ACCESSORY', 'BAG', 'TRADITIONAL', 'ACTIVEWEAR'];

/**
 * Grid view (plan §3: "Grid view, Item detail w/ AI tags, Upload flow
 * (Cloudinary), Gap analysis, 'You Already Own X' surfacing").
 *
 * "You Already Own X" is NOT built here — no distinct endpoint for it was
 * found anywhere in the backend (not in wardrobe, gaps, or nexi routes).
 * It reads like a UI treatment layered on top of Nexi's outfit-generation
 * output rather than its own data source, but that's a guess, not a
 * confirmed contract — not worth building against an assumption. Flagged
 * for whoever builds Nexi's outfit flow (§7 step 6) to confirm for real,
 * rather than fabricated here.
 */
export default function WardrobeGridScreen() {
  const [items, setItems] = useState<WardrobeItemSummary[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [category, setCategory] = useState<GarmentCategory | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const loadInitial = useCallback(async (cat: GarmentCategory | undefined) => {
    setLoading(true);
    setError(null);
    try {
      const page = await wardrobeApi.list({ category: cat, limit: PAGE_LIMIT });
      setItems(page.items);
      setCursor(page.nextCursor ?? undefined);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInitial(undefined);
  }, [loadInitial]);

  const onCategoryPress = (cat: GarmentCategory) => {
    const next = category === cat ? undefined : cat;
    setCategory(next);
    loadInitial(next);
  };

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await wardrobeApi.list({ category, cursor, limit: PAGE_LIMIT });
      setItems((prev: WardrobeItemSummary[]) => [...prev, ...page.items]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore, category]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={() => loadInitial(category)} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={items}
      keyExtractor={(item: WardrobeItemSummary) => item.id}
      numColumns={3}
      columnWrapperStyle={{ gap: 6, paddingHorizontal: 10 }}
      onEndReached={loadMore}
      onEndReachedThreshold={0.5}
      ListHeaderComponent={
        <View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 12 }}>
            <Pressable onPress={() => router.push('/(tabs)/profile/wardrobe/gaps')}>
              <Text style={{ color: colors.gold }}>Gap analysis</Text>
            </Pressable>
            <Pressable onPress={() => router.push('/(tabs)/profile/wardrobe/upload')}>
              <Text style={{ color: colors.gold, fontWeight: '700' }}>+ Add item</Text>
            </Pressable>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingHorizontal: 10, marginBottom: 10 }}>
            {CATEGORIES.map((c) => (
              <Pressable
                key={c}
                onPress={() => onCategoryPress(c)}
                style={{
                  paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, marginRight: 8,
                  borderWidth: 1, borderColor: category === c ? colors.gold : colors.goldMuted,
                  backgroundColor: category === c ? 'rgba(200,164,93,0.12)' : 'transparent',
                }}
              >
                <Text style={{ color: category === c ? colors.gold : colors.cream, fontSize: 12 }}>{c}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      }
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted, textAlign: 'center' }}>
            Nothing here yet — add a piece you own to get started.
          </Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: WardrobeItemSummary }) => (
        <Pressable
          onPress={() => router.push(`/(tabs)/profile/wardrobe/${item.id}`)}
          style={{ flex: 1 / 3, marginBottom: 8, aspectRatio: 1 }}
        >
          <Image source={{ uri: item.thumbnailUrl ?? item.imageUrl }} style={{ width: '100%', height: '100%', borderRadius: 6 }} />
          {!item.aiTagged && (
            <View style={{ position: 'absolute', bottom: 4, right: 4, backgroundColor: colors.black, borderRadius: 4, paddingHorizontal: 4 }}>
              <Text style={{ color: colors.goldMuted, fontSize: 9 }}>Tagging…</Text>
            </View>
          )}
        </Pressable>
      )}
    />
  );
}
