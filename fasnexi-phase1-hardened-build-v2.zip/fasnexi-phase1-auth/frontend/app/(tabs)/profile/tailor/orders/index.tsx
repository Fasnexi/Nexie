import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Pressable } from 'react-native';
import { router } from 'expo-router';
import { tailorApi } from '../../../../../packages/api-client/src/endpoints/tailor';
import type { CustomOrder } from '../../../../../packages/api-contracts/src/tailor';
import { ApiErrorView } from '../../../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../../../lib/money';
import { colors } from '../../../../../packages/ui/src/tokens/colors';

/**
 * GET /api/tailor/orders is role-aware — this covers the client-side
 * shape (activeRole !== TAILOR). It has no cursor pagination at all
 * (confirmed from getClientCustomOrders — a flat findMany with no take
 * limit), so there's no "load more" here; it's genuinely everything.
 */
export default function MyCustomOrdersScreen() {
  const [orders, setOrders] = useState<CustomOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await tailorApi.myOrders();
      setOrders(result.orders);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={orders}
      keyExtractor={(item: CustomOrder) => item.id}
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No custom orders yet.</Text>
        </View>
      }
      renderItem={({ item }: { item: CustomOrder }) => (
        <Pressable
          onPress={() => router.push(`/(tabs)/profile/tailor/orders/${item.id}`)}
          style={{ padding: 14, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}
        >
          <Text style={{ color: colors.cream }}>{item.tailor.businessName ?? 'Tailor'}</Text>
          <Text numberOfLines={1} style={{ color: colors.goldMuted, fontSize: 12, marginTop: 2 }}>{item.brief}</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
            <Text style={{ color: colors.gold, fontSize: 12 }}>{item.status}</Text>
            {item.quoteAmount !== null && (
              <Text style={{ color: colors.goldMuted, fontSize: 12 }}>{formatMoney(item.quoteAmount, item.currency)}</Text>
            )}
          </View>
        </Pressable>
      )}
    />
  );
}
