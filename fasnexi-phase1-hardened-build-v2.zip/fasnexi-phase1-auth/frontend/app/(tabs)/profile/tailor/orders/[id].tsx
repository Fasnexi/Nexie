import { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, ActivityIndicator, TextInput, Pressable, Platform, Linking, KeyboardAvoidingView } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { tailorApi } from '../../../../../packages/api-client/src/endpoints/tailor';
import type { CustomOrder, CustomOrderMessage } from '../../../../../packages/api-contracts/src/tailor';
import { GATEWAY_BY_CURRENCY } from '../../../../../packages/api-contracts/src/common';
import { ApiClientError } from '../../../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../../../lib/money';
import { colors } from '../../../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../../../lib/onboarding/OnboardingLayout';

/**
 * Custom order detail: brief/status, deposit payment (same Stripe-only
 * gate as resale purchase — confirmed from tailor/[id]/deposit/route.ts
 * hardcoding a raw Stripe session), and in-order messaging.
 *
 * No way to fetch a single custom order's fresh detail directly (no
 * `GET /api/tailor/:id` for an order) — this screen finds it in the
 * already-fetched "my orders" list by id instead of fabricating a
 * detail endpoint.
 */
export default function CustomOrderDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [order, setOrder] = useState<CustomOrder | null>(null);
  const [messages, setMessages] = useState<CustomOrderMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [depositing, setDepositing] = useState(false);
  const [messageBody, setMessageBody] = useState('');
  const [sending, setSending] = useState(false);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const [ordersResult, messagesResult] = await Promise.all([
        tailorApi.myOrders(),
        tailorApi.messages.list(id),
      ]);
      const found = ordersResult.orders.find((o) => o.id === id);
      if (!found) throw new Error('Order not found in your order list');
      setOrder(found);
      setMessages(messagesResult.messages);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const payDeposit = async () => {
    if (!id) return;
    setDepositing(true);
    try {
      const { url } = await tailorApi.payDeposit(id);
      if (Platform.OS === 'web') {
        window.location.href = url;
      } else {
        await Linking.openURL(url);
      }
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : "Couldn't start deposit payment.";
      setError(message);
    } finally {
      setDepositing(false);
    }
  };

  const sendMessage = async () => {
    if (!id || !messageBody.trim()) return;
    setSending(true);
    try {
      const { message } = await tailorApi.messages.send(id, messageBody.trim());
      setMessages((prev: CustomOrderMessage[]) => [...prev, message]);
      setMessageBody('');
    } catch {
      // leave the draft in place so the user can retry
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error || !order) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  const gateway = GATEWAY_BY_CURRENCY[order.currency];
  const depositPayable = order.status === 'PAYMENT_PROCESSING' && order.quoteAmount !== null && !order.depositPaid;
  const depositCurrencySupported = gateway === 'stripe';

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.black }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: colors.cream, fontSize: 18, fontWeight: '700' }}>{order.tailor.businessName ?? 'Tailor'}</Text>
        <Text style={{ color: colors.goldMuted, marginTop: 4 }}>{order.brief}</Text>
        <Text style={{ color: colors.gold, marginTop: 10 }}>{order.status}</Text>
        {order.quoteAmount !== null && (
          <Text style={{ color: colors.cream, marginTop: 4 }}>
            Quote: {formatMoney(order.quoteAmount, order.currency)} {order.depositPaid ? '(deposit paid)' : ''}
          </Text>
        )}

        {depositPayable && !depositCurrencySupported && (
          <Text style={{ color: colors.gold, fontSize: 12, marginTop: 10 }}>
            This quote is in {order.currency}, and deposit checkout only
            supports Stripe-routed currencies (USD, EUR, GBP, EGP) right
            now — paying the deposit isn't available yet.
          </Text>
        )}
        {depositPayable && depositCurrencySupported && (
          <View style={{ marginTop: 14 }}>
            {depositing ? <ActivityIndicator color={colors.gold} /> : <PrimaryButton label="Pay deposit" onPress={payDeposit} />}
          </View>
        )}

        <Text style={{ color: colors.cream, fontWeight: '600', marginTop: 24, marginBottom: 10 }}>Messages</Text>
        {messages.length === 0 && <Text style={{ color: colors.goldMuted }}>No messages yet.</Text>}
        {messages.map((m) => (
          <View key={m.id} style={{ marginBottom: 10, padding: 10, borderRadius: 8, backgroundColor: 'rgba(214,199,178,0.08)' }}>
            <Text style={{ color: colors.cream }}>{m.body}</Text>
            <Text style={{ color: colors.goldMuted, fontSize: 10, marginTop: 4 }}>{new Date(m.createdAt).toLocaleString()}</Text>
          </View>
        ))}
      </ScrollView>

      <View style={{ flexDirection: 'row', gap: 8, padding: 16 }}>
        <TextInput
          value={messageBody}
          onChangeText={setMessageBody}
          placeholder="Message the tailor…"
          placeholderTextColor={colors.goldMuted}
          style={{ flex: 1, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 10, color: colors.cream }}
        />
        <Pressable
          onPress={sendMessage}
          disabled={sending || !messageBody.trim()}
          style={{ justifyContent: 'center', paddingHorizontal: 16, backgroundColor: colors.gold, borderRadius: 8, opacity: sending || !messageBody.trim() ? 0.5 : 1 }}
        >
          <Text style={{ color: colors.black, fontWeight: '700' }}>Send</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
