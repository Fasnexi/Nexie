import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, Pressable, Modal, ScrollView, TextInput, Alert } from 'react-native';
import { router } from 'expo-router';
import { tailorApi } from '../../../../packages/api-client/src/endpoints/tailor';
import type { TailorListItem } from '../../../../packages/api-contracts/src/tailor';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../../packages/ui/src/tokens/typography';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

/**
 * Browse tailors + "Tailor profile" + brief submission, all in one
 * screen. There is no single-tailor detail endpoint anywhere (`:id` in
 * every tailor/[id]/* route is a CustomOrder id, not a TailorProfile id
 * — confirmed from the quote route's own comment), so a tailor's full
 * info is shown in a modal using the data already fetched by this
 * browse list, rather than navigating to a route with nothing to fetch.
 */
export default function TailorBrowseScreen() {
  const [tailors, setTailors] = useState<TailorListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [selected, setSelected] = useState<TailorListItem | null>(null);
  const [brief, setBrief] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await tailorApi.browse();
      setTailors(result.tailors);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const submitBrief = async () => {
    if (!selected || !brief.trim()) {
      Alert.alert('Add a brief', 'Describe what you want made.');
      return;
    }
    setSubmitting(true);
    try {
      await tailorApi.submitBrief({ tailorId: selected.id, brief: brief.trim() });
      setSelected(null);
      setBrief('');
      Alert.alert('Sent', `Your brief was sent to ${selected.businessName ?? selected.user.displayName}.`, [
        { text: 'View my orders', onPress: () => router.push('/(tabs)/profile/tailor/orders') },
        { text: 'OK' },
      ]);
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : "Couldn't send your brief.";
      Alert.alert('Not sent', message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <Pressable onPress={() => router.push('/(tabs)/profile/tailor/orders')} style={{ padding: 14, alignItems: 'flex-end' }}>
        <Text style={{ color: colors.gold }}>My custom orders</Text>
      </Pressable>
      <FlatList
        data={tailors}
        keyExtractor={(item: TailorListItem) => item.id}
        ListEmptyComponent={
          <View style={{ padding: 32, alignItems: 'center' }}>
            <Text style={{ color: colors.goldMuted }}>No verified tailors available right now.</Text>
          </View>
        }
        renderItem={({ item }: { item: TailorListItem }) => (
          <Pressable
            onPress={() => setSelected(item)}
            style={{ flexDirection: 'row', gap: 12, padding: 14, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}
          >
            {item.portfolioUrls[0] && (
              <Image source={{ uri: item.portfolioUrls[0] }} style={{ width: 56, height: 56, borderRadius: 8 }} />
            )}
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.cream }}>{item.businessName ?? item.user.displayName}</Text>
              <Text style={{ color: colors.goldMuted, fontSize: 12 }}>{item.city}, {item.country}</Text>
              <Text style={{ color: colors.gold, fontSize: 12 }}>
                ★ {item.ratingAvg.toFixed(1)} ({item.ratingCount}) · responds in ~{item.responseHours}h
              </Text>
            </View>
          </Pressable>
        )}
      />

      <Modal visible={selected !== null} animationType="slide" onRequestClose={() => setSelected(null)}>
        <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
          {selected && (
            <>
              <Pressable onPress={() => setSelected(null)} style={{ marginBottom: 12 }}>
                <Text style={{ color: colors.goldMuted }}>← Back</Text>
              </Pressable>
              <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl }}>
                {selected.businessName ?? selected.user.displayName}
              </Text>
              <Text style={{ color: colors.goldMuted, marginTop: 4 }}>{selected.city}, {selected.country}</Text>
              <Text style={{ color: colors.gold, marginTop: 4 }}>
                ★ {selected.ratingAvg.toFixed(1)} ({selected.ratingCount} reviews) · responds in ~{selected.responseHours}h
              </Text>
              {selected.specialties.length > 0 && (
                <Text style={{ color: colors.cream, marginTop: 10 }}>
                  Specialties: {selected.specialties.map((s) => s.replace(/_/g, ' ')).join(', ')}
                </Text>
              )}
              {selected.portfolioUrls.length > 0 && (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }}>
                  {selected.portfolioUrls.map((url, i) => (
                    <Image key={i} source={{ uri: url }} style={{ width: 100, height: 100, borderRadius: 8, marginRight: 8 }} />
                  ))}
                </ScrollView>
              )}

              <Text style={{ color: colors.cream, fontWeight: '600', marginTop: 24, marginBottom: 8 }}>
                Describe what you want made
              </Text>
              <TextInput
                value={brief}
                onChangeText={setBrief}
                placeholder="E.g. a custom Ankara dress for a wedding, size 10, navy and gold…"
                placeholderTextColor={colors.goldMuted}
                multiline
                style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, minHeight: 100, marginBottom: 16 }}
              />
              {submitting ? <ActivityIndicator color={colors.gold} /> : <PrimaryButton label="Send brief" onPress={submitBrief} />}
            </>
          )}
        </ScrollView>
      </Modal>
    </View>
  );
}
