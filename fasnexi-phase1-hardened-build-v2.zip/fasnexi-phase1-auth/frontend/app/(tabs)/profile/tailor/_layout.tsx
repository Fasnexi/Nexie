import { Stack } from 'expo-router';
import { colors } from '../../../../packages/ui/src/tokens/colors';

export default function TailorLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Tailor Marketplace' }} />
      <Stack.Screen name="orders/index" options={{ title: 'My custom orders' }} />
      <Stack.Screen name="orders/[id]" options={{ title: 'Order' }} />
    </Stack>
  );
}
