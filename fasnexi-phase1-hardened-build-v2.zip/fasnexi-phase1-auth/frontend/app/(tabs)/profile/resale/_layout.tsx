import { Stack } from 'expo-router';
import { colors } from '../../../../packages/ui/src/tokens/colors';

export default function ResaleLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Resale' }} />
      <Stack.Screen name="[id]" options={{ title: 'Listing' }} />
      <Stack.Screen name="list-item" options={{ title: 'List for resale' }} />
    </Stack>
  );
}
