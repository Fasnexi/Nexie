import { useState } from 'react';
import { View, Text, Image, ScrollView, ActivityIndicator, Platform, Linking } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { resaleApi } from '../../../../packages/api-client/src/endpoints/resale';
import { GATEWAY_BY_CURRENCY, type Currency } from '../../../../packages/api-contracts/src/common';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { formatMoney } from '../../../../lib/money';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

/**
 * No detail endpoint exists for a single listing — the browse response's
 * shape is all there is. This screen receives the listing's data as
 * route params (passed by the browse screen, which already fetched it)
 * rather than fabricate a second fetch that doesn't exist.
 *
 * Purchase currency gate: confirmed from resale/[id]/purchase/route.ts —
 * it hardcodes a raw Stripe session regardless of the listing's own
 * currency (the exact item the plan's own §0 flagged as an open product
 * decision). Only currencies that route to Stripe in this codebase
 * (USD/EUR/GBP/EGP) are offered a working purchase button here.
 */
export default function ResaleListingDetailScreen() {
  const params = useLocalSearchParams<{
    id: string; imageUrl: string; category: string; brand?: string;
    askingPrice: string; currency: string; condition: string; description?: string;
    sellerUsername: string;
  }>();
  const [purchasing, setPurchasing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currency = params.currency as Currency;
  const askingPrice = Number(params.askingPrice);
  const gateway = GATEWAY_BY_CURRENCY[currency];
  const purchasable = gateway === 'stripe';

  const purchase = async () => {
    setPurchasing(true);
    setError(null);
    try {
      const { url } = await resaleApi.purchase(params.id);
      if (Platform.OS === 'web') {
        window.location.href = url;
      } else {
        await Linking.openURL(url);
      }
    } catch (err) {
      // The route DOES translate "Cannot purchase your own listing" and
      // the reservation-lost case to real 400/409 {error} bodies — safe
      // to show verbatim. A nonexistent listing id ("Listing not found")
      // is NOT caught there though, and would be an uncaught 500 — the
      // generic fallback below covers that case.
      setError(err instanceof ApiClientError ? err.apiError.error : "Couldn't start checkout. Please try again.");
    } finally {
      setPurchasing(false);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }}>
      <Image source={{ uri: params.imageUrl }} style={{ width: '100%', aspectRatio: 1 }} />
      <View style={{ padding: 16 }}>
        <Text style={{ color: colors.cream, fontSize: 20, fontWeight: '700' }}>
          {params.brand || params.category}
        </Text>
        <Text style={{ color: colors.gold, fontSize: 18, marginTop: 4 }}>
          {formatMoney(askingPrice, currency)}
        </Text>
        <Text style={{ color: colors.goldMuted, marginTop: 2 }}>
          {params.condition.replace(/_/g, ' ')} · sold by @{params.sellerUsername}
        </Text>
        {params.description && <Text style={{ color: colors.cream, marginTop: 12 }}>{params.description}</Text>}

        {!purchasable && (
          <Text style={{ color: colors.gold, fontSize: 12, marginTop: 16 }}>
            This listing is priced in {currency}, and resale checkout only
            supports Stripe-routed currencies (USD, EUR, GBP, EGP) right
            now — purchasing this item isn't available yet. See this
            project's README for why.
          </Text>
        )}

        {error && <Text style={{ color: '#e0654f', marginTop: 12 }}>{error}</Text>}

        <View style={{ marginTop: 20 }}>
          {purchasing ? (
            <ActivityIndicator color={colors.gold} />
          ) : (
            <PrimaryButton
              label={purchasable ? 'Buy this item' : 'Currently unavailable'}
              onPress={purchase}
              disabled={!purchasable}
            />
          )}
        </View>
      </View>
    </ScrollView>
  );
}
