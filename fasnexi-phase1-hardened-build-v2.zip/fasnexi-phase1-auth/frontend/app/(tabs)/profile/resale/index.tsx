import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, Pressable, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { resaleApi } from '../../../../packages/api-client/src/endpoints/resale';
import type { ResaleListing, ResaleCondition } from '../../../../packages/api-contracts/src/resale';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../../lib/money';
import { colors } from '../../../../packages/ui/src/tokens/colors';

const PAGE_LIMIT = 24;
const CONDITIONS: ResaleCondition[] = ['NEW_WITH_TAGS', 'LIKE_NEW', 'GOOD', 'FAIR', 'POOR'];

/**
 * Browse listings (plan §3). No category filter here — confirmed dead
 * parameter server-side (see resale.ts contract notes); a control for it
 * would silently do nothing.
 */
export default function ResaleBrowseScreen() {
  const [listings, setListings] = useState<ResaleListing[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [condition, setCondition] = useState<ResaleCondition | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const loadInitial = useCallback(async (cond: ResaleCondition | undefined) => {
    setLoading(true);
    setError(null);
    try {
      const page = await resaleApi.browse({ condition: cond, limit: PAGE_LIMIT });
      setListings(page.listings);
      setCursor(page.nextCursor ?? undefined);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInitial(undefined);
  }, [loadInitial]);

  const onConditionPress = (c: ResaleCondition) => {
    const next = condition === c ? undefined : c;
    setCondition(next);
    loadInitial(next);
  };

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await resaleApi.browse({ condition, cursor, limit: PAGE_LIMIT });
      setListings((prev: ResaleListing[]) => [...prev, ...page.listings]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore, condition]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={() => loadInitial(condition)} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={listings}
      keyExtractor={(item: ResaleListing) => item.id}
      numColumns={2}
      columnWrapperStyle={{ gap: 10, paddingHorizontal: 12 }}
      onEndReached={loadMore}
      onEndReachedThreshold={0.4}
      ListHeaderComponent={
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ padding: 12 }}>
          {CONDITIONS.map((c) => (
            <Pressable
              key={c}
              onPress={() => onConditionPress(c)}
              style={{
                paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, marginRight: 8,
                borderWidth: 1, borderColor: condition === c ? colors.gold : colors.goldMuted,
                backgroundColor: condition === c ? 'rgba(200,164,93,0.12)' : 'transparent',
              }}
            >
              <Text style={{ color: condition === c ? colors.gold : colors.cream, fontSize: 12 }}>{c.replace(/_/g, ' ')}</Text>
            </Pressable>
          ))}
        </ScrollView>
      }
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No listings match right now.</Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: ResaleListing }) => (
        <Pressable
          onPress={() => router.push({
            pathname: '/(tabs)/profile/resale/[id]',
            params: {
              id: item.id,
              imageUrl: item.wardrobeItem.imageUrl,
              category: item.wardrobeItem.category,
              brand: item.wardrobeItem.brand ?? '',
              askingPrice: String(item.askingPrice),
              currency: item.currency,
              condition: item.condition,
              description: item.description ?? '',
              sellerUsername: item.seller.username,
            },
          })}
          style={{ flex: 1, marginBottom: 12 }}
        >
          <Image source={{ uri: item.wardrobeItem.imageUrl }} style={{ width: '100%', aspectRatio: 0.8, borderRadius: 8 }} />
          <Text numberOfLines={1} style={{ color: colors.cream, marginTop: 6 }}>
            {item.wardrobeItem.brand ?? item.wardrobeItem.category}
          </Text>
          <Text style={{ color: colors.gold }}>{formatMoney(item.askingPrice, item.currency)}</Text>
          <Text style={{ color: colors.goldMuted, fontSize: 11 }}>{item.condition.replace(/_/g, ' ')}</Text>
        </Pressable>
      )}
    />
  );
}
