import { useState } from 'react';
import { View, Text, Image, TextInput, ActivityIndicator, Pressable, Alert, ScrollView } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { resaleApi } from '../../../../packages/api-client/src/endpoints/resale';
import type { ResaleCondition } from '../../../../packages/api-contracts/src/resale';
import type { Currency } from '../../../../packages/api-contracts/src/common';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { formatMoney } from '../../../../lib/money';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

const CONDITIONS: ResaleCondition[] = ['NEW_WITH_TAGS', 'LIKE_NEW', 'GOOD', 'FAIR', 'POOR'];
const CURRENCIES: Currency[] = ['USD', 'EUR', 'GBP', 'NGN', 'GHS', 'ZAR', 'KES', 'XOF', 'XAF', 'EGP'];

/**
 * List-an-item flow (plan §3), reached from a Wardrobe item's detail
 * screen. There's no "my listings" endpoint anywhere to manage this
 * listing again later (see resale.ts contract notes) — so right after a
 * successful create, this screen shows the new listing with a Withdraw
 * button immediately, since that's the only moment the client reliably
 * has the listing's id to act on it.
 */
export default function ListForResaleScreen() {
  const { wardrobeItemId, imageUrl, category } = useLocalSearchParams<{ wardrobeItemId: string; imageUrl: string; category: string }>();
  const [askingPrice, setAskingPrice] = useState('');
  const [currency, setCurrency] = useState<Currency>('USD');
  const [condition, setCondition] = useState<ResaleCondition | undefined>(undefined);
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [created, setCreated] = useState<{ id: string; sellerReceivesAmount: number; platformFeeAmount: number } | null>(null);
  const [withdrawing, setWithdrawing] = useState(false);

  const submit = async () => {
    const priceMinorUnits = Math.round(parseFloat(askingPrice) * 100);
    if (!priceMinorUnits || priceMinorUnits <= 0 || !condition) {
      Alert.alert('Missing details', 'Enter a price and pick a condition.');
      return;
    }
    setSubmitting(true);
    try {
      const { listing } = await resaleApi.create({
        wardrobeItemId, askingPrice: priceMinorUnits, currency, condition, description: description || undefined,
      });
      setCreated(listing);
    } catch (err) {
      const message = err instanceof ApiClientError ? err.apiError.error : "Couldn't create the listing.";
      Alert.alert('Not listed', message);
    } finally {
      setSubmitting(false);
    }
  };

  const withdraw = async () => {
    if (!created) return;
    setWithdrawing(true);
    try {
      await resaleApi.withdraw(created.id);
      router.back();
    } catch {
      Alert.alert("Couldn't withdraw", 'Please try again.');
    } finally {
      setWithdrawing(false);
    }
  };

  if (created) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, padding: 16, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: colors.gold, fontSize: 20, fontWeight: '700', marginBottom: 8 }}>Listed!</Text>
        <Text style={{ color: colors.cream, textAlign: 'center' }}>
          You'll receive {formatMoney(created.sellerReceivesAmount, currency)} after the platform fee
          ({formatMoney(created.platformFeeAmount, currency)}).
        </Text>
        <Pressable onPress={withdraw} disabled={withdrawing} style={{ marginTop: 24 }}>
          <Text style={{ color: '#e0654f' }}>{withdrawing ? 'Withdrawing…' : 'Withdraw this listing'}</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      {imageUrl && <Image source={{ uri: imageUrl }} style={{ width: '100%', aspectRatio: 1, borderRadius: 10, marginBottom: 16 }} />}
      <Text style={{ color: colors.goldMuted, marginBottom: 16 }}>{category}</Text>

      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
        <TextInput
          value={askingPrice}
          onChangeText={setAskingPrice}
          placeholder="Price"
          placeholderTextColor={colors.goldMuted}
          keyboardType="decimal-pad"
          style={{ flex: 1, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream }}
        />
        <View style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, justifyContent: 'center', paddingHorizontal: 10 }}>
          <Text style={{ color: colors.cream }}>{currency}</Text>
        </View>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
        {CURRENCIES.map((c) => (
          <Pressable
            key={c}
            onPress={() => setCurrency(c)}
            style={{ paddingVertical: 4, paddingHorizontal: 10, borderRadius: 12, borderWidth: 1, borderColor: currency === c ? colors.gold : colors.goldMuted }}
          >
            <Text style={{ color: currency === c ? colors.gold : colors.goldMuted, fontSize: 11 }}>{c}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={{ color: colors.cream, marginBottom: 8, fontWeight: '600' }}>Condition</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        {CONDITIONS.map((c) => (
          <Pressable
            key={c}
            onPress={() => setCondition(c)}
            style={{
              paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16,
              borderWidth: 1, borderColor: condition === c ? colors.gold : colors.goldMuted,
              backgroundColor: condition === c ? 'rgba(200,164,93,0.12)' : 'transparent',
            }}
          >
            <Text style={{ color: condition === c ? colors.gold : colors.cream, fontSize: 12 }}>{c.replace(/_/g, ' ')}</Text>
          </Pressable>
        ))}
      </View>

      <TextInput
        value={description}
        onChangeText={setDescription}
        placeholder="Description (optional)"
        placeholderTextColor={colors.goldMuted}
        multiline
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, minHeight: 70, marginBottom: 20 }}
      />

      {submitting ? <ActivityIndicator color={colors.gold} /> : <PrimaryButton label="List item" onPress={submit} />}
    </ScrollView>
  );
}
