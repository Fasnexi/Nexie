import { useEffect, useState } from 'react';
import { View, Text, Pressable } from 'react-native';
import { router } from 'expo-router';
import { notificationsApi } from '../../../packages/api-client/src/endpoints/notifications';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';

/**
 * Profile: view/edit, role switcher, settings, role dashboards, and the
 * Wardrobe/Loyalty/Resale/Tailor Marketplace sub-sections (plan §2).
 * Wardrobe (step 5) and Notifications/Settings (step 7) are built out —
 * the rest are later steps. "Wallet" is intentionally absent —
 * Investor-only, Phase 7 (§1.5b).
 */
export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const [unreadCount, setUnreadCount] = useState<number | null>(null);

  useEffect(() => {
    notificationsApi.list({ limit: 1 }).then((r) => setUnreadCount(r.unreadCount)).catch(() => setUnreadCount(null));
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, padding: 16, paddingTop: insets.top + 16 }}>
      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'], marginBottom: 20 }}>
        Profile
      </Text>

      <MenuRow label="Wardrobe" onPress={() => router.push('/(tabs)/profile/wardrobe')} />
      <MenuRow
        label="Notifications"
        onPress={() => router.push('/(tabs)/profile/notifications')}
        note={unreadCount ? String(unreadCount) : undefined}
      />
      <MenuRow label="Settings" onPress={() => router.push('/(tabs)/profile/settings')} />
      <MenuRow label="Loyalty" onPress={() => router.push('/(tabs)/profile/loyalty')} />
      <MenuRow label="Resale" onPress={() => router.push('/(tabs)/profile/resale')} />
      <MenuRow label="Tailor Marketplace" onPress={() => router.push('/(tabs)/profile/tailor')} />
      <MenuRow label="Role dashboards" onPress={() => router.push('/(tabs)/profile/dashboards')} />
    </View>
  );
}

function MenuRow({ label, onPress, disabled, note }: { label: string; onPress: () => void; disabled?: boolean; note?: string }) {
  return (
    <Pressable
      onPress={disabled ? undefined : onPress}
      style={{
        flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
        paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: colors.goldMuted, opacity: disabled ? 0.5 : 1,
      }}
    >
      <Text style={{ color: colors.cream }}>{label}</Text>
      <Text style={{ color: note && !disabled ? colors.gold : colors.goldMuted, fontSize: 12 }}>{note ?? '›'}</Text>
    </Pressable>
  );
}
