import { useCallback, useEffect, useState } from 'react';
import { View, Text, Pressable, ActivityIndicator, ScrollView, TextInput, Alert } from 'react-native';
import { router } from 'expo-router';
import { loyaltyApi } from '../../../../packages/api-client/src/endpoints/loyalty';
import type { LoyaltyTier } from '../../../../packages/api-contracts/src/loyalty';
import type { LoyaltyAccount } from '../../../../packages/api-contracts/src/loyalty';
import { ApiClientError } from '../../../../packages/api-client/src/client';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../../packages/ui/src/tokens/typography';
import { PrimaryButton } from '../../../../lib/onboarding/OnboardingLayout';

/**
 * Tier thresholds are hardcoded here from the confirmed constant in
 * loyalty/service.ts (Bronze 0 / Silver 500 / Gold 2000 / Platinum 5000)
 * — the API only returns `nextTier.pointsNeeded`, not the current tier's
 * own threshold, so computing a progress bar needs this. Safe to
 * hardcode: these are stable program-design constants, not something
 * likely to drift silently, and unlike currency/gateway logic, a stale
 * progress bar is a minor display issue, not a financial-correctness one.
 */
const TIER_THRESHOLDS: Record<LoyaltyTier, number> = { BRONZE: 0, SILVER: 500, GOLD: 2000, PLATINUM: 5000 };

export default function LoyaltyScreen() {
  const [account, setAccount] = useState<LoyaltyAccount | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [redeemAmount, setRedeemAmount] = useState('');
  const [redeeming, setRedeeming] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setAccount(await loyaltyApi.account());
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const redeem = async () => {
    const points = parseInt(redeemAmount, 10);
    if (!points || points <= 0) {
      Alert.alert('Enter an amount', 'How many points would you like to redeem?');
      return;
    }
    setRedeeming(true);
    try {
      await loyaltyApi.redeem(points, 'Redeemed in app');
      setRedeemAmount('');
      await load();
      Alert.alert('Redeemed', `${points} points redeemed.`);
    } catch (err) {
      // This route DOES translate its business error ("Insufficient
      // points: have X, requested Y") into a real 400 {error} — safe to
      // show verbatim, unlike the uncaught-500 cases elsewhere.
      const message = err instanceof ApiClientError ? err.apiError.error : "Couldn't redeem points.";
      Alert.alert('Not redeemed', message);
    } finally {
      setRedeeming(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error || !account) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  const currentThreshold = TIER_THRESHOLDS[account.tier];
  const nextThreshold = account.nextTier ? TIER_THRESHOLDS[account.nextTier.tier] : null;
  const progress = nextThreshold
    ? Math.min(1, (account.lifetimePoints - currentThreshold) / (nextThreshold - currentThreshold))
    : 1;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      <Text style={{ color: colors.gold, fontFamily: fontFamily.heading, fontSize: fontSize['3xl'] }}>
        {account.tier}
      </Text>
      <Text style={{ color: colors.cream, marginTop: 4 }}>{account.points} points available</Text>

      <View style={{ height: 6, backgroundColor: colors.goldMuted, borderRadius: 3, marginTop: 16, overflow: 'hidden' }}>
        <View style={{ height: '100%', width: `${progress * 100}%`, backgroundColor: colors.gold }} />
      </View>
      <Text style={{ color: colors.goldMuted, fontSize: 12, marginTop: 6 }}>
        {account.nextTier
          ? `${account.nextTier.pointsNeeded} lifetime points to ${account.nextTier.tier}`
          : "You've reached the highest tier."}
      </Text>

      <Pressable onPress={() => router.push('/(tabs)/profile/loyalty/history')} style={{ marginTop: 20 }}>
        <Text style={{ color: colors.gold }}>View points history</Text>
      </Pressable>

      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg, marginTop: 32, marginBottom: 10 }}>
        Redeem points
      </Text>
      <TextInput
        value={redeemAmount}
        onChangeText={setRedeemAmount}
        placeholder="Points to redeem"
        placeholderTextColor={colors.goldMuted}
        keyboardType="numeric"
        style={{ borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream, marginBottom: 12 }}
      />
      {redeeming ? (
        <ActivityIndicator color={colors.gold} />
      ) : (
        <PrimaryButton label="Redeem" onPress={redeem} />
      )}
      <Text style={{ color: colors.goldMuted, fontSize: 11, marginTop: 10 }}>
        Redeeming lowers your available points but never affects your tier
        — tier is based on lifetime points earned, which never decreases.
      </Text>
    </ScrollView>
  );
}
