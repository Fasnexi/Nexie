import { Stack } from 'expo-router';
import { colors } from '../../../../packages/ui/src/tokens/colors';

export default function LoyaltyLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.black },
        headerTintColor: colors.cream,
        contentStyle: { backgroundColor: colors.black },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Loyalty' }} />
      <Stack.Screen name="history" options={{ title: 'Points history' }} />
    </Stack>
  );
}
