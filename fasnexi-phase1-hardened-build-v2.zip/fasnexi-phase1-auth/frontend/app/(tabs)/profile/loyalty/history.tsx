import { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator } from 'react-native';
import { loyaltyApi } from '../../../../packages/api-client/src/endpoints/loyalty';
import type { LoyaltyTransaction } from '../../../../packages/api-contracts/src/loyalty';
import { ApiErrorView } from '../../../../lib/ApiErrorBoundary';
import { colors } from '../../../../packages/ui/src/tokens/colors';

const PAGE_LIMIT = 30;

export default function LoyaltyHistoryScreen() {
  const [transactions, setTransactions] = useState<LoyaltyTransaction[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);

  const loadInitial = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const page = await loyaltyApi.history({ limit: PAGE_LIMIT });
      setTransactions(page.transactions);
      setCursor(page.nextCursor ?? undefined);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInitial();
  }, [loadInitial]);

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await loyaltyApi.history({ cursor, limit: PAGE_LIMIT });
      setTransactions((prev: LoyaltyTransaction[]) => [...prev, ...page.transactions]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={loadInitial} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black }}
      data={transactions}
      keyExtractor={(item: LoyaltyTransaction) => item.id}
      onEndReached={loadMore}
      onEndReachedThreshold={0.4}
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No point activity yet.</Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: LoyaltyTransaction }) => (
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 14, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
          <View>
            <Text style={{ color: colors.cream }}>{item.reason}</Text>
            <Text style={{ color: colors.goldMuted, fontSize: 11, marginTop: 2 }}>
              {new Date(item.createdAt).toLocaleString()}
            </Text>
          </View>
          <Text style={{ color: item.delta > 0 ? colors.gold : colors.goldMuted, fontWeight: '600' }}>
            {item.delta > 0 ? '+' : ''}{item.delta}
          </Text>
        </View>
      )}
    />
  );
}
