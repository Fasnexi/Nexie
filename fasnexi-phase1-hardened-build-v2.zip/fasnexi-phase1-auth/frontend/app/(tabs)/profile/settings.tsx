import { useCallback, useEffect, useState } from 'react';
import { View, Text, Pressable, ActivityIndicator, ScrollView, Alert } from 'react-native';
import { authApi } from '../../../packages/api-client/src/endpoints/auth';
import { authClient } from '../../../lib/auth-client';
import type { Role } from '../../../packages/api-contracts/src/auth';
import { registerForPushNotifications, unregisterPushNotifications, type PushRegistrationResult } from '../../../lib/push-notifications';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';

/**
 * Confirmed from packages/auth/src/permissions/matrix.ts:
 *  - SELF_ACTIVATABLE_ROLES (no verification gate): CONSUMER, CREATOR, INVESTOR
 *  - VERIFICATION_REQUIRED_ROLES (self-activatable, write-locked until a
 *    moderator approves): VENDOR, DESIGNER, TAILOR, EVENT_ORGANIZER,
 *    SUSTAINABLE_PARTNER
 *  - STAFF_ONLY_ROLES (never self-activatable — the plugin's `before`
 *    hook 403s unconditionally): MODERATOR, ADMIN
 * These two are deliberately excluded from the offerable list below —
 * showing "Activate" next to ADMIN in a self-service settings screen
 * would be offering a button that's guaranteed to fail every time.
 */
const SELF_SERVICE_ROLES: Role[] = [
  'CONSUMER', 'CREATOR', 'INVESTOR',
  'VENDOR', 'DESIGNER', 'TAILOR', 'EVENT_ORGANIZER', 'SUSTAINABLE_PARTNER',
];

export default function SettingsScreen() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [activeRole, setActiveRole] = useState<Role | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<unknown>(null);
  const [busyRole, setBusyRole] = useState<Role | null>(null);

  const [pushState, setPushState] = useState<PushRegistrationResult | null>(null);
  const [pushBusy, setPushBusy] = useState(false);
  const [deviceTokenId, setDeviceTokenId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await authApi.myRoles();
      setRoles(result.roles);
      setActiveRole(result.activeRole);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const onRolePress = async (role: Role) => {
    setBusyRole(role);
    try {
      if (roles.includes(role)) {
        if (role === activeRole) return;
        const result = await authApi.switchRole(role);
        setActiveRole(result.activeRole);
      } else {
        const result = await authApi.activateRole(role);
        setRoles(result.roles);
        if (result.requiresVerification) {
          Alert.alert('Verification needed', `${role} needs profile verification before it's fully active.`);
        }
      }
    } catch {
      Alert.alert("Couldn't update role", 'Please try again.');
    } finally {
      setBusyRole(null);
    }
  };

  const onTogglePush = async () => {
    setPushBusy(true);
    try {
      if (deviceTokenId) {
        const ok = await unregisterPushNotifications(deviceTokenId);
        if (ok) {
          setDeviceTokenId(null);
          setPushState(null);
        }
      } else {
        const result = await registerForPushNotifications();
        setPushState(result);
        if (result.status === 'registered') setDeviceTokenId(result.deviceTokenId);
      }
    } finally {
      setPushBusy(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={load} />;
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.black }} contentContainerStyle={{ padding: 16 }}>
      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg, marginBottom: 12 }}>
        Roles
      </Text>
      {[...new Set([...SELF_SERVICE_ROLES, ...roles])].map((role) => {
        const held = roles.includes(role);
        const active = role === activeRole;
        const staffOnly = role === 'ADMIN' || role === 'MODERATOR';
        return (
          <Pressable
            key={role}
            onPress={staffOnly ? undefined : () => onRolePress(role)}
            disabled={busyRole !== null || staffOnly}
            style={{
              flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
              paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.goldMuted,
              opacity: staffOnly && !held ? 0.4 : 1,
            }}
          >
            <Text style={{ color: active ? colors.gold : colors.cream }}>{role}</Text>
            <Text style={{ color: colors.goldMuted, fontSize: 12 }}>
              {busyRole === role ? '…' : active ? 'Active' : staffOnly ? 'Staff-assigned only' : held ? 'Switch to' : 'Activate'}
            </Text>
          </Pressable>
        );
      })}

      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg, marginTop: 28, marginBottom: 12 }}>
        Notifications
      </Text>
      <Pressable
        onPress={onTogglePush}
        disabled={pushBusy}
        style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12 }}
      >
        <Text style={{ color: colors.cream }}>Push notifications</Text>
        <Text style={{ color: colors.gold, fontSize: 12 }}>
          {pushBusy ? '…' : deviceTokenId ? 'On — tap to turn off' : 'Off — tap to turn on'}
        </Text>
      </Pressable>
      {pushState && pushState.status !== 'registered' && (
        <Text style={{ color: colors.goldMuted, fontSize: 12, marginTop: 4 }}>
          {pushStateMessage(pushState)}
        </Text>
      )}

      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.lg, marginTop: 28, marginBottom: 12 }}>
        Account
      </Text>
      <Pressable
        onPress={async () => {
          try {
            await authClient.signOut();
          } catch {
            Alert.alert('Sign out failed', 'Please try again.');
          }
        }}
        style={{ paddingVertical: 12 }}
      >
        <Text style={{ color: colors.cream }}>Sign out</Text>
      </Pressable>
    </ScrollView>
  );
}

function pushStateMessage(state: PushRegistrationResult): string {
  switch (state.status) {
    case 'not-configured': return state.reason;
    case 'permission-denied': return 'Notification permission was denied — enable it in your device settings.';
    case 'unsupported-platform': return 'Push notifications on web need separate setup (VAPID keys) not configured here.';
    case 'error': return state.message;
    default: return '';
  }
}
