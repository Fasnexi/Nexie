import { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, Pressable, TextInput, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { productsApi } from '../../../packages/api-client/src/endpoints/products';
import { promotedProductsApi } from '../../../packages/api-client/src/endpoints/promoted-products';
import type { PromotedProduct } from '../../../packages/api-contracts/src/promoted-products';
import type { ProductSummary } from '../../../packages/api-contracts/src/products';
import { useCartStore, type CartState, type CartLine } from '../../../lib/cart-store';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../lib/money';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../../packages/ui/src/tokens/typography';

const PAGE_LIMIT = 20;

/** Shop: Catalog, cart, multi-currency checkout, order history (plan §7 step 4). */
export default function ShopScreen() {
  const insets = useSafeAreaInsets();
  const [products, setProducts] = useState<ProductSummary[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [promotions, setPromotions] = useState<PromotedProduct[]>([]);
  const [query, setQuery] = useState('');
  const [search, setSearch] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const impressioned = useRef(new Set<string>());
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const cartCount = useCartStore((s: CartState) => s.lines.reduce((n: number, l: CartLine) => n + l.quantity, 0));

  const loadInitial = useCallback(async (q = search) => {
    setLoading(true);
    setError(null);
    try {
      const [page, featured] = await Promise.all([
        productsApi.list({ limit: PAGE_LIMIT, sortBy: q ? 'popular' : 'newest', q: q || undefined }),
        promotedProductsApi.featured(6).catch(() => ({ promotions: [] })),
      ]);
      setProducts(page.products);
      setCursor(page.nextCursor ?? undefined);
      setPromotions(featured.promotions);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    const timer = setTimeout(() => loadInitial(search), search ? 350 : 0);
    return () => clearTimeout(timer);
  }, [search, loadInitial]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadInitial(search);
    setRefreshing(false);
  }, [loadInitial, search]);

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await productsApi.list({ cursor, limit: PAGE_LIMIT, sortBy: search ? 'popular' : 'newest', q: search || undefined });
      setProducts((prev: ProductSummary[]) => [...prev, ...page.products]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore, search]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={loadInitial} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black, paddingTop: insets.top }}
      data={products}
      keyExtractor={(item: ProductSummary) => item.id}
      numColumns={2}
      columnWrapperStyle={{ gap: 10, paddingHorizontal: 12 }}
      onEndReached={loadMore}
      onEndReachedThreshold={0.4}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.gold} />}
      ListHeaderComponent={
        <View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16 }}>
            <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'] }}>Shop</Text>
            <View style={{ flexDirection: 'row', gap: 16 }}>
              <Pressable onPress={() => router.push('/search')}><Text style={{ color: colors.cream }}>Search</Text></Pressable>
              <Pressable onPress={() => router.push('/events')}><Text style={{ color: colors.cream }}>Events</Text></Pressable>
              <Pressable onPress={() => router.push('/orders/history')}>
                <Text style={{ color: colors.goldMuted }}>Orders</Text>
              </Pressable>
              <Pressable onPress={() => router.push('/cart')}>
                <Text style={{ color: colors.gold, fontWeight: '700' }}>Cart{cartCount > 0 ? ` (${cartCount})` : ''}</Text>
              </Pressable>
            </View>
          </View>
          <View style={{ paddingHorizontal: 16, paddingBottom: 12 }}>
            <TextInput
              value={query}
              onChangeText={setQuery}
              onSubmitEditing={() => setSearch(query.trim())}
              placeholder="Search products"
              placeholderTextColor={colors.goldMuted}
              returnKeyType="search"
              style={{ backgroundColor: '#151515', color: colors.cream, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, borderWidth: 1, borderColor: colors.goldMuted }}
            />
          </View>
          {promotions.length > 0 && (
            <View style={{ paddingBottom: 14 }}>
              <Text style={{ color: colors.cream, fontWeight: '700', paddingHorizontal: 16, marginBottom: 8 }}>Featured for you</Text>
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={promotions}
                keyExtractor={(item) => item.id}
                contentContainerStyle={{ paddingHorizontal: 16, gap: 10 }}
                renderItem={({ item }) => (
                  <Pressable
                    style={{ width: 150 }}
                    onPress={() => { promotedProductsApi.click(item.id).catch(() => {}); router.push(`/product/${item.product.id}`); }}
                    onLayout={() => {
                      if (impressioned.current.has(item.id)) return;
                      impressioned.current.add(item.id);
                      promotedProductsApi.impression(item.id).catch(() => { impressioned.current.delete(item.id); });
                    }}
                  >
                    {item.product.imageUrls[0] && <Image source={{ uri: item.product.imageUrls[0] }} style={{ width: 150, height: 150, borderRadius: 8 }} />}
                    <Text numberOfLines={1} style={{ color: colors.cream, marginTop: 5 }}>{item.product.name}</Text>
                    <Text style={{ color: colors.gold }}>{formatMoney(item.product.priceAmount, item.product.priceCurrency)}</Text>
                    <Text style={{ color: colors.goldMuted, fontSize: 10, marginTop: 2 }}>Sponsored</Text>
                  </Pressable>
                )}
              />
            </View>
          )}
        </View>
      }
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No products yet — check back soon.</Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: ProductSummary }) => (
        <Pressable onPress={() => router.push(`/product/${item.slug}`)} style={{ flex: 1, marginBottom: 12 }}>
          {item.imageUrls[0] && (
            <Image source={{ uri: item.imageUrls[0] }} style={{ width: '100%', aspectRatio: 0.8, borderRadius: 8 }} />
          )}
          <Text numberOfLines={1} style={{ color: colors.cream, marginTop: 6 }}>{item.name}</Text>
          <Text style={{ color: colors.gold }}>{formatMoney(item.priceAmount, item.priceCurrency)}</Text>
        </Pressable>
      )}
    />
  );
}
