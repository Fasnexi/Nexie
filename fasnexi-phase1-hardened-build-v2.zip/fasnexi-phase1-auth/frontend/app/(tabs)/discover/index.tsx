import { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, Image, TextInput, ScrollView, Pressable } from 'react-native';
import { router } from 'expo-router';
import { productsApi } from '../../../packages/api-client/src/endpoints/products';
import { creatorsApi, challengesApi } from '../../../packages/api-client/src/endpoints/discover';
import type { ProductSummary, GarmentCategory } from '../../../packages/api-contracts/src/products';
import type { CreatorListItem, ChallengeListItem } from '../../../packages/api-contracts/src/discover';
import { ApiErrorView } from '../../../lib/ApiErrorBoundary';
import { formatMoney } from '../../../lib/money';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../../packages/ui/src/tokens/colors';

const PAGE_LIMIT = 20;
const CATEGORIES: GarmentCategory[] = ['TOP', 'BOTTOM', 'DRESS', 'OUTERWEAR', 'FOOTWEAR', 'ACCESSORY', 'BAG', 'TRADITIONAL', 'ACTIVEWEAR'];

/**
 * Discover: Browse (products/creators/challenges), search + filters.
 * Product search/filter/pagination wired to the corrected /api/products
 * contract (see packages/api-contracts/src/products.ts for what changed
 * from the Step 1 guess). Creators uses the bare-array response from
 * /api/creators (no pagination on that endpoint at all — confirmed from
 * source, not assumed).
 */
export default function DiscoverScreen() {
  const insets = useSafeAreaInsets();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<GarmentCategory | undefined>(undefined);
  const [products, setProducts] = useState<ProductSummary[]>([]);
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [creators, setCreators] = useState<CreatorListItem[]>([]);
  const [challenges, setChallenges] = useState<ChallengeListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadInitial = useCallback(async (q: string, cat: GarmentCategory | undefined) => {
    setLoading(true);
    setError(null);
    try {
      const [productPage, creatorsList, challengesPage] = await Promise.all([
        productsApi.list({ q: q || undefined, category: cat, limit: PAGE_LIMIT }),
        creatorsApi.topList(10),
        challengesApi.list({ status: 'ACTIVE', limit: 5 }),
      ]);
      setProducts(productPage.products);
      setCursor(productPage.nextCursor ?? undefined);
      setCreators(creatorsList);
      setChallenges(challengesPage.challenges);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInitial('', undefined);
  }, [loadInitial]);

  const onQueryChange = (text: string) => {
    setQuery(text);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => loadInitial(text, category), 350);
  };

  const onCategoryPress = (cat: GarmentCategory) => {
    const next = category === cat ? undefined : cat;
    setCategory(next);
    loadInitial(query, next);
  };

  const loadMore = useCallback(async () => {
    if (!cursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const page = await productsApi.list({ q: query || undefined, category, cursor, limit: PAGE_LIMIT });
      setProducts((prev: ProductSummary[]) => [...prev, ...page.products]);
      setCursor(page.nextCursor ?? undefined);
    } catch {
      // pagination errors are non-fatal — leave the existing list intact
    } finally {
      setLoadingMore(false);
    }
  }, [cursor, loadingMore, query, category]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.gold} />
      </View>
    );
  }

  if (error) {
    return <ApiErrorView error={error} onRetry={() => loadInitial(query, category)} />;
  }

  return (
    <FlatList
      style={{ backgroundColor: colors.black, paddingTop: insets.top }}
      data={products}
      keyExtractor={(item: ProductSummary) => item.id}
      numColumns={2}
      columnWrapperStyle={{ gap: 10, paddingHorizontal: 12 }}
      onEndReached={loadMore}
      onEndReachedThreshold={0.4}
      ListHeaderComponent={
        <View>
          <TextInput
            value={query}
            onChangeText={onQueryChange}
            placeholder="Search products…"
            placeholderTextColor={colors.goldMuted}
            style={{ margin: 12, borderWidth: 1, borderColor: colors.goldMuted, borderRadius: 8, padding: 12, color: colors.cream }}
          />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingHorizontal: 12, marginBottom: 12 }}>
            {CATEGORIES.map((c) => (
              <Pressable
                key={c}
                onPress={() => onCategoryPress(c)}
                style={{
                  paddingVertical: 6, paddingHorizontal: 12, borderRadius: 16, marginRight: 8,
                  borderWidth: 1, borderColor: category === c ? colors.gold : colors.goldMuted,
                  backgroundColor: category === c ? 'rgba(200,164,93,0.12)' : 'transparent',
                }}
              >
                <Text style={{ color: category === c ? colors.gold : colors.cream, fontSize: 12 }}>{c}</Text>
              </Pressable>
            ))}
          </ScrollView>

          {creators.length > 0 && (
            <View style={{ marginBottom: 16 }}>
              <SectionTitle text="Top creators" />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingHorizontal: 12 }}>
                {creators.map((c: CreatorListItem) => (
                  <View key={c.id} style={{ alignItems: 'center', width: 76, marginRight: 10 }}>
                    {c.avatarUrl ? (
                      <Image source={{ uri: c.avatarUrl }} style={{ width: 56, height: 56, borderRadius: 28 }} />
                    ) : (
                      <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: colors.beige, alignItems: 'center', justifyContent: 'center' }}>
                        <Text>{c.username[0]?.toUpperCase()}</Text>
                      </View>
                    )}
                    <Text numberOfLines={1} style={{ color: colors.cream, fontSize: 11, marginTop: 4 }}>{c.username}</Text>
                    <Text style={{ color: colors.goldMuted, fontSize: 10 }}>{c.followerCount} followers</Text>
                  </View>
                ))}
              </ScrollView>
            </View>
          )}

          {challenges.length > 0 && (
            <View style={{ marginBottom: 16 }}>
              <SectionTitle text="Active challenges" />
              {challenges.map((ch: ChallengeListItem) => (
                <Pressable
                  key={ch.id}
                  onPress={() => router.push(`/challenge/${ch.id}`)}
                  style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, gap: 10 }}
                >
                  {ch.coverUrl && <Image source={{ uri: ch.coverUrl }} style={{ width: 44, height: 44, borderRadius: 6 }} />}
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.cream }}>{ch.title}</Text>
                    <Text style={{ color: colors.goldMuted, fontSize: 12 }}>{ch._count.entries} entries</Text>
                  </View>
                </Pressable>
              ))}
            </View>
          )}

          <SectionTitle text="Products" />
        </View>
      }
      ListEmptyComponent={
        <View style={{ padding: 32, alignItems: 'center' }}>
          <Text style={{ color: colors.goldMuted }}>No products match — try a different search.</Text>
        </View>
      }
      ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.gold} style={{ margin: 16 }} /> : null}
      renderItem={({ item }: { item: ProductSummary }) => (
        <Pressable
          onPress={() => router.push(`/product/${item.slug}`)}
          style={{ flex: 1, marginBottom: 12 }}
        >
          {item.imageUrls[0] && (
            <Image source={{ uri: item.imageUrls[0] }} style={{ width: '100%', aspectRatio: 0.8, borderRadius: 8 }} />
          )}
          <Text numberOfLines={1} style={{ color: colors.cream, marginTop: 6 }}>{item.name}</Text>
          <Text style={{ color: colors.gold }}>{formatMoney(item.priceAmount, item.priceCurrency)}</Text>
          {!item.isInStock && <Text style={{ color: colors.goldMuted, fontSize: 11 }}>Out of stock</Text>}
        </Pressable>
      )}
    />
  );
}

function SectionTitle({ text }: { text: string }) {
  return (
    <Text style={{ color: colors.cream, fontWeight: '700', paddingHorizontal: 12, marginBottom: 8 }}>{text}</Text>
  );
}
