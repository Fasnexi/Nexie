import { useCallback, useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, Pressable, FlatList } from 'react-native';
import { router } from 'expo-router';
import { ordersApi } from '../../packages/api-client/src/endpoints/orders';
import type { Order } from '../../packages/api-contracts/src/orders';
import { ApiErrorView } from '../../lib/ApiErrorBoundary';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function OrderHistoryScreen() {
  const [orders, setOrders] = useState<Order[]>([]); const [loading, setLoading] = useState(true); const [error, setError] = useState<unknown>(null);
  const load = useCallback(async () => { setLoading(true); setError(null); try { setOrders((await ordersApi.list()).orders); } catch (e) { setError(e); } finally { setLoading(false); } }, []);
  useEffect(() => { load(); }, [load]);
  if (loading) return <View style={{ flex:1, backgroundColor:colors.black, alignItems:'center', justifyContent:'center' }}><ActivityIndicator color={colors.gold}/></View>;
  if (error) return <ApiErrorView error={error} onRetry={load}/>;
  return <FlatList data={orders} keyExtractor={o=>o.id} contentContainerStyle={{ padding:16, flexGrow:1, backgroundColor:colors.black }} ListEmptyComponent={<View style={{ flex:1, alignItems:'center', justifyContent:'center' }}><Text style={{ color:colors.cream }}>No orders yet.</Text></View>} renderItem={({item})=><Pressable onPress={()=>router.push(`/orders/${item.id}`)} style={{ padding:16, borderBottomWidth:1, borderBottomColor:colors.goldMuted }}><Text style={{ color:colors.cream, fontWeight:'700' }}>Order {item.id.slice(0,8)}</Text><Text style={{ color:colors.gold }}>{formatMoney(item.totalAmount,item.currency)}</Text><Text style={{ color:colors.goldMuted }}>{item.status} · {new Date(item.createdAt).toLocaleDateString()}</Text></Pressable>}/>;
}
