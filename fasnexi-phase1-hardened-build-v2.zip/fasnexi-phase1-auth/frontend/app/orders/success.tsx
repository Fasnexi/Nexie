import { useEffect, useState } from 'react';
import { View, Text, Pressable, ActivityIndicator } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { ordersApi } from '../../packages/api-client/src/endpoints/orders';
import { useCartStore } from '../../lib/cart-store';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function OrderSuccessScreen() {
  const params = useLocalSearchParams<{
    session_id?: string;
    reference?: string;
    tx_ref?: string;
    transaction_id?: string;
  }>();
  const clearCart = useCartStore((s) => s.clear);
  const checkoutKey = params.session_id ?? params.reference ?? params.tx_ref ?? params.transaction_id;
  const [state, setState] = useState<'loading' | 'pending' | 'error'>(checkoutKey ? 'loading' : 'pending');

  useEffect(() => {
    if (!checkoutKey) return;
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let attempts = 0;

    const poll = async () => {
      try {
        const result = await ordersApi.getByCheckoutSession(checkoutKey);
        if (cancelled) return;
        clearCart();
        router.replace(`/orders/${result.order.id}`);
        return;
      } catch {
        attempts += 1;
        if (attempts >= 8) {
          if (!cancelled) setState('pending');
          return;
        }
        timer = setTimeout(poll, 2000);
      }
    };

    void poll();
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [checkoutKey, clearCart]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      {state === 'loading' ? (
        <>
          <ActivityIndicator color={colors.gold} />
          <Text style={{ color: colors.goldMuted, marginTop: 12 }}>Confirming your order…</Text>
        </>
      ) : (
        <>
          <Text style={{ color: colors.gold, fontSize: 28, fontWeight: '700' }}>Payment received</Text>
          <Text style={{ color: colors.goldMuted, textAlign: 'center', marginTop: 12 }}>
            {state === 'pending'
              ? 'Your payment is still being confirmed. Your cart has been kept safe. Check Order History shortly.'
              : 'We could not confirm the order yet.'}
          </Text>
          <Pressable onPress={() => router.replace('/orders/history')} style={{ marginTop: 20 }}>
            <Text style={{ color: colors.gold }}>View Order History</Text>
          </Pressable>
        </>
      )}
    </View>
  );
}
