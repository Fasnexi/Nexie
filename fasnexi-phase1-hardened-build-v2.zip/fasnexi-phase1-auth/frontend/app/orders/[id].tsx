import { useCallback, useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, ScrollView } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { ordersApi } from '../../packages/api-client/src/endpoints/orders';
import type { Order } from '../../packages/api-contracts/src/orders';
import { ApiErrorView } from '../../lib/ApiErrorBoundary';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';

export default function OrderDetailScreen() {
  const { id } = useLocalSearchParams<{ id:string }>(); const [order,setOrder]=useState<Order|null>(null); const [loading,setLoading]=useState(true); const [error,setError]=useState<unknown>(null);
  const load=useCallback(async()=>{setLoading(true);setError(null);try{setOrder((await ordersApi.get(id)).order)}catch(e){setError(e)}finally{setLoading(false)}},[id]); useEffect(()=>{load()},[load]);
  if(loading)return <View style={{flex:1,backgroundColor:colors.black,alignItems:'center',justifyContent:'center'}}><ActivityIndicator color={colors.gold}/></View>; if(error||!order)return <ApiErrorView error={error} onRetry={load}/>;
  return <ScrollView style={{flex:1,backgroundColor:colors.black}} contentContainerStyle={{padding:16}}><Text style={{color:colors.gold,fontSize:24,fontWeight:'700'}}>Order {order.id.slice(0,8)}</Text><Text style={{color:colors.cream,marginVertical:8}}>{order.status}</Text>{order.items.map(i=><View key={i.id} style={{paddingVertical:12,borderBottomWidth:1,borderBottomColor:colors.goldMuted}}><Text style={{color:colors.cream}}>{i.product.name} × {i.quantity}</Text><Text style={{color:colors.goldMuted}}>{formatMoney(i.unitAmount,i.currency)} each</Text></View>)}<Text style={{color:colors.gold,fontSize:20,marginTop:20}}>Total {formatMoney(order.totalAmount,order.currency)}</Text>{order.trackingNumber&&<Text style={{color:colors.goldMuted,marginTop:8}}>Tracking: {order.trackingCarrier ?? ''} {order.trackingNumber}</Text>}</ScrollView>;
}
