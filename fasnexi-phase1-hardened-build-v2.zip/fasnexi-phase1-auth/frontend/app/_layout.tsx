import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { wireApiClient } from '../lib/auth-wiring';
import { useCartStore } from '../lib/cart-store';
import { colors } from '../packages/ui/src/tokens/colors';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://localhost:3000';

/**
 * Found missing in a full-app audit: no safe-area handling existed
 * anywhere in the app. `SafeAreaProvider` here is the required root wrap
 * for `useSafeAreaInsets` to work at all — applied surgically to the
 * highest-risk screens (the 5 tab roots with headerShown:false, whose
 * custom top content has nothing else protecting it from a notch/status
 * bar, and the video player modal's close button) rather than retrofit
 * every screen at once, which risks introducing layout bugs faster than
 * it can be verified without a real device to test on.
 */
export default function RootLayout() {
  const hydrateCart = useCartStore((s) => s.hydrate);

  useEffect(() => {
    wireApiClient(API_BASE_URL);
    void hydrateCart();
  }, [hydrateCart]);

  return (
    <SafeAreaProvider>
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: colors.black },
          headerTintColor: colors.cream,
          contentStyle: { backgroundColor: colors.black },
        }}
      >
        <Stack.Screen name="(auth)" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="challenge/[id]/index" options={{ title: 'Challenge' }} />
        <Stack.Screen name="challenge/[id]/enter" options={{ title: 'Enter challenge' }} />
        <Stack.Screen name="product/[slug]" options={{ title: 'Product' }} />
        <Stack.Screen name="post/[id]/comments" options={{ title: 'Comments' }} />
        <Stack.Screen name="user/[username]" options={{ title: 'Profile' }} />
        <Stack.Screen name="video" options={{ headerShown: false }} />
        <Stack.Screen name="cart/index" options={{ title: 'Cart' }} />
        <Stack.Screen name="checkout/index" options={{ title: 'Checkout' }} />
        <Stack.Screen name="orders/success" options={{ title: 'Order placed', headerBackVisible: false }} />
        <Stack.Screen name="orders/history" options={{ title: 'Your orders' }} />
        <Stack.Screen name="console" options={{ title: 'Console' }} />
      </Stack>
    </SafeAreaProvider>
  );
}
