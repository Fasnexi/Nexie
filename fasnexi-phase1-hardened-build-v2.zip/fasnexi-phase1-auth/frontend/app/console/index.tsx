import { useState } from 'react';
import { View, Text, Pressable, useWindowDimensions, Platform } from 'react-native';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';
import VendorDashboardScreen from '../(tabs)/profile/dashboards/vendor/index';
import VendorOrdersScreen from '../(tabs)/profile/dashboards/vendor/orders';
import PromotionsScreen from '../(tabs)/profile/dashboards/promotions';

type Section = 'dashboard' | 'orders' | 'promotions';

/**
 * Web admin "Console" (plan §2): a desktop-optimized shell (sidebar nav,
 * wider layout) that activates above a breakpoint, wrapping the SAME
 * Vendor dashboard/orders/promotions screens already built for mobile —
 * "same components, same API client, different shell chrome above a
 * breakpoint — not a second app," per the plan's own wording. Achieved
 * here by literally importing and rendering those screen components
 * inline rather than re-implementing their data-fetching logic a second
 * time for a "desktop version."
 *
 * Breakpoint is a plain width check via useWindowDimensions — real
 * responsive behavior, not just a Platform.OS === 'web' gate, so a
 * narrow browser window (or a tablet in portrait) correctly falls back
 * to directing the person to the mobile-shaped flow instead of squeezing
 * a sidebar layout into a phone-width screen.
 */
const DESKTOP_BREAKPOINT = 900;

export default function ConsoleScreen() {
  const { width } = useWindowDimensions();
  const [section, setSection] = useState<Section>('dashboard');
  const isDesktopWidth = width >= DESKTOP_BREAKPOINT;

  if (!isDesktopWidth) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <Text style={{ color: colors.cream, textAlign: 'center' }}>
          Console is designed for wider screens. On mobile, use Profile →
          Role dashboards for the same Vendor tools.
        </Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, flexDirection: 'row', backgroundColor: colors.black }}>
      <View style={{ width: 220, borderRightWidth: 1, borderRightColor: colors.goldMuted, padding: 20 }}>
        <Text style={{ color: colors.gold, fontFamily: fontFamily.heading, fontSize: fontSize.xl, marginBottom: 24 }}>
          Console
        </Text>
        <NavItem label="Dashboard" active={section === 'dashboard'} onPress={() => setSection('dashboard')} />
        <NavItem label="Orders" active={section === 'orders'} onPress={() => setSection('orders')} />
        <NavItem label="Promoted listings" active={section === 'promotions'} onPress={() => setSection('promotions')} />
      </View>
      <View style={{ flex: 1 }}>
        {section === 'dashboard' && <VendorDashboardScreen onViewOrders={() => setSection('orders')} />}
        {section === 'orders' && <VendorOrdersScreen />}
        {section === 'promotions' && <PromotionsScreen />}
      </View>
    </View>
  );
}

function NavItem({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ paddingVertical: 10 }}>
      <Text style={{ color: active ? colors.gold : colors.cream, fontWeight: active ? '700' : '400' }}>{label}</Text>
    </Pressable>
  );
}
