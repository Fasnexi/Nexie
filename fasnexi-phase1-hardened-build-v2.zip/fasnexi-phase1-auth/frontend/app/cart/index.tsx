import { View, Text, FlatList, Image, Pressable } from 'react-native';
import { router } from 'expo-router';
import { useCartStore, cartSubtotal, type CartState, type CartLine } from '../../lib/cart-store';
import { formatMoney } from '../../lib/money';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';
import { PrimaryButton } from '../../lib/onboarding/OnboardingLayout';

export default function CartScreen() {
  const lines = useCartStore((s: CartState) => s.lines);
  const setQuantity = useCartStore((s: CartState) => s.setQuantity);
  const removeItem = useCartStore((s: CartState) => s.removeItem);
  const subtotal = cartSubtotal(lines);
  const currency = lines[0]?.product.priceCurrency;

  if (lines.length === 0) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.black, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize.xl, marginBottom: 8 }}>
          Your cart is empty
        </Text>
        <Pressable onPress={() => router.push('/(tabs)/shop')}>
          <Text style={{ color: colors.gold }}>Browse the shop</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <FlatList
        data={lines}
        keyExtractor={(l: CartLine) => `${l.product.id}::${l.size ?? ''}::${l.color ?? ''}`}
        renderItem={({ item }: { item: CartLine }) => (
          <View style={{ flexDirection: 'row', padding: 12, gap: 12, borderBottomWidth: 1, borderBottomColor: colors.goldMuted }}>
            {item.product.imageUrls[0] && (
              <Image source={{ uri: item.product.imageUrls[0] }} style={{ width: 64, height: 64, borderRadius: 8 }} />
            )}
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.cream }}>{item.product.name}</Text>
              {(item.size || item.color) && (
                <Text style={{ color: colors.goldMuted, fontSize: 12 }}>
                  {[item.size, item.color].filter(Boolean).join(' · ')}
                </Text>
              )}
              <Text style={{ color: colors.gold, marginTop: 4 }}>
                {formatMoney(item.product.priceAmount, item.product.priceCurrency)}
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 6 }}>
                <QtyButton label="–" onPress={() => setQuantity(item.product.id, item.quantity - 1, item.size, item.color)} />
                <Text style={{ color: colors.cream }}>{item.quantity}</Text>
                <QtyButton label="+" onPress={() => setQuantity(item.product.id, item.quantity + 1, item.size, item.color)} />
                <Pressable onPress={() => removeItem(item.product.id, item.size, item.color)} style={{ marginLeft: 12 }}>
                  <Text style={{ color: colors.goldMuted, fontSize: 12 }}>Remove</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}
      />
      <View style={{ padding: 16, borderTopWidth: 1, borderTopColor: colors.goldMuted }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
          <Text style={{ color: colors.cream }}>Subtotal</Text>
          <Text style={{ color: colors.cream, fontWeight: '700' }}>
            {currency ? formatMoney(subtotal, currency) : '—'}
          </Text>
        </View>
        <PrimaryButton label="Checkout" onPress={() => router.push('/checkout')} />
      </View>
    </View>
  );
}

function QtyButton({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={{ width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: colors.goldMuted, alignItems: 'center', justifyContent: 'center' }}
    >
      <Text style={{ color: colors.cream }}>{label}</Text>
    </Pressable>
  );
}
