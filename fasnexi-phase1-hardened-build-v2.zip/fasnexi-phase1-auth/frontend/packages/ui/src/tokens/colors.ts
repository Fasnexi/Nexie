/**
 * FasNexi design tokens — colors
 * Source of truth: brand SVGs (wordmark on black, wordmark transparent,
 * FN monogram + lockup on black). See frontend plan §1.5.
 *
 * NOTE: #E8DCCB (beige) is provisional — it does not appear in the logo
 * files themselves. Flag for a designer check before shipping.
 */
export const colors = {
  black: '#0B0B0B', // primary background
  cream: '#F5F1EA', // primary text/ink on dark surfaces
  gold: '#C8A45D', // brand accent / monogram fill / CTA
  goldMuted: '#D6C7B2', // hairline divider color (from monogram lockup)
  beige: '#E8DCCB', // tertiary surface tone — PROVISIONAL, not in logo files
} as const;

export type ColorToken = keyof typeof colors;

/** Semantic aliases — screens should reference these, not raw hex */
export const semanticColors = {
  background: colors.black,
  surface: colors.beige,
  textPrimary: colors.cream,
  textOnLight: colors.black,
  accent: colors.gold,
  divider: colors.goldMuted,
} as const;
