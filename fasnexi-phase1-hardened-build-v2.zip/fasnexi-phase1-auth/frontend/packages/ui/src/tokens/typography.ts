/**
 * FasNexi design tokens — typography
 * Headings: Playfair Display (editorial/luxury register)
 * Body/UI: Inter
 *
 * The wordmark itself is custom path-based lettering in the brand SVGs —
 * it is a logo asset only, never a substitute for these UI typefaces.
 */
export const fontFamily = {
  heading: 'PlayfairDisplay_600SemiBold',
  headingBold: 'PlayfairDisplay_700Bold',
  body: 'Inter_400Regular',
  bodyMedium: 'Inter_500Medium',
  bodySemiBold: 'Inter_600SemiBold',
} as const;

export const fontSize = {
  xs: 12,
  sm: 14,
  base: 16,
  lg: 18,
  xl: 20,
  '2xl': 24,
  '3xl': 30,
  '4xl': 36,
} as const;

export const lineHeight = {
  tight: 1.15,
  normal: 1.4,
  relaxed: 1.6,
} as const;
