import { z } from 'zod';
import { apiErrorSchema, rawErrorSchema, type ApiError } from '../../api-contracts/src/common';

/**
 * Reuses the existing Better Auth client (packages/auth/src/client) rather
 * than rebuilding auth. Web uses cookie-based sessions automatically;
 * mobile injects a Bearer token persisted in expo-secure-store via
 * fetchOptions.auth.token(). See frontend plan §1.1 / §4.
 *
 * This module only depends on a `getAuthHeaders()` fn so it stays
 * decoupled from the concrete Better Auth client implementation —
 * wire the real one up in apps/mobile and apps/web entry points.
 */
export type AuthHeaderProvider = () => Promise<Record<string, string>>;

let getAuthHeaders: AuthHeaderProvider = async () => ({});
export function configureApiClient(opts: { baseUrl: string; authHeaderProvider?: AuthHeaderProvider }) {
  baseUrl = opts.baseUrl;
  if (opts.authHeaderProvider) getAuthHeaders = opts.authHeaderProvider;
}

let baseUrl = '';

/**
 * Exposes the same configured base URL / auth headers `apiRequest` uses,
 * for the few callers (currently just useNexiStream) that need to do
 * their own raw `fetch` — e.g. to read a streaming response body —
 * rather than going through `apiRequest`. Keeps a single source of truth
 * instead of requiring every such caller to be separately wired with its
 * own copy of the base URL / auth provider, which is easy to leave stale.
 */
export function getApiBaseUrl(): string {
  return baseUrl;
}
export async function getConfiguredAuthHeaders(): Promise<Record<string, string>> {
  return getAuthHeaders();
}

export class ApiClientError extends Error {
  readonly apiError: ApiError;
  constructor(apiError: ApiError) {
    super(apiError.error);
    this.name = 'ApiClientError';
    this.apiError = apiError;
  }
}

interface RequestOptions<TResponse> {
  method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  path: string;
  query?: Record<string, string | number | undefined>;
  body?: unknown;
  responseSchema: z.ZodType<TResponse>;
}

interface RawRequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  path: string;
  query?: Record<string, string | number | undefined>;
  body?: unknown;
}

interface RawResponse {
  status: number;
  headers: Headers;
  json: unknown;
}

/**
 * Low-level primitive `apiRequest` is built on: does the fetch, auth
 * header injection, and query-string building, but returns the raw
 * status/headers/body with NO schema validation and NO error throwing.
 * Exists for endpoints where a "successful" HTTP status (2xx) carries a
 * body that isn't the normal success shape — e.g. nexi/style-this's 202
 * "still tagging" response, which is `res.ok === true` but has an
 * `{error}` body, not the outfit-response shape. Reach for this only when
 * the normal apiRequest/error-shape assumptions genuinely don't fit;
 * everything else should use apiRequest.
 */
export async function apiRequestRaw(opts: RawRequestOptions): Promise<RawResponse> {
  const { method = 'GET', path, query, body } = opts;

  const url = new URL(path, baseUrl);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined) url.searchParams.set(key, String(value));
    }
  }

  const authHeaders = await getAuthHeaders();
  const res = await fetch(url.toString(), {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders,
    },
    credentials: 'include',
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) {
    return { status: res.status, headers: res.headers, json: undefined };
  }

  return { status: res.status, headers: res.headers, json: await safeJson(res) };
}

/**
 * Every route call goes through here. Handles:
 *  - Better Auth header injection (cookie on web is automatic; Bearer
 *    token added explicitly for native)
 *  - Building the cursor-based query string (?cursor=&limit=)
 *  - Normalizing the backend's structured {error, code, fields} shape into ApiError
 *  - Zod-validating the success response so shape drift fails loudly in
 *    dev instead of silently rendering `undefined`
 */
export async function apiRequest<TResponse>(opts: RequestOptions<TResponse>): Promise<TResponse> {
  const { responseSchema, ...rawOpts } = opts;
  const { status, json } = await apiRequestRaw(rawOpts);

  // 204 No Content has no body by definition — calling res.json() on it
  // either throws (real fetch) or, worse, silently returns {} in some
  // environments, which would fail a z.void() response schema (found
  // while wiring wardrobe's archive/DELETE, which returns 204). Handled
  // inside apiRequestRaw for every caller, not just that one endpoint.
  if (status === 204) {
    return responseSchema.parse(undefined);
  }

  if (status < 200 || status >= 300) {
    const parsedRaw = rawErrorSchema.safeParse(json);
    const apiError: ApiError = apiErrorSchema.parse({
      error: parsedRaw.success ? parsedRaw.data.error : 'Unknown error',
      code: parsedRaw.success ? parsedRaw.data.code : undefined,
      fields: parsedRaw.success ? parsedRaw.data.fields : undefined,
      status,
    });
    throw new ApiClientError(apiError);
  }

  return responseSchema.parse(json);
}

async function safeJson(res: Response): Promise<unknown> {
  try {
    return await res.json();
  } catch {
    return {};
  }
}

/** Nexi's X-Nexi-Remaining header — surfaced separately since it's not body JSON */
export function readNexiRemaining(res: Response): number | null {
  const raw = res.headers.get('X-Nexi-Remaining');
  return raw === null ? null : Number(raw);
}
