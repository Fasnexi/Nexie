import { apiRequest } from '../client';
import {
  resaleBrowseResponseSchema,
  createResaleListingRequestSchema,
  createResaleListingResponseSchema,
  resalePurchaseResponseSchema,
  resaleWithdrawResponseSchema,
  type ResaleCondition,
} from '../../../api-contracts/src/resale';

export const resaleApi = {
  browse: (params: { condition?: ResaleCondition; maxPrice?: number; cursor?: string; limit?: number } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/resale',
      query: params,
      responseSchema: resaleBrowseResponseSchema,
    }),

  create: (body: { wardrobeItemId: string; askingPrice: number; currency: string; condition: ResaleCondition; description?: string }) =>
    apiRequest({
      method: 'POST',
      path: '/api/resale',
      body: createResaleListingRequestSchema.parse(body),
      responseSchema: createResaleListingResponseSchema,
    }),

  purchase: (id: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/resale/${id}/purchase`,
      responseSchema: resalePurchaseResponseSchema,
    }),

  withdraw: (id: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/resale/${id}/withdraw`,
      responseSchema: resaleWithdrawResponseSchema,
    }),
};
