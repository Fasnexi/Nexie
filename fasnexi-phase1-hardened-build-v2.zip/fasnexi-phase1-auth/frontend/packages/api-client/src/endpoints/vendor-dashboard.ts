import { apiRequest } from '../client';
import {
  creatorEarningsResponseSchema,
  vendorDashboardSummaryResponseSchema,
  vendorTopProductsResponseSchema,
  vendorOrdersResponseSchema,
  updateVendorOrderStatusRequestSchema,
  updateVendorOrderStatusResponseSchema,
  updateInventoryRequestSchema,
  updateInventoryResponseSchema,
} from '../../../api-contracts/src/vendor-dashboard';

export const creatorDashboardApi = {
  earnings: (period: 'week' | 'month' | 'all' = 'month') =>
    apiRequest({
      method: 'GET',
      path: '/api/creators/earnings',
      query: { period },
      responseSchema: creatorEarningsResponseSchema,
    }),
};

export const vendorDashboardApi = {
  summary: () =>
    apiRequest({
      method: 'GET',
      path: '/api/vendors',
      responseSchema: vendorDashboardSummaryResponseSchema,
    }),

  topProducts: () =>
    apiRequest({
      method: 'GET',
      path: '/api/vendors',
      query: { view: 'top-products' },
      responseSchema: vendorTopProductsResponseSchema,
    }),

  orders: (params: { status?: string; cursor?: string; limit?: number } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/vendors/orders',
      query: params,
      responseSchema: vendorOrdersResponseSchema,
    }),

  updateOrderStatus: (orderId: string, status: 'FULFILLING' | 'SHIPPED', trackingNumber?: string) =>
    apiRequest({
      method: 'PATCH',
      path: `/api/vendors/orders/${orderId}`,
      body: updateVendorOrderStatusRequestSchema.parse({ status, trackingNumber }),
      responseSchema: updateVendorOrderStatusResponseSchema,
    }),

  updateInventory: (productId: string, inventoryCount: number) =>
    apiRequest({
      method: 'PATCH',
      path: `/api/vendors/products/${productId}/inventory`,
      body: updateInventoryRequestSchema.parse({ inventoryCount }),
      responseSchema: updateInventoryResponseSchema,
    }),
};
