import { apiRequest } from '../client';
import { searchResponseSchema, type SearchType } from '../../../api-contracts/src/search';

export const searchApi = {
  query: (q: string, type: SearchType = 'all', limit = 8) => apiRequest({
    method: 'GET', path: '/api/search', query: { q, type, limit }, responseSchema: searchResponseSchema,
  }),
};
