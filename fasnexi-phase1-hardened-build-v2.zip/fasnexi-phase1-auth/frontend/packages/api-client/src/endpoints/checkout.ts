import { apiRequest } from '../client';
import { checkoutRequestSchema, checkoutResponseSchema, type CheckoutRequest } from '../../../api-contracts/src/checkout';

export const checkoutApi = {
  createSession: (request: CheckoutRequest) =>
    apiRequest({
      method: 'POST',
      path: '/api/checkout',
      body: checkoutRequestSchema.parse(request),
      responseSchema: checkoutResponseSchema,
    }),
};
