import { apiRequest } from '../client';
import { eventDetailResponseSchema, eventsResponseSchema, ticketPurchaseResponseSchema, ticketsResponseSchema } from '../../../api-contracts/src/events';

export const eventsApi = {
  list: (limit = 20) => apiRequest({ method: 'GET', path: '/api/events', query: { limit }, responseSchema: eventsResponseSchema }),
  detail: (id: string) => apiRequest({ method: 'GET', path: `/api/events/${id}`, responseSchema: eventDetailResponseSchema }),
  purchase: (tierId: string) => apiRequest({ method: 'POST', path: `/api/tickets/${tierId}/purchase`, responseSchema: ticketPurchaseResponseSchema }),
  tickets: () => apiRequest({ method: 'GET', path: '/api/tickets', responseSchema: ticketsResponseSchema }),
};
