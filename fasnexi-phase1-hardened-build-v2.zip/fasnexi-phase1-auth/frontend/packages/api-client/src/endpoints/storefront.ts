import { apiRequest } from '../client';
import { storefrontResponseSchema } from '../../../api-contracts/src/storefront';

export const storefrontApi = {
  get: (handle: string) =>
    apiRequest({
      method: 'GET',
      path: `/api/creators/${handle}`,
      responseSchema: storefrontResponseSchema,
    }),
};
