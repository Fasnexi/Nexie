import { z } from 'zod';
import { apiRequest } from '../client';
import { promotedProductsResponseSchema, promotionTrackingResponseSchema } from '../../../api-contracts/src/promoted-products';

export const promotedProductsApi = {
  featured: (limit = 6) => apiRequest({
    method: 'GET',
    path: '/api/promotions/featured',
    query: { limit },
    responseSchema: promotedProductsResponseSchema,
  }),

  impression: (id: string, count = 1) => apiRequest({
    method: 'POST',
    path: `/api/promotions/${id}/impression`,
    body: { count },
    responseSchema: promotionTrackingResponseSchema,
  }),

  click: (id: string) => apiRequest({
    method: 'POST',
    path: `/api/promotions/${id}/click`,
    responseSchema: z.object({ recorded: z.boolean() }),
  }),
};
