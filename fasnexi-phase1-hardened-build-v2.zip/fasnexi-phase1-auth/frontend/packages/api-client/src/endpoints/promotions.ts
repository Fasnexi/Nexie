import { apiRequest } from '../client';
import {
  promotionsListResponseSchema,
  createPromotionRequestSchema,
  createPromotionResponseSchema,
  type CreatePromotionRequest,
} from '../../../api-contracts/src/promotions';

export const promotionsApi = {
  list: () =>
    apiRequest({
      method: 'GET',
      path: '/api/promotions',
      responseSchema: promotionsListResponseSchema,
    }),

  create: (body: CreatePromotionRequest) =>
    apiRequest({
      method: 'POST',
      path: '/api/promotions',
      body: createPromotionRequestSchema.parse(body),
      responseSchema: createPromotionResponseSchema,
    }),
};
