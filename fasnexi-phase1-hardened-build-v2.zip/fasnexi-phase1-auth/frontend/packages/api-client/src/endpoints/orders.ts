import { apiRequest } from '../client';
import { ordersListResponseSchema, orderResponseSchema } from '../../../api-contracts/src/orders';

export const ordersApi = {
  list: (params: { status?: string; cursor?: string; limit?: number } = {}) => apiRequest({ method: 'GET', path: '/api/orders', query: params, responseSchema: ordersListResponseSchema }),
  get: (id: string) => apiRequest({ method: 'GET', path: `/api/orders/${id}`, responseSchema: orderResponseSchema }),
  getByCheckoutSession: (sessionId: string) => apiRequest({ method: 'GET', path: '/api/orders/by-checkout-session', query: { sessionId }, responseSchema: orderResponseSchema }),
};
