import { apiRequest } from '../client';
import {
  wardrobeListResponseSchema,
  wardrobeItemDetailResponseSchema,
  createWardrobeItemRequestSchema,
  createWardrobeItemResponseSchema,
  recordWearRequestSchema,
  recordWearResponseSchema,
  updateWardrobeItemRequestSchema,
  updateWardrobeItemResponseSchema,
  wardrobeAnalyticsResponseSchema,
  type WardrobeListParams,
  type CreateWardrobeItemRequest,
  type UpdateWardrobeItemRequest,
} from '../../../api-contracts/src/wardrobe';
import { z } from 'zod';

export const wardrobeApi = {
  list: (params: WardrobeListParams = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/wardrobe',
      query: {
        category: params.category,
        cursor: params.cursor,
        limit: params.limit,
        tagged: params.tagged === undefined ? undefined : String(params.tagged),
      },
      responseSchema: wardrobeListResponseSchema,
    }),

  analytics: () =>
    apiRequest({
      method: 'GET',
      path: '/api/wardrobe',
      query: { view: 'analytics' },
      responseSchema: wardrobeAnalyticsResponseSchema,
    }),

  create: (body: CreateWardrobeItemRequest) =>
    apiRequest({
      method: 'POST',
      path: '/api/wardrobe',
      body: createWardrobeItemRequestSchema.parse(body),
      responseSchema: createWardrobeItemResponseSchema,
    }),

  detail: (id: string) =>
    apiRequest({
      method: 'GET',
      path: `/api/wardrobe/${id}`,
      responseSchema: wardrobeItemDetailResponseSchema,
    }),

  /** Distinct from `update` — same route, different action, different response. */
  recordWear: (id: string, wornOn?: string) =>
    apiRequest({
      method: 'PATCH',
      path: `/api/wardrobe/${id}`,
      body: recordWearRequestSchema.parse({ action: 'record_wear', wornOn }),
      responseSchema: recordWearResponseSchema,
    }),

  update: (id: string, body: UpdateWardrobeItemRequest) =>
    apiRequest({
      method: 'PATCH',
      path: `/api/wardrobe/${id}`,
      body: updateWardrobeItemRequestSchema.parse(body),
      responseSchema: updateWardrobeItemResponseSchema,
    }),

  /** DELETE is a soft-archive; 204 No Content on success, so there's no body to validate. */
  archive: (id: string) =>
    apiRequest({
      method: 'DELETE',
      path: `/api/wardrobe/${id}`,
      responseSchema: z.void(),
    }),

  retag: (id: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/wardrobe/${id}/tag`,
      responseSchema: z.object({ queued: z.boolean(), message: z.string() }),
    }),
};
