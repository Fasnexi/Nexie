import { apiRequest } from '../client';
import { uploadSignRequestSchema, uploadSignResponseSchema, type UploadFolder } from '../../../api-contracts/src/uploads';

export const uploadsApi = {
  sign: (folder: UploadFolder) =>
    apiRequest({
      method: 'POST',
      path: '/api/uploads/sign',
      body: uploadSignRequestSchema.parse({ folder }),
      responseSchema: uploadSignResponseSchema,
    }),
};
