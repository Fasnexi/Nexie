import { apiRequest } from '../client';
import { feedResponseSchema, storiesResponseSchema, feedEngagementEventSchema } from '../../../api-contracts/src/feed';
import { z } from 'zod';

/**
 * GET /api/feed returns `{posts, count}` — no nextCursor field (see
 * feed.ts contract notes). Callers derive the next cursor themselves from
 * the last post's id, and treat `posts.length < limit` as end-of-list.
 */
export const feedApi = {
  list: (params: { cursor?: string; limit?: number } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/feed',
      query: params,
      responseSchema: feedResponseSchema,
    }),

  recordEvent: (postId: string, event: z.infer<typeof feedEngagementEventSchema>) =>
    apiRequest({
      method: 'POST',
      path: '/api/feed',
      body: { postId, event: feedEngagementEventSchema.parse(event) },
      responseSchema: z.object({ ok: z.boolean() }),
    }),
};

export const storiesApi = {
  list: () =>
    apiRequest({
      method: 'GET',
      path: '/api/stories',
      responseSchema: storiesResponseSchema,
    }),
};
