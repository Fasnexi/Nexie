import { apiRequest } from '../client';
import {
  followToggleResponseSchema,
  relationshipResponseSchema,
  followersListResponseSchema,
  followingListResponseSchema,
  toggleLikeResponseSchema,
  toggleSaveResponseSchema,
  commentsListResponseSchema,
  createCommentResponseSchema,
  deleteCommentResponseSchema,
} from '../../../api-contracts/src/social';

export const socialApi = {
  followers: (userId: string, cursor?: string, limit?: number) =>
    apiRequest({
      method: 'GET',
      path: '/api/social',
      query: { action: 'followers', userId, cursor, limit },
      responseSchema: followersListResponseSchema,
    }),

  following: (userId: string, cursor?: string, limit?: number) =>
    apiRequest({
      method: 'GET',
      path: '/api/social',
      query: { action: 'following', userId, cursor, limit },
      responseSchema: followingListResponseSchema,
    }),

  relationship: (userId: string) =>
    apiRequest({
      method: 'GET',
      path: '/api/social',
      query: { action: 'relationship', userId },
      responseSchema: relationshipResponseSchema,
    }),

  follow: (userId: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/social/${userId}`,
      body: { action: 'follow' },
      responseSchema: followToggleResponseSchema,
    }),

  unfollow: (userId: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/social/${userId}`,
      body: { action: 'unfollow' },
      responseSchema: followToggleResponseSchema,
    }),
};

export const engagementApi = {
  toggleLike: (postId: string) =>
    apiRequest({
      method: 'POST',
      path: '/api/social/engagement',
      body: { action: 'like', postId },
      responseSchema: toggleLikeResponseSchema,
    }),

  toggleSave: (postId: string) =>
    apiRequest({
      method: 'POST',
      path: '/api/social/engagement',
      body: { action: 'save', postId },
      responseSchema: toggleSaveResponseSchema,
    }),

  comments: (postId: string, cursor?: string, limit?: number) =>
    apiRequest({
      method: 'GET',
      path: '/api/social/engagement',
      query: { postId, cursor, limit },
      responseSchema: commentsListResponseSchema,
    }),

  addComment: (postId: string, body: string, parentId?: string) =>
    apiRequest({
      method: 'POST',
      path: '/api/social/engagement',
      body: { action: 'comment', postId, body, parentId },
      responseSchema: createCommentResponseSchema,
    }),

  deleteComment: (commentId: string) =>
    apiRequest({
      method: 'POST',
      path: '/api/social/engagement',
      body: { action: 'delete_comment', commentId },
      responseSchema: deleteCommentResponseSchema,
    }),
};
