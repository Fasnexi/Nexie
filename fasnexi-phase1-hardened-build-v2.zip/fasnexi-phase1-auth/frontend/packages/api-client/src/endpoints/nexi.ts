import { apiRequest, apiRequestRaw, ApiClientError } from '../client';
import {
  nexiChatRequestSchema, nexiChatResponseSchema,
  nexiOutfitRequestSchema, nexiOutfitResponseSchema,
  nexiStyleThisRequestSchema, nexiStyleThisPendingSchema,
  type NexiChatRequest,
} from '../../../api-contracts/src/nexi';
import { apiErrorSchema, rawErrorSchema, type ApiError } from '../../../api-contracts/src/common';

export const nexiApi = {
  /** Non-streaming JSON path — for callers that don't need SSE (stream: false). */
  chat: (request: Omit<NexiChatRequest, 'stream'>) =>
    apiRequest({
      method: 'POST',
      path: '/api/nexi/chat',
      body: nexiChatRequestSchema.parse({ ...request, stream: false }),
      responseSchema: nexiChatResponseSchema,
    }),

  outfit: (request: { mood?: string; occasion?: string; season?: string; count?: number; sessionId?: string }) =>
    apiRequest({
      method: 'POST',
      path: '/api/nexi/outfit',
      body: nexiOutfitRequestSchema.parse(request),
      responseSchema: nexiOutfitResponseSchema,
    }),

  /**
   * Returns a discriminated result rather than throwing/crashing on the
   * 202 "item still tagging" case, which is `res.ok` but not the outfit
   * shape — see nexi.ts's contract notes.
   */
  styleThis: async (request: { wardrobeItemId: string; occasion?: string; season?: string; count?: number; sessionId?: string }) => {
    const body = nexiStyleThisRequestSchema.parse(request);
    const { status, json } = await apiRequestRaw({ method: 'POST', path: '/api/nexi/style-this', body });

    if (status === 202) {
      const pending = nexiStyleThisPendingSchema.parse(json);
      return { status: 'pending' as const, message: pending.error };
    }

    if (status < 200 || status >= 300) {
      const parsedRaw = rawErrorSchema.safeParse(json);
      const apiError: ApiError = apiErrorSchema.parse({
        error: parsedRaw.success ? parsedRaw.data.error : 'Unknown error',
        code: parsedRaw.success ? parsedRaw.data.code : undefined,
        fields: parsedRaw.success ? parsedRaw.data.fields : undefined,
        status,
      });
      throw new ApiClientError(apiError);
    }

    return { status: 'ready' as const, ...nexiOutfitResponseSchema.parse(json) };
  },
};
