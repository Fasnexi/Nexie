import { apiRequest } from '../client';
import {
  tailorBrowseResponseSchema,
  submitBriefRequestSchema,
  submitBriefResponseSchema,
  clientOrdersResponseSchema,
  depositResponseSchema,
  messagesListResponseSchema,
  sendMessageRequestSchema,
  sendMessageResponseSchema,
  tailorQueueResponseSchema,
  provideQuoteRequestSchema,
  provideQuoteResponseSchema,
  updateCustomOrderStatusRequestSchema,
  updateCustomOrderStatusResponseSchema,
} from '../../../api-contracts/src/tailor';

export const tailorApi = {
  browse: (params: { city?: string; specialty?: string } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/tailor',
      query: params,
      responseSchema: tailorBrowseResponseSchema,
    }),

  submitBrief: (body: { tailorId: string; brief: string; deadline?: string }) =>
    apiRequest({
      method: 'POST',
      path: '/api/tailor',
      body: submitBriefRequestSchema.parse(body),
      responseSchema: submitBriefResponseSchema,
    }),

  /** Client-side shape only — see tailor.ts's contract notes on the role-aware split. */
  myOrders: () =>
    apiRequest({
      method: 'GET',
      path: '/api/tailor/orders',
      responseSchema: clientOrdersResponseSchema,
    }),

  payDeposit: (customOrderId: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/tailor/${customOrderId}/deposit`,
      responseSchema: depositResponseSchema,
    }),

  messages: {
    list: (customOrderId: string) =>
      apiRequest({
        method: 'GET',
        path: `/api/tailor/${customOrderId}/messages`,
        responseSchema: messagesListResponseSchema,
      }),

    send: (customOrderId: string, body: string, mediaUrl?: string) =>
      apiRequest({
        method: 'POST',
        path: `/api/tailor/${customOrderId}/messages`,
        body: sendMessageRequestSchema.parse({ body, mediaUrl }),
        responseSchema: sendMessageResponseSchema,
      }),
  },
};

// -----------------------------------------------------------------------
// TAILOR-role dashboard (deferred from Step 9, built in Step 11 alongside
// other role dashboards — see tailor.ts's contract notes)
// -----------------------------------------------------------------------
export const tailorDashboardApi = {
  queue: (status?: string) =>
    apiRequest({
      method: 'GET',
      path: '/api/tailor/orders',
      query: { status },
      responseSchema: tailorQueueResponseSchema,
    }),

  provideQuote: (customOrderId: string, quoteAmount: number, currency: string, notes?: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/tailor/${customOrderId}/quote`,
      body: provideQuoteRequestSchema.parse({ quoteAmount, currency, notes }),
      responseSchema: provideQuoteResponseSchema,
    }),

  updateStatus: (customOrderId: string, status: 'FULFILLING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED') =>
    apiRequest({
      method: 'PATCH',
      path: `/api/tailor/${customOrderId}/status`,
      body: updateCustomOrderStatusRequestSchema.parse({ status }),
      responseSchema: updateCustomOrderStatusResponseSchema,
    }),
};
