import { apiRequest } from '../client';
import {
  activateRoleRequestSchema, activateRoleResponseSchema,
  deactivateRoleRequestSchema, deactivateRoleResponseSchema,
  switchRoleRequestSchema, switchRoleResponseSchema,
  myRolesResponseSchema,
  type Role,
} from '../../../api-contracts/src/auth';

export const authApi = {
  activateRole: (role: Role) =>
    apiRequest({
      method: 'POST',
      path: '/api/auth/roles/activate',
      body: activateRoleRequestSchema.parse({ role }),
      responseSchema: activateRoleResponseSchema,
    }),

  deactivateRole: (role: Role) =>
    apiRequest({
      method: 'POST',
      path: '/api/auth/roles/deactivate',
      body: deactivateRoleRequestSchema.parse({ role }),
      responseSchema: deactivateRoleResponseSchema,
    }),

  switchRole: (role: Role) =>
    apiRequest({
      method: 'POST',
      path: '/api/auth/roles/switch',
      body: switchRoleRequestSchema.parse({ role }),
      responseSchema: switchRoleResponseSchema,
    }),

  myRoles: () =>
    apiRequest({
      method: 'GET',
      path: '/api/auth/roles/mine',
      responseSchema: myRolesResponseSchema,
    }),
};
