import { apiRequest } from '../client';
import {
  videoFeedResponseSchema,
  createVideoPostRequestSchema,
  createVideoPostResponseSchema,
  type CreateVideoPostRequest,
} from '../../../api-contracts/src/video';

export const videoApi = {
  feed: (params: { cursor?: string; limit?: number } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/video',
      query: params,
      responseSchema: videoFeedResponseSchema,
    }),

  create: (body: CreateVideoPostRequest) =>
    apiRequest({
      method: 'POST',
      path: '/api/video',
      body: createVideoPostRequestSchema.parse(body),
      responseSchema: createVideoPostResponseSchema,
    }),
};
