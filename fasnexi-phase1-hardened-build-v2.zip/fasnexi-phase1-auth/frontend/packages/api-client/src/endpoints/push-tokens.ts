import { apiRequest } from '../client';
import { z } from 'zod';
import {
  registerPushTokenRequestSchema,
  registerPushTokenResponseSchema,
  type RegisterPushTokenRequest,
} from '../../../api-contracts/src/push-tokens';

export const pushTokensApi = {
  register: (body: RegisterPushTokenRequest) =>
    apiRequest({
      method: 'POST',
      path: '/api/push-tokens',
      body: registerPushTokenRequestSchema.parse(body),
      responseSchema: registerPushTokenResponseSchema,
    }),

  /** 204 No Content on success — handled by apiRequest's 204 short-circuit. */
  unregister: (deviceTokenRowId: string) =>
    apiRequest({
      method: 'DELETE',
      path: `/api/push-tokens/${deviceTokenRowId}`,
      responseSchema: z.void(),
    }),
};
