import { apiRequest } from '../client';
import {
  productListResponseSchema,
  productDetailResponseSchema,
  type ProductListParams,
} from '../../../api-contracts/src/products';

export const productsApi = {
  list: (params: ProductListParams = {}) => {
    const { culturalTags, ...rest } = params;
    return apiRequest({
      method: 'GET',
      path: '/api/products',
      query: {
        ...rest,
        inStockOnly: rest.inStockOnly === undefined ? undefined : String(rest.inStockOnly),
        culturalTags: culturalTags?.length ? culturalTags.join(',') : undefined,
      },
      responseSchema: productListResponseSchema,
    });
  },

  detail: (idOrSlug: string) =>
    apiRequest({
      method: 'GET',
      path: `/api/products/${idOrSlug}`,
      responseSchema: productDetailResponseSchema,
    }),
};
