import { apiRequest } from '../client';
import {
  loyaltyAccountResponseSchema,
  loyaltyHistoryResponseSchema,
  redeemPointsRequestSchema,
  redeemPointsResponseSchema,
} from '../../../api-contracts/src/loyalty';

export const loyaltyApi = {
  account: () =>
    apiRequest({
      method: 'GET',
      path: '/api/loyalty',
      responseSchema: loyaltyAccountResponseSchema,
    }),

  history: (params: { cursor?: string; limit?: number } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/loyalty',
      query: { view: 'history', cursor: params.cursor, limit: params.limit },
      responseSchema: loyaltyHistoryResponseSchema,
    }),

  redeem: (points: number, reason?: string) =>
    apiRequest({
      method: 'POST',
      path: '/api/loyalty',
      body: redeemPointsRequestSchema.parse({ points, reason }),
      responseSchema: redeemPointsResponseSchema,
    }),
};
