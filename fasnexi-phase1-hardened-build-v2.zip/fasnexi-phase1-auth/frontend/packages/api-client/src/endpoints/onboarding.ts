import type { StyleDnaAnswers } from '../../../api-contracts/src/style-dna';
import { apiRequest } from '../client';
import { z } from 'zod';

const responseSchema = z.object({ profile: z.unknown().nullable() });
export async function submitStyleDnaAnswers(answers: StyleDnaAnswers): Promise<{ ok: true }> {
  await apiRequest({ method: 'PUT', path: '/api/style-profile', body: answers, responseSchema });
  return { ok: true };
}
