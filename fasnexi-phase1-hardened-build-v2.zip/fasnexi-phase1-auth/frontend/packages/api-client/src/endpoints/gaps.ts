import { apiRequest } from '../client';
import { gapsGetResponseSchema, gapsAnalyzeResponseSchema } from '../../../api-contracts/src/gaps';

export const gapsApi = {
  current: () =>
    apiRequest({
      method: 'GET',
      path: '/api/gaps',
      responseSchema: gapsGetResponseSchema,
    }),

  /**
   * Rate-gated to 1/24h server-side, but not via an error — see
   * gaps.ts's contract notes. Callers should compare the returned
   * `analysedAt` against what they already had rather than assume every
   * call produces a fresh result.
   */
  analyze: () =>
    apiRequest({
      method: 'POST',
      path: '/api/gaps',
      responseSchema: gapsAnalyzeResponseSchema,
    }),
};
