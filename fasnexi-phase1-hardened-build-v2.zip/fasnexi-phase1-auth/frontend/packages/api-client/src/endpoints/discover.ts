import { apiRequest } from '../client';
import {
  creatorsListResponseSchema,
  challengesListResponseSchema,
  challengeDetailResponseSchema,
  voteResponseSchema,
  submitEntryRequestSchema,
  submitEntryResponseSchema,
} from '../../../api-contracts/src/discover';

export const creatorsApi = {
  /** GET /api/creators returns a bare array — no cursor pagination exists here. */
  topList: (limit?: number) =>
    apiRequest({
      method: 'GET',
      path: '/api/creators',
      query: { limit },
      responseSchema: creatorsListResponseSchema,
    }),
};

export const challengesApi = {
  list: (params: { status?: string; cursor?: string; limit?: number } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/challenges',
      query: params,
      responseSchema: challengesListResponseSchema,
    }),

  detail: (id: string) =>
    apiRequest({
      method: 'GET',
      path: `/api/challenges/${id}`,
      responseSchema: challengeDetailResponseSchema,
    }),

  /**
   * Business-logic failures here (wrong phase, voting closed, entry not
   * found) are thrown as plain `Error`s server-side and NOT caught by
   * withErrorHandling — they surface as raw 500s, not the flat {error}
   * shape. apiRequest's normal error parsing will fall back to a generic
   * message for those. See discover.ts contract notes / README.
   */
  vote: (challengeId: string, entryId: string) =>
    apiRequest({
      method: 'POST',
      path: `/api/challenges/${challengeId}/vote`,
      body: { entryId },
      responseSchema: voteResponseSchema,
    }),

  /** Same uncaught-500 pattern as vote() for its business-logic failures — see submitEntryResponseSchema's contract notes. */
  submitEntry: (challengeId: string, body: { caption?: string; mediaUrls: string[]; culturalTags?: string[] }) =>
    apiRequest({
      method: 'POST',
      path: `/api/challenges/${challengeId}/entries`,
      body: submitEntryRequestSchema.parse(body),
      responseSchema: submitEntryResponseSchema,
    }),
};
