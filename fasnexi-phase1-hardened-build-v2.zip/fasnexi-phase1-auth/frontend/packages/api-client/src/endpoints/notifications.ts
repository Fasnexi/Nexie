import { apiRequest } from '../client';
import {
  notificationsListResponseSchema,
  markReadResponseSchema,
  markAllReadResponseSchema,
} from '../../../api-contracts/src/notifications';

export const notificationsApi = {
  list: (params: { cursor?: string; limit?: number; unreadOnly?: boolean } = {}) =>
    apiRequest({
      method: 'GET',
      path: '/api/notifications',
      query: {
        cursor: params.cursor,
        limit: params.limit,
        unreadOnly: params.unreadOnly === undefined ? undefined : String(params.unreadOnly),
      },
      responseSchema: notificationsListResponseSchema,
    }),

  markRead: (id: string) =>
    apiRequest({
      method: 'PATCH',
      path: `/api/notifications/${id}`,
      body: { action: 'mark_read' },
      responseSchema: markReadResponseSchema,
    }),

  markAllRead: () =>
    apiRequest({
      method: 'PATCH',
      path: '/api/notifications',
      body: { action: 'mark_all_read' },
      responseSchema: markAllReadResponseSchema,
    }),
};
