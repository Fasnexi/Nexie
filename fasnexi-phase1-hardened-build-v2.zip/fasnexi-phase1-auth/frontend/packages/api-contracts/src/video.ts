import { z } from 'zod';
import { currencySchema } from './common';

/**
 * Confirmed from packages/api/src/video/service.ts's getVideoFeed +
 * createVideoPost. Video posts are stored in the SAME `Post` model as
 * the main feed (filtered by `type: "VIDEO"`), but this endpoint's own
 * `select` returns a DIFFERENT, narrower field set than /api/feed's —
 * no `saveCount`/`culturalTags`/`rankScore` here. Modeled separately
 * from feed.ts's `feedPostSchema` rather than reusing it, since reusing
 * it would silently assert fields this endpoint doesn't actually return.
 *
 * Also confirmed: `GET /api/video` EXCLUDES the current user's own videos
 * (`userId: { not: userId }` in the query) — you will never see your own
 * posted video in your own video feed. This is real, intended behavior,
 * not a bug to "fix" in the UI — worth knowing so it doesn't look broken
 * when testing (post a video, then don't see it in your own feed).
 *
 * Pagination here DOES have a real nextCursor (unlike /api/feed, which
 * has none at all) — confirmed from the function's own return statement.
 */
export const videoFeedItemSchema = z.object({
  id: z.string(),
  userId: z.string(),
  caption: z.string().nullable(),
  videoUrl: z.string(),
  thumbnailUrl: z.string(),
  videoDuration: z.number().nullable(),
  likeCount: z.number(),
  commentCount: z.number(),
  user: z.object({ username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable() }),
  taggedProducts: z.array(z.object({
    product: z.object({
      id: z.string(), name: z.string(), priceAmount: z.number(), priceCurrency: currencySchema,
    }),
  })),
});
export type VideoFeedItem = z.infer<typeof videoFeedItemSchema>;

export const videoFeedResponseSchema = z.object({
  videos: z.array(videoFeedItemSchema),
  nextCursor: z.string().nullable(),
});

/** Max duration confirmed from MAX_DURATION_SECONDS (video/service.ts) — 180s (3 min) */
export const MAX_VIDEO_DURATION_SECONDS = 180;

export const createVideoPostRequestSchema = z.object({
  videoUrl: z.string(),
  thumbnailUrl: z.string(),
  durationSeconds: z.number().positive().max(MAX_VIDEO_DURATION_SECONDS),
  caption: z.string().optional(),
  culturalTags: z.array(z.string()).optional(),
  taggedProductIds: z.array(z.string()).optional(),
});
export type CreateVideoPostRequest = z.infer<typeof createVideoPostRequestSchema>;

/** POST returns the full created Post row (createVideoPost has no `select`, so every scalar column comes back) */
export const createVideoPostResponseSchema = z.object({
  post: z.object({
    id: z.string(),
    userId: z.string(),
    type: z.literal('VIDEO'),
    status: z.string(),
    caption: z.string().nullable(),
    mediaUrls: z.array(z.string()),
    mediaTypes: z.array(z.string()),
    thumbnailUrl: z.string().nullable(),
    culturalTags: z.array(z.string()),
    occasions: z.array(z.string()),
    styleCategories: z.array(z.string()),
    outfitId: z.string().nullable(),
    challengeId: z.string().nullable(),
    likeCount: z.number(),
    commentCount: z.number(),
    shareCount: z.number(),
    saveCount: z.number(),
    viewCount: z.number(),
    rankScore: z.number(),
    videoDuration: z.number().nullable(),
    videoUrl: z.string().nullable(),
    publishedAt: z.string().nullable(),
    createdAt: z.string(),
    updatedAt: z.string(),
  }),
});
