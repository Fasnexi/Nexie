import { z } from 'zod';
import { currencySchema } from './common';

const organizerSchema = z.object({ id: z.string(), orgName: z.string(), country: z.string().nullable() });
export const eventSchema = z.object({
  id: z.string(), title: z.string(), description: z.string().nullable(), coverUrl: z.string().nullable(), venue: z.string().nullable(), city: z.string().nullable(), country: z.string().nullable(),
  startDate: z.coerce.date(), endDate: z.coerce.date(), isLive: z.boolean(), streamUrl: z.string().nullable(), isPublished: z.boolean(),
  organizer: organizerSchema,
  ticketTiers: z.array(z.object({ id: z.string(), name: z.string(), description: z.string().nullable(), priceAmount: z.number(), currency: currencySchema, capacity: z.number(), sold: z.number() })),
});
export const eventDetailResponseSchema = z.object({ event: eventSchema });
export const eventListItemSchema = z.object({ id: z.string(), title: z.string(), description: z.string().nullable(), coverUrl: z.string().nullable(), venue: z.string().nullable(), city: z.string().nullable(), country: z.string().nullable(), startDate: z.coerce.date(), endDate: z.coerce.date(), isLive: z.boolean(), isPublished: z.boolean(), organizer: z.object({ orgName: z.string() }), ticketTiers: z.array(z.unknown()).default([]) });
export const eventsResponseSchema = z.object({ events: z.array(eventListItemSchema) });
export const ticketPurchaseResponseSchema = z.object({ url: z.string(), sessionId: z.string(), ticketId: z.string() });
export const ticketsResponseSchema = z.object({ tickets: z.array(z.object({ id: z.string(), qrPayload: z.string(), usedAt: z.coerce.date().nullable(), paymentRef: z.string().nullable(), createdAt: z.coerce.date(), event: z.object({ title: z.string(), startDate: z.coerce.date(), coverUrl: z.string().nullable(), venue: z.string().nullable() }), tier: z.object({ name: z.string() }) })) });
