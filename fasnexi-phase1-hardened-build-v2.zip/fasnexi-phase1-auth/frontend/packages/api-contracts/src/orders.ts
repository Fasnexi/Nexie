import { z } from 'zod';
import { currencySchema } from './common';
import { orderStatusSchema } from './checkout';

export const orderItemSchema = z.object({
  id: z.string(), productId: z.string(), quantity: z.number(), unitAmount: z.number(), currency: currencySchema, size: z.string().nullable(), color: z.string().nullable(),
  product: z.object({ id: z.string(), name: z.string(), imageUrls: z.array(z.string()) }),
});
export const orderSchema = z.object({
  id: z.string(), status: orderStatusSchema, paymentMethod: z.string().nullable(), paymentRef: z.string().nullable(), subtotalAmount: z.number(), shippingAmount: z.number(), discountAmount: z.number(), totalAmount: z.number(), currency: currencySchema,
  shippingName: z.string().nullable(), shippingLine1: z.string().nullable(), shippingLine2: z.string().nullable(), shippingCity: z.string().nullable(), shippingCountry: z.string().nullable(), shippingPostal: z.string().nullable(),
  trackingNumber: z.string().nullable(), trackingCarrier: z.string().nullable(), shippedAt: z.string().nullable(), deliveredAt: z.string().nullable(), createdAt: z.string(), updatedAt: z.string(), items: z.array(orderItemSchema),
});
export const ordersListResponseSchema = z.object({ orders: z.array(orderSchema), nextCursor: z.string().nullable() });
export const orderResponseSchema = z.object({ order: orderSchema });
export type Order = z.infer<typeof orderSchema>;
