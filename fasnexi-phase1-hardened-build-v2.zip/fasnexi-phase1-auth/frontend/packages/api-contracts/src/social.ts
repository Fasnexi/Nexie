import { z } from 'zod';

/**
 * MAJOR GAP found in a full repo audit after all 11 build steps: this
 * entire feature area (follow/unfollow, followers/following lists,
 * like/save/comment on posts) had full backend support and was never
 * built anywhere — the Home feed (Step 3) displays likeCount/commentCount
 * on every post but has no way to actually like, save, or comment, and
 * there was no way to view another user's profile or follow them at all.
 * Confirmed from social/graph.ts + social/engagement.ts.
 *
 * CONFIRMED QUIRK: `followerCount` is denormalized on `CreatorProfile`
 * only (`db.creatorProfile.updateMany` on follow/unfollow) — a Follow
 * row is created for ANY user regardless of role, but the returned
 * follower count is `0` for anyone without a CreatorProfile, even though
 * they may have real followers in the `Follow` table. Don't treat a `0`
 * follower count as "this user has no followers" for non-creators — it
 * may just mean the count isn't tracked for them.
 */
export const followToggleResponseSchema = z.object({
  followed: z.boolean().optional(),
  unfollowed: z.boolean().optional(),
  followerCount: z.number().optional(),
});

export const relationshipResponseSchema = z.object({
  isFollowing: z.boolean(),
  isFollowedBy: z.boolean(),
});

const followUserSummarySchema = z.object({
  id: z.string(),
  username: z.string(),
  displayName: z.string(),
  avatarUrl: z.string().nullable(),
  creatorProfile: z.object({ followerCount: z.number() }).nullable(),
  followedAt: z.string(),
});

export const followersListResponseSchema = z.object({
  followers: z.array(followUserSummarySchema),
  nextCursor: z.string().nullable(),
});
export const followingListResponseSchema = z.object({
  following: z.array(followUserSummarySchema),
  nextCursor: z.string().nullable(),
});

export const toggleLikeResponseSchema = z.object({ liked: z.boolean(), likeCount: z.number() });
export const toggleSaveResponseSchema = z.object({ saved: z.boolean(), saveCount: z.number() });

const commentUserSchema = z.object({ id: z.string(), username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable() });
const replySchema = z.object({
  id: z.string(), body: z.string(), likeCount: z.number(), createdAt: z.string(), user: commentUserSchema,
});
export const commentSchema = z.object({
  id: z.string(),
  body: z.string(),
  isRemoved: z.boolean(),
  likeCount: z.number(),
  createdAt: z.string(),
  user: commentUserSchema,
  replies: z.array(replySchema),
});
export type Comment = z.infer<typeof commentSchema>;

export const commentsListResponseSchema = z.object({
  comments: z.array(commentSchema),
  nextCursor: z.string().nullable(),
});

/** createComment returns the bare comment object directly, not wrapped in `{comment: ...}` — confirmed from the service function's own return statement. */
export const createCommentResponseSchema = z.object({
  id: z.string(),
  body: z.string(),
  parentId: z.string().nullable(),
  createdAt: z.string(),
  user: commentUserSchema,
});

export const deleteCommentResponseSchema = z.object({ deleted: z.boolean() });
