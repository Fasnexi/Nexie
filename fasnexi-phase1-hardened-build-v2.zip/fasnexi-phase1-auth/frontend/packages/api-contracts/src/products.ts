import { z } from 'zod';
import { currencySchema, cursorPageParamsSchema } from './common';

/**
 * CORRECTED from Step 1: the original version of this file guessed at
 * field names from the plan's prose summary instead of reading
 * packages/api/src/products/catalog.ts directly. Real shape, confirmed
 * by reading catalog.ts + schema.prisma's Product model:
 *  - list response is `{products, nextCursor, total}`, not `{items,
 *    nextCursor}` — products is the field name, not a generic wrapper
 *  - the search query param on the wire is `q`, not `query`
 *  - ProductSummary has `slug`, `category`, `isInStock`, `salesCount`,
 *    `vendor` — there is no `inventoryCount` on the list shape (that's
 *    only on the full Product model, used in detail view)
 */
export const garmentCategorySchema = z.enum([
  'TOP', 'BOTTOM', 'DRESS', 'OUTERWEAR', 'FOOTWEAR', 'ACCESSORY',
  'BAG', 'TRADITIONAL', 'ACTIVEWEAR', 'SWIMWEAR', 'UNDERWEAR',
]);
export type GarmentCategory = z.infer<typeof garmentCategorySchema>;

export const productSummarySchema = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
  priceAmount: z.number(),
  priceCurrency: currencySchema,
  imageUrls: z.array(z.string()),
  category: garmentCategorySchema,
  isInStock: z.boolean(),
  salesCount: z.number(),
  vendor: z.object({ id: z.string(), businessName: z.string() }),
});
export type ProductSummary = z.infer<typeof productSummarySchema>;

export const productListParamsSchema = cursorPageParamsSchema.extend({
  q: z.string().optional(),
  category: garmentCategorySchema.optional(),
  minPrice: z.number().int().optional(),
  maxPrice: z.number().int().optional(),
  currency: currencySchema.optional(),
  culturalTags: z.array(z.string()).optional(), // joined with ',' on the wire
  occasion: z.string().optional(),
  vendorId: z.string().optional(),
  inStockOnly: z.boolean().optional(),
  sortBy: z.enum(['price_asc', 'price_desc', 'newest', 'popular']).optional(),
});
export type ProductListParams = z.infer<typeof productListParamsSchema>;

export const productListResponseSchema = z.object({
  products: z.array(productSummarySchema),
  nextCursor: z.string().nullable(),
  total: z.number(),
});

/** Full Product model fields returned on detail, plus vendor/reviews/reviewStats */
export const productDetailSchema = productSummarySchema
  .omit({ vendor: true })
  .extend({
    description: z.string().nullable(),
    videoUrl: z.string().nullable(),
    subcategory: z.string().nullable(),
    brand: z.string().nullable(),
    sizes: z.array(z.string()),
    colors: z.array(z.string()),
    occasions: z.array(z.string()),
    inventoryCount: z.number(),
    vendor: z.object({
      id: z.string(),
      businessName: z.string(),
      logoUrl: z.string().nullable(),
      country: z.string().nullable(),
      isVerified: z.boolean(),
    }),
    reviews: z.array(z.object({
      id: z.string(),
      rating: z.number(),
      body: z.string().nullable(),
      imageUrls: z.array(z.string()),
      createdAt: z.string(),
    })),
    reviewStats: z.object({ count: z.number(), average: z.number() }),
  });

export const productDetailResponseSchema = z.object({ product: productDetailSchema });
