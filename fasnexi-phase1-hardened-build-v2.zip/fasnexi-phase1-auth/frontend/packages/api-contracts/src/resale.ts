import { z } from 'zod';
import { currencySchema } from './common';
import { garmentCategorySchema } from './products';

export const resaleConditionSchema = z.enum(['NEW_WITH_TAGS', 'LIKE_NEW', 'GOOD', 'FAIR', 'POOR']);
export type ResaleCondition = z.infer<typeof resaleConditionSchema>;

export const resaleStatusSchema = z.enum(['DRAFT', 'LISTED', 'RESERVED', 'SOLD', 'WITHDRAWN']);

/**
 * Confirmed from browseResaleListings — includes a subset of the linked
 * WardrobeItem and seller User, not the full ResaleItem row.
 *
 * CONFIRMED DEAD PARAMETER: browseResaleListings's options accept a
 * `category` field but never use it in the Prisma `where` clause —
 * passing it does nothing server-side. No category filter is offered in
 * the browse UI as a result; building one would be a control that looks
 * functional but silently no-ops.
 */
export const resaleListingSchema = z.object({
  id: z.string(),
  askingPrice: z.number(), // minor units, same convention as Product.priceAmount
  currency: currencySchema,
  condition: resaleConditionSchema,
  status: resaleStatusSchema,
  description: z.string().nullable(),
  listedAt: z.string().nullable(),
  wardrobeItem: z.object({
    imageUrl: z.string(),
    category: garmentCategorySchema,
    brand: z.string().nullable(),
    aiColors: z.array(z.string()),
  }),
  seller: z.object({
    username: z.string(),
    displayName: z.string(),
    avatarUrl: z.string().nullable(),
  }),
});
export type ResaleListing = z.infer<typeof resaleListingSchema>;

export const resaleBrowseParamsSchema = z.object({
  condition: resaleConditionSchema.optional(),
  maxPrice: z.number().int().optional(),
  cursor: z.string().optional(),
  limit: z.number().int().positive().max(100).optional(),
});

export const resaleBrowseResponseSchema = z.object({
  listings: z.array(resaleListingSchema),
  nextCursor: z.string().nullable(),
});

export const createResaleListingRequestSchema = z.object({
  wardrobeItemId: z.string(),
  askingPrice: z.number().int().positive(),
  currency: currencySchema,
  condition: resaleConditionSchema,
  description: z.string().optional(),
});

/** POST response returns the full upserted ResaleItem row (not the browse subset) */
export const createResaleListingResponseSchema = z.object({
  listing: z.object({
    id: z.string(),
    wardrobeItemId: z.string(),
    askingPrice: z.number(),
    currency: currencySchema,
    condition: resaleConditionSchema,
    status: resaleStatusSchema,
    description: z.string().nullable(),
    platformFeeAmount: z.number(),
    sellerReceivesAmount: z.number(),
  }),
});

/**
 * POST /api/resale/:id/purchase — CONFIRMED to hardcode a raw Stripe
 * session directly (`new Stripe(...)`, bypassing the multi-gateway
 * createCheckoutSession entirely), regardless of the listing's own
 * currency. This is the exact item the plan itself flagged as an open
 * product decision (§0 item 7) — confirmed here at the implementation
 * level, not just from the plan's description. A NGN/KES/etc-priced
 * listing would attempt a Stripe session in a currency this codebase's
 * Stripe integration doesn't handle. The purchase UI gates on this (see
 * the resale listing detail screen) rather than let a buyer hit an
 * opaque failure.
 */
export const resalePurchaseResponseSchema = z.object({
  url: z.string(),
  sessionId: z.string(),
});

export const resaleWithdrawResponseSchema = z.object({ withdrawn: z.boolean() });
