import { z } from 'zod';
import { currencySchema } from './common';

export const promotedProductSchema = z.object({
  id: z.string(),
  productId: z.string(),
  budgetAmount: z.number(),
  dailyBudget: z.number(),
  billedAmount: z.number(),
  currency: currencySchema,
  cpmAmount: z.number().nullable(),
  impressions: z.number(),
  clicks: z.number(),
  startDate: z.string(),
  endDate: z.string(),
  isActive: z.boolean(),
  lastBilledAt: z.string().nullable(),
  product: z.object({
    id: z.string(),
    name: z.string(),
    imageUrls: z.array(z.string()),
    priceAmount: z.number(),
    priceCurrency: currencySchema,
  }),
});
export type PromotedProduct = z.infer<typeof promotedProductSchema>;

export const promotedProductsResponseSchema = z.object({
  promotions: z.array(promotedProductSchema),
});

export const promotionTrackingResponseSchema = z.object({
  billed: z.boolean().optional(),
  costBilled: z.number().optional(),
  recorded: z.boolean().optional(),
});
