import { z } from 'zod';
import { garmentCategorySchema } from './products';

/**
 * All fields/shapes below confirmed directly from
 * packages/api/src/wardrobe/service.ts + the three wardrobe route files +
 * schema.prisma's WardrobeItem model — none guessed from the plan's prose.
 */
export const occasionSchema = z.enum([
  'WORK', 'CASUAL', 'SOCIAL', 'RELIGIOUS', 'CULTURAL_EVENT', 'WEDDING',
]);
export const seasonSchema = z.enum([
  'ALL_YEAR', 'DRY', 'WET', 'HARMATTAN', 'SPRING', 'SUMMER', 'AUTUMN', 'WINTER',
]);

/**
 * `purchasePrice` is a Prisma `Decimal(10,2)` column, NOT an Int stored in
 * minor units like Product.priceAmount — schema.prisma's comment on the
 * `priceAmount` fields doesn't apply here. Prisma's default Decimal JSON
 * serialization (decimal.js's `toJSON()`) produces a STRING
 * (e.g. `"49.99"`), not a number, when returned raw from list/detail
 * endpoints. Modeled as a nullable string here — do NOT run this through
 * lib/money.ts's formatMoney (that divides by 100, which would be wrong
 * for an already-major-unit decimal string).
 *
 * The wardrobe analytics endpoint is the exception: its service function
 * explicitly calls `Number(...)` before returning `totalValue` and
 * `topCostPerWear[].purchasePrice`/`costPerWear`, so those specific
 * fields ARE numbers on the wire — see wardrobeAnalyticsResponseSchema.
 */
export const wardrobeItemSummarySchema = z.object({
  id: z.string(),
  imageUrl: z.string(),
  thumbnailUrl: z.string().nullable(),
  category: garmentCategorySchema,
  subcategory: z.string().nullable(),
  brand: z.string().nullable(),
  colorLabel: z.string().nullable(),
  size: z.string().nullable(),
  aiTagged: z.boolean(),
  aiColors: z.array(z.string()),
  aiPattern: z.string().nullable(),
  aiOccasions: z.array(occasionSchema),
  aiSeasons: z.array(seasonSchema),
  aiFormalityScore: z.number().nullable(),
  aiStyleCategories: z.array(z.string()),
  aiCulturalAffinity: z.array(z.string()),
  aiConfidence: z.number().nullable(),
  wearCount: z.number(),
  lastWornAt: z.string().nullable(),
  createdAt: z.string(),
});
export type WardrobeItemSummary = z.infer<typeof wardrobeItemSummarySchema>;

export const wardrobeListParamsSchema = z.object({
  category: garmentCategorySchema.optional(),
  cursor: z.string().optional(),
  limit: z.number().int().positive().max(100).optional(),
  tagged: z.boolean().optional(), // wire param is "tagged", not "taggedOnly"
});
export type WardrobeListParams = z.infer<typeof wardrobeListParamsSchema>;

export const wardrobeListResponseSchema = z.object({
  items: z.array(wardrobeItemSummarySchema),
  nextCursor: z.string().nullable(),
  total: z.number(),
});

/** GET /api/wardrobe/:id — full item + linked outfit history */
export const wardrobeItemDetailSchema = wardrobeItemSummarySchema.extend({
  purchasePrice: z.string().nullable(),
  purchaseCurrency: z.string().nullable(),
  purchaseDate: z.string().nullable(),
  notes: z.string().nullable(),
  aiSilhouette: z.string().nullable(),
  aiFabricType: z.string().nullable(),
  aiTaggedAt: z.string().nullable(),
  outfitItems: z.array(z.object({
    outfit: z.object({
      id: z.string(), name: z.string().nullable(), occasion: z.string().nullable(), imageUrl: z.string().nullable(),
    }),
  })),
});
export const wardrobeItemDetailResponseSchema = z.object({ item: wardrobeItemDetailSchema });

/** POST /api/wardrobe — confirmed request body from route.ts */
export const createWardrobeItemRequestSchema = z.object({
  imageUrl: z.string(),
  thumbnailUrl: z.string().optional(),
  category: garmentCategorySchema,
  subcategory: z.string().optional(),
  brand: z.string().optional(),
  colorLabel: z.string().optional(),
  size: z.string().optional(),
  purchasePrice: z.string().optional(), // sent as string, route does parseFloat()
  purchaseCurrency: z.string().optional(),
  purchaseDate: z.string().optional(), // ISO date string, route does new Date()
  notes: z.string().optional(),
});
export type CreateWardrobeItemRequest = z.infer<typeof createWardrobeItemRequestSchema>;

/** POST response is a trimmed subset, NOT the full summary/detail shape — confirmed from createWardrobeItem's `select` */
export const createWardrobeItemResponseSchema = z.object({
  item: z.object({
    id: z.string(),
    imageUrl: z.string(),
    category: garmentCategorySchema,
    subcategory: z.string().nullable(),
    brand: z.string().nullable(),
    colorLabel: z.string().nullable(),
    aiTagged: z.boolean(),
    createdAt: z.string(),
  }),
});

/**
 * PATCH /api/wardrobe/:id has TWO distinct modes sharing one route,
 * confirmed from wardrobe/[id]/route.ts — not one generic "update":
 *  - {action: "record_wear", wornOn?} -> {recorded: true}
 *  - the general field-update body -> {item: <updated fields only>}
 * Modeled as two separate schemas/functions rather than merged into one,
 * to match the real API shape instead of a cleaner-looking guess.
 */
export const recordWearRequestSchema = z.object({
  action: z.literal('record_wear'),
  wornOn: z.string().optional(),
});
export const recordWearResponseSchema = z.object({ recorded: z.boolean() });

export const updateWardrobeItemRequestSchema = z.object({
  category: garmentCategorySchema.optional(),
  subcategory: z.string().optional(),
  brand: z.string().optional(),
  colorLabel: z.string().optional(),
  size: z.string().optional(),
  notes: z.string().optional(),
  purchasePrice: z.string().optional(),
  purchaseDate: z.string().optional(),
});
export type UpdateWardrobeItemRequest = z.infer<typeof updateWardrobeItemRequestSchema>;

/**
 * updateWardrobeItem's Prisma `.update()` call has no `select`/`include`,
 * so it returns every scalar column on WardrobeItem (confirmed by reading
 * the full function body) — the same fields as the detail schema, minus
 * the `outfitItems` relation (which requires an explicit `include` Prisma
 * doesn't add here).
 */
export const updateWardrobeItemResponseSchema = z.object({
  item: wardrobeItemDetailSchema.omit({ outfitItems: true }),
});

/**
 * Wardrobe analytics — GET /api/wardrobe?view=analytics. Confirmed from
 * getWardrobeAnalytics: these are plain numbers (post-`Number()`
 * conversion), unlike the raw item list's `purchasePrice` string.
 */
export const wardrobeAnalyticsResponseSchema = z.object({
  totalItems: z.number(),
  totalValue: z.number(),
  categoryBreakdown: z.record(z.number()),
  styleDistribution: z.record(z.number()),
  topCostPerWear: z.array(z.object({
    id: z.string(),
    category: garmentCategorySchema,
    purchasePrice: z.number(),
    wearCount: z.number(),
    costPerWear: z.number(),
  })),
  utilisationRate: z.number().nullable(),
});
