import { z } from 'zod';
import { currencySchema } from './common';

export const createPromotionRequestSchema = z.object({
  productId: z.string(),
  budgetAmount: z.number().int().positive(),
  dailyBudget: z.number().int().positive(),
  cpmAmount: z.number().int().positive(),
  currency: currencySchema,
  startDate: z.string(),
  endDate: z.string(),
});
export type CreatePromotionRequest = z.infer<typeof createPromotionRequestSchema>;

export const promotionSchema = z.object({
  id: z.string(),
  productId: z.string(),
  vendorId: z.string(),
  budgetAmount: z.number(),
  dailyBudget: z.number(),
  billedAmount: z.number(),
  currency: currencySchema,
  cpmAmount: z.number().nullable(),
  impressions: z.number(),
  clicks: z.number(),
  startDate: z.string(),
  endDate: z.string(),
  isActive: z.boolean(),
  lastBilledAt: z.string().nullable(),
  product: z.object({ name: z.string(), imageUrls: z.array(z.string()) }),
});
export type Promotion = z.infer<typeof promotionSchema>;

export const promotionsListResponseSchema = z.object({ promotions: z.array(promotionSchema) });
export const createPromotionResponseSchema = z.object({ promotion: promotionSchema });
