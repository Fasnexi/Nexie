import { z } from 'zod';

/**
 * Confirmed from packages/api/src/loyalty/service.ts + schema.prisma.
 * Tier thresholds (lifetime points, monotonic — redemption never reduces
 * lifetimePoints or demotes tier, confirmed from awardPoints's own
 * comment: "spending doesn't demote you"): Bronze 0, Silver 500, Gold
 * 2000, Platinum 5000.
 */
export const loyaltyTierSchema = z.enum(['BRONZE', 'SILVER', 'GOLD', 'PLATINUM']);
export type LoyaltyTier = z.infer<typeof loyaltyTierSchema>;

export const loyaltyAccountResponseSchema = z.object({
  tier: loyaltyTierSchema,
  points: z.number(),
  lifetimePoints: z.number(),
  // null at the top tier (Platinum) — there's no higher threshold to
  // compute a "next tier" against. The UI must handle this, not assume
  // nextTier always exists.
  nextTier: z.object({
    tier: loyaltyTierSchema,
    pointsNeeded: z.number(),
  }).nullable(),
});
export type LoyaltyAccount = z.infer<typeof loyaltyAccountResponseSchema>;

export const loyaltyTransactionSchema = z.object({
  id: z.string(),
  delta: z.number(), // positive = earn, negative = redeem
  reason: z.string(),
  ref: z.string().nullable(),
  createdAt: z.string(),
});
export type LoyaltyTransaction = z.infer<typeof loyaltyTransactionSchema>;

export const loyaltyHistoryResponseSchema = z.object({
  transactions: z.array(loyaltyTransactionSchema),
  nextCursor: z.string().nullable(),
});

/**
 * POST /api/loyalty — confirmed this route DOES translate its business
 * error ("Insufficient points: have X, requested redemption of Y")
 * into a real 400 {error} response (unlike vote/wardrobe-archive/
 * wardrobe-tag, which leave the same class of error uncaught). Safe to
 * surface this specific message to the user rather than showing a
 * generic fallback.
 */
export const redeemPointsRequestSchema = z.object({
  points: z.number().positive(),
  reason: z.string().optional(),
});

export const redeemPointsResponseSchema = z.object({
  awarded: z.boolean(),
  points: z.number(),
  lifetimePoints: z.number(),
  tier: loyaltyTierSchema,
  tierChanged: z.boolean(),
});
