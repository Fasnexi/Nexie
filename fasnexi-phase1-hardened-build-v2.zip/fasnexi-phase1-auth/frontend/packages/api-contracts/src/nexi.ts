import { z } from 'zod';

/**
 * All shapes below confirmed from packages/api/src/nexi/engine.ts (the
 * NexiChatRequest/Response/OutfitResponse interfaces + runNexiChat/
 * streamNexiChat/generateOutfits bodies) and all three nexi route files —
 * not from the plan's prose summary, which got the request field name
 * and the SSE frame format wrong (see lib/useNexiStream.ts).
 */
export const nexiModeSchema = z.enum(['chat', 'outfit', 'gap-analysis', 'style-this']);

/** POST /api/nexi/chat request — field is `query`, not `message` */
export const nexiChatRequestSchema = z.object({
  query: z.string().min(1).max(2000),
  sessionId: z.string().optional(),
  occasion: z.string().optional(),
  season: z.string().optional(),
  stream: z.boolean().optional(),
});
export type NexiChatRequest = z.infer<typeof nexiChatRequestSchema>;

/** Non-streaming (`stream: false`) JSON response */
export const nexiChatResponseSchema = z.object({
  sessionId: z.string(),
  content: z.string(),
  turnCount: z.number(),
  tokenCount: z.number(),
  remaining: z.number(),
});

/**
 * SSE frame shapes for the streaming path. CONFIRMED format, corrected
 * from an earlier wrong assumption: each frame is a single `data: <json>`
 * line, where the JSON payload itself carries a `type` field
 * distinguishing session/delta/done/error — there is NO separate SSE
 * `event:` line. (`X-Nexi-Session` and `X-Nexi-Remaining` also arrive as
 * real HTTP headers on the initial response, before any stream body.)
 */
export const nexiSseSessionFrameSchema = z.object({ type: z.literal('session'), sessionId: z.string() });
export const nexiSseDeltaFrameSchema = z.object({ type: z.literal('delta'), text: z.string() });
export const nexiSseDoneFrameSchema = z.object({ type: z.literal('done'), sessionId: z.string(), tokenCount: z.number() });
export const nexiSseErrorFrameSchema = z.object({ type: z.literal('error'), message: z.string() });
export const nexiSseFrameSchema = z.discriminatedUnion('type', [
  nexiSseSessionFrameSchema, nexiSseDeltaFrameSchema, nexiSseDoneFrameSchema, nexiSseErrorFrameSchema,
]);
export type NexiSseFrame = z.infer<typeof nexiSseFrameSchema>;

/**
 * Outfit generation — same response shape for both /api/nexi/outfit and
 * /api/nexi/style-this (both call the same generateOutfits()). Confirmed
 * gap: generateOutfits consumes a rate-limited query (calls
 * checkAndIncrementRateLimit) but its response has NO `remaining` field
 * at all — unlike chat, there's no way to know the updated daily count
 * from this call. The UI should treat any remaining-count display as
 * possibly stale after generating outfits, not attempt to update it from
 * this response.
 */
export const outfitOwnedItemSchema = z.object({
  wardrobeItemId: z.string().nullable(),
  description: z.string(),
  role: z.string(),
});
export const outfitGapItemSchema = z.object({
  category: z.string(),
  description: z.string(),
  reason: z.string(),
});
export const outfitSuggestionSchema = z.object({
  name: z.string(),
  ownedItems: z.array(outfitOwnedItemSchema),
  gapItems: z.array(outfitGapItemSchema),
  styleNote: z.string(),
});
export type OutfitSuggestion = z.infer<typeof outfitSuggestionSchema>;

export const nexiOutfitResponseSchema = z.object({
  sessionId: z.string(),
  outfits: z.array(outfitSuggestionSchema),
  tokenCount: z.number(),
});

export const nexiOutfitRequestSchema = z.object({
  mood: z.string().optional(),
  occasion: z.string().optional(),
  season: z.string().optional(),
  count: z.number().int().min(1).max(3).optional(),
  sessionId: z.string().optional(),
}).refine((v) => v.mood || v.occasion, { message: 'Provide at least one of: mood, occasion' });

export const nexiStyleThisRequestSchema = z.object({
  wardrobeItemId: z.string(),
  occasion: z.string().optional(),
  season: z.string().optional(),
  count: z.number().int().min(1).max(3).optional(),
  sessionId: z.string().optional(),
});

/**
 * style-this's "item still tagging" case is a genuinely sneaky contract
 * detail: it returns HTTP 202 (Accepted) with an `{error: string}` body
 * — NOT a 4xx, so `fetch`'s `res.ok` is TRUE for it, meaning it would
 * silently skip apiRequest's normal error-handling path and instead try
 * (and fail) to validate `{error}` against the outfit-response success
 * schema. Modeled as a discriminated result the endpoint function
 * returns, rather than letting it crash into a confusing Zod error.
 */
export const nexiStyleThisPendingSchema = z.object({ error: z.string() });
