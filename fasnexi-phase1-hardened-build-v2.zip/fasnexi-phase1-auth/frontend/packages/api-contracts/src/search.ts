import { z } from 'zod';
import { currencySchema } from './common';
import { garmentCategorySchema } from './products';

const product = z.object({ id: z.string(), name: z.string(), slug: z.string(), imageUrls: z.array(z.string()), priceAmount: z.number(), priceCurrency: currencySchema, category: garmentCategorySchema, isInStock: z.boolean(), vendor: z.object({ id: z.string(), businessName: z.string() }) });
const vendor = z.object({ id: z.string(), businessName: z.string(), logoUrl: z.string().nullable(), country: z.string(), isVerified: z.boolean() });
const creator = z.object({ id: z.string(), bannerUrl: z.string().nullable(), followerCount: z.number(), user: z.object({ id: z.string(), username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable() }) });
const user = z.object({ id: z.string(), username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable() });
const event = z.object({ id: z.string(), title: z.string(), description: z.string().nullable(), coverUrl: z.string().nullable(), venue: z.string().nullable(), city: z.string().nullable(), country: z.string().nullable(), startDate: z.coerce.date(), endDate: z.coerce.date(), isLive: z.boolean(), organizer: z.object({ orgName: z.string() }) });

export const searchResponseSchema = z.object({ query: z.string(), products: z.array(product), vendors: z.array(vendor), creators: z.array(creator), users: z.array(user), events: z.array(event), categories: z.array(garmentCategorySchema) });
export type SearchResponse = z.infer<typeof searchResponseSchema>;
export type SearchType = 'all' | 'products' | 'vendors' | 'creators' | 'users' | 'events';
