import { z } from 'zod';

/**
 * Confirmed from apps/web/app/api/feed/route.ts + packages/api/src/feed/ranking.ts.
 *
 * Real response is `{posts, count}` — NOT the `{items, nextCursor}` shape
 * the plan claimed was "confirmed consistent across every list endpoint
 * reviewed... no normalization needed." There's no explicit nextCursor:
 * pagination is keyset on the last post's id, so the client derives the
 * next cursor itself (see feed.ts endpoint) and treats
 * `posts.length < limit` as end-of-list.
 *
 * CORRECTED during a full-app audit: this schema was missing
 * `styleCategories` and `viewCount`, both present in the real select —
 * zod silently drops unknown response fields rather than erroring, so
 * this wasn't a crash, just data the backend provides that the UI
 * couldn't see. Also confirmed while re-checking: there is NO
 * `likedByMe`/`savedByMe` field anywhere in this select — the feed
 * cannot tell a post card whether the viewer already liked/saved it, so
 * every post renders as unliked/unsaved on load regardless of the
 * viewer's real prior state, only reflecting changes made in-session.
 */
export const feedPostSchema = z.object({
  id: z.string(),
  userId: z.string(),
  type: z.string(),
  caption: z.string().nullable(),
  mediaUrls: z.array(z.string()),
  culturalTags: z.array(z.string()),
  styleCategories: z.array(z.string()),
  likeCount: z.number(),
  commentCount: z.number(),
  saveCount: z.number(),
  viewCount: z.number(),
  rankScore: z.number(),
  publishedAt: z.string().nullable(),
  user: z.object({
    id: z.string(), username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable(),
  }),
  taggedProducts: z.array(z.object({
    productId: z.string(),
    product: z.object({
      id: z.string(), name: z.string(), priceAmount: z.number(),
      priceCurrency: z.string(), imageUrls: z.array(z.string()),
    }),
  })),
});
export type FeedPost = z.infer<typeof feedPostSchema>;

export const feedResponseSchema = z.object({
  posts: z.array(feedPostSchema),
  count: z.number(),
});

export const feedEngagementEventSchema = z.enum(['like', 'comment', 'share', 'save', 'view']);

/** Confirmed from apps/web/app/api/stories/route.ts + stories/service.ts */
export const storyFeedItemSchema = z.object({
  userId: z.string(),
  user: z.object({ id: z.string(), username: z.string(), avatarUrl: z.string().nullable() }),
  stories: z.array(z.object({
    id: z.string(),
    mediaUrl: z.string(),
    mediaType: z.string(),
    durationSeconds: z.number(),
    expiresAt: z.string(),
    viewed: z.boolean(),
  })),
  hasUnviewed: z.boolean(),
});
export type StoryFeedItem = z.infer<typeof storyFeedItemSchema>;

export const storiesResponseSchema = z.object({
  stories: z.array(storyFeedItemSchema),
});
