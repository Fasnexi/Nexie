import { z } from 'zod';

/**
 * Field names and enum values below are transcribed directly from
 * packages/db/prisma/schema.prisma's StyleProfile model — not guessed.
 *
 * IMPORTANT — confirmed gap, not in the plan's §0 list:
 * `db.styleProfile` is read-only everywhere in the backend (feed/ranking.ts,
 * gaps/analyser.ts, nexi/context.ts all call findUnique — grep for
 * `db.styleProfile` turns up zero .create/.update/.upsert calls, and zero
 * of the 57 routes touch this model). There is no working endpoint to
 * submit onboarding answers to yet. See onboarding/submit.ts for how this
 * is stubbed until the backend adds one.
 */
export const styleArchetypeSchema = z.enum([
  'MODERN_MINIMALIST',
  'AFROCENTRIC_MAXIMALIST',
  'STREET_STYLE_FUSION',
  'TRADITIONAL_CONTEMPORARY',
  'AVANT_GARDE',
  'EVERYDAY_ELEGANCE',
]);

export const bodyShapeSchema = z.enum([
  'HOURGLASS', 'PEAR', 'APPLE', 'RECTANGLE', 'INVERTED_TRIANGLE',
]);

export const fitPreferenceSchema = z.enum([
  'FITTED', 'RELAXED', 'OVERSIZED', 'TAILORED', 'FLOWY',
]);

export const coveragePreferenceSchema = z.enum([
  'MINIMAL', 'MODERATE', 'FULL', 'FLEXIBLE',
]);

export const occasionSchema = z.enum([
  'WORK', 'CASUAL', 'SOCIAL', 'RELIGIOUS', 'CULTURAL_EVENT', 'WEDDING',
]);

export const climateZoneSchema = z.enum([
  'TROPICAL', 'SEMI_ARID', 'ARID', 'HUMID', 'TEMPERATE',
]);

export const activityLevelSchema = z.enum(['LOW', 'MODERATE', 'HIGH']);

export const seasonSchema = z.enum([
  'ALL_YEAR', 'DRY', 'WET', 'HARMATTAN', 'SPRING', 'SUMMER', 'AUTUMN', 'WINTER',
]);

/** Step 2 — Archetype */
export const archetypeStepSchema = z.object({
  primaryArchetype: styleArchetypeSchema,
  secondaryArchetype: styleArchetypeSchema.optional(),
});

/** Step 3 — Body & Fit */
export const bodyProfileStepSchema = z.object({
  bodyShape: bodyShapeSchema.optional(),
  fitPreferences: z.array(fitPreferenceSchema).default([]),
  sizeTopUS: z.string().optional(),
  sizeBottomUS: z.string().optional(),
  sizeShoeUS: z.string().optional(),
  coveragePreferences: z.array(coveragePreferenceSchema).default([]),
});

/** Step 4 — Lifestyle */
export const lifestyleStepSchema = z.object({
  primaryOccasions: z.array(occasionSchema).default([]),
  climateZone: climateZoneSchema.optional(),
  activityLevel: activityLevelSchema.optional(),
  preferredColors: z.array(z.string()).default([]),
  avoidedColors: z.array(z.string()).default([]),
  seasonalPreference: seasonSchema.optional(),
});

/** Step 5 — Wardrobe Snapshot is optional; it hands off to the real
 * wardrobe upload flow (§1.5a) rather than collecting its own data. */
export const wardrobeSnapshotStepSchema = z.object({
  skipped: z.boolean().default(false),
  uploadedItemIds: z.array(z.string()).default([]),
});

export const styleDnaAnswersSchema = z.object({
  archetype: archetypeStepSchema.optional(),
  bodyProfile: bodyProfileStepSchema.optional(),
  lifestyle: lifestyleStepSchema.optional(),
  wardrobeSnapshot: wardrobeSnapshotStepSchema.optional(),
});
export type StyleDnaAnswers = z.infer<typeof styleDnaAnswersSchema>;
