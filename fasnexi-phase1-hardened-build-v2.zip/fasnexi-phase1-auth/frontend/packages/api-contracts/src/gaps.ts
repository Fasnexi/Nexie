import { z } from 'zod';
import { garmentCategorySchema } from './products';
import { occasionSchema } from './wardrobe';

/**
 * Confirmed from packages/api/src/gaps/analyser.ts's GapItem interface:
 * there is NO `id` field, on either GET or POST's response — the DB row
 * has one, but `getExistingGaps`'s `.map()` explicitly drops it before
 * returning. React list keys need a composite of category+occasion
 * instead (see the gaps screen) — reaching for `gap.id` would silently
 * be `undefined` for every item.
 */
export const gapItemSchema = z.object({
  category: garmentCategorySchema,
  occasion: occasionSchema,
  priority: z.number(),
  reason: z.string(),
  currentCount: z.number(),
  minimumNeeded: z.number(),
});
export type GapItem = z.infer<typeof gapItemSchema>;

export const gapsGetResponseSchema = z.object({
  gaps: z.array(gapItemSchema),
  count: z.number(),
});

/**
 * POST /api/gaps is rate-gated to once per 24h — but NOT by rejecting the
 * request. Confirmed from analyseWardrobeGaps: within the window, it
 * silently returns the *previous* unresolved gaps again, with
 * `wellCoveredOccasions: []` (not recomputed) and `analysedAt` set to the
 * OLD analysis's timestamp, not now. There is no error, status code, or
 * flag distinguishing "fresh analysis" from "rate-limited, here's the old
 * one" — the UI has to compare the returned `analysedAt` against what it
 * already had to tell the difference (see gaps screen).
 *
 * Also confirmed and worth being explicit about: since Step 2 found no
 * write path exists for StyleProfile anywhere in the backend, and this
 * function returns empty gaps whenever `styleProfile.primaryOccasions` is
 * empty, gap analysis will show nothing for any real user until that
 * earlier gap is fixed — not a bug in this screen, a downstream
 * consequence of one already documented.
 */
export const gapsAnalyzeResponseSchema = z.object({
  gaps: z.array(gapItemSchema),
  wellCoveredOccasions: z.array(z.string()),
  analysedAt: z.string(),
  count: z.number(),
});
