import { z } from 'zod';

/**
 * CORRECTED — this was wrong in the original version of this file.
 * The original search (`grep -rln "NotificationType\."`) was too narrow —
 * it only matched dot-accessed enum references, not the plain string
 * literals (`type: "SYSTEM"`) this codebase actually uses. Redone with
 * `grep -rn "enqueueNotification("` and found 17 real call sites across
 * social/graph.ts, social/engagement.ts, checkout/stripe.ts,
 * resale/service.ts, tailor/service.ts, challenges/service.ts,
 * vendors/dashboard.ts, and payouts/service.ts.
 *
 * One caveat still genuinely holds, though: `enqueueNotification` only
 * enqueues a BullMQ job (`NotificationJobData: {recipientId, type,
 * data}`) — the actual `Notification` DB row is created by a separate
 * worker (`apps/worker/src/notifications.ts`, per a comment elsewhere in
 * this codebase), which is NOT present anywhere in this zip. So these
 * are confirmed *intended* payloads at the enqueue call site, not
 * independently verified *persisted* shapes — the worker could in
 * principle transform `data` before storing it, though there's no
 * evidence it does and the simplest implementation just persists it
 * as-is.
 *
 * Sampled 9 of the 17 call sites directly. Findings:
 *  - Every SYSTEM notification includes a `message: string` — 5/5
 *    sampled (tailor quote, resale sold, two challenge-milestone sites,
 *    a duplicate in concurrency/challenges-hardened.ts).
 *  - ORDER_UPDATE is INCONSISTENT even within itself: checkout/stripe.ts
 *    sends `{status, paymentRef}` (no message), vendors/dashboard.ts
 *    sends `{orderId, status, trackingNumber}` (no message), but
 *    resale/service.ts sends `{message, resaleItemId}` (has one). There
 *    is no single fixed shape for this type — don't assume one.
 *  - FOLLOW/LIKE/COMMENT are structured-only, never a `message`:
 *    `{followerId}` / `{postId, likerId}` / `{postId, commentId,
 *    commenterId}`.
 *  - PAYOUT_PROCESSED: `{batchId, amount, currency}`, no message.
 *
 * Given this, `data` is modeled as `z.unknown()` still (no single shape
 * is safe to assert), but the inbox screen now checks for `data.message`
 * first (covers every confirmed SYSTEM case and some ORDER_UPDATE cases)
 * and falls back to the generic per-type label otherwise — genuinely
 * better than pure-generic, grounded in real call-site evidence, while
 * still not pretending to know a shape that demonstrably varies.
 */
export const notificationTypeSchema = z.enum([
  'LIKE', 'COMMENT', 'FOLLOW', 'ORDER_UPDATE', 'NEXI_SUGGESTION',
  'CHALLENGE_ENDING', 'DROP_ALERT', 'PAYOUT_PROCESSED', 'COMMISSION_EARNED',
  'PRICE_ALERT', 'SYSTEM',
]);
export type NotificationType = z.infer<typeof notificationTypeSchema>;

/** Best-effort extraction of the optional `message` field confirmed common to several (not all) notification types — see the contract notes above. */
export function extractNotificationMessage(data: unknown): string | null {
  if (data && typeof data === 'object' && 'message' in data && typeof (data as { message: unknown }).message === 'string') {
    return (data as { message: string }).message;
  }
  return null;
}

export const notificationSchema = z.object({
  id: z.string(),
  type: notificationTypeSchema,
  read: z.boolean(),
  data: z.unknown(),
  createdAt: z.string(),
});
export type NotificationItem = z.infer<typeof notificationSchema>;

export const notificationsListResponseSchema = z.object({
  notifications: z.array(notificationSchema),
  nextCursor: z.string().nullable(),
  unreadCount: z.number(),
});

export const markReadResponseSchema = z.object({ updated: z.boolean() });
export const markAllReadResponseSchema = z.object({ updatedCount: z.number() });
