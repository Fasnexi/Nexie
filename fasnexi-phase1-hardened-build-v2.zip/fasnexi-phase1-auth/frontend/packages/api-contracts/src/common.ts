import { z } from 'zod';

/**
 * Backend error shape — CORRECTED after auditing more routes in Step 4.
 * When a route's error path is actually reached through `withErrorHandling`,
 * it is the flat `{error: string}` shape with no `code`/`fields` — that
 * part of the plan's claim held up.
 *
 * But `withErrorHandling` only catches `UnauthenticatedError` and
 * `ForbiddenError` (confirmed by reading guards.ts). A route that throws
 * a plain `Error` for a business-logic failure — e.g. challenges/vote's
 * "wrong phase" / "voting closed" checks — is NOT caught, and becomes an
 * unhandled 500 with no guaranteed JSON body at all, let alone this
 * shape. So "all error responses are the flat {error} shape" is true for
 * routes that reach their own explicit `Response.json({error}, ...)` —
 * it is not true universally, and apiRequest's parsing (client.ts)
 * degrades to a generic message when the body isn't parseable JSON,
 * rather than assuming this shape always holds.
 */
export const rawErrorSchema = z.object({
  error: z.string(),
  code: z.string().optional(),
  fields: z.record(z.string()).optional(),
});

export const apiErrorSchema = z.object({
  error: z.string(),
  code: z.string().optional(),
  fields: z.record(z.string()).optional(),
  /** HTTP status, attached client-side, not part of the wire payload */
  status: z.number(),
});
export type ApiError = z.infer<typeof apiErrorSchema>;

/**
 * Cursor query params — `?cursor=&limit=` is a common wire pattern across
 * several endpoints (products, feed, challenges), but NOT their response
 * shape: products returns `{products, nextCursor, total}`, feed returns
 * `{posts, count}` with no nextCursor field at all, and creators has no
 * pagination whatsoever (bare array). There is no single response
 * contract to share, so unlike an earlier version of this file, there is
 * no generic `cursorPageSchema` helper here — it was dead code nothing
 * actually used, built on a "confirmed consistent" claim from the plan
 * that further reading falsified. Each endpoint's contract module
 * defines its own list-response shape instead.
 */
export const cursorPageParamsSchema = z.object({
  cursor: z.string().optional(),
  limit: z.number().int().positive().max(100).optional(),
});
export type CursorPageParams = z.infer<typeof cursorPageParamsSchema>;

/**
 * Currency enum — 10 values confirmed in schema.prisma.
 * Gateway routing, confirmed by reading the FULL createCheckoutSession +
 * createAfricanGatewaySession functions in checkout/stripe.ts (Step 1
 * only partially read this and wrongly flagged doubt on it — corrected
 * in Step 4's audit):
 *   - `africaCurrencies = [NGN, KES, GHS, ZAR, XOF, XAF]` routes to
 *     createAfricanGatewaySession, which then splits: Paystack for
 *     NGN/GHS/ZAR, Flutterwave for KES/XOF/XAF — exactly as the plan
 *     stated.
 *   - Everything NOT in that list — including EGP — falls through to the
 *     Stripe branch. So EGP does have a code path (Stripe), contrary to
 *     the previous version of this file which marked it `null`. Whether
 *     Stripe's actual merchant account supports EGP is an account-config
 *     question this codebase can't answer — flagged, not resolved.
 *
 * IMPORTANT gap found in Step 4, not caught by the plan: nothing in
 * createCheckoutSession validates that a product's own `priceCurrency`
 * matches the checkout `currency` the buyer selects — it charges
 * `p.priceAmount` at face value in whatever currency was requested. A
 * $50 USD product checked out in EUR would charge €50.00, not a
 * converted amount. The frontend cart (see cart-store.ts) works around
 * this by only allowing single-currency checkout per cart, rather than
 * exercising a mismatch the backend doesn't guard against.
 */
export const currencySchema = z.enum([
  'USD', 'NGN', 'KES', 'GHS', 'ZAR', 'GBP', 'EUR', 'XOF', 'XAF', 'EGP',
]);
export type Currency = z.infer<typeof currencySchema>;

export const GATEWAY_BY_CURRENCY: Record<Currency, 'stripe' | 'paystack' | 'flutterwave'> = {
  USD: 'stripe', EUR: 'stripe', GBP: 'stripe', EGP: 'stripe',
  NGN: 'paystack', GHS: 'paystack', ZAR: 'paystack',
  KES: 'flutterwave', XOF: 'flutterwave', XAF: 'flutterwave',
};
