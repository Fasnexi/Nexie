import { z } from 'zod';
import { currencySchema } from './common';
import { garmentCategorySchema } from './products';

/**
 * GET /api/creators/:handle — confirmed this returns `null` (-> 404)
 * for any user without a CreatorProfile. There is no general "view any
 * user's profile" endpoint anywhere in the backend — this only works for
 * Creators. The profile screen built against this falls back to
 * whatever minimal info the caller already has (e.g. a post's author
 * fields from the feed) when this 404s, rather than fabricate a general
 * profile endpoint that doesn't exist.
 */
export const storefrontPostSchema = z.object({
  id: z.string(),
  type: z.string(),
  mediaUrls: z.array(z.string()),
  likeCount: z.number(),
  commentCount: z.number(),
  publishedAt: z.string().nullable(),
  taggedProducts: z.array(z.object({
    product: z.object({
      id: z.string(), name: z.string(), priceAmount: z.number(), priceCurrency: currencySchema, imageUrls: z.array(z.string()),
    }),
  })),
});

/**
 * NOT the same shape as products.ts's `productSummarySchema` — confirmed
 * by reading getStorefront's own `select`, which has no `vendor` or
 * `salesCount` fields at all (unlike the /api/products list endpoint).
 * Modeled separately rather than reusing productSummarySchema, which
 * would have asserted two fields this response never actually returns.
 */
export const storefrontFeaturedProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
  priceAmount: z.number(),
  priceCurrency: currencySchema,
  imageUrls: z.array(z.string()),
  category: garmentCategorySchema,
  isInStock: z.boolean(),
});

export const storefrontResponseSchema = z.object({
  storefront: z.object({
    id: z.string(),
    username: z.string(),
    displayName: z.string(),
    avatarUrl: z.string().nullable(),
    bio: z.string().nullable(),
    website: z.string().nullable(),
    isVerified: z.boolean(),
    creatorProfile: z.object({
      bio: z.string().nullable(),
      bannerUrl: z.string().nullable(),
      styleNiche: z.string().nullable(),
      culturalFocus: z.array(z.string()).nullable(),
      followerCount: z.number(),
      totalSales: z.number(),
      commissionRate: z.number(),
    }),
    posts: z.array(storefrontPostSchema),
    featuredProducts: z.array(storefrontFeaturedProductSchema),
  }),
});
