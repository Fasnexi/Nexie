import { z } from 'zod';

/**
 * Confirmed from apps/web/app/api/push-tokens/route.ts +
 * packages/api/src/notifications/push.ts's registerDeviceToken.
 *
 * `expoToken` MUST be a real Expo push token (starts with
 * "ExponentPushToken[" or "ExpoPushToken[") — this is validated
 * server-side and rejected with a 400 otherwise. It is NOT a raw
 * FCM/APNs token; the client must obtain it via
 * expo-notifications' getExpoPushTokenAsync(), not any native push SDK
 * directly.
 */
export const devicePlatformSchema = z.enum(['ios', 'android', 'web', 'unknown']);
export type DevicePlatform = z.infer<typeof devicePlatformSchema>;

export const registerPushTokenRequestSchema = z.object({
  expoToken: z.string().refine(
    (t: string) => t.startsWith('ExponentPushToken[') || t.startsWith('ExpoPushToken['),
    { message: 'expoToken does not look like a valid Expo push token' },
  ),
  platform: devicePlatformSchema.optional(),
  deviceName: z.string().optional(),
});
export type RegisterPushTokenRequest = z.infer<typeof registerPushTokenRequestSchema>;

/** 201 on success — {registered, id}. `id` is the DB row's id, needed later for DELETE (not the raw token). */
export const registerPushTokenResponseSchema = z.object({
  registered: z.boolean(),
  id: z.string(),
});
