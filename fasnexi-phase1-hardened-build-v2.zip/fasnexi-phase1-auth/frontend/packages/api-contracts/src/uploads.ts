import { z } from 'zod';

/**
 * Confirmed from packages/api/src/uploads/cloudinary.ts. The `folder`
 * value returned is ALREADY namespaced (e.g. "wardrobe/<userId>"), not
 * the raw folder name the client requested — the client must send this
 * exact returned value back to Cloudinary, not reconstruct its own.
 *
 * Critical constraint, not obvious from the shape alone: Cloudinary's
 * signature covers exactly `folder` + `timestamp` (see the function's own
 * comment on how paramsToSign is built). The client upload request must
 * send ONLY {file, api_key, timestamp, signature, folder} — adding any
 * other param (public_id, tags, etc.) without the backend also signing it
 * will make Cloudinary reject the signature. See cloudinary-upload.ts.
 */
export const uploadFolderSchema = z.enum(['wardrobe', 'posts', 'video', 'avatars']);
export type UploadFolder = z.infer<typeof uploadFolderSchema>;

export const uploadSignRequestSchema = z.object({ folder: uploadFolderSchema });

export const uploadSignResponseSchema = z.object({
  signature: z.string(),
  timestamp: z.number(),
  apiKey: z.string(),
  cloudName: z.string(),
  folder: z.string(), // pre-namespaced by the backend — see note above
});
export type UploadSignature = z.infer<typeof uploadSignResponseSchema>;
