import { z } from 'zod';
import { currencySchema } from './common';

/**
 * Confirmed from apps/web/app/api/checkout/route.ts +
 * packages/api/src/checkout/stripe.ts (both createCheckoutSession and
 * createAfricanGatewaySession — both branches return the same
 * `{url, sessionId}` shape, so one response schema covers both gateways).
 */
export const checkoutItemSchema = z.object({
  productId: z.string(),
  quantity: z.number().int().min(1),
  size: z.string().optional(),
  color: z.string().optional(),
});
export type CheckoutItem = z.infer<typeof checkoutItemSchema>;

export const checkoutRequestSchema = z.object({
  items: z.array(checkoutItemSchema).min(1),
  currency: currencySchema,
  creatorId: z.string().optional(),
  couponCode: z.string().optional(),
});
export type CheckoutRequest = z.infer<typeof checkoutRequestSchema>;

export const checkoutResponseSchema = z.object({
  url: z.string(),
  sessionId: z.string(),
});

/**
 * Order status FSM — confirmed 9 states from schema.prisma's OrderStatus
 * enum, matching the plan's corrected count (not the earlier "4 states"
 * draft it mentions superseding).
 */
export const orderStatusSchema = z.enum([
  'PENDING', 'PAYMENT_PROCESSING', 'PAID', 'FULFILLING',
  'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDED', 'DISPUTED',
]);
export type OrderStatus = z.infer<typeof orderStatusSchema>;
