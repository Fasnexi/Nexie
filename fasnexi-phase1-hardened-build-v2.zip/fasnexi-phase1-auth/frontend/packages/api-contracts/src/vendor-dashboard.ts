import { z } from 'zod';
import { currencySchema } from './common';
import { orderStatusSchema } from './checkout';

export const creatorEarningsResponseSchema = z.object({
  period: z.enum(['week', 'month', 'all']),
  currencies: z.record(z.object({ pending: z.number(), confirmed: z.number(), paid: z.number(), total: z.number() })),
  commissionCount: z.number(),
});
export type CreatorEarnings = z.infer<typeof creatorEarningsResponseSchema>;

export const vendorDashboardSummaryResponseSchema = z.object({
  products: z.object({ total: z.number(), inStock: z.number() }),
  revenue: z.object({ allTime: z.record(z.number()), last30Days: z.record(z.number()) }),
  recentOrders: z.array(z.object({
    id: z.string(), status: orderStatusSchema, totalAmount: z.number(), currency: currencySchema, createdAt: z.string(),
  })),
});
export type VendorDashboardSummary = z.infer<typeof vendorDashboardSummaryResponseSchema>;

export const vendorTopProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  imageUrls: z.array(z.string()),
  priceAmount: z.number(),
  priceCurrency: currencySchema,
  salesCount: z.number(),
  inventoryCount: z.number(),
  isInStock: z.boolean(),
});
export const vendorTopProductsResponseSchema = z.object({ products: z.array(vendorTopProductSchema) });

/**
 * Vendor order list — confirmed from getVendorOrders. Unlike the
 * dashboard summary's aggregates, these ARE per-order and each has its
 * own real `currency` — safe to format normally.
 */
export const vendorOrderItemSchema = z.object({
  id: z.string(),
  quantity: z.number(),
  unitAmount: z.number(),
  size: z.string().nullable(),
  color: z.string().nullable(),
  product: z.object({ id: z.string(), name: z.string(), imageUrls: z.array(z.string()) }),
});
export const vendorOrderSchema = z.object({
  id: z.string(),
  status: orderStatusSchema,
  totalAmount: z.number(),
  currency: currencySchema,
  createdAt: z.string(),
  shippingCity: z.string().nullable(),
  shippingCountry: z.string().nullable(),
  trackingNumber: z.string().nullable(),
  items: z.array(vendorOrderItemSchema),
});
export type VendorOrder = z.infer<typeof vendorOrderSchema>;

export const vendorOrdersResponseSchema = z.object({
  orders: z.array(vendorOrderSchema),
  nextCursor: z.string().nullable(),
});

/**
 * PATCH /api/vendors/orders/:id — confirmed valid transitions are ONLY
 * PAID->FULFILLING and FULFILLING->SHIPPED (updateOrderStatus's own
 * validTransitions map). Anything else throws a plain Error not caught
 * by the route (same uncaught-500 pattern found repeatedly elsewhere) —
 * the vendor orders screen only offers the one valid next action per
 * order's current status, rather than a free status picker that could
 * trigger this.
 */
export const updateVendorOrderStatusRequestSchema = z.object({
  status: z.enum(['FULFILLING', 'SHIPPED']),
  trackingNumber: z.string().optional(),
});
export const updateVendorOrderStatusResponseSchema = z.object({
  updated: z.boolean(),
  status: z.string(),
});

export const updateInventoryRequestSchema = z.object({ inventoryCount: z.number().int().nonnegative() });
export const updateInventoryResponseSchema = z.object({ updated: z.boolean(), inventoryCount: z.number() });
