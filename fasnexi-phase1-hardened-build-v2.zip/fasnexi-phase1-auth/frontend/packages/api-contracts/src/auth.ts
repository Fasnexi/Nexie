import { z } from 'zod';

/**
 * RBAC roles — confirmed exact set from packages/auth/src/permissions/matrix.ts
 *
 * All four request/response shapes below (and the /api/auth/roles/*
 * path itself — confirmed via the catch-all route's own comment plus no
 * `basePath` override in auth.ts, so Better Auth's default `/api/auth`
 * applies) are read directly from packages/auth/src/plugins/multi-role.ts,
 * not the plan's prose.
 *
 * One thing NOT confirmed, unlike everything else in this file: these
 * are Better Auth PLUGIN endpoints, not this project's own Next.js route
 * handlers — their errors are thrown as Better Auth's `APIError`, not
 * constructed as this backend's usual `Response.json({error}, {status})`.
 * No `better-auth` package source was available anywhere in this
 * environment to check how `APIError` actually serializes over HTTP, so
 * whether it matches the flat `{error: string}` shape the rest of this
 * backend uses is unverified — genuinely unknown, not assumed either way.
 * The client code that calls these four endpoints (see auth.ts's
 * endpoint functions and the Settings screen) deliberately doesn't
 * depend on extracting a specific message from a failed response here —
 * it shows a generic retry message instead, so this gap doesn't silently
 * produce a broken-looking error string if the shape turns out different.
 */
export const roleSchema = z.enum([
  'CONSUMER',
  'CREATOR',
  'VENDOR',
  'DESIGNER',
  'TAILOR',
  'EVENT_ORGANIZER',
  'SUSTAINABLE_PARTNER',
  'INVESTOR',
  'ADMIN',
  'MODERATOR',
]);
export type Role = z.infer<typeof roleSchema>;

/** Roles that require requireVerifiedRole() — profile.isVerified check */
export const verifiableRoleSchema = z.enum([
  'VENDOR', 'DESIGNER', 'TAILOR', 'EVENT_ORGANIZER', 'SUSTAINABLE_PARTNER',
]);

export const authUserSchema = z.object({
  id: z.string(),
  roles: z.array(roleSchema),
  activeRole: roleSchema,
  isBanned: z.boolean().optional(),
});
export type AuthUser = z.infer<typeof authUserSchema>;

// POST /api/auth/roles/activate
export const activateRoleRequestSchema = z.object({ role: roleSchema });
export const activateRoleResponseSchema = z.object({
  roles: z.array(roleSchema),
  alreadyActive: z.boolean(),
  requiresVerification: z.boolean().optional(),
});

// POST /api/auth/roles/deactivate
export const deactivateRoleRequestSchema = z.object({ role: roleSchema });
export const deactivateRoleResponseSchema = z.object({
  roles: z.array(roleSchema),
  activeRole: roleSchema,
});

// POST /api/auth/roles/switch
export const switchRoleRequestSchema = z.object({ role: roleSchema });
export const switchRoleResponseSchema = z.object({ activeRole: roleSchema });

// GET /api/auth/roles/mine
export const myRolesResponseSchema = z.object({
  roles: z.array(roleSchema),
  activeRole: roleSchema,
  verificationStatus: z.record(z.boolean()).optional(),
});
