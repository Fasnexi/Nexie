import { z } from 'zod';
import { currencySchema } from './common';
import { orderStatusSchema } from './checkout';

/**
 * Confirmed from schema.prisma: TailorProfile.specialties is typed
 * `TraditionalPreference[]`, NOT a dedicated "TailorSpecialty" enum
 * (no such enum exists) — the route's own `specialty as any` cast is a
 * clue the route author wasn't fully certain either. Reusing the
 * confirmed real enum rather than inventing a plausible-sounding one.
 */
export const traditionalPreferenceSchema = z.enum([
  'AGBADA', 'DASHIKI', 'KENTE', 'ANKARA', 'ADIRE', 'ASO_OKE',
  'KITENGE', 'KAFTAN', 'BOUBOU', 'SHWESHWE', 'OTHER',
]);

/**
 * Confirmed from GET /api/tailor. No cursor pagination on this endpoint
 * at all — flat `take: 30` cap, no nextCursor. There is also no
 * dedicated single-tailor detail endpoint anywhere (`tailor/[id]/*`'s
 * `:id` is a CustomOrder id, not a TailorProfile id, confirmed by the
 * quote route's own comment) — a "tailor profile" screen has to reuse
 * data already fetched from this browse list rather than fetch its own
 * detail, because there's nothing to fetch.
 */
export const tailorListItemSchema = z.object({
  id: z.string(),
  businessName: z.string().nullable(),
  country: z.string(),
  city: z.string(),
  specialties: z.array(traditionalPreferenceSchema),
  portfolioUrls: z.array(z.string()),
  ratingAvg: z.number(),
  ratingCount: z.number(),
  responseHours: z.number(),
  user: z.object({ username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable() }),
});
export type TailorListItem = z.infer<typeof tailorListItemSchema>;

export const tailorBrowseResponseSchema = z.object({
  tailors: z.array(tailorListItemSchema),
});

/** POST /api/tailor — tailorId is TailorProfile.id, confirmed from submitCustomOrderBrief's own comment */
export const submitBriefRequestSchema = z.object({
  tailorId: z.string(),
  brief: z.string().min(1),
  deadline: z.string().optional(),
  // attachments intentionally omitted — no upload folder exists for them
  // (uploads/sign's VALID_FOLDERS is a hard-capped set: wardrobe, posts,
  // video, avatars — confirmed by reading the route directly. Adding
  // "tailor" would need a backend change, not a client-side workaround).
});

/**
 * CustomOrder.status reuses the SAME 9-state OrderStatus FSM as
 * e-commerce orders (confirmed from schema.prisma — there is no separate
 * CustomOrderStatus enum on the model itself), not a tailoring-specific
 * status set.
 */
export const customOrderSchema = z.object({
  id: z.string(),
  tailorId: z.string(),
  clientId: z.string(),
  brief: z.string(),
  attachments: z.array(z.string()),
  quoteAmount: z.number().nullable(),
  currency: currencySchema,
  status: orderStatusSchema,
  depositPaid: z.boolean(),
  notes: z.string().nullable(),
  deadline: z.string().nullable(),
  completedAt: z.string().nullable(),
  createdAt: z.string(),
  tailor: z.object({ businessName: z.string().nullable(), city: z.string(), country: z.string() }),
});
export type CustomOrder = z.infer<typeof customOrderSchema>;

export const submitBriefResponseSchema = z.object({ order: customOrderSchema });

/** GET /api/tailor/orders — role-aware; this contract covers the client-side shape (activeRole !== TAILOR) only. Tailor's own queue shape is a step-11/Role-dashboards concern, not read here. */
export const clientOrdersResponseSchema = z.object({ orders: z.array(customOrderSchema) });

/**
 * POST /api/tailor/:id/deposit — CONFIRMED to hardcode a raw Stripe
 * session directly, same systemic pattern as resale purchase (and,
 * per this route's own comment, tickets purchase too) — bypasses
 * multi-gateway routing regardless of the order's own currency.
 */
export const depositResponseSchema = z.object({ url: z.string(), sessionId: z.string() });

export const customOrderMessageSchema = z.object({
  id: z.string(),
  senderId: z.string(),
  receiverId: z.string(),
  threadId: z.string(),
  body: z.string(),
  mediaUrl: z.string().nullable(),
  readAt: z.string().nullable(),
  createdAt: z.string(),
});
export type CustomOrderMessage = z.infer<typeof customOrderMessageSchema>;

export const messagesListResponseSchema = z.object({ messages: z.array(customOrderMessageSchema) });
export const sendMessageRequestSchema = z.object({ body: z.string().min(1), mediaUrl: z.string().optional() });
export const sendMessageResponseSchema = z.object({ message: customOrderMessageSchema });

/**
 * TAILOR-role queue (GET /api/tailor/orders when activeRole === TAILOR),
 * deferred from Step 9 since it's a Role-dashboards (step 11) concern
 * per the plan's own screen taxonomy. Confirmed from getTailorOrders:
 * a flat findMany with NO `include` at all — no `tailor` relation (the
 * viewing tailor already knows who they are) and, importantly, no
 * `client` info either. There's no username/display name to show for
 * who placed the order — just the raw `clientId`. This screen displays
 * what's actually there rather than fabricating a client-name lookup
 * that doesn't exist in this response.
 */
export const tailorQueueOrderSchema = customOrderSchema.omit({ tailor: true });
export type TailorQueueOrder = z.infer<typeof tailorQueueOrderSchema>;
export const tailorQueueResponseSchema = z.object({ orders: z.array(tailorQueueOrderSchema) });

/**
 * Quote route — confirmed from tailor/[id]/quote/route.ts +
 * provideQuote(). Only valid when the order's current status is PENDING
 * (provideQuote throws a plain Error otherwise, uncaught by the route —
 * same recurring pattern). This route IS well-behaved though: "do not
 * own"/"not found"/"Cannot quote" are all properly caught as real
 * 403/400 {error} responses. Response wraps the updated order as
 * `{order}`.
 */
export const provideQuoteRequestSchema = z.object({
  quoteAmount: z.number().int().positive(),
  currency: currencySchema,
  notes: z.string().optional(),
});
export const provideQuoteResponseSchema = z.object({ order: tailorQueueOrderSchema });

/**
 * Status route — confirmed from tailor/[id]/status/route.ts +
 * updateCustomOrderStatus(). TAILOR-only action (requireVerifiedRole).
 * This route is well-behaved — "not found"/"Cannot transition"/"do not
 * own" are all properly caught and returned as real 400/403 {error}
 * responses, unlike several other routes in this codebase. Valid next
 * statuses confirmed from the route's own VALID_NEXT set (includes
 * CANCELLED, easy to miss). Response wraps the updated order as
 * `{order}`, not a bare `{updated: boolean}`.
 */
export const updateCustomOrderStatusRequestSchema = z.object({
  status: z.enum(['FULFILLING', 'SHIPPED', 'DELIVERED', 'CANCELLED']),
});
export const updateCustomOrderStatusResponseSchema = z.object({ order: tailorQueueOrderSchema });
