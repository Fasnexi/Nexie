import { z } from 'zod';

/**
 * Confirmed from packages/api/src/creators/storefront.ts's getTopCreators.
 * Response is a BARE ARRAY (route does `Response.json(await getTopCreators(...))`
 * directly) — not wrapped in `{creators: [...]}` like most other list
 * endpoints. The service does `{...p.user, ...p}`, which both flattens
 * the user fields to the top level AND keeps a nested `user` object
 * (the spread of `p` includes its own `user` key) — messy, but that's
 * what the code returns, not something to "clean up" client-side in a
 * way that silently diverges from the real shape.
 */
const creatorUserSchema = z.object({
  id: z.string(), username: z.string(), displayName: z.string(),
  avatarUrl: z.string().nullable(), isVerified: z.boolean(),
});

export const creatorListItemSchema = creatorUserSchema.extend({
  followerCount: z.number(),
  styleNiche: z.string().nullable(),
  culturalFocus: z.array(z.string()).nullable(),
  user: creatorUserSchema,
});
export type CreatorListItem = z.infer<typeof creatorListItemSchema>;

export const creatorsListResponseSchema = z.array(creatorListItemSchema);

/**
 * Confirmed from apps/web/app/api/challenges/route.ts +
 * packages/api/src/challenges/service.ts's listChallenges/getChallenge.
 * `status` is a free-form string on the wire (cast `as any` server-side)
 * — kept as z.string() rather than guessing at a closed enum.
 */
export const challengeListItemSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  theme: z.string().nullable(),
  coverUrl: z.string().nullable(),
  status: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  votingEnds: z.string().nullable(),
  prizePool: z.number().nullable(),
  currency: z.string().nullable(),
  _count: z.object({ entries: z.number() }),
});
export type ChallengeListItem = z.infer<typeof challengeListItemSchema>;

export const challengesListResponseSchema = z.object({
  challenges: z.array(challengeListItemSchema),
  nextCursor: z.string().nullable(),
});

const challengeEntrySchema = z.object({
  id: z.string(),
  voteCount: z.number(),
  rank: z.number().nullable(),
  createdAt: z.string(),
  user: z.object({ id: z.string(), username: z.string(), displayName: z.string(), avatarUrl: z.string().nullable() }),
  post: z.object({ id: z.string(), mediaUrls: z.array(z.string()), caption: z.string().nullable(), likeCount: z.number() }),
});

export const challengeDetailSchema = challengeListItemSchema.extend({
  entries: z.array(challengeEntrySchema),
});
export const challengeDetailResponseSchema = z.object({ challenge: challengeDetailSchema });

export const voteRequestSchema = z.object({ entryId: z.string() });
export const voteResponseSchema = z.object({ voteCount: z.number() });

/**
 * Found missing in a full-app audit: challenge voting was built (Step 3)
 * but entering a challenge (the OTHER half of "Vote/entry flow" in the
 * plan's own screens table) never was — `challenges/[id]/entries` was
 * never referenced anywhere. Confirmed from submitChallengeEntry: needs
 * at least one media URL (reuses the same Cloudinary upload flow, folder
 * "posts"), and every business-logic failure ("not currently accepting
 * entries", "already submitted", "reached maximum") is a plain thrown
 * Error not caught by the route — same recurring uncaught-500 pattern
 * found throughout this backend.
 */
export const submitEntryRequestSchema = z.object({
  caption: z.string().optional(),
  mediaUrls: z.array(z.string()).min(1),
  culturalTags: z.array(z.string()).optional(),
});
export const submitEntryResponseSchema = z.object({
  entry: z.object({
    id: z.string(),
    challengeId: z.string(),
    userId: z.string(),
    postId: z.string(),
    voteCount: z.number(),
    rank: z.number().nullable(),
    createdAt: z.string(),
    post: z.object({ id: z.string() }),
  }),
});
