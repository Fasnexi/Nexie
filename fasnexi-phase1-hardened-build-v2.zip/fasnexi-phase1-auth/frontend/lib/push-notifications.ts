import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { pushTokensApi } from '../packages/api-client/src/endpoints/push-tokens';
import { ApiClientError } from '../packages/api-client/src/client';
import type { DevicePlatform } from '../packages/api-contracts/src/push-tokens';

/**
 * `Notifications.getExpoPushTokenAsync()` requires an EAS `projectId` as
 * of the SDK versions this scaffold targets — normally read from
 * `app.json`'s `extra.eas.projectId`, set when a project is actually
 * linked to an EAS account. NO such id is configured anywhere in this
 * scaffold's `app.json` (there is no real EAS project behind this build)
 * — rather than assume one or fabricate a placeholder value that would
 * silently fail in a confusing way, this is treated as a real
 * precondition that isn't met yet, and the function returns a typed
 * failure instead of throwing something cryptic deep inside the Expo SDK.
 *
 * Two API surfaces below are NOT independently confirmed against the
 * actual installed package source — no network in this sandbox to `npm
 * install` and check, same limitation flagged in Step 5's upload screen:
 *  - `Constants.expoConfig?.extra?.eas?.projectId` is the standard
 *    documented Expo path for this value, but "standard as documented"
 *    isn't the same confidence level as the backend contracts in this
 *    project, which were all read from real source.
 *  - `Constants.deviceName` may have moved to `expo-device`'s
 *    `Device.deviceName` in some SDK versions — used here as a
 *    best-effort, optional field (the backend accepts it as `undefined`
 *    fine), so a wrong/missing value degrades gracefully rather than
 *    breaking registration if this assumption is off.
 * Confirm both against the actual installed versions once `npm install`
 * runs for real.
 */
export type PushRegistrationResult =
  | { status: 'registered'; deviceTokenId: string }
  | { status: 'not-configured'; reason: string }
  | { status: 'permission-denied' }
  | { status: 'unsupported-platform' }
  | { status: 'error'; message: string };

export async function registerForPushNotifications(): Promise<PushRegistrationResult> {
  // Expo push tokens on the web target need VAPID web-push credentials
  // configured, which aren't set up anywhere in this scaffold either —
  // same "don't fake it" treatment as the wardrobe web-upload gap.
  if (Platform.OS === 'web') {
    return { status: 'unsupported-platform' };
  }

  const projectId = Constants.expoConfig?.extra?.eas?.projectId as string | undefined;
  if (!projectId) {
    return {
      status: 'not-configured',
      reason: 'No EAS projectId configured in app.json (extra.eas.projectId) — link this app to a real EAS project before push tokens can be requested.',
    };
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== 'granted') {
    return { status: 'permission-denied' };
  }

  try {
    const tokenResponse = await Notifications.getExpoPushTokenAsync({ projectId });
    const platform: DevicePlatform = Platform.OS === 'ios' ? 'ios' : Platform.OS === 'android' ? 'android' : 'unknown';

    const result = await pushTokensApi.register({
      expoToken: tokenResponse.data,
      platform,
      deviceName: Constants.deviceName ?? undefined,
    });
    return { status: 'registered', deviceTokenId: result.id };
  } catch (err) {
    const message = err instanceof ApiClientError ? err.apiError.error : (err as Error).message;
    return { status: 'error', message };
  }
}

export async function unregisterPushNotifications(deviceTokenId: string): Promise<boolean> {
  try {
    await pushTokensApi.unregister(deviceTokenId);
    return true;
  } catch {
    return false;
  }
}
