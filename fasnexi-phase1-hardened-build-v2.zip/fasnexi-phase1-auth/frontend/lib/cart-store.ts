import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import type { ProductSummary } from '../packages/api-contracts/src/products';

const STORAGE_KEY = '@fasnexi/cart/v1';

export interface CartLine {
  product: ProductSummary;
  quantity: number;
  size?: string;
  color?: string;
}

export interface CartState {
  lines: CartLine[];
  hydrated: boolean;
  addItem: (product: ProductSummary, opts?: { size?: string; color?: string }) => { ok: true } | { ok: false; reason: string };
  removeItem: (productId: string, size?: string, color?: string) => void;
  setQuantity: (productId: string, quantity: number, size?: string, color?: string) => void;
  clear: () => void;
  hydrate: () => Promise<void>;
  persist: () => Promise<void>;
}

function lineKey(productId: string, size?: string, color?: string) {
  return `${productId}::${size ?? ''}::${color ?? ''}`;
}

async function persistLines(lines: CartLine[]) {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
  } catch {
    // Cart remains usable in-memory if storage is temporarily unavailable.
  }
}

export const useCartStore = create<CartState>((set, get) => ({
  lines: [],
  hydrated: false,

  addItem: (product, opts) => {
    const { lines } = get();
    const existingCurrency = lines[0]?.product.priceCurrency;
    if (existingCurrency && existingCurrency !== product.priceCurrency) {
      return {
        ok: false,
        reason: `Your cart is checking out in ${existingCurrency}. Finish or clear that order before adding a ${product.priceCurrency} item.`,
      };
    }

    const key = lineKey(product.id, opts?.size, opts?.color);
    const existingIndex = lines.findIndex((l) => lineKey(l.product.id, l.size, l.color) === key);
    const updated = [...lines];
    if (existingIndex >= 0) {
      updated[existingIndex] = { ...updated[existingIndex], quantity: updated[existingIndex].quantity + 1 };
    } else {
      updated.push({ product, quantity: 1, size: opts?.size, color: opts?.color });
    }
    set({ lines: updated });
    void persistLines(updated);
    return { ok: true };
  },

  removeItem: (productId, size, color) => {
    const key = lineKey(productId, size, color);
    const updated = get().lines.filter((l) => lineKey(l.product.id, l.size, l.color) !== key);
    set({ lines: updated });
    void persistLines(updated);
  },

  setQuantity: (productId, quantity, size, color) => {
    const key = lineKey(productId, size, color);
    const updated = get().lines
      .map((l) => lineKey(l.product.id, l.size, l.color) === key ? { ...l, quantity: Math.max(1, quantity) } : l);
    set({ lines: updated });
    void persistLines(updated);
  },

  clear: () => {
    set({ lines: [] });
    void AsyncStorage.removeItem(STORAGE_KEY).catch(() => undefined);
  },

  hydrate: async () => {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) set({ lines: parsed as CartLine[] });
    } catch {
      // Ignore corrupt/unavailable persisted carts; never block app startup.
    } finally {
      set({ hydrated: true });
    }
  },

  persist: async () => persistLines(get().lines),
}));

export function cartSubtotal(lines: CartLine[]): number {
  return lines.reduce((sum, l) => sum + l.product.priceAmount * l.quantity, 0);
}
