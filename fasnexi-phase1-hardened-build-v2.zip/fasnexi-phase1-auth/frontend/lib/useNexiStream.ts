import { useCallback, useRef, useState } from 'react';
import { nexiSseFrameSchema } from '../packages/api-contracts/src/nexi';
import { getApiBaseUrl, getConfiguredAuthHeaders } from '../packages/api-client/src/client';

/**
 * REWRITTEN from Step 1's version, which was built from the plan's prose
 * summary and got two load-bearing details wrong, confirmed against the
 * real apps/web/app/api/nexi/chat/route.ts + packages/api/src/nexi/engine.ts:
 *
 *  1. The request field is `query`, not `message` — Step 1 sent `message`,
 *     which the real route would have rejected with a 400 ("query is
 *     required") on every single call.
 *  2. There is no SSE `event:` line at all. Every frame is a single
 *     `data: <json>` line, and the JSON payload itself carries a `type`
 *     field (session/delta/done/error). Step 1's parser looked for a
 *     separate `event:` line that never exists, so its delta-handling
 *     branch could never have fired — the chat UI would have shown
 *     nothing, ever, despite looking like it was streaming.
 *
 * Also now captures `X-Nexi-Session`/`X-Nexi-Remaining` from the initial
 * response headers (sent before the stream body, confirmed from the
 * route), and distinguishes a 429 rate-limit response (real JSON
 * `{error}` body, no stream at all) from a mid-stream `error` frame.
 */
export interface NexiStreamState {
  text: string;
  isStreaming: boolean;
  remaining: number | null;
  sessionId: string | null;
  error: string | null;
  rateLimited: boolean;
}

export function useNexiStream() {
  const [state, setState] = useState<NexiStreamState>({
    text: '', isStreaming: false, remaining: null, sessionId: null, error: null, rateLimited: false,
  });
  const abortRef = useRef<AbortController | null>(null);

  const send = useCallback(async (query: string, sessionId?: string, occasion?: string, season?: string) => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setState((s) => ({ ...s, text: '', isStreaming: true, error: null, rateLimited: false }));

    try {
      const authHeaders = await getConfiguredAuthHeaders();
      const res = await fetch(`${getApiBaseUrl()}/api/nexi/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        credentials: 'include',
        body: JSON.stringify({ query, sessionId, occasion, season, stream: true }),
        signal: controller.signal,
      });

      // 429 (daily limit reached) arrives as a real JSON error body, not
      // a stream — confirmed from the route's catch block. No delta
      // frames will follow; handle it before trying to read a body.
      if (res.status === 429) {
        const body = await res.json().catch(() => ({ error: 'Daily Nexi query limit reached.' }));
        setState((s) => ({ ...s, isStreaming: false, rateLimited: true, error: body.error ?? 'Daily Nexi query limit reached.' }));
        return;
      }

      if (!res.ok) {
        const body = await res.json().catch(() => ({ error: 'Something went wrong.' }));
        setState((s) => ({ ...s, isStreaming: false, error: body.error ?? 'Something went wrong.' }));
        return;
      }

      const remainingHeader = res.headers.get('X-Nexi-Remaining');
      const remaining = remainingHeader === null ? null : Number(remainingHeader);
      const sessionHeader = res.headers.get('X-Nexi-Session');

      if (!res.body) throw new Error('Streaming not supported in this environment');
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const frames = buffer.split('\n\n');
        buffer = frames.pop() ?? '';

        for (const frame of frames) {
          const dataLine = frame.split('\n').find((l) => l.startsWith('data:'));
          if (!dataLine) continue;
          const raw = dataLine.slice(5).trim();
          if (!raw) continue;

          let parsedJson: unknown;
          try {
            parsedJson = JSON.parse(raw);
          } catch {
            continue; // malformed frame — skip rather than crash the stream
          }
          const parsed = nexiSseFrameSchema.safeParse(parsedJson);
          if (!parsed.success) continue;
          const evt = parsed.data;

          if (evt.type === 'session') {
            setState((s) => ({ ...s, sessionId: evt.sessionId, remaining }));
          } else if (evt.type === 'delta') {
            setState((s) => ({ ...s, text: s.text + evt.text }));
          } else if (evt.type === 'error') {
            setState((s) => ({ ...s, isStreaming: false, error: evt.message }));
          } else if (evt.type === 'done') {
            setState((s) => ({ ...s, isStreaming: false, sessionId: evt.sessionId, remaining }));
          }
        }
      }

      // Fallback in case a 'done' frame never arrived (e.g. connection cut) —
      // still record whatever headers/session we had.
      setState((s) => ({
        ...s,
        isStreaming: false,
        remaining: s.remaining ?? remaining,
        sessionId: s.sessionId ?? sessionHeader,
      }));
    } catch (err) {
      if ((err as Error).name === 'AbortError') return;
      setState((s) => ({ ...s, isStreaming: false, error: (err as Error).message }));
    }
  }, []);

  const cancel = useCallback(() => abortRef.current?.abort(), []);

  return { ...state, send, cancel };
}
