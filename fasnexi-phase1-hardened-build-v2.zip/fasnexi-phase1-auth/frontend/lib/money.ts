/**
 * All `priceAmount` fields across the backend (Product, TicketTier,
 * PricePoint, etc.) are stored in the smallest currency unit — confirmed
 * from schema.prisma's comment ("stored in smallest unit, e.g. kobo /
 * cents") and cross-checked against checkout/stripe.ts, which divides by
 * 100 uniformly for every currency it handles (including XOF/XAF, which
 * real-world ISO 4217 treats as zero-decimal — the backend doesn't apply
 * that distinction, so neither does this formatter, to stay consistent
 * with what checkout actually does rather than a "more correct" standard
 * the backend itself doesn't follow).
 *
 * Found during a Step 4 audit: `priceAmount` was being displayed raw in
 * the Discover product grid (Step 3) — e.g. a $50.00 item stored as 5000
 * would have shown "USD 5000". Fixed at the source with this helper.
 */
export function formatMoney(minorUnitAmount: number, currency: string): string {
  const major = minorUnitAmount / 100;
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(major);
  } catch {
    // Intl.NumberFormat throws on a currency code it doesn't recognize —
    // fall back to a plain "CODE 12.34" rendering rather than crashing.
    return `${currency} ${major.toFixed(2)}`;
  }
}
