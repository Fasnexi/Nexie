/**
 * Plain TS types mirroring packages/api-contracts/src/style-dna.ts's Zod
 * step schemas, kept separate so the zustand store doesn't need to import
 * zod inference types directly.
 */
export interface ArchetypeStep {
  primaryArchetype: string;
  secondaryArchetype?: string;
}

export interface BodyProfileStep {
  bodyShape?: string;
  fitPreferences: string[];
  sizeTopUS?: string;
  sizeBottomUS?: string;
  sizeShoeUS?: string;
  coveragePreferences: string[];
}

export interface LifestyleStep {
  primaryOccasions: string[];
  climateZone?: string;
  activityLevel?: string;
  preferredColors: string[];
  avoidedColors: string[];
  seasonalPreference?: string;
}

export interface WardrobeSnapshotStep {
  skipped: boolean;
  uploadedItemIds: string[];
}
