import type { ReactNode } from 'react';
import { View, Text, Pressable } from 'react-native';
import { colors } from '../../packages/ui/src/tokens/colors';
import { fontFamily, fontSize } from '../../packages/ui/src/tokens/typography';
import { ONBOARDING_STEPS } from '../onboarding-store';

/**
 * Visible progress indicator + back button, shared across all 6 steps.
 * "Welcome" and "Preview" are bookends and don't count toward the
 * step-progress bar (4 substantive steps: Archetype → Wardrobe Snapshot).
 */
export function OnboardingLayout({
  stepIndex,
  title,
  subtitle,
  onBack,
  children,
}: {
  stepIndex: number;
  title: string;
  subtitle?: string;
  onBack?: () => void;
  children: ReactNode;
}) {
  const substantiveSteps = ONBOARDING_STEPS.slice(1, -1); // exclude welcome/preview
  const progressIndex = stepIndex - 1; // 0-based within substantiveSteps

  return (
    <View style={{ flex: 1, backgroundColor: colors.black, padding: 20 }}>
      {progressIndex >= 0 && progressIndex < substantiveSteps.length && (
        <View style={{ flexDirection: 'row', gap: 6, marginBottom: 24 }}>
          {substantiveSteps.map((step, i) => (
            <View
              key={step}
              style={{
                flex: 1,
                height: 3,
                borderRadius: 2,
                backgroundColor: i <= progressIndex ? colors.gold : colors.goldMuted,
                opacity: i <= progressIndex ? 1 : 0.4,
              }}
            />
          ))}
        </View>
      )}

      {onBack && (
        <Pressable onPress={onBack} style={{ marginBottom: 12 }}>
          <Text style={{ color: colors.goldMuted }}>← Back</Text>
        </Pressable>
      )}

      <Text style={{ color: colors.cream, fontFamily: fontFamily.heading, fontSize: fontSize['2xl'] }}>
        {title}
      </Text>
      {subtitle && (
        <Text style={{ color: colors.goldMuted, marginTop: 6, marginBottom: 20 }}>{subtitle}</Text>
      )}

      <View style={{ flex: 1, marginTop: subtitle ? 0 : 20 }}>{children}</View>
    </View>
  );
}

export function PrimaryButton({ label, onPress, disabled }: { label: string; onPress: () => void; disabled?: boolean }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={{
        backgroundColor: colors.gold,
        paddingVertical: 14,
        borderRadius: 8,
        alignItems: 'center',
        opacity: disabled ? 0.5 : 1,
      }}
    >
      <Text style={{ color: colors.black, fontWeight: '700' }}>{label}</Text>
    </Pressable>
  );
}

export function SecondaryButton({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ paddingVertical: 14, alignItems: 'center' }}>
      <Text style={{ color: colors.goldMuted }}>{label}</Text>
    </Pressable>
  );
}
