import { createAuthClient } from 'better-auth/react';
import { expoClient } from '@better-auth/expo/client';
import * as SecureStore from 'expo-secure-store';

const baseURL = process.env.EXPO_PUBLIC_API_BASE_URL ?? 'http://localhost:3000';

export const authClient = createAuthClient({
  baseURL,
  plugins: [
    expoClient({
      scheme: 'fasnexi',
      storagePrefix: 'fasnexi',
      storage: SecureStore,
    }),
  ],
});

export type FasNexiSession = typeof authClient.$Infer.Session;
