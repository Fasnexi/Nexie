import { Platform } from 'react-native';
import { configureApiClient } from '../packages/api-client/src/client';
import { authClient } from './auth-client';

/**
 * Keeps the API client and Better Auth session on the same authentication
 * mechanism. Web uses normal secure cookies; native forwards the Better Auth
 * cookie stored by the Expo plugin in SecureStore.
 */
export function wireApiClient(baseUrl: string) {
  configureApiClient({
    baseUrl,
    authHeaderProvider: async () => {
      if (Platform.OS === 'web') return {};
      const cookie = await authClient.getCookie();
      return cookie ? { Cookie: cookie } : {};
    },
  });
}
