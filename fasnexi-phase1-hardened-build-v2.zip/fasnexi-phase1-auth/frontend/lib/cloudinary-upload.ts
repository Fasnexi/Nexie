import { uploadsApi } from '../packages/api-client/src/endpoints/uploads';
import type { UploadFolder } from '../packages/api-contracts/src/uploads';

/**
 * Implements the flow documented verbatim in the backend's own
 * uploads/sign route.ts header comment:
 *   POST /api/uploads/sign -> {signature, timestamp, apiKey, cloudName, folder}
 *   -> POST directly to https://api.cloudinary.com/v1_1/{cloudName}/auto/upload
 *      with those fields + the file -> Cloudinary returns secure_url
 *   -> POST that url to /api/wardrobe (or /api/video) as imageUrl/videoUrl
 *
 * CRITICAL constraint confirmed from uploads/cloudinary.ts: the signature
 * only covers `folder` + `timestamp`. The multipart body sent to
 * Cloudinary must be EXACTLY {file, api_key, timestamp, signature,
 * folder} — no extra fields (public_id, tags, context, etc.), or
 * Cloudinary will reject the signature as invalid. Do not "improve" this
 * by adding more form fields without also changing the backend to sign
 * them.
 */
export interface DirectUploadResult {
  secureUrl: string;
  thumbnailUrl: string;
  width: number;
  height: number;
  /** Only present for video resource-type uploads — Cloudinary measures
   * this server-side during upload, which is more reliable than trying
   * to read local file metadata client-side. Undefined for images. */
  durationSeconds?: number;
}

interface CloudinaryUploadApiResponse {
  secure_url: string;
  width: number;
  height: number;
  duration?: number;
  [key: string]: unknown;
}

export async function uploadToCloudinary(
  folder: UploadFolder,
  file: { uri: string; name: string; type: string },
): Promise<DirectUploadResult> {
  const sig = await uploadsApi.sign(folder);

  const form = new FormData();
  // React Native's FormData accepts this {uri, name, type} shape for a
  // file field; on web this same helper would need a real File/Blob
  // instead — see the web-upload note in the wardrobe upload screen.
  form.append('file', file as unknown as Blob);
  form.append('api_key', sig.apiKey);
  form.append('timestamp', String(sig.timestamp));
  form.append('signature', sig.signature);
  form.append('folder', sig.folder);

  const res = await fetch(`https://api.cloudinary.com/v1_1/${sig.cloudName}/auto/upload`, {
    method: 'POST',
    body: form,
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Cloudinary upload failed (${res.status}): ${body.slice(0, 200)}`);
  }

  const result = (await res.json()) as CloudinaryUploadApiResponse;
  const isVideo = folder === 'video' || result.duration !== undefined;

  return {
    secureUrl: result.secure_url,
    thumbnailUrl: deriveThumbnailUrl(result.secure_url, isVideo),
    width: result.width,
    height: result.height,
    durationSeconds: result.duration,
  };
}

/**
 * Cloudinary's standard on-the-fly transformation syntax — inserting a
 * transformation string after `/upload/` in any delivery URL — is a
 * documented Cloudinary product feature that works without server-side
 * eager-transformation config. This is a client-side URL rewrite, not
 * something confirmed against this backend's Cloudinary account settings
 * (no such config was found anywhere in the codebase — see the "no
 * thumbnail convention exists" note in wardrobe.ts's contract notes).
 *
 * For video, this needs an extra step beyond the image case: inserting a
 * transformation into a `/video/upload/....mp4` URL as-is would return a
 * TRANSFORMED VIDEO CLIP, not a static thumbnail image — Cloudinary only
 * produces a still frame when the delivery URL's extension is swapped to
 * an image format (`.jpg`) while keeping the `/video/upload/` resource
 * path. Caught this before it shipped: the original version of this
 * function (written for Step 5's wardrobe photos) would have produced a
 * broken "thumbnail" for every video post in Step 10 if reused as-is.
 */
function deriveThumbnailUrl(secureUrl: string, isVideo: boolean): string {
  const withTransform = secureUrl.replace('/upload/', '/upload/w_300,h_300,c_fill,q_auto/');
  if (!isVideo) return withTransform;
  return withTransform.replace(/\.[a-zA-Z0-9]+$/, '.jpg');
}
