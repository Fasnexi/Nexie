import { create } from 'zustand';
import type {
  ArchetypeStep, BodyProfileStep, LifestyleStep, WardrobeSnapshotStep,
} from './onboarding-types';

/**
 * Style DNA flow: Welcome → Archetype → Body Profile → Lifestyle →
 * Wardrobe Snapshot → Preview (plan §2).
 *
 * UX requirements driven by the stated >70% completion goal: a visible
 * progress indicator, ability to exit and resume, and no step blocking on
 * an optional action (wardrobe snapshot allows "skip, add later").
 *
 * "Resume" here means in-memory only for this scaffold — wiring this to
 * persisted local storage (or the backend, once a write endpoint exists)
 * is a follow-up, not done in this step.
 */
export const ONBOARDING_STEPS = [
  'welcome', 'archetype', 'body-profile', 'lifestyle', 'wardrobe-snapshot', 'preview',
] as const;
export type OnboardingStep = (typeof ONBOARDING_STEPS)[number];

interface OnboardingState {
  currentStepIndex: number;
  archetype?: ArchetypeStep;
  bodyProfile?: BodyProfileStep;
  lifestyle?: LifestyleStep;
  wardrobeSnapshot?: WardrobeSnapshotStep;

  goToStep: (step: OnboardingStep) => void;
  next: () => void;
  back: () => void;
  setArchetype: (v: ArchetypeStep) => void;
  setBodyProfile: (v: BodyProfileStep) => void;
  setLifestyle: (v: LifestyleStep) => void;
  setWardrobeSnapshot: (v: WardrobeSnapshotStep) => void;
  reset: () => void;
}
export type { OnboardingState };

export const useOnboardingStore = create<OnboardingState>((set, get) => ({
  currentStepIndex: 0,

  goToStep: (step: OnboardingStep) => set({ currentStepIndex: ONBOARDING_STEPS.indexOf(step) }),
  next: () => set({ currentStepIndex: Math.min(get().currentStepIndex + 1, ONBOARDING_STEPS.length - 1) }),
  back: () => set({ currentStepIndex: Math.max(get().currentStepIndex - 1, 0) }),

  setArchetype: (v: ArchetypeStep) => set({ archetype: v }),
  setBodyProfile: (v: BodyProfileStep) => set({ bodyProfile: v }),
  setLifestyle: (v: LifestyleStep) => set({ lifestyle: v }),
  setWardrobeSnapshot: (v: WardrobeSnapshotStep) => set({ wardrobeSnapshot: v }),

  reset: () => set({
    currentStepIndex: 0, archetype: undefined, bodyProfile: undefined,
    lifestyle: undefined, wardrobeSnapshot: undefined,
  }),
}));

export function currentStepName(index: number): OnboardingStep {
  return ONBOARDING_STEPS[index];
}
