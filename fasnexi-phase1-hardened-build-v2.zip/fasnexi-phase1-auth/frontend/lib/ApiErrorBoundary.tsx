import type { ReactNode } from 'react';
import { View, Text, Pressable } from 'react-native';
import { ApiClientError } from '../packages/api-client/src/client';
import { colors } from '../packages/ui/src/tokens/colors';

/**
 * One boundary component per screen, per plan §5.3:
 *  - 401: session-expired flow (caller re-triggers Better Auth refresh
 *    before falling back to sign-in; this component just signals it)
 *  - 403/404/409: inline recoverable message
 *  - 429: treated as transient — caller should toast instead of using
 *    this full-block boundary, but it degrades gracefully here too
 *  - 5xx / network: full-screen recoverable state with retry
 */
export function ApiErrorView({
  error,
  onRetry,
  onSessionExpired,
}: {
  error: unknown;
  onRetry?: () => void;
  onSessionExpired?: () => void;
}) {
  const apiError = error instanceof ApiClientError ? error.apiError : null;
  const status = apiError?.status;

  if (status === 401) {
    onSessionExpired?.();
    return (
      <Centered>
        <Text style={{ color: colors.cream }}>Your session expired. Signing you back in…</Text>
      </Centered>
    );
  }

  const message = apiError?.error ?? 'Something went wrong. Please try again.';

  return (
    <Centered>
      <Text style={{ color: colors.cream, marginBottom: 12, textAlign: 'center' }}>{message}</Text>
      {onRetry && (
        <Pressable onPress={onRetry} style={{ borderWidth: 1, borderColor: colors.gold, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 6 }}>
          <Text style={{ color: colors.gold }}>Retry</Text>
        </Pressable>
      )}
    </Centered>
  );
}

function Centered({ children }: { children: ReactNode }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: colors.black }}>
      {children}
    </View>
  );
}
