# FasNexi Expo SDK 54 Baseline

## Required toolchain

- Expo: `54.0.0`
- React Native: `~0.81.5`
- React: `19.1.0`
- React DOM: `19.1.0`
- React Native Web: `0.21.0`
- Node: `20.19.4`

Node is pinned in both `.nvmrc` and `.node-version`, and `package.json` declares the same exact engine version.

## SDK-aligned Expo packages

The package manifest is aligned to Expo SDK 54 recommendations for the Expo modules already used by the app:

- `expo-router` `~6.0.24`
- `expo-secure-store` `~15.0.8`
- `expo-image` `~3.0.11`
- `expo-image-picker` `~17.0.11`
- `expo-av` `~16.0.8`
- `expo-notifications` `~0.32.17`
- `expo-constants` `~18.0.14`
- `react-native-safe-area-context` `~5.6.0`
- `react-native-svg` `15.12.1`
- `jest-expo` `~54.0.0`
- `@types/react` `~19.1.0`

`expo-av` remains temporarily because the existing video screen imports it. Expo SDK 54 marks it deprecated in favor of `expo-video` / `expo-audio`; migrating that screen is a separate compatibility pass.

## Install/validation gate

Run with Node 20.19.4:

```bash
npm install
npx expo install --fix
npx expo-doctor
npm run typecheck
npx expo start
```

The supplied archive did not contain installed dependencies, and the execution environment could not complete npm dependency resolution, so the manifest migration is applied but dependency-backed typecheck/build validation must be run in the real development environment.
