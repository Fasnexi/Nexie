# FasNexi Auth implementation

This build wires the Expo 54 frontend to the existing Better Auth backend.

## Implemented

- Email/password sign-in
- Account creation with required username
- Password reset request
- Password reset screen for deep-link tokens
- Email verification/resend screen
- Session restoration through `@better-auth/expo` + `expo-secure-store`
- Native API requests forward the Better Auth session cookie
- Auth entry routing sends authenticated users to onboarding or the app
- Backend Better Auth now includes the Expo server plugin

## Required environment

`EXPO_PUBLIC_API_BASE_URL` must point at the FasNexi backend origin, for example:

`https://api.example.com`

The Better Auth endpoint remains `/api/auth`.

## Production verification

1. Install dependencies with Node 20.19.4.
2. Run `npx expo install --fix`.
3. Run `npx expo-doctor`.
4. Run `npm run typecheck`.
5. Use a development build for native OAuth/deep-link testing.
6. Verify email delivery and password-reset delivery against the configured transactional email provider.
