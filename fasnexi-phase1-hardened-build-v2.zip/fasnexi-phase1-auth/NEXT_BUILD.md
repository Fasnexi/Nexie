# FasNexi Marketplace Core Build

Implemented after the Phase 1 commerce build:

- Consumer featured/promoted product endpoint.
- Authenticated promotion impression tracking with bounded batch counts.
- Promotion click tracking client integration.
- Shop search with debounced query state and server-side `q` filtering.
- Featured sponsored products surfaced above the catalog with explicit Sponsored disclosure.
- Catalog filtering now honors `vendorId` and `currency` on the PostgreSQL path.
- Existing Expo 54 / React Native 0.81 / React 19.1 / Node 20.19.4 baseline retained.

Validation note: dependency-backed Expo/TypeScript builds still require `npm install` in a real development environment because the supplied archive does not include node_modules.
